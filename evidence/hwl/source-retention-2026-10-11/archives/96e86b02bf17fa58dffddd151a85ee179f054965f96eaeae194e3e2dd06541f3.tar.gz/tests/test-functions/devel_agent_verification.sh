fast_assert_devel_agent_workdir() {
  local agent_var="$1"
  require_var "TEST_RUN_DIR"
  require_var "TEST_REPO_NAME"
  require_var "$agent_var"
  require_runtime

  local agent_name="${!agent_var}"

  local expected_dir="$TEST_RUN_DIR/.ploinky/repos/$TEST_REPO_NAME"
  expected_dir=$(resolve_realpath "$expected_dir")

  # The watchdog may still be (re)starting this container.  Wait for it to
  # reach a stable running state before attempting to exec into it.
  local cont_name
  cont_name=$(compute_container_name "$agent_name" "$TEST_REPO_NAME") || true
  if [[ -n "$cont_name" ]]; then
    wait_for_container "$cont_name"
  fi

  local raw_output
  if ! raw_output=$( {
    echo "pwd"
    echo "if [ -r . ] && [ -w . ]; then echo PERM_OK; else echo PERM_FAIL; fi"
    echo "exit"
  } | ploinky shell "$agent_name" ); then
    echo "Failed to execute 'pwd' in ${agent_name} shell." >&2
    return 1
  fi

  local actual_dir
  # Docker shell prefixes output with "# " (root prompt), bwrap does not
  actual_dir=$(echo "$raw_output" | tr -d '\r' | sed -n 's/^#\{0,1\} *\(\/.*\)/\1/p' | head -1)
  actual_dir=$(resolve_realpath "$actual_dir")
  if [[ "$actual_dir" != "$expected_dir" ]]; then
    echo "Devel agent working directory mismatch for ${agent_name}." >&2
    echo "Expected: '$expected_dir'" >&2
    echo "Got: '$actual_dir'" >&2
    echo "--- Full shell output ---" >&2
    echo "$raw_output" >&2
    echo "-------------------------" >&2
    return 1
  fi

  local perm_status
  # `\+` is a GNU sed extension; BSD sed (macOS default) treats it as a literal
  # `+` and the substitution silently produces nothing. Use POSIX `\{1,\}` so
  # the same expression works on Linux and macOS.
  perm_status=$(echo "$raw_output" | tr -d '\r' | sed -n 's/^#\{0,1\} *\(PERM_[A-Z0-9]\{1,\}\)$/\1/p' | tail -n 1)
  if [[ "$perm_status" != "PERM_OK" ]]; then
    echo "Devel agent workspace lacks read/write permissions for ${agent_name}." >&2
    echo "Expected PERM_OK marker but saw: '${perm_status}'" >&2
    echo "--- Full shell output ---" >&2
    echo "$raw_output" >&2
    echo "-------------------------" >&2
    return 1
  fi
}
