// vLLM (runners plan §5.5, Phase R5). Installed on demand from the image's
// runner lock (DS004); it runs from its runnable copy, reads a Hugging Face
// snapshot (weight format hf), listens on loopback with a per-start key, and
// is admitted only when its weights and KV cache fit the GPU unless the admin
// explicitly offloads weights to RAM (admitVllm).
//
// On unified memory (DS005) vLLM is experimental: it runs only when the
// deployment's operator turns it on (LOCAL_LLM_VLLM_UNIFIED=experimental,
// set with `ploinky var`); no catalog entry, parameter or runner choice can
// turn it on. It is then sized by admitUnifiedVllm, from a fresh snapshot,
// and watched by the unified memory guard like every runner there.

import fs from 'node:fs';
import path from 'node:path';

import { admissionResult, admitVllm } from '../controller/admission.mjs';
import { admitUnifiedVllm } from '../controller/profiles.mjs';
import { createVllmMpsQualificationResolver, resolveVllmMpsQualification, vllmRunnerLockDigest } from '../controller/vllmMpsQualification.mjs';
import {
    ParamError,
    assertAbsolutePath,
    assertApiKey,
    assertPort,
    codedError,
    deepFreeze,
    recommendedFor,
    validateParams
} from './params.mjs';

export const VLLM_UNIFIED_SWITCH = 'LOCAL_LLM_VLLM_UNIFIED';
const UNIFIED_SWITCH_VALUE = 'experimental';

const ID = 'vllm';
const PORT = 18082;
const PINNED_VERSION = '0.30.0';
const NVIDIA_LIB_DIR = '/usr/local/nvidia/lib64';
// vLLM's front end and engine talk over ZMQ ipc:// sockets and set up
// torch.distributed through a file: in nested rootless Podman the container's
// /tmp (fuse-overlayfs) makes new socket nodes unusable, while the agent's own
// /dev/shm is a private tmpfs (Ploinky gives every agent its own IPC namespace).
const RPC_DIR_NAME = 'local-llm-vllm';
const RPC_DIR = `/dev/shm/${RPC_DIR_NAME}`;
// gpt-oss's chat format (openai_harmony) needs OpenAI's o200k_base tokenizer
// vocabulary. The runner lock pins it into this directory of the runnable copy
// (`into`), and harmony reads it from here, checking its sha256, instead of
// downloading it from openaipublic when the first request arrives.
const TIKTOKEN_DIR_NAME = 'tiktoken';
const O200K_FILE = 'o200k_base.tiktoken';

const paramSchema = deepFreeze({
    type: 'object',
    additionalProperties: false,
    properties: {
        maxModelLen: {
            type: 'integer', minimum: 512, maximum: 131072, default: 4096,
            title: 'Max model length',
            description: 'Maximum context length per request, in tokens; the KV cache is sized for it.'
        },
        gpuMemoryUtilization: {
            type: ['number', 'null'], minimum: 0.1, maximum: 0.95, default: null,
            title: 'GPU memory utilization',
            description: 'Share of the GPU vLLM may use for weights and KV cache; empty takes what is free now (at most 0.9).'
        },
        cpuOffloadGb: {
            type: 'number', minimum: 0, maximum: 512, default: 0,
            title: 'CPU offload (GiB)',
            description: 'GiB of model weights kept in system RAM; lets a larger model run, much more slowly.'
        },
        dtype: {
            type: 'string', enum: ['auto', 'float16', 'bfloat16'], default: 'auto',
            title: 'Data type',
            description: 'Data type for model weights and activations.'
        },
        quantization: {
            type: ['string', 'null'], pattern: '^[a-z0-9_]{1,32}$', maxLength: 32, default: null,
            title: 'Quantization',
            description: 'Quantization method name (e.g. awq_marlin, gptq); empty lets vLLM detect it.'
        },
        kvCacheDtype: {
            type: 'string', enum: ['auto', 'fp8'], default: 'auto',
            title: 'KV cache type',
            description: 'Data type of the KV cache.'
        },
        enforceEager: {
            type: 'boolean', default: true,
            title: 'Enforce eager mode',
            description: 'Skip CUDA graph capture and compilation: a faster start, slightly slower generation.'
        },
        maxNumSeqs: {
            type: 'integer', minimum: 1, maximum: 256, default: 1,
            title: 'Max sequences',
            description: 'Maximum number of requests processed concurrently.'
        }
    }
});

// Unified memory has one pool, so there is nothing to offload weights to.
const { cpuOffloadGb: _offload, ...unifiedProperties } = paramSchema.properties;
const unifiedParamSchema = deepFreeze({
    ...paramSchema,
    properties: {
        ...unifiedProperties,
        gpuMemoryUtilization: {
            ...paramSchema.properties.gpuMemoryUtilization,
            description: 'Share of the shared memory pool vLLM may use for weights and KV cache; empty takes what is free now, '
                + 'keeping the host reserve and the floor (at most 0.9).',
        },
    },
});

const schemas = Object.freeze({ dedicated: paramSchema, unified: unifiedParamSchema });

function paramSchemaFor(profile = 'dedicated') {
    return schemas[profile] ?? null;
}

function normalizeParams(params = {}, { model, profile = 'dedicated' } = {}) {
    const schema = paramSchemaFor(profile);
    if (!schema) throw new ParamError('(runner)', `vLLM has no parameters for the ${profile} profile`);
    return validateParams(schema, params, { defaults: recommendedFor(model, ID, profile) });
}

// The operator's switch (DS004) for unified memory. On a dedicated GPU vLLM is
// not gated, and neither is it on the CPU profile: the switch is about unified
// memory, and vLLM has no CPU policy, so admission refuses it there. `null`
// means the profile is not decided and this image could run on unified memory
// (the controller passes `dedicated` for an image that never can): that fails
// closed, since the switch is what decides there. A caller that names no
// profile gets the same fail-closed answer.
function enabled(env = {}, profile = null) {
    if (profile === 'dedicated' || profile === 'cpu' || env[VLLM_UNIFIED_SWITCH] === UNIFIED_SWITCH_VALUE) return { enabled: true, reason: null };
    const turnOn = `The operator can turn it on with ploinky var ${VLLM_UNIFIED_SWITCH} ${UNIFIED_SWITCH_VALUE}; `
        + 'it has not been measured on this hardware.';
    return {
        enabled: false,
        reason: profile === 'unified'
            ? `vLLM is experimental on unified memory and is not enabled on this deployment. ${turnOn}`
            : 'vLLM is not enabled: the GPU could not be read, so it is not known whether it shares system memory, where vLLM '
                + `is experimental and needs the operator's switch. ${turnOn}`,
    };
}

function describeContext(params = {}, { model, profile = 'dedicated' } = {}) {
    const { maxModelLen, maxNumSeqs } = normalizeParams(params, { model, profile });
    // vLLM's paged KV pool is shared by all sequences; each may grow up to maxModelLen.
    return { totalContext: maxModelLen, perRequestContext: maxModelLen, parallel: maxNumSeqs, kvUnified: true };
}

// Installed on demand (DS004): detection asks the installer, which reads the
// cache and its install record; it never imports Python packages.
async function detect({ installer } = {}) {
    if (!installer?.installable(ID)) {
        return { installed: false, version: null, reason: 'This image\'s runner lock has no vLLM entry.' };
    }
    const info = await installer.describe(ID);
    if (!info.installed) return { installed: false, version: null, reason: 'Not installed. An admin can Install it under Runners.' };
    return { installed: true, version: info.version, reason: null };
}

function assertModelId(model) {
    if (typeof model?.id !== 'string' || model.id.length === 0) {
        throw codedError('invalid_launch', 'model.id must be a non-empty string', { field: 'model.id' });
    }
    return model.id;
}

function buildLaunch({ runnerDir, artifactPath, params, port, apiKey, model, gpuMemoryUtilization, cacheDir, rpcDir = RPC_DIR,
    profile = 'dedicated' } = {}) {
    const values = normalizeParams(params, { model, profile });
    const utilization = values.gpuMemoryUtilization ?? gpuMemoryUtilization;
    if (typeof utilization !== 'number' || !(utilization >= 0.1 && utilization <= 0.95)) {
        throw codedError('invalid_launch', 'gpuMemoryUtilization must come from the parameters or from admission', { field: 'gpuMemoryUtilization' });
    }
    const runRoot = assertAbsolutePath(runnerDir, 'runnerDir');
    const cache = assertAbsolutePath(cacheDir, 'cacheDir');
    const args = [
        '-m', 'vllm.entrypoints.openai.api_server',
        '--model', assertAbsolutePath(artifactPath, 'artifactPath'),
        '--served-model-name', assertModelId(model),
        '--host', '127.0.0.1',
        '--port', assertPort(port),
        '--max-model-len', values.maxModelLen,
        '--gpu-memory-utilization', utilization,
        '--max-num-seqs', values.maxNumSeqs,
        '--dtype', values.dtype,
    ];
    if (values.enforceEager) args.push('--enforce-eager');
    if (values.quantization) args.push('--quantization', values.quantization);
    if (values.kvCacheDtype !== 'auto') args.push('--kv-cache-dtype', values.kvCacheDtype);
    if (values.cpuOffloadGb > 0) args.push('--cpu-offload-gb', values.cpuOffloadGb);
    return {
        command: path.join(runRoot, 'venv', 'bin', 'python'),
        args: args.map(String),
        env: {
            // vLLM reads its key from the environment, so it is neither in the
            // process arguments nor in the "non-default args" line vLLM logs.
            VLLM_API_KEY: assertApiKey(apiKey),
            LD_LIBRARY_PATH: NVIDIA_LIB_DIR,
            // Triton compiles a small C launcher and links the granted driver
            // library by its versioned name, libcuda.so.1.
            TRITON_LIBCUDA_PATH: NVIDIA_LIB_DIR,
            TRITON_CACHE_DIR: path.join(cache, 'triton'),
            XDG_CACHE_HOME: path.join(cache, 'xdg'),
            VLLM_CACHE_ROOT: path.join(cache, 'vllm'),
            VLLM_RPC_BASE_PATH: assertAbsolutePath(rpcDir, 'rpcDir'),
            TMPDIR: rpcDir,
            // torch.distributed's Gloo and NCCL groups (created even for one
            // GPU) otherwise listen on the container's Box-network address,
            // where other agents could reach them; keep them on loopback.
            GLOO_SOCKET_IFNAME: 'lo',
            NCCL_SOCKET_IFNAME: 'lo',
            VLLM_HOST_IP: '127.0.0.1',
            // The FlashInfer sampler compiles CUDA code at run time; the image has no CUDA toolkit.
            VLLM_USE_FLASHINFER_SAMPLER: '0',
            VLLM_NO_USAGE_STATS: '1',
            DO_NOT_TRACK: '1',
            HF_HUB_OFFLINE: '1',
            TRANSFORMERS_OFFLINE: '1',
            TIKTOKEN_ENCODINGS_BASE: path.join(runRoot, TIKTOKEN_DIR_NAME),
        },
    };
}

function snapshotModelType(snapshotDir) {
    try {
        return JSON.parse(fs.readFileSync(path.join(snapshotDir, 'config.json'), 'utf8'))?.model_type ?? null;
    } catch {
        return null;
    }
}

// The runnable copy is rebuilt per container; the Triton and vLLM caches sit
// beside it in the container's own filesystem, so compiled kernels never
// outlive the container either.
async function start(ctx) {
    // vLLM loads harmony only on the first gpt-oss chat request, after
    // readiness passed; without the pinned vocabulary that request would fail.
    const vocabulary = path.join(ctx.runnerDir, TIKTOKEN_DIR_NAME, O200K_FILE);
    if (snapshotModelType(ctx.weights.path) === 'gpt_oss' && !fs.existsSync(vocabulary)) {
        throw codedError('runner_incomplete',
            `This vLLM install has no pinned ${O200K_FILE}, which gpt-oss models need; uninstall vLLM and install it again from this image's runner lock.`,
            { file: O200K_FILE });
    }
    const cacheDir = path.join(path.dirname(path.dirname(ctx.runnerDir)), '.cache', ID);
    const rpcDir = path.join(ctx.shmDir || '/dev/shm', RPC_DIR_NAME);
    for (const dir of [cacheDir, rpcDir]) fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
    const process = ctx.launch(ctx.runner.buildLaunch({
        runnerDir: ctx.runnerDir,
        artifactPath: ctx.weights.path,
        params: ctx.params,
        port: ctx.port,
        apiKey: ctx.apiKey,
        model: ctx.model,
        gpuMemoryUtilization: ctx.admission?.estimate?.gpuMemoryUtilization,
        cacheDir,
        rpcDir,
        profile: ctx.profile,
    }));
    const base = `http://127.0.0.1:${ctx.port}`;
    await ctx.waitForHttp(`${base}/health`, { process });
    await ctx.waitForHttp(`${base}/v1/models`, { headers: { authorization: `Bearer ${ctx.apiKey}` }, process });
    return {};
}

const MIB = 1024 * 1024;
const GIB = 1024 * MIB;

// vLLM logs the memory its weights took and the KV cache it allocated.
function parseReport(lines) {
    const report = { modelMiB: null, kvMiB: null, kvTokens: null, computeMiB: null, offloaded: null, device: null };
    for (const { line } of lines) {
        const loaded = /Model loading took ([\d.]+) GiB/.exec(line);
        if (loaded) report.modelMiB = Math.round(Number(loaded[1]) * GIB / MIB);
        const kv = /Available KV cache memory: ([\d.]+) GiB/.exec(line);
        if (kv) report.kvMiB = Math.round(Number(kv[1]) * GIB / MIB);
        const tokens = /GPU KV cache size: ([\d,]+) tokens/.exec(line);
        if (tokens) report.kvTokens = Number(tokens[1].replaceAll(',', ''));
    }
    const known = [report.modelMiB, report.kvMiB].filter((value) => value !== null);
    report.totalMiB = known.length ? known.reduce((total, value) => total + value, 0) : null;
    return report;
}

/**
 * The tuple a qualification entry must match (vllmMpsQualification.mjs): the
 * selected lock entry's digest and the physical GPU's driver, PCI device id,
 * compute capability and total memory. Admission asks for it through
 * `qualifyMps`; the calibration probe (tools/vllm_mps_calibration.mjs) reads
 * the very same tuple, so a proposed entry is computed by production's own code.
 */
export function vllmMpsTuple({ gpu, runnerLockEntry } = {}) {
    return {
        runnerLockDigest: vllmRunnerLockDigest(runnerLockEntry), driverVersion: gpu?.driverVersion,
        gpuPciDeviceId: gpu?.device?.pciDeviceId, computeCapability: gpu?.device?.computeCapability,
        deviceTotalBytes: gpu?.totalBytes,
    };
}

const vllmRuntime = Object.freeze({
    id: ID,
    displayName: 'vLLM',
    weightFormat: 'hf',
    pinnedVersion: PINNED_VERSION,
    supported: true,
    executable: null,
    port: PORT,
    apiKey: true,
    paramSchema,
    paramSchemaFor,
    basicParams: Object.freeze(['maxModelLen', 'cpuOffloadGb']),
    moeParams: Object.freeze([]),
    normalizeParams,
    describeContext,
    detect,
    buildLaunch,
    start,
    chatModel: (deployment) => deployment.modelId,
    enabled,
    admit: admitVllm,
    qualifyMps({ gpu, runnerLockEntry, qualificationDataProvider }) {
        const resolve = typeof qualificationDataProvider === 'function'
            ? createVllmMpsQualificationResolver(qualificationDataProvider) : resolveVllmMpsQualification;
        return resolve(vllmMpsTuple({ gpu, runnerLockEntry }));
    },
    admitUnified: (input) => admitUnifiedVllm(input, admissionResult),
    parseReport,
});

export { vllmRuntime, vllmRuntime as vllmRunner };
