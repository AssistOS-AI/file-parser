// Pure HTML builders for the Local LLMs dashboard. They take plain data and
// return markup, so the layout rules (no Run button in the table, one in the
// detail panel) can be tested without a browser.
import {
    admissionLabel,
    contextLabel,
    downloadLabel,
    escapeHtml,
    formatBytes,
    formatDuration,
    formatMiB,
    progressPercent,
    runnerLabel,
    stripBidi,
} from '../../../local-llm-settings/local-llm-settings-model.js';

export const ACTIVE_PHASES = new Set(['downloading', 'copying', 'verifying', 'pulling', 'starting', 'loading', 'ready', 'stopping']);
const DOWNLOAD_PHASES = new Set(['downloading', 'copying', 'verifying', 'pulling', 'paused']);

/**
 * The runners that get a column in the Models table: those that can run here, that this deployment's
 * operator did not leave off, and that have a policy for the hardware profile (DS005).
 */
export function tableRunners(runners = []) {
    return (Array.isArray(runners) ? runners : [])
        .filter((runner) => runner?.supported && runner.enabled !== false && !runner.profileUnsupportedReason);
}

function labelOf(runnerId, runners = []) {
    return runners.find((runner) => runner.id === runnerId)?.displayName || runnerLabel(runnerId);
}

/**
 * Split a runner's form fields into the basic ones and the "Advanced" rest.
 * The runner names its basic fields (the ones that decide whether a model
 * fits); those in `moeParams` show only for a mixture-of-experts model.
 */
export function splitRunFields(fields = [], runner = null, model = null) {
    const moeOnly = new Set(runner?.moeParams || []);
    const wanted = (runner?.basicParams || [])
        .filter((name) => !moeOnly.has(name) || model?.architecture === 'moe');
    const basic = [];
    const advanced = [];
    for (const field of fields) (wanted.includes(field.name) ? basic : advanced).push(field);
    basic.sort((left, right) => wanted.indexOf(left.name) - wanted.indexOf(right.name));
    return { basic, advanced };
}

function meter({ label, value, max, text }) {
    if (!Number.isFinite(value) || !Number.isFinite(max) || max <= 0) return '';
    const clamped = Math.max(0, Math.min(value, max));
    return `<meter class="local-llm-meter" min="0" max="${max}" value="${clamped}" low="${max * 0.7}" high="${max * 0.9}" optimum="0"
                   aria-label="${escapeHtml(label)}" title="${escapeHtml(text)}">${escapeHtml(text)}</meter>`;
}

function statCard(name, title, value, meta = '', extra = '') {
    return `
        <div class="settings-card settings-card-static local-llm-stat" data-llm-card="${escapeHtml(name)}">
            <div class="settings-card-meta local-llm-stat-title">${escapeHtml(title)}</div>
            <div class="settings-card-title local-llm-stat-value">${escapeHtml(value)}</div>
            ${extra}
            ${meta ? `<div class="settings-card-meta">${escapeHtml(meta)}</div>` : ''}
        </div>`;
}

// Why no NVIDIA GPU is used, led by the cause of the profile decision (DS005).
const CPU_LEADS = Object.freeze({
    absent: 'no NVIDIA GPU is attached',
    unusable: 'the NVIDIA GPU cannot be used',
    mismatch: 'this image\'s CUDA runners were not built for this GPU',
    'unreadable-timeout': 'the NVIDIA GPU could not be read for 60 s',
});

// The cpu profile: the compute device and why it is the CPU, the memory pool with the floor kept free, and the disk.
function cpuCardsHtml(hardware, decision, limits) {
    const memory = hardware.memory || {};
    const disk = hardware.disk || {};
    const cores = Number.isFinite(hardware.cores) ? hardware.cores : (Number.isFinite(hardware.cpus) ? hardware.cpus : null);
    const lead = CPU_LEADS[decision?.cause] || 'no NVIDIA GPU is used';
    const why = String(decision?.reason || '').replace(/\.+\s*$/, '');
    // A container memory limit caps the pool, so the controller says what the pool and what is available are.
    const pool = Number.isFinite(limits?.poolBytes) ? limits.poolBytes : memory.totalBytes;
    const available = Number.isFinite(limits?.availableBytes) ? limits.availableBytes : memory.availableBytes;
    const used = Number.isFinite(pool) && Number.isFinite(available) ? pool - available : null;
    return [
        statCard('compute', 'Compute', cores === null ? 'CPU' : `CPU · ${cores} ${cores === 1 ? 'core' : 'cores'}`,
            `No NVIDIA GPU is used: ${lead}${why ? `. ${why}` : ''}.`),
        statCard('memory', 'Memory available', `${formatMiB(available)} of ${formatMiB(pool)}`,
            Number.isFinite(limits?.floorBytes) ? `keeps ${formatMiB(limits.floorBytes)} free for the workspace` : '',
            meter({ label: 'Memory in use', value: used, max: pool, text: `${formatMiB(used)} in use` })),
        statCard('disk', 'Disk free', formatBytes(disk.freeBytes),
            Number.isFinite(disk.totalBytes) ? `of ${formatBytes(disk.totalBytes)}, for model weights` : 'for model weights'),
    ].join('');
}

// The container budget Ploinky set, shown only when the overview carries one.
function budgetCardHtml(budget) {
    if (!budget || typeof budget !== 'object') return '';
    const parts = [];
    if (Number.isFinite(budget.cpus) && budget.cpus > 0) parts.push(`${budget.cpus} ${budget.cpus === 1 ? 'CPU' : 'CPUs'}`);
    if (Number.isFinite(budget.memoryBytes)) parts.push(`${formatMiB(budget.memoryBytes)} RAM`);
    if (budget.gpuShare?.assurance === 'best-effort') parts.push(`${budget.gpuShare.smPercent}% GPU SM, ${formatMiB(budget.gpuShare.vramBytes)} per CUDA process (best-effort)`);
    if (!parts.length) return '';
    return statCard('budget', 'Limits from Ploinky', parts.join(' · '),
        'Models are sized against this container budget; a temporary shortage clears when memory is released.');
}

/**
 * The GPU, RAM and disk cards; on a GPU that shares system memory, one unified-memory card and disk; on the
 * cpu profile (`profile`, with the controller's `decision` and pool `limits`), the Compute, Memory and disk
 * cards. `gpu` may come from a fresher status poll.
 */
export function hardwareCardsHtml(hardware = {}, gpuOverride = null, { profile = null, decision = null, limits = null } = {}) {
    const budget = budgetCardHtml(limits?.budget);
    if (profile === 'cpu') return cpuCardsHtml(hardware, decision, limits) + budget;
    const gpu = gpuOverride?.available ? { ...(hardware.gpu || {}), ...gpuOverride } : (hardware.gpu || {});
    const cards = [];
    const memory = hardware.memory || {};
    if (gpu.available && gpu.memoryModel === 'unified') {
        // One pool: the GPU and everything else share system memory (DS005).
        const users = Array.isArray(gpu.processes) && gpu.processes.length
            ? `GPU in use by ${gpu.processes.map((process) => process.name).join(', ')}`
            : 'no process is using the GPU';
        const used = Number.isFinite(memory.totalBytes) && Number.isFinite(memory.availableBytes)
            ? memory.totalBytes - memory.availableBytes : null;
        const cache = Number.isFinite(memory.cachedBytes) ? ` · page cache ${formatMiB(memory.cachedBytes)}` : '';
        cards.push(statCard('unified', 'Unified memory available', `${formatMiB(memory.availableBytes)} of ${formatMiB(memory.totalBytes)}`,
            `${gpu.name || 'GPU'} shares system memory · ${users}${cache}`,
            meter({ label: 'Unified memory in use', value: used, max: memory.totalBytes, text: `${formatMiB(used)} in use` })));
        const disk = hardware.disk || {};
        cards.push(statCard('disk', 'Disk free', formatBytes(disk.freeBytes),
            Number.isFinite(disk.totalBytes) ? `of ${formatBytes(disk.totalBytes)}, for model weights` : 'for model weights'));
        return cards.join('') + budget;
    }
    if (gpu.available) {
        const users = Array.isArray(gpu.processes) && gpu.processes.length
            ? `in use by ${gpu.processes.map((process) => process.name).join(', ')}`
            : 'no process is using it';
        cards.push(statCard('gpu', 'GPU memory', `${formatMiB(gpu.usedBytes)} of ${formatMiB(gpu.totalBytes)}`,
            `${gpu.name || 'GPU'} · ${users}`,
            meter({ label: 'GPU memory used', value: gpu.usedBytes, max: gpu.totalBytes, text: `${formatMiB(gpu.usedBytes)} used` })));
    } else {
        cards.push(statCard('gpu', 'GPU', 'Not available', gpu.reason || 'No GPU is attached to this agent.'));
    }
    cards.push(statCard('ram', 'RAM available', formatMiB(memory.availableBytes),
        Number.isFinite(memory.totalBytes) ? `of ${formatMiB(memory.totalBytes)}` : ''));
    const disk = hardware.disk || {};
    cards.push(statCard('disk', 'Disk free', formatBytes(disk.freeBytes),
        Number.isFinite(disk.totalBytes) ? `of ${formatBytes(disk.totalBytes)}, for model weights` : 'for model weights'));
    return cards.join('') + budget;
}

/** The deployment card: what runs, how it is doing, and its actions. */
export function statusCardHtml(status = {}) {
    const deployment = status.deployment || null;
    const phase = status.phase || deployment?.phase || 'idle';
    const actions = `
        <div class="settings-card-actions local-llm-stat-actions">
            <button type="button" class="general-button secondary" data-llm-cancel data-local-action="cancelDownload">Cancel download</button>
            <button type="button" class="gray-button" data-llm-stop data-local-action="stopDeployment">Stop</button>
        </div>`;
    if (!deployment || phase === 'idle') {
        const last = deployment ? `Last run: ${deployment.modelId} on ${runnerLabel(deployment.runnerId)}` : 'Select a model below, then Run';
        return `
            <div class="settings-card settings-card-static local-llm-stat local-llm-stat-status" data-llm-card="status">
                <div class="settings-card-meta local-llm-stat-title">Running model</div>
                <div class="settings-card-title local-llm-stat-value">None</div>
                <div class="settings-card-meta">${escapeHtml(last)}</div>
                ${actions}
            </div>`;
    }
    const badge = phase === 'ready' ? 'success' : phase === 'error' ? 'error' : '';
    const lines = [];
    const download = deployment.download || null;
    if (download && DOWNLOAD_PHASES.has(phase)) {
        const percent = progressPercent(download) ?? 0;
        const rate = download.rate ? `${formatBytes(download.rate)}/s` : '';
        const eta = Number.isFinite(download.etaSeconds) ? `about ${formatDuration(download.etaSeconds)} left` : '';
        lines.push(`<progress class="local-llm-progress" max="100" value="${percent}" aria-label="Download progress">${percent}%</progress>`);
        lines.push(`<div class="settings-card-meta">${escapeHtml([`${formatBytes(download.bytes)} of ${formatBytes(download.total)}`, rate, eta].filter(Boolean).join(' · '))}</div>`);
    }
    const report = status.runnerReport || {};
    const reportParts = [
        report.device ? `device ${report.device}` : '',
        report.offloaded?.layers > 0 ? `${report.offloaded.layers}/${report.offloaded.of} layers on the GPU` : '',
        Number.isFinite(report.totalMiB) ? `buffers ${report.totalMiB.toLocaleString('en-US')} MiB` : '',
    ].filter(Boolean);
    if (reportParts.length) lines.push(`<div class="settings-card-meta">${escapeHtml(reportParts.join(' · '))}</div>`);
    if (status.context) lines.push(`<div class="settings-card-meta">Context: ${escapeHtml(contextLabel(status.context))}</div>`);
    const last = status.lastCompletion;
    if (last && Number.isFinite(last.generationTokensPerSecond)) {
        lines.push(`<div class="settings-card-meta">Last completion: ${escapeHtml(String(last.completionTokens ?? '?'))} tokens at ${escapeHtml(last.generationTokensPerSecond.toFixed(1))} tokens/s (${escapeHtml(last.source || 'runner')})</div>`);
    }
    if (deployment.error) lines.push(`<div class="settings-status error">${escapeHtml(deployment.error)}</div>`);
    if (deployment.pausedReason && phase === 'paused') lines.push(`<div class="settings-card-meta">${escapeHtml(deployment.pausedReason)}</div>`);
    return `
        <div class="settings-card settings-card-static local-llm-stat local-llm-stat-status" data-llm-card="status">
            <div class="settings-card-meta local-llm-stat-title">Running model</div>
            <div class="local-llm-stat-line">
                <span class="settings-card-title local-llm-stat-value">${escapeHtml(deployment.modelId)} on ${escapeHtml(runnerLabel(deployment.runnerId))}</span>
                <span class="status-badge ${badge}">${escapeHtml(phase)}</span>
            </div>
            ${lines.join('')}
            ${actions}
        </div>`;
}

function runnerCell(entry) {
    if (!entry) return '<td class="settings-card-meta">—</td>';
    return `
        <td>
            <div>${escapeHtml(downloadLabel(entry.download, entry.size))}</div>
            <div class="settings-card-meta">${escapeHtml(admissionLabel(entry.admission))}</div>
        </td>`;
}

function modelChips(model, activeModelId) {
    return [
        model.architecture === 'moe' ? '<span class="settings-chip">MoE</span>' : '',
        model.seed ? '<span class="settings-chip">catalog</span>' : '<span class="settings-chip">added</span>',
        model.id === activeModelId ? '<span class="status-badge success">in use</span>' : '',
    ].join('');
}

function modelSizes(model) {
    return [model.totalParams, model.activeParams ? `${model.activeParams} active` : '']
        .filter(Boolean).join(' · ');
}

/**
 * The models table. It has no buttons: a row selects its model, and the
 * detail panel holds the model's actions and its one Run button.
 */
export function modelsTableHtml(models = [], { selectedId = '', activeModelId = '', runners = [] } = {}) {
    if (!models.length) return '<div class="settings-empty-state">No models in the catalog.</div>';
    const columns = tableRunners(runners);
    const rows = models.map((model) => {
        const selected = model.id === selectedId;
        return `
            <tr class="local-llm-model-row${selected ? ' active' : ''}" data-local-action="selectModel ${escapeHtml(model.id)}"
                data-model-id="${escapeHtml(model.id)}" tabindex="0" aria-selected="${selected ? 'true' : 'false'}">
                <td>
                    <div class="local-llm-model-name">
                        <span class="settings-card-title">${escapeHtml(model.displayName || model.id)}</span>
                        ${modelChips(model, activeModelId)}
                    </div>
                    <div class="settings-card-meta">${escapeHtml(modelSizes(model) || model.id)}</div>
                </td>
                <td>${escapeHtml(model.license || '—')}</td>
                ${columns.map((runner) => runnerCell(model.runners?.[runner.id])).join('')}
            </tr>`;
    }).join('');
    return `
        <div class="local-llm-table-scroll">
            <table class="local-llm-table" aria-label="Models">
                <thead>
                    <tr>
                        <th scope="col">Model</th>
                        <th scope="col">Licence</th>
                        ${columns.map((runner) => `<th scope="col">${escapeHtml(labelOf(runner.id, runners))}</th>`).join('')}
                    </tr>
                </thead>
                <tbody>${rows}</tbody>
            </table>
        </div>`;
}

/** Whether any of this model's weights are on disk (downloaded or partial). */
export function hasWeightsOnDisk(model) {
    const entries = model?.weights ? Object.values(model.weights) : Object.values(model?.runners || {});
    return entries.some((entry) => ['complete', 'partial'].includes(entry?.download?.state));
}

/**
 * The selected model's heading, its weights once per format (runners that
 * read the same format share one download, so Delete weights sits there),
 * and each supported runner's fit. An added model also gets Remove.
 */
export function detailInfoHtml(model, { runners = [], activeModelId = '' } = {}) {
    if (!model) return '';
    const supported = new Set(tableRunners(runners).map((runner) => runner.id));
    const weights = Object.entries(model.weights || {}).map(([format, entry]) => {
        const deletable = entry.download && ['complete', 'partial'].includes(entry.download.state);
        const readers = (entry.runners || []).filter((runnerId) => supported.has(runnerId))
            .map((runnerId) => labelOf(runnerId, runners));
        return `
                <li class="local-llm-runner-item">
                    <div>
                        <div class="settings-card-title">${escapeHtml(entry.label || format)}</div>
                        <div class="settings-card-meta">${escapeHtml(downloadLabel(entry.download, entry.size))}${readers.length ? ` · used by ${escapeHtml(readers.join(', '))}` : ''}</div>
                    </div>
                    ${deletable ? `<button type="button" class="gray-button" data-local-action="deleteWeights ${escapeHtml(model.id)} ${escapeHtml(format)}">Delete weights</button>` : ''}
                </li>`;
    }).join('');
    const fits = Object.entries(model.runners || {})
        .filter(([runnerId]) => supported.has(runnerId))
        .map(([runnerId, entry]) => `
                <li class="local-llm-runner-item">
                    <div>
                        <div class="settings-card-title">${escapeHtml(labelOf(runnerId, runners))}</div>
                        <div class="settings-card-meta">${escapeHtml(admissionLabel(entry.admission))}</div>
                    </div>
                </li>`).join('');
    const facts = [modelSizes(model), model.license, model.id].filter(Boolean).join(' · ');
    // The server removes a model only once none of its weights are on disk.
    const weightsPresent = hasWeightsOnDisk(model);
    const remove = model.seed ? '' : `
            <div class="local-llm-remove">
                <button type="button" class="gray-button" data-local-action="removeModel ${escapeHtml(model.id)}"
                        ${weightsPresent ? 'disabled title="Delete its weights first"' : ''}>Remove</button>
                ${weightsPresent ? '<span class="settings-card-meta">Delete its weights first to remove it.</span>' : ''}
            </div>`;
    return `
        <div class="local-llm-detail-head">
            <div>
                <h3 class="settings-section-title local-llm-model-name">${escapeHtml(model.displayName || model.id)} ${modelChips(model, activeModelId)}</h3>
                <p class="settings-section-description">${escapeHtml(facts)}</p>
            </div>
            ${remove}
        </div>
        <ul class="local-llm-runner-list" aria-label="Weights">${weights}</ul>
        <ul class="local-llm-runner-list" aria-label="Runners">${fits || '<li class="settings-card-meta">No runner can run this model.</li>'}</ul>`;
}

function licenceLine(licence = {}, accepted = null) {
    const links = [
        licence.url ? `<a href="${escapeHtml(licence.url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(licence.name || 'Licence')}</a>` : escapeHtml(licence.name || ''),
        licence.source ? `<a href="${escapeHtml(licence.source)}" target="_blank" rel="noopener noreferrer">source</a>` : '',
    ].filter(Boolean).join(' · ');
    const acceptance = accepted?.acceptedBy
        ? ` · accepted by ${escapeHtml(accepted.acceptedBy)} on ${escapeHtml(String(accepted.acceptedAt || '').slice(0, 10))}` : '';
    return `<div class="settings-card-meta">Licence: ${links}${acceptance}</div>`;
}

function installProgress(state) {
    const download = state?.download;
    if (!download?.total || !['downloading', 'installing'].includes(state.phase)) return '';
    const percent = progressPercent(download) ?? 0;
    const rate = download.rate ? ` · ${formatBytes(download.rate)}/s` : '';
    return `
        <progress class="local-llm-progress" max="100" value="${percent}" aria-label="Install progress">${percent}%</progress>
        <div class="settings-card-meta">${escapeHtml(`${formatBytes(download.bytes)} of ${formatBytes(download.total)}${rate}`)}</div>`;
}

/**
 * The Runners tab's intro, from the overview: the runners the image itself
 * contains, and whether any other runner can be installed here. Plain text.
 */
export function runnersIntroText(runners = [], { profile = null } = {}) {
    const list = (Array.isArray(runners) ? runners : []).filter(Boolean);
    if (!list.length) return '';
    const inImage = list.filter((runner) => runner.supported !== false && !runner.install)
        .map((runner) => runner.displayName || runner.id);
    const inImageText = inImage.length ? `In this image: ${inImage.join(', ')}.` : 'No runner is part of this image.';
    // On the cpu profile only the runners with a CPU policy (a parameter schema for it) run models.
    const onCpu = list.filter((runner) => runner.supported !== false && runner.paramSchema).map((runner) => runner.displayName || runner.id);
    const first = profile === 'cpu' && onCpu.length ? `${inImageText} On this machine models run on the CPU, with: ${onCpu.join(', ')}.` : inImageText;
    // Install is offered only for a runner with a policy for the profile, so the intro says so only then.
    const onDemand = list.filter((runner) => runner.install);
    const second = onDemand.some((runner) => !runner.profileUnsupportedReason)
        ? 'Other runners are installed here, only when you press Install: their pinned files are downloaded, checked and set up on this workspace\'s disk.'
        : onDemand.length
            ? 'No other runner can be installed while models run on the CPU.'
            : 'No other runner can be installed on this image.';
    return `${first} ${second}`;
}

/**
 * The Runners tab: every runner with its state. Runners in the image have no
 * actions; on-demand runners show their size, licence and install progress,
 * with Install or Uninstall (never a second Install while one runs).
 */
export function runnersPanelHtml(runners = []) {
    const busy = runners.some((runner) => runner.install?.installing);
    const cards = runners.map((runner) => {
        const install = runner.install;
        const off = runner.enabled === false;
        // A runner the image lacks says so in the platform's words, never through
        // the version probe's "Executable not found" (that is `reason`).
        const lacking = (runner.supported === false ? runner.unsupportedReason : '') || runner.profileUnsupportedReason || '';
        const status = lacking || (off
            ? `${runner.installed ? 'installed · ' : ''}not enabled on this deployment`
            : runner.installed
                ? `${runner.version || install?.version || ''} · installed`
                : (install ? 'not installed' : (runner.reason || 'not available')));
        let body = '';
        let actions = '';
        if (install) {
            const state = install.state || {};
            const phase = install.installing ? state.phase : null;
            body = `
                <div class="settings-card-meta">${escapeHtml(`Version ${install.version} · ${formatBytes(install.totalBytes)} to download`)}${
    state.rebuild?.seconds ? escapeHtml(` · set up in ${Math.round(state.rebuild.seconds)} s`) : ''}</div>
                ${licenceLine(install.licence, state.licence)}
                ${install.licence?.notice ? `<div class="settings-card-meta">${escapeHtml(install.licence.notice)}</div>` : ''}
                ${phase ? `<div class="settings-card-meta">${escapeHtml(phase === 'installing' ? 'Setting up the runner…' : 'Downloading…')}</div>` : ''}
                ${installProgress(install.installing ? state : null)}
                ${state.phase === 'paused' && state.pausedReason ? `<div class="settings-card-meta">${escapeHtml(state.pausedReason)}</div>` : ''}
                ${state.phase === 'error' && state.error ? `<div class="settings-status error">${escapeHtml(state.error)}</div>` : ''}`;
            if (install.installed && !install.installing) {
                actions = `<button type="button" class="gray-button" data-local-action="uninstallRunner ${escapeHtml(runner.id)}">Uninstall</button>`;
            } else if (!install.installing && !busy && !off && !runner.profileUnsupportedReason) {
                actions = `<button type="button" class="general-button" data-local-action="installRunner ${escapeHtml(runner.id)}">Install</button>`;
            }
        }
        return `
            <li class="local-llm-runner-item">
                <div>
                    <div class="settings-card-title">${escapeHtml(runner.displayName || runner.id)}</div>
                    <div class="settings-card-meta">${escapeHtml(status)}</div>
                    ${off && runner.disabledReason ? `<div class="settings-card-meta">${escapeHtml(runner.disabledReason)}</div>` : ''}
                    ${body}
                </div>
                ${actions}
            </li>`;
    }).join('');
    return `<ul class="local-llm-runner-list" aria-label="Runners">${cards || '<li class="settings-card-meta">No runners.</li>'}</ul>`;
}

/**
 * What the Install confirmation says: the download size and the licence. A
 * licence that needs acceptance is shown with its link and notice; a
 * proprietary one (LM Studio) also says it is for internal use only.
 */
export function installMessage(runner = {}) {
    const install = runner.install || {};
    const licence = install.licence || {};
    const name = runner.displayName || runner.id;
    const head = `Install ${name} ${install.version}? It downloads ${formatBytes(install.totalBytes)} of pinned files to this workspace.`;
    if (!licence.requiresAcceptance) return `${head} Licence: ${licence.name}.`;
    const where = `${licence.url}${licence.source ? `; source: ${licence.source}` : ''}`;
    const terms = licence.proprietary
        ? ` ${name} is proprietary software, for internal use only: it is not part of this agent, and each deployment downloads it from its publisher. Its terms: ${licence.name} (${where}).`
        : ` It is licensed under ${licence.name} (${where}).`;
    const notice = licence.notice || '';
    // The lock's notice may already say it; the dialog says it once.
    const accepts = /acceptance is recorded/.test(notice) ? '' : ' Installing accepts these terms on this workspace\'s behalf, and your acceptance is recorded.';
    return `${head}${terms} ${notice}${accepts}`.trimEnd();
}

/**
 * GPU and RAM estimate meters for the run form. On the cpu profile the controller's pool `limits` say
 * what is available under a container memory limit, which the host's figure does not.
 */
export function estimateHtml({ admission = null, context = null, error = '' } = {}, hardware = {}, { limits = null } = {}) {
    if (error) return `<div class="settings-status error">${escapeHtml(error)}</div>`;
    const estimate = admission?.estimate || {};
    const gpu = hardware.gpu || {};
    const memory = { ...(hardware.memory || {}) };
    if (Number.isFinite(limits?.availableBytes)) memory.availableBytes = limits.availableBytes;
    const parts = [];
    if (Number.isFinite(estimate.unifiedBytes) && Number.isFinite(memory.totalBytes)) {
        // Unified memory: one estimate against the shared pool (DS005).
        const available = Number.isFinite(memory.availableBytes) ? `, ${formatMiB(memory.availableBytes)} available now` : '';
        parts.push(`
            <div class="local-llm-estimate-row">
                <span class="settings-card-meta">Shared memory about ${escapeHtml(formatMiB(estimate.unifiedBytes))} of ${escapeHtml(formatMiB(memory.totalBytes))}${escapeHtml(available)}</span>
                ${meter({ label: 'Estimated shared memory', value: estimate.unifiedBytes, max: memory.totalBytes, text: `Shared memory about ${formatMiB(estimate.unifiedBytes)}` })}
            </div>`);
    }
    if (Number.isFinite(estimate.gpuBytes) && gpu.available) {
        parts.push(`
            <div class="local-llm-estimate-row">
                <span class="settings-card-meta">GPU about ${escapeHtml(formatMiB(estimate.gpuBytes))} of ${escapeHtml(formatMiB(gpu.totalBytes))}</span>
                ${meter({ label: 'Estimated GPU memory', value: estimate.gpuBytes, max: gpu.totalBytes, text: `GPU about ${formatMiB(estimate.gpuBytes)}` })}
            </div>`);
    }
    if (Number.isFinite(estimate.ramBytes) && Number.isFinite(memory.availableBytes)) {
        parts.push(`
            <div class="local-llm-estimate-row">
                <span class="settings-card-meta">RAM about ${escapeHtml(formatMiB(estimate.ramBytes))} of ${escapeHtml(formatMiB(memory.availableBytes))} available${
    Number.isFinite(estimate.floorBytes) ? escapeHtml(`, keeps ${formatMiB(estimate.floorBytes)} free`) : ''}</span>
                ${meter({ label: 'Estimated RAM', value: estimate.ramBytes, max: memory.availableBytes, text: `RAM about ${formatMiB(estimate.ramBytes)}` })}
            </div>`);
    }
    const warnings = Array.isArray(admission?.warnings) ? admission.warnings : [];
    const summary = [admissionLabel(admission), estimate.basis ? `estimate from ${estimate.basis}` : '', ...warnings].filter(Boolean).join(' · ');
    return `
        ${parts.join('')}
        ${context ? `<div class="settings-card-meta">Context: ${escapeHtml(contextLabel(context))}</div>` : ''}
        ${summary ? `<div class="settings-card-meta">${escapeHtml(summary)}</div>` : ''}`;
}

const GATED_LABELS = Object.freeze({
    auto: 'Gated (access is granted automatically)',
    manual: 'Gated (access needs approval)',
});

function gatedLabel(gated) {
    if (gated === false) return 'Not gated';
    if (Object.hasOwn(GATED_LABELS, gated)) return GATED_LABELS[gated];
    return typeof gated === 'string' && gated ? `Gated (${gated})` : 'Gated status unknown';
}

const count = (value) => (Number.isFinite(value) ? value.toLocaleString('en-US') : '—');

// What was read for the sizing, in one line; every value is data from Hugging Face or from a file, so it is escaped.
function sizingLine(sizing) {
    if (!sizing || typeof sizing !== 'object') return '';
    const from = sizing.source === 'gguf-header' ? 'the GGUF header' : sizing.source === 'config.json' ? 'config.json' : 'the model files';
    const memory = sizing.memory || {};
    const parts = [
        `${count(memory.layers)} layers`,
        `context ${count(sizing.contextLength)} tokens`,
        Number.isFinite(memory.kvBytesPerToken) ? `KV cache ${count(memory.kvBytesPerToken)} bytes per token (f16)` : 'KV cache size not read, so the estimate uses its default',
        String(sizing.architecture) === 'moe' ? 'mixture of experts' : 'dense',
    ];
    // A note can repeat a key name from the model's own files, so it loses bidi controls like the licence does.
    const notes = Array.isArray(sizing.notes) ? sizing.notes.filter((note) => typeof note === 'string' && note).map((note) => stripBidi(note)) : [];
    return `<div class="settings-card-meta">Read from ${escapeHtml(from)}: ${escapeHtml(parts.join(' · '))}${notes.length ? escapeHtml(` (${notes.join('; ')})`) : ''}</div>`;
}

/**
 * The Add model form's lookup results (DS002): what `local_llm_model_lookup`
 * returned, or its error. A GGUF lookup lists one radio row per file or split
 * set, `file · quantization · size`, with the repository's gated status; a
 * snapshot lookup lists a summary. Everything in `result` is text from Hugging
 * Face or from a model file, so every value is escaped; a row's action names
 * its index in `result.files`, never a file name.
 */
export function lookupResultsHtml(result = {}, { selectedFile = '' } = {}) {
    if (result?.error) return `<div class="settings-status error">${escapeHtml(result.error)}</div>`;
    if (result?.message) return `<div class="settings-card-meta">${escapeHtml(result.message)}</div>`;
    const files = Array.isArray(result?.files) ? result.files : [];
    const gated = result?.gated === 'auto' || result?.gated === 'manual' || (typeof result?.gated === 'string' && result.gated !== '');
    const badges = [
        `<span class="status-badge">${escapeHtml(gatedLabel(result?.gated))}</span>`,
        result?.license ? `<span class="status-badge">Licence ${escapeHtml(stripBidi(result.license))}</span>` : '',
    ].filter(Boolean).join('');
    const head = `
        <div class="settings-card-meta">${escapeHtml(result?.repo ?? '')} at commit ${escapeHtml(String(result?.commit ?? '').slice(0, 12))}</div>
        <div class="local-llm-lookup-badges">${badges}</div>
        ${gated ? '<div class="settings-card-meta">Downloading a gated model needs a token: run `ploinky var HF_TOKEN &lt;token&gt;` on the host, then restart local-llm.</div>' : ''}`;
    const cut = result?.truncated
        ? '<div class="settings-card-meta">The list is cut short: the repository has more files or folders than a lookup reads.</div>' : '';
    if (result?.format === 'hf' || result?.format === 'exl3') {
        const weights = files.filter((entry) => String(entry?.file).endsWith('.safetensors'));
        const total = files.reduce((sum, entry) => sum + (Number.isFinite(entry?.size) ? entry.size : 0), 0);
        return `${head}
        <div class="settings-card-meta">${escapeHtml(`${files.length} files, ${weights.length} of them safetensors · ${formatBytes(total)} in all`)}</div>
        ${sizingLine(result.sizing) || '<div class="settings-card-meta">No config.json to size the model from: the estimate uses its defaults.</div>'}${cut}`;
    }
    if (files.length === 0) {
        return `${head}
        <div class="settings-card-meta">No GGUF file in this repository can be added (a file must be stored with Git LFS, and a split file needs all of its parts).</div>${cut}`;
    }
    const rows = files.map((entry, index) => {
        const shards = Array.isArray(entry?.shards) ? `${entry.shards.length} parts` : '';
        const text = [entry?.quantization || 'quantization unknown', formatBytes(entry?.size), shards].filter(Boolean).join(' · ');
        return `
            <li class="local-llm-lookup-row">
                <label>
                    <input type="radio" name="lookupFile" value="${index}" data-local-action="pickLookupFile ${index}"${entry?.file === selectedFile ? ' checked' : ''}>
                    <span class="local-llm-lookup-file">${escapeHtml(entry?.file ?? '')}</span>
                    <span class="settings-card-meta">${escapeHtml(text)}${gated ? '<span class="status-badge">gated</span>' : ''}</span>
                </label>
            </li>`;
    }).join('');
    return `${head}
        <ul class="local-llm-lookup-files" role="radiogroup" aria-label="GGUF files">${rows}</ul>${sizingLine(result.sizing)}${cut}`;
}
