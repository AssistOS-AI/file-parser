import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, '..');

function read(relativePath) {
    return fs.readFileSync(path.join(repoRoot, relativePath), 'utf8');
}

function dockerfileInstructions(dockerfile) {
    const instructions = [];
    let logicalInstruction = '';

    for (const line of dockerfile.split(/\r?\n/)) {
        if (!logicalInstruction && /^\s*(?:#.*)?$/.test(line)) {
            continue;
        }

        logicalInstruction += logicalInstruction ? `\n${line}` : line;
        if (/\\\s*$/.test(line)) {
            continue;
        }

        const keyword = logicalInstruction.match(/^\s*([A-Za-z]+)\b/)?.[1];
        if (keyword) {
            instructions.push({
                keyword: keyword.toUpperCase(),
                source: logicalInstruction,
            });
        }
        logicalInstruction = '';
    }

    return instructions;
}

test('ploinky-node publishes proven native Trixie candidates before explicit promotion', () => {
    const workflow = read('.github/workflows/publish-ploinky-node-image.yml');
    const dockerfile = read('images/ploinky-node/Dockerfile');

    assert.match(workflow, /images\/ploinky-node/);
    assert.match(workflow, /docker\/login-action@[0-9a-f]{40}/);
    assert.match(workflow, /docker\/build-push-action@[0-9a-f]{40}/);
    assert.match(workflow, /password:\s*\$\{\{\s*secrets\.DOCKERHUB_TOKEN\s*\}\}/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04(?:\s|$)/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04-arm/);
    assert.match(workflow, /platform:\s*linux\/amd64/);
    assert.match(workflow, /platform:\s*linux\/arm64/);
    assert.match(workflow, /push-by-digest=true/);
    assert.match(workflow, /smoke-git-transport\.mjs/);
    assert.match(workflow, /transport\.ok, true/);
    assert.match(workflow, /assert\.equal\(index\.manifests\.length, 2\)/);
    assert.match(workflow, /candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(workflow, /IMAGE_TAG: 24-trixie-tools/);
    assert.match(workflow, /if:\s*\$\{\{ inputs\.promote_stable == true \}\}/);
    assert.doesNotMatch(workflow, /24-bookworm-tools|setup-qemu-action|node_base:|image_tag:|^\s*push:/m);
    const base = 'docker.io/library/node:24.20.0-trixie-slim@sha256:50c3b2f6988dfc307b86e5301d69611af31f4789bdf232863b07d3b02fe55ae0';
    assert.equal(dockerfile.split('\n')[0], `FROM ${base}`);
    assert.ok(workflow.includes(`BASE_IMAGE: ${base}`));
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) {
        assert.match(use[1], /^[0-9a-f]{40}$/);
    }
    assert.match(dockerfile, /\bbubblewrap\b/);
    assert.match(dockerfile, /\bffmpeg\b/);
    assert.match(dockerfile, /\bpython3\b/);
    assert.match(dockerfile, /^USER 1000:1000$/m);
});

test('onlyoffice-agent workflow layers Node onto the standard Document Server image', () => {
    const workflow = read('.github/workflows/publish-onlyoffice-agent-image.yml');
    const dockerfile = read('images/onlyoffice-agent/Dockerfile');
    const bindInterposer = read('images/onlyoffice-agent/docservice-loopback-bind.c');

    assert.match(workflow, /images\/onlyoffice-agent/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/onlyoffice-agent/);
    assert.match(workflow, /uses:\s*actions\/checkout@v4[\s\S]*?fetch-depth:\s*0/);
    assert.match(workflow, /docker\/login-action@v3/);
    assert.match(workflow, /password:\s*\$\{\{\s*secrets\.DOCKERHUB_TOKEN\s*\}\}/);
    assert.match(workflow, /--platform linux\/amd64,linux\/arm64/);
    assert.match(workflow, /expected_digest:[\s\S]*required:\s*true/);
    assert.match(workflow, /Verify archive digest and platform set before registry mutation/);
    assert.match(workflow, /skopeo copy --all/);
    assert.match(workflow, /remote_digest.*EXPECTED_DIGEST/);
    assert.doesNotMatch(workflow, /onlyoffice_version|node_runtime_image|ONLYOFFICE_BASE_IMAGE=/);
    assert.doesNotMatch(workflow, /^\s*push:/m);
    assert.match(workflow, /test -x \/app\/ds\/run-document-server\.sh/);

    assert.match(dockerfile, /^FROM docker\.io\/library\/node:24-bookworm-slim@sha256:[0-9a-f]{64} AS node-runtime$/m);
    assert.match(dockerfile, /^FROM docker\.io\/onlyoffice\/documentserver:9\.3\.1@sha256:[0-9a-f]{64}$/m);
    assert.doesNotMatch(dockerfile, /^ARG (NODE_RUNTIME_IMAGE|ONLYOFFICE_BASE_IMAGE)=/m);
    assert.match(dockerfile, /snapshot\.ubuntu\.com\/ubuntu\/\$\{UBUNTU_SNAPSHOT\}/);
    assert.match(dockerfile, /Acquire::Retries "10"/);
    assert.match(dockerfile, /Acquire::https::Timeout "60"/);
    assert.match(dockerfile, /"g\+\+=\$\{GXX_VERSION\}"/);
    assert.match(dockerfile, /"git=\$\{GIT_VERSION\}"/);
    assert.match(dockerfile, /"python3=\$\{PYTHON_VERSION\}"/);
    assert.match(dockerfile, /COPY --from=node-runtime \/usr\/local\/bin\/node \/usr\/local\/bin\/node/);
    assert.match(dockerfile, /\/usr\/local\/bin\/npm/);
    assert.match(dockerfile, /\bgit\b/);
    assert.match(dockerfile, /\bpython3\b/);
    assert.match(dockerfile, /\bmake\b/);
    assert.match(dockerfile, /onlyoffice-docservice-loopback-bind\.so/);
    assert.match(dockerfile, /onlyoffice\.contract/);
    assert.match(dockerfile, /interposer_sha256=/);
    assert.match(dockerfile, /chmod 0444/);
    assert.match(dockerfile, /find \/var\/log -type f -exec sh -c/);
    assert.match(dockerfile, /\/var\/cache\/ldconfig\/aux-cache/);
    assert.match(dockerfile, /rm -rf \/tmp\/node-compile-cache/);
    assert.match(dockerfile, /truncate -s 0 "\$file" 2>\/dev\/null \|\| true/);
    assert.match(bindInterposer, /sin_port == htons\(8000\)/);
    assert.match(bindInterposer, /INADDR_ANY/);
    assert.match(bindInterposer, /INADDR_LOOPBACK/);
    assert.match(bindInterposer, /IN6_IS_ADDR_UNSPECIFIED/);
    assert.match(bindInterposer, /in6addr_loopback/);
    assert.match(bindInterposer, /docservice-port-8000/);
});

test('independent WebTTY image and publication workflow are retired', () => {
    const readme = read('README.md');

    assert.equal(fs.existsSync(path.join(repoRoot, 'images/webtty-agent')), false);
    assert.equal(
        fs.existsSync(path.join(repoRoot, '.github/workflows/publish-webtty-agent-image.yml')),
        false,
    );
    assert.doesNotMatch(readme, /assistos\/webtty-agent|publish-webtty-agent-image|images\/webtty-agent/);
});

test('llm-runtime-cpu workflow builds the real CPU runtime image', () => {
    const workflow = read('.github/workflows/publish-llm-runtime-cpu-image.yml');
    const dockerfile = read('images/llm-runtime-cpu/Dockerfile');

    assert.match(workflow, /images\/llm-runtime-cpu/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/llm-runtime-cpu/);
    assert.match(workflow, /docker\/login-action@v3/);
    assert.match(workflow, /docker\/build-push-action@v6/);
    assert.match(workflow, /password:\s*\$\{\{\s*secrets\.DOCKERHUB_TOKEN\s*\}\}/);
    assert.match(workflow, /runs-on:\s*ubuntu-24\.04-arm/);
    assert.match(workflow, /DEFAULT_PLATFORMS:\s*linux\/arm64/);
    assert.match(workflow, /llama-server --version/);
    assert.match(dockerfile, /^ARG NODE_BASE=node:24-bookworm-slim$/m);
    assert.match(dockerfile, /^ARG LLAMA_CPP_REF=b6412$/m);
    assert.match(dockerfile, /\bhuggingface_hub\b/);
    assert.match(dockerfile, /\bllama-server\b/);
    assert.match(dockerfile, /GGML_NATIVE=OFF/);
    assert.match(dockerfile, /\/models\/hf-cache/);
    assert.match(dockerfile, /\/models\/artifacts/);
    assert.match(dockerfile, /\/models\/derived/);
});

test('default-local-llm image and publication workflow are retired', () => {
    const readme = read('README.md');
    const workflowsDir = path.join(repoRoot, '.github/workflows');

    assert.equal(fs.existsSync(path.join(repoRoot, 'images/default-local-llm')), false);
    assert.equal(
        fs.existsSync(path.join(workflowsDir, 'publish-default-local-llm-image.yml')),
        false,
    );
    for (const name of fs.readdirSync(workflowsDir)) {
        const workflow = read(path.join('.github/workflows', name));
        assert.doesNotMatch(workflow, /default-local-llm/i, name);
    }
    assert.doesNotMatch(readme, /publish-default-local-llm-image|images\/default-local-llm/);
    assert.doesNotMatch(readme, /assistos\/default-local-llm:/);
    assert.match(readme, /`assistos\/llm-runtime-cpu:[^`]+`.*`publish-llm-runtime-cpu-image\.yml`/);
    assert.match(readme, /gh workflow run publish-llm-runtime-cpu-image\.yml/);
    assert.equal(
        fs.existsSync(path.join(workflowsDir, 'publish-llm-runtime-cpu-image.yml')),
        true,
    );
    assert.equal(fs.existsSync(path.join(repoRoot, 'images/llm-runtime-cpu/Dockerfile')), true);
});

test('search-agent image bakes SearXNG, Chromium, and Puppeteer for an unprivileged runtime', () => {
    const workflow = read('.github/workflows/publish-search-agent-image.yml');
    const dockerfile = read('images/search-agent/Dockerfile');
    const packageJson = JSON.parse(read('images/search-agent/package.json'));
    const runtime = read('images/search-agent/smoke-runtime.mjs');

    assert.match(workflow, /IMAGE_NAME:\s*assistos\/search-agent/);
    assert.doesNotMatch(workflow, /image_tag:|promote_stable:|IMAGE_TAG:|searxng-browser|setup-qemu/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04-arm/);
    assert.match(workflow, /push-by-digest=true/);
    assert.match(workflow, /--cap-drop=ALL --security-opt=no-new-privileges/);
    assert.match(workflow, /docker buildx imagetools create/);
    assert.match(workflow, /assert\.equal\(index\.manifests\.length, 2\)/);
    assert.match(workflow, /members\.get\('linux\/amd64'\), process\.env\.AMD64_DIGEST/);
    assert.match(workflow, /members\.get\('linux\/arm64'\), process\.env\.ARM64_DIGEST/);
    assert.match(workflow, /candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(workflow, /cmp "\$evidence\/candidate-index\.json" "\$evidence\/registry-index\.json"/);
    assert.match(workflow, /--network=none --cap-drop=ALL --security-opt=no-new-privileges/);
    assert.match(workflow, /smoke-git-transport\.mjs/);
    assert.match(workflow, /assert\.equal\(transport\.probes\.length, 14\)/);
    assert.match(workflow, /assert\.equal\(source\.workflowAttempt, process\.env\.GITHUB_RUN_ATTEMPT\)/);
    assert.match(workflow, /assert\.deepEqual\(runtime\.browser\.errors, \[\]\)/);
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) {
        assert.match(use[1], /^[0-9a-f]{40}$/);
    }

    const base = 'docker.io/assistos/ploinky-node:24-trixie-tools@sha256:accd925fcbf460c1f4c7a5cd9e2d46539c615bbfad2e896cabb7556d8050a669';
    assert.equal(dockerfile.split('\n')[0], `FROM ${base} AS searxng-builder`);
    assert.ok(workflow.includes(`BASE_IMAGE: ${base}`));
    assert.equal(
        dockerfile.match(/^FROM docker\.io\/assistos\/ploinky-node:24-trixie-tools@sha256:[0-9a-f]{64}(?: AS searxng-builder)?$/gm)?.length,
        2,
    );
    assert.match(dockerfile, /9fea41204fdfa7a5cfa15b0ebd12904c520478ce/);
    assert.match(dockerfile, /msgspec==0\.21\.1/);
    assert.match(dockerfile, /--no-build-isolation -e \/opt\/search-agent\/searxng-src/);
    assert.match(dockerfile, /COPY --from=searxng-builder \/opt\/search-agent\/searx-pyenv/);
    assert.match(dockerfile, /\bchromium\b/);
    assert.match(dockerfile, /python3 -m venv \/opt\/search-agent\/searx-pyenv/);
    assert.match(dockerfile, /npm ci --omit=dev --ignore-scripts/);
    assert.match(dockerfile, /^ENV NODE_PATH=\/opt\/search-agent\/node_modules/m);
    assert.match(dockerfile, /^USER root$/m);
    assert.match(dockerfile, /^USER 1000:1000$/m);
    assert.equal(packageJson.dependencies['puppeteer-core'], '25.9.0');
    assert.match(runtime, /spawn\(python, \['-m', 'searx\.webapp'\]/);
    assert.match(runtime, /127\.0\.0\.1:8888\/healthz/);
    assert.match(runtime, /127\.0\.0\.1:8888\/search\?format=json/);
    assert.match(runtime, /puppeteer\.launch\(/);
    assert.match(runtime, /page\.\$eval\('#proof'/);
    assert.doesNotMatch(runtime, /https:\/\//);
});

test('opencode-free-agent image bakes the pinned OpenCode CLI with a read-only ask-everything configuration', () => {
    const workflow = read('.github/workflows/publish-opencode-free-agent-image.yml');
    const dockerfile = read('images/opencode-free-agent/Dockerfile');
    const config = JSON.parse(read('images/opencode-free-agent/opencode.json'));
    const runtime = read('images/opencode-free-agent/smoke-runtime.mjs');

    assert.match(workflow, /IMAGE_NAME:\s*assistos\/opencode-free-agent/);
    assert.doesNotMatch(workflow, /image_tag:|promote_stable:|IMAGE_TAG:|setup-qemu|:latest\b/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04-arm/);
    assert.match(workflow, /context: images\/opencode-free-agent/);
    assert.match(workflow, /push-by-digest=true,name-canonical=true,push=true/);
    assert.match(workflow, /--network=none --cap-drop=ALL --security-opt=no-new-privileges/);
    assert.match(workflow, /opencode-free-agent\/smoke-runtime\.mjs:\/smoke-runtime\.mjs:ro/);
    assert.match(workflow, /docker buildx imagetools create/);
    assert.match(workflow, /candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(workflow, /cmp "\$evidence\/candidate-index\.json" "\$evidence\/registry-index\.json"/);
    assert.match(workflow, /assert\.equal\(runtime\.schema, 'ploinky\.opencode-free-runtime\/v1'\)/);
    assert.match(workflow, /assert\.equal\(runtime\.resolvedTools\.length, 13\)/);
    assert.match(workflow, /assert\.deepEqual\(runtime\.lastPermissionRule, \{ permission: '\*', action: 'ask', pattern: '\*' \}\)/);
    assert.match(workflow, /assert\.equal\(runtime\.binarySha256, source\.binarySha256\)/);
    assert.doesNotMatch(workflow, /smoke-git-transport/);
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) {
        assert.match(use[1], /^[0-9a-f]{40}$/);
    }

    const base = 'docker.io/assistos/ploinky-node:24-trixie-tools@sha256:accd925fcbf460c1f4c7a5cd9e2d46539c615bbfad2e896cabb7556d8050a669';
    assert.equal(dockerfile.split('\n')[0], `FROM ${base}`);
    assert.equal(dockerfile.match(/^FROM /gm)?.length, 1);
    assert.ok(workflow.includes(`BASE_IMAGE: ${base}`));
    assert.match(dockerfile, /^ARG TARGETARCH$/m);
    assert.match(dockerfile, /releases\/download\/v1\.18\.31\/\$asset/);
    assert.match(dockerfile, /amd64\) asset=opencode-linux-x64\.tar\.gz;\s+sha=e9312be75ed803b7415fc2aeabda1f4fe938912a39673762dc0c38c0e11ebde4 ;;/);
    assert.match(dockerfile, /arm64\) asset=opencode-linux-arm64\.tar\.gz;\s+sha=d4e332f46b227448582c0d9fc75f6f826dfe95c9f751bc2011fc4d937a042be6 ;;/);
    assert.match(dockerfile, /\| sha256sum --check --strict -;/);
    assert.match(dockerfile, /tar -xzf \/tmp\/opencode\.tar\.gz -C \/opt\/opencode\/bin;/);
    assert.match(dockerfile, /test "\$\(\/opt\/opencode\/bin\/opencode --version\)" = 1\.18\.31;/);
    assert.match(dockerfile, /cli_version=1\.18\.31\\nrelease_asset=%s\\nrelease_asset_sha256=%s\\nbinary_sha256=%s\\n/);
    assert.match(dockerfile, /> \/opt\/opencode-free\/source\.contract;/);
    assert.match(dockerfile, /^COPY opencode\.json \/opt\/opencode-free\/config\/opencode\/opencode\.json$/m);
    assert.match(dockerfile, /chown -R root:root \/opt\/opencode-free \/opt\/opencode;/);
    assert.match(dockerfile, /chmod 0444 \/opt\/opencode-free\/config\/opencode\/opencode\.json \/opt\/opencode-free\/source\.contract;/);
    assert.match(dockerfile, /chmod 0555 \/opt\/opencode-free\/config\/opencode \/opt\/opencode-free\/config \/opt\/opencode-free;/);
    assert.match(dockerfile, /chown 1000:1000 \/var\/tmp\/opencode-free;/);
    assert.match(dockerfile, /^USER root$/m);
    assert.equal(dockerfile.trimEnd().split('\n').at(-1), 'USER 1000:1000');
    assert.doesNotMatch(dockerfile, /latest/);

    assert.deepEqual(config.permission, { '*': 'ask' });
    assert.equal(config.default_agent, 'chat');
    assert.equal(Object.hasOwn(config, 'tools'), false);
    assert.deepEqual(config.enabled_providers, ['opencode']);
    assert.equal(config.model, 'opencode/big-pickle');
    assert.equal(config.small_model, 'opencode/big-pickle');
    assert.equal(config.autoupdate, false);
    assert.equal(config.share, 'disabled');
    assert.deepEqual(config.agent, { chat: { mode: 'primary', description: 'Plain chat answer.',
        prompt: "You are a helpful assistant. Answer the user's message directly in plain text." } });

    assert.match(runtime, /\['debug', 'agent', 'chat', '--pure'\]/);
    assert.match(runtime, /schema: 'ploinky\.opencode-free-runtime\/v1'/);
    assert.match(runtime, /\/var\/tmp\/opencode-free\/proof-/);
    assert.doesNotMatch(runtime, /API_KEY|'run'|--print-logs|https:\/\//);
});

test('local-llm amd64 image pins llama.cpp and Ollama CUDA releases, with no weights', () => {
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const dockerfile = read('images/local-llm/Dockerfile');
    const lock = JSON.parse(read('images/local-llm/sources.lock.json'));

    const base = 'docker.io/assistos/ploinky-node:24-trixie-tools@sha256:accd925fcbf460c1f4c7a5cd9e2d46539c615bbfad2e896cabb7556d8050a669';
    // A digest-pinned builder stage for ik_llama.cpp, then the runtime stage on the pinned base.
    const froms = dockerfile.match(/^FROM .*$/gm);
    assert.equal(froms.length, 2);
    assert.equal(froms[0], `FROM ${lock.ikLlamaCpp.builderImage} AS ik-builder`);
    assert.match(lock.ikLlamaCpp.builderImage, /^docker\.io\/nvidia\/cuda@sha256:[0-9a-f]{64}$/);
    assert.equal(froms[1], `FROM ${base}`);
    assert.equal(lock.baseImage, base);
    assert.equal(lock.architecture, 'amd64');
    assert.match(dockerfile, /test "\$\{TARGETARCH:-amd64\}" = amd64;/);
    assert.match(dockerfile, /llama=b11159; ollama=0\.34\.4;/);
    assert.equal(lock.llamaCpp.tag, 'b11159');
    assert.equal(lock.ollama.version, '0.34.4');
    // Every downloaded asset is checked against the lock's sha256.
    for (const asset of [...lock.llamaCpp.assets, lock.ollama.asset]) {
        assert.match(asset.sha256, /^[0-9a-f]{64}$/);
        assert.ok(dockerfile.includes(asset.sha256), asset.name);
        assert.ok(asset.url.startsWith('https://github.com/'), asset.name);
    }
    assert.match(dockerfile, /sha256sum --check --strict -;/);
    assert.match(dockerfile, /grep -q "build 11159,"/);
    assert.match(dockerfile, /grep -q "version is \$ollama"/);
    assert.match(dockerfile, /createZstdDecompress/);
    // The granted driver libraries and nvidia-smi come from the Box at runtime.
    assert.match(dockerfile, /^ENV PATH=\/usr\/local\/nvidia\/bin:\/opt\/llama\.cpp:\/opt\/ollama\/bin:/m);
    assert.doesNotMatch(dockerfile.match(/^ENV PATH=.*$/m)[0], /ik_llama/, 'both servers are named llama-server; ik stays off PATH');
    assert.match(dockerfile, /^ENV LD_LIBRARY_PATH=\/usr\/local\/nvidia\/lib64$/m);
    assert.match(dockerfile, /^ENTRYPOINT \[\]$/m);
    assert.equal(dockerfile.trimEnd().split('\n').at(-1), 'USER 1000:1000');
    assert.doesNotMatch(dockerfile, /\.gguf|safetensors|ollama pull|huggingface|:latest/);

    assert.match(workflow, /^on:\n {2}workflow_dispatch:\n/m);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/local-llm/);
    assert.ok(workflow.includes(`BASE_IMAGE: ${base}`));
    // amd64 is not rebuilt: the published digest is reused and proven again (B1).
    assert.doesNotMatch(workflow, /platforms: linux\/amd64/);
    assert.match(workflow, /^ {2}AMD64_DIGEST: sha256:b6c79af2aad08b542339346f4a985c84d5cbcacc31e8c6df45f951da7ba0fbf7$/m);
    assert.match(workflow, /^ {2}AMD64_REVISION: 95ba10a2be4eb1aeb0d9612186c746ae9d7b9efe$/m);
    assert.match(workflow, /= "\$AMD64_REVISION"/);
    // Only arm64 is built, natively, and nothing is emulated. latest moves only on an explicit dispatch (index test).
    assert.doesNotMatch(workflow, /setup-qemu/);
    assert.match(workflow, /push-by-digest=true,name-canonical=true,push=true/);
    assert.match(workflow, /--network=none --cap-drop=ALL --security-opt=no-new-privileges/);
    assert.match(workflow, /-path "\*\/blobs\/sha256-\*"/);
    assert.match(workflow, /test "\$weights" = 0/);
    assert.match(workflow, /grep -v "libcuda\.so\.1"/);
    assert.match(workflow, /candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(workflow, /timeout-minutes: 90$/m);
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) {
        assert.match(use[1], /^[0-9a-f]{40}$/);
    }
});

test('local-llm arm64 image: llama.cpp for NVIDIA GB10 from pinned release assets, same layout, vLLM only in its lock', () => {
    const dockerfile = read('images/local-llm/Dockerfile.arm64');
    const amd64 = read('images/local-llm/Dockerfile');
    const lock = JSON.parse(read('images/local-llm/sources.lock.arm64.json'));
    const runners = JSON.parse(read('images/local-llm/runners.lock.arm64.json'));
    const base = 'docker.io/assistos/ploinky-node:24-trixie-tools@sha256:accd925fcbf460c1f4c7a5cd9e2d46539c615bbfad2e896cabb7556d8050a669';
    assert.deepEqual(dockerfile.match(/^FROM .*$/gm), [`FROM ${base}`]);
    assert.equal(lock.baseImage, base);
    assert.equal(lock.architecture, 'arm64');
    assert.match(dockerfile, /test "\$\{TARGETARCH:-arm64\}" = arm64;/);
    assert.match(dockerfile, /test "\$\(uname -m\)" = aarch64;/);
    // L1 (decision 1): ggml-org's CUDA 13.4 arm64 release pair, pinned by sha256.
    assert.equal(lock.llamaCpp.tag, 'b11159');
    assert.equal(lock.llamaCpp.cuda, '13.4');
    assert.deepEqual(lock.llamaCpp.gpuComputeCapabilities, ['12.1']);
    assert.deepEqual(lock.llamaCpp.assets.map((asset) => asset.sha256), [
        '258c9dc7c6c02fd2d805ebf9511876ab7b9d7b2d3f0c2166454d682ccae7644b',
        '34d8602d0084b2498dbf0c436fe2d1d4e54ba577b8d5567eb56990e8fff11bfa',
    ]);
    for (const asset of [...lock.llamaCpp.assets, lock.uv.asset]) {
        assert.ok(dockerfile.includes(asset.sha256), asset.name);
        assert.ok(asset.url.startsWith('https://github.com/'), asset.name);
        assert.match(asset.name, /arm64|aarch64/, asset.name);
    }
    assert.match(dockerfile, /sha256sum --check --strict -;/);
    assert.match(dockerfile, /grep -q "build 11159,"/);
    // source.contract names the platform and the GPUs the CUDA runner was built for (DS005).
    for (const line of ['architecture=arm64', 'llama_cpp=%s', 'llama_cpp_cuda=13.4', 'llama_cpp_build=release', 'gpu_compute_capabilities=12.1']) {
        assert.ok(dockerfile.includes(line), line);
    }
    // No other runner, and nothing proprietary: decision 2 (no Ollama), LM Studio amd64-only.
    // (Comments explain the absence, and PATH keeps amd64's /opt/ollama/bin entry; the instructions fetch none of them.)
    const instructions = dockerfile.split('\n').filter((line) => !/^\s*#/.test(line) && !/^ENV PATH=/.test(line)).join('\n');
    assert.doesNotMatch(instructions, /ollama|ik_llama|lmstudio|llmster|\.gguf|safetensors|huggingface|:latest/i);
    // The arm64 runner lock holds vLLM only (experimental on unified memory, installed on demand): the amd64 entry's
    // version, licence and checks, the same distributions at the same versions, as aarch64 or pure-Python wheels
    // from the same host, and the same pinned tokenizer vocabulary. Nothing new is downloaded from anywhere else.
    assert.equal(runners.schema, 'local-llm.runners-lock/v1');
    assert.deepEqual(Object.keys(runners.runners), ['vllm']);
    const vllm = runners.runners.vllm;
    const amdVllm = JSON.parse(read('images/local-llm/runners.lock.json')).runners.vllm;
    for (const key of ['version', 'kind', 'licence', 'check']) assert.deepEqual(vllm[key], amdVllm[key], key);
    const wheels = (files) => files.filter((file) => file.name.endsWith('.whl'));
    const distributions = (files) => wheels(files).map((file) => file.name.split('-').slice(0, 2).join('==').replace(/[-_.]+(?=[^=]*==)/g, '-').toLowerCase()).sort();
    assert.equal(wheels(vllm.files).length, 196);
    assert.deepEqual(distributions(vllm.files), distributions(amdVllm.files));
    // Installable by the image's CPython 3.13 on aarch64 with glibc 2.41 (Debian trixie): at least one tag triple
    // of the (possibly compressed) wheel tags is cp313-cp313, cp3X-abi3 with X <= 13, or py3-none, on
    // manylinux_2_Y_aarch64 with Y <= 41, manylinux2014_aarch64 or any. musllinux, free-threaded cp313t and
    // bare linux_aarch64 never qualify.
    const installable = (name) => {
        const [py, abi, plat] = name.slice(0, -'.whl'.length).split('-').slice(-3).map((tags) => tags.split('.'));
        const interpreter = (p, a) => (p === 'cp313' && a === 'cp313')
            || (/^cp3\d+$/.test(p) && Number(p.slice(3)) <= 13 && a === 'abi3')
            || (/^py3(\d+)?$/.test(p) && Number(p.slice(3) || 0) <= 13 && a === 'none');
        const platform = (pl) => pl === 'any' || pl === 'manylinux2014_aarch64'
            || (/^manylinux_2_(\d+)_aarch64$/.test(pl) && Number(/^manylinux_2_(\d+)_/.exec(pl)[1]) <= 41);
        return py.some((p) => abi.some((a) => interpreter(p, a))) && plat.some(platform);
    };
    for (const file of wheels(vllm.files)) {
        assert.ok(installable(file.name), `${file.name} is not installable by CPython 3.13 on aarch64 with glibc 2.41`);
        assert.doesNotMatch(file.name, /x86_64|musllinux|cp313t|-linux_aarch64/, file.name);
        assert.match(file.url, new RegExp(`^https://files\\.pythonhosted\\.org/packages/[0-9a-f/]+/${file.name.replace(/[.+]/g, '\\$&')}$`), file.name);
        assert.match(file.sha256, /^[0-9a-f]{64}$/, file.name);
        assert.ok(Number.isInteger(file.size) && file.size > 0, file.name);
    }
    assert.deepEqual(vllm.files.filter((file) => !file.name.endsWith('.whl')), amdVllm.files.filter((file) => !file.name.endsWith('.whl')));
    const hosts = (files) => [...new Set(files.map((file) => new URL(file.url).hostname))].sort();
    assert.deepEqual(hosts(vllm.files), hosts(amdVllm.files));
    assert.deepEqual(vllm.files.map((file) => file.name), [...wheels(vllm.files).map((file) => file.name).sort(), 'o200k_base.tiktoken']);
    // Triton's launcher needs a C compiler and the Python headers at run time; uv rebuilds the environment offline.
    assert.match(dockerfile, /apt-get install -y --no-install-recommends gcc libc6-dev libpython3\.13-dev;/);
    assert.match(dockerfile, /^COPY --chmod=0444 runners\.lock\.arm64\.json \/opt\/local-llm\/runners\.lock\.json$/m);
    // The same PATH, library path, entrypoint and user as amd64, so the JavaScript never branches on the architecture.
    for (const pattern of [/^ENV PATH=.*$/m, /^ENV LD_LIBRARY_PATH=.*$/m, /^ENTRYPOINT \[\]$/m]) {
        assert.equal(dockerfile.match(pattern)[0], amd64.match(pattern)[0]);
    }
    assert.equal(dockerfile.trimEnd().split('\n').at(-1), 'USER 1000:1000');
    assert.match(dockerfile, /install -d -o 1000 -g 1000 -m 0755 \/opt\/runners;/);
});

test('local-llm arm64 proof and the index fail closed on the exact digests', () => {
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const arm64 = workflow.split('\n  arm64:\n')[1].split('\n  install-check:\n')[0];
    assert.match(arm64, /runs-on: ubuntu-24\.04-arm$/m);
    assert.match(arm64, /file: images\/local-llm\/Dockerfile\.arm64$/m);
    assert.match(arm64, /platforms: linux\/arm64$/m);
    assert.match(arm64, /provenance: false$/m);
    assert.match(arm64, /\.Architecture\}\}' "\$image"\)" = arm64/);
    assert.match(arm64, /= "\$GITHUB_SHA"/);
    // The amd64 proof rules that apply: uid, version, weight scan, LM Studio absence, closure, lock bytes, contract.
    for (const rule of ['test "$(sed -n 1p "$evidence/runtime.txt")" = 1000', "grep -q 'build 11159,'", 'test "$weights" = 0',
        'test "$lmstudio_files" = 0', 'grep -v "libcuda.so.1"', 'cmp images/local-llm/runners.lock.arm64.json "$evidence/runners.lock.json"',
        "grep -qx 'gpu_compute_capabilities=12.1'", "grep -qx 'architecture=arm64'"]) {
        assert.ok(arm64.includes(rule), rule);
    }
    // Native GB10 code, checked without a GPU from the pinned CUDA image.
    assert.match(workflow, /^ {2}CUOBJDUMP_IMAGE: docker\.io\/nvidia\/cuda@sha256:[0-9a-f]{64}$/m);
    assert.match(arm64, /cuobjdump --list-elf \/proof\/libggml-cuda\.so/);
    assert.match(arm64, /grep -q 'sm_121a' "\$evidence\/cuobjdump\.txt"/);
    // Each architecture's install check reads its own lock.
    assert.match(workflow, /lock: images\/local-llm\/runners\.lock\.json$/m);
    assert.match(workflow, /lock: images\/local-llm\/runners\.lock\.arm64\.json$/m);
    assert.match(workflow, /cmp "\$LOCK" -/);
    // The index comes only after both proofs and both install checks, from the exact digests, and is verified.
    const index = workflow.split('\n  index:\n')[1];
    assert.match(index, /needs: \[amd64, arm64, install-check\]$/m);
    assert.match(index, /test "\$AMD64" = "\$AMD64_DIGEST"/);
    assert.match(index, /imagetools create --tag "\$staging" \\\n\s+"docker\.io\/\$\{IMAGE_NAME\}@\$\{AMD64\}" "docker\.io\/\$\{IMAGE_NAME\}@\$\{ARM64\}"/);
    assert.match(index, /index\.manifests\.length !== 2/);
    assert.match(index, /Refusing to overwrite existing staging tag/);
    assert.match(index, /echo "digest=\$index_digest" >> "\$GITHUB_OUTPUT"/);
    // latest moves only when dispatched with promote_latest (default false), after the index, to the exact
    // proven index digest, and is confirmed read-only afterwards. No other job names latest.
    assert.match(workflow, /promote_latest:\n\s+description: [^\n]+\n\s+required: true\n\s+default: false\n\s+type: boolean\n/);
    const promote = workflow.split('\n  promote:\n')[1];
    assert.match(promote, /if: \$\{\{ inputs\.promote_latest == true \}\}$/m);
    assert.match(promote, /needs: index$/m);
    assert.match(promote, /INDEX_DIGEST: \$\{\{ needs\.index\.outputs\.digest \}\}$/m);
    assert.ok(promote.includes('test "sha256:$(sha256sum "$RUNNER_TEMP/candidate-index.json" | cut -d \' \' -f1)" = "$INDEX_DIGEST"'));
    assert.ok(promote.includes('imagetools create --tag "docker.io/${IMAGE_NAME}:latest" "docker.io/${IMAGE_NAME}@${INDEX_DIGEST}"'));
    assert.match(promote, /test "\$latest_digest" = "\$INDEX_DIGEST"/);
    assert.equal(workflow.split(':latest').length, promote.split(':latest').length);
});

test('local-llm image builds ik_llama.cpp from a pinned commit for this machine family, off PATH', () => {
    const dockerfile = read('images/local-llm/Dockerfile');
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const lock = JSON.parse(read('images/local-llm/sources.lock.json'));
    const ik = lock.ikLlamaCpp;
    assert.equal(ik.repository, 'https://github.com/ikawrakow/ik_llama.cpp.git');
    assert.match(ik.commit, /^[0-9a-f]{40}$/);
    assert.equal(ik.cudaArchitectures, '86-real;89-real');
    assert.ok(dockerfile.includes(`ARG IK_COMMIT=${ik.commit}`));
    assert.ok(dockerfile.includes(`ARG IK_CUDA_ARCHITECTURES=${ik.cudaArchitectures}`));
    // The source is the exact commit, not a branch or a tarball.
    assert.match(dockerfile, /git fetch --depth 1 origin "\$IK_COMMIT"/);
    assert.match(dockerfile, /test "\$\(git rev-parse HEAD\)" = "\$IK_COMMIT"/);
    // Portable CPU code (no -march=native), no NCCL, and libraries found next to the binary.
    for (const flag of ['-DGGML_NATIVE=OFF', '-DGGML_AVX2=ON', '-DGGML_FMA=ON', '-DGGML_F16C=ON', '-DGGML_NCCL=OFF',
        '-DGGML_CUDA=ON', '-DCMAKE_BUILD_WITH_INSTALL_RPATH=ON', '--target llama-server',
        '-DCMAKE_EXE_LINKER_FLAGS=-Wl,--allow-shlib-undefined']) {
        assert.ok(dockerfile.includes(flag), flag);
    }
    assert.ok(dockerfile.includes("-DCMAKE_INSTALL_RPATH='$ORIGIN:$ORIGIN/../llama.cpp'"));
    assert.match(dockerfile, /^COPY --from=ik-builder \/out\/ \/opt\/ik_llama\.cpp\/$/m);
    assert.match(dockerfile, /printf '[^']*ik_llama_cpp=%s\\n[^']*'[^\n]*"\$ik"/);
    // The workflow proves the ik build, its library closure and its commit in the published digest.
    assert.match(workflow, /LD_LIBRARY_PATH=\/usr\/local\/nvidia\/lib64 missing \/opt\/ik_llama\.cpp\/llama-server/);
    // ik's own libraries must resolve next to it, never to llama.cpp's same-named copies,
    // and the CUDA runtime from /opt/llama.cpp.
    assert.ok(workflow.includes('test "$(printf "%s\\n" "$closure" | grep -cE "lib(ggml|llama|mtmd)\\.so => /opt/ik_llama\\.cpp/lib")" = 3'));
    assert.ok(workflow.includes('test "$(printf "%s\\n" "$closure" | grep -cE "lib(cudart|cublas|cublasLt)\\.so\\.12 => /opt/ik_llama\\.cpp/\\.\\./llama\\.cpp/")" = 3'));
    assert.ok(workflow.includes(`grep -qx 'ik_llama_cpp=${ik.commit}'`));
    assert.match(workflow, /Free runner disk/);
});

test('local-llm workflow proof steps fail closed', () => {
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    // The weight scan runs as root with read-search over every directory
    // (uid 1000's Ollama store included), and any find error fails the step.
    const scan = workflow.split('\n').find((line) => line.includes('weights="$(run --user 0'));
    assert.ok(scan, 'weight scan');
    assert.match(scan, /--cap-add=DAC_READ_SEARCH/);
    assert.match(workflow, /2>"\$scan_errors"/);
    assert.match(workflow, /test ! -s "\$scan_errors"/);
    // The runtime versions gate the step from the outer shell as well.
    assert.match(workflow, /run "\$image" sh -c 'set -eu; id -u;/);
    assert.match(workflow, /grep -q 'build 11159,' "\$evidence\/runtime\.txt"/);
    assert.match(workflow, /grep -q 'version is 0\.34\.4' "\$evidence\/runtime\.txt"/);
    // A missing library fails the closure check instead of passing it.
    assert.match(workflow, /missing\(\) \{ test -f "\$1" \|\| \{ echo "missing file: \$1"; return 0; \};/);
});

test('local-llm image ships the runner lock, a pinned uv and a runner directory for uid 1000, and CI installs every lock entry', () => {
    const dockerfile = read('images/local-llm/Dockerfile');
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const sources = JSON.parse(read('images/local-llm/sources.lock.json'));
    const runners = JSON.parse(read('images/local-llm/runners.lock.json'));
    assert.equal(runners.schema, 'local-llm.runners-lock/v1');
    const hosts = ['files.pythonhosted.org', 'github.com', 'codeload.github.com', 'download.pytorch.org', 'openaipublic.blob.core.windows.net', 'llmster.lmstudio.ai'];
    for (const [id, entry] of Object.entries(runners.runners)) {
        assert.ok(['python', 'archive'].includes(entry.kind), id);
        assert.ok(entry.files.length > 0, id);
        for (const file of entry.files) {
            const url = new URL(file.url);
            assert.equal(url.protocol, 'https:', file.name);
            assert.ok(hosts.includes(url.hostname), `${file.name} on ${url.hostname}`);
            assert.match(file.sha256, /^[0-9a-f]{64}$/, file.name);
            assert.ok(Number.isSafeInteger(file.size) && file.size > 0, file.name);
        }
    }
    // gpt-oss's tokenizer vocabulary is pinned for vLLM, so nothing is fetched
    // at run time; the sha256 is the one tiktoken and openai_harmony check.
    assert.deepEqual(runners.runners.vllm.files.find((file) => file.name === 'o200k_base.tiktoken'), {
        name: 'o200k_base.tiktoken',
        url: 'https://openaipublic.blob.core.windows.net/encodings/o200k_base.tiktoken',
        size: 3613922,
        sha256: '446a9538cb6c348e3516120d7c08b09f57c36495e2acfffe59a5bf8b0cfb1a2d',
        into: 'tiktoken',
    });
    // TabbyAPI is AGPL-3.0: installed from upstream only after an admin accepts the notice.
    assert.equal(runners.runners.tabbyapi.licence.name, 'AGPL-3.0');
    assert.equal(runners.runners.tabbyapi.licence.requiresAcceptance, true);
    // The lock is read-only in the image; admins pick a runner id, never a URL.
    assert.match(dockerfile, /^COPY --chmod=0444 runners\.lock\.json \/opt\/local-llm\/runners\.lock\.json$/m);
    // uv is pinned by version and sha256 like every other download.
    assert.match(sources.uv.version, /^\d+\.\d+\.\d+$/);
    assert.match(sources.uv.asset.sha256, /^[0-9a-f]{64}$/);
    assert.ok(sources.uv.asset.url.startsWith('https://github.com/astral-sh/uv/releases/download/'));
    assert.ok(dockerfile.includes(sources.uv.asset.sha256));
    assert.ok(dockerfile.includes(`uv=${sources.uv.version};`));
    assert.match(dockerfile, /\/usr\/local\/bin\/uv --version 2>&1 \| grep -q "uv \$uv"/);
    // Triton compiles its C launcher at run time.
    assert.match(dockerfile, /apt-get install -y --no-install-recommends gcc libc6-dev libpython3\.13-dev;/);
    // The runnable copies are built in the container's own filesystem, by uid 1000.
    assert.match(dockerfile, /install -d -o 1000 -g 1000 -m 0755 \/opt\/runners;/);
    assert.ok(workflow.includes(`grep -qx 'uv=${sources.uv.version}'`));
    // CI installs each lock entry in the published image, in its own job after the build.
    assert.match(workflow, /^ {2}install-check:\n {4}name: [^\n]+\n {4}needs: \[amd64, arm64\]$/m);
    assert.match(workflow, /LOCAL_LLMS_COMMIT: [0-9a-f]{40}$/m);
    // A real, pushed local-llms commit, never a placeholder.
    assert.doesNotMatch(workflow, /LOCAL_LLMS_COMMIT: 0{40}$/m);
    assert.match(workflow, /cmp images\/local-llm\/runners\.lock\.json "\$evidence\/runners\.lock\.json"/);
    assert.match(workflow, /node \/code\/local-llm\/tools\/runner_install_check\.mjs "\$runner"/);
    assert.match(workflow, /for runner in \$\(node -e/);
    assert.match(workflow.split('\n  install-check:\n')[1] || '', /--cap-drop=ALL --security-opt=no-new-privileges/);
});

// LM Studio (runners plan §5.7, handoff decision L3): proprietary, so it is
// never part of the image, and CI never downloads it, which would accept its
// Terms on behalf of whoever runs CI. Its lock entry is validated offline.
test('local-llm pins LM Studio as a proprietary lock entry that CI validates without downloading and the image never contains', () => {
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const dockerfile = read('images/local-llm/Dockerfile');
    const runners = JSON.parse(read('images/local-llm/runners.lock.json'));
    const lmstudio = runners.runners.lmstudio;
    assert.equal(lmstudio.version, '0.0.25-1');
    assert.equal(lmstudio.kind, 'archive');
    assert.deepEqual(lmstudio.files, [{
        name: '0.0.25-1-linux-x64.full+cuda12.tar.gz',
        url: 'https://llmster.lmstudio.ai/download/0.0.25-1-linux-x64.full%2Bcuda12.tar.gz',
        size: 1105623572,
        sha256: '46778639487e1f6def9a722d3a4e0c5ce8960f4cd290be79832a36d7f95a1e6a',
        // llmster and .bundle/ sit at the tarball's root.
        strip: 0,
    }]);
    assert.equal(lmstudio.licence.url, 'https://lmstudio.ai/app-terms');
    assert.match(lmstudio.licence.name, /August 23, 2026/);
    assert.equal(lmstudio.licence.proprietary, true);
    assert.equal(lmstudio.licence.requiresAcceptance, true);
    for (const clause of [/internal business purposes/, /software-as-a-service/, /published interfaces/, /internal use only/i]) {
        assert.match(lmstudio.licence.notice, clause);
    }
    // Only LM Studio is proprietary.
    assert.deepEqual(Object.keys(runners.runners).filter((id) => runners.runners[id].licence.proprietary), ['lmstudio']);
    // Nothing in the Dockerfile fetches it.
    assert.doesNotMatch(dockerfile, /lmstudio\.ai|llmster/);
    const install = workflow.split('\n  install-check:\n')[1] || '';
    // A proprietary entry runs the check in validate-only mode with no network.
    assert.match(install, /licence\.proprietary === true/);
    assert.match(install, /net=\(--network=none\); mode=\(--validate-only\)/);
    assert.match(install, /docker run --rm "\$\{net\[@\]\}" --cap-drop=ALL --security-opt=no-new-privileges/);
    assert.match(install, /runner_install_check\.mjs "\$runner" "\$\{mode\[@\]\}"/);
    assert.match(install, /grep -q '"downloaded": false' "\$evidence\/\$runner\.json"/);
    // The publish proof scans the image for LM Studio files, as root, failing closed.
    const scan = workflow.split('\n').find((line) => line.includes('lmstudio_files="$(run --user 0'));
    assert.ok(scan, 'LM Studio file scan');
    assert.match(scan, /--cap-add=DAC_READ_SEARCH/);
    assert.match(scan, /-iname "\*llmster\*"/);
    assert.match(workflow, /test "\$lmstudio_files" = 0/);
});

// The LM Studio runner loads models through LM Studio's MIT SDK, which sets
// every memory flag (runners plan §5.7, handoff decision L9). The SDK and its
// dependencies are MIT, ISC or Apache-2.0 and go in the image, each pinned by
// its npm sha512; LM Studio itself never does.
test('local-llm image carries the pinned LM Studio SDK closure, fetched by sha512, and proves it imports', () => {
    const dockerfile = read('images/local-llm/Dockerfile');
    const workflow = read('.github/workflows/publish-local-llm-image.yml');
    const sources = JSON.parse(read('images/local-llm/sources.lock.json'));
    const sdk = sources.lmstudioSdk;
    assert.equal(sdk.version, '2.0.0');
    assert.equal(sdk.directory, '/opt/local-llm/lmstudio-sdk');
    assert.deepEqual(sdk.packages.map((pkg) => pkg.name).sort(), [
        '@lmstudio/lms-isomorphic', '@lmstudio/sdk', 'ansi-styles', 'chalk', 'color-convert', 'color-name',
        'has-flag', 'jsonschema', 'supports-color', 'ws', 'zod', 'zod-to-json-schema',
    ]);
    for (const pkg of sdk.packages) {
        assert.ok(['MIT', 'ISC', 'Apache-2.0'].includes(pkg.license), pkg.name);
        const base = pkg.name.split('/').pop();
        assert.equal(pkg.url, `https://registry.npmjs.org/${pkg.name}/-/${base}-${pkg.version}.tgz`, pkg.name);
        assert.match(pkg.sha512, /^[0-9a-f]{128}$/, pkg.name);
        // Every package is fetched and checked by its pinned hash.
        assert.ok(dockerfile.includes(`npm_pkg ${pkg.name} ${pkg.version} ${pkg.sha512}`), pkg.name);
    }
    assert.match(dockerfile, /sha512sum --check --strict -/);
    assert.match(dockerfile, /tar -xzf "\/tmp\/\$base\.tgz" -C "\$sdk\/node_modules\/\$name" --strip-components=1 --no-same-owner;/);
    assert.match(dockerfile, /printf 'lmstudio_sdk=%s\\n' "\$sdk_version" >> \/opt\/local-llm\/source\.contract;/);
    // The proof imports it from the exact digest and checks its version.
    assert.ok(workflow.includes(`grep -qx 'lmstudio_sdk=${sdk.version}'`));
    assert.match(workflow, /createRequire\(\\"\/opt\/local-llm\/lmstudio-sdk\/\\"\)/);
});

test('umami-agent workflow source-builds a pinned prefix over the retained stack', () => {
    const workflow = read('.github/workflows/publish-umami-agent-image.yml');
    const dockerfile = read('images/umami-agent/Dockerfile');
    const sources = JSON.parse(read('images/umami-agent/sources.lock.json'));

    assert.match(workflow, /images\/umami-agent/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/umami-agent/);
    assert.match(workflow, /IMAGE_TAG:\s*umami-stack/);
    assert.match(workflow, /platforms:\s*\$\{\{ matrix\.platform \}\}/);
    assert.match(workflow, /runner: ubuntu-24\.04-arm/);
    assert.match(workflow, /postgres --version/);
    assert.match(workflow, /bun --version/);
    assert.match(workflow, /\/opt\/umami-mcp\/dist\/index\.js/);
    assert.match(workflow, /if:\s*\$\{\{ inputs\.promote_stable == true \}\}/);
    assert.doesNotMatch(workflow, /^  push:/m);
    assert.deepEqual(dockerfile.match(/^FROM .+$/gm), [
        `FROM ${sources.runtimeBase.image} AS umami-build`, `FROM ${sources.runtimeBase.image}`,
    ]);
    assert.match(dockerfile, /BASE_PATH=\/base-agent-additional-server\/umamiAgent\/3000/);
    assert.match(dockerfile, /install --frozen-lockfile --prod=false/);
    assert.match(dockerfile, /npm run build-docker/);
    assert.match(dockerfile, /RUN rm -rf \/app && mkdir \/app/);
    assert.doesNotMatch(dockerfile, /^ARG |apk add|npm install -g|git clone|sed -i/m);
    assert.equal(sources.postgresql.version, '18.4');
    assert.equal(sources.bun.version, '1.3.14');
});

test('bwrap-runner workflow publishes only digest-proven native candidates before optional promotion', () => {
    const workflow = read('.github/workflows/publish-bwrap-runner.yml');
    const dockerfile = read('images/bwrap-runner/Dockerfile');
    const gptSmoke = read('scripts/smoke-gpt-researcher.sh');

    assert.match(workflow, /source_ref:[\s\S]*?required:\s*true/);
    assert.match(workflow, /copilot_agents_ref:[\s\S]*?required:\s*true/);
    assert.match(workflow, /achilles_cli_ref:[\s\S]*?required:\s*true/);
    assert.match(workflow, /prepublication consumer-code SHAs/);
    assert.doesNotMatch(workflow, /source_ref:[\s\S]*?default:\s*['"]?main/);
    assert.match(workflow, /\^\[0-9a-f\]\{40\}\$/);
    assert.match(workflow, /repository:\s*AssistOS-AI\/basic/);
    assert.match(workflow, /path:\s*sources\/basic/);
    assert.match(workflow, /repository:\s*AssistOS-AI\/copilot-agents/);
    assert.match(workflow, /repository:\s*AssistOS-AI\/AchillesCLI/);
    assert.match(workflow, /git -C sources\/basic rev-parse HEAD/);
    assert.match(workflow, /git -C sources\/copilot-agents rev-parse HEAD/);
    assert.match(workflow, /git -C sources\/AchillesCLI rev-parse HEAD/);
    assert.match(workflow, /git status --porcelain=v1/);
    assert.match(workflow, /context:\s*\.\/sources\/basic\/bwrap-runner/);
    assert.match(workflow, /file:\s*\.\/images\/bwrap-runner\/Dockerfile/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/bwrap-runner/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04(?:\s|$)/);
    assert.match(workflow, /runner:\s*ubuntu-24\.04-arm/);
    assert.match(workflow, /platform:\s*linux\/amd64/);
    assert.match(workflow, /platform:\s*linux\/arm64/);
    assert.doesNotMatch(workflow, /setup-qemu-action/);
    assert.match(workflow, /push-by-digest=true/);
    assert.match(workflow, /name-canonical=true/);
    assert.match(workflow, /\^sha256:\[0-9a-f\]\{64\}\$/);
    assert.match(workflow, /podman info --format '\{\{\.Host\.Security\.Rootless\}\}'/);
    assert.match(workflow, /--cap-drop=all/);
    assert.match(workflow, /--security-opt=no-new-privileges/);
    assert.match(workflow, /for field in CapInh CapPrm CapEff CapBnd CapAmb/);
    assert.doesNotMatch(workflow, /--privileged|--cap-add|seccomp=unconfined|apparmor=unconfined/);
    assert.match(workflow, /bwrapRunnerNative\.mjs/);
    assert.match(workflow, /Run canonical health and representative task by digest/);
    assert.match(workflow, /Prepare Open Interpreter and prove deterministic disposition/);
    assert.match(workflow, /PLOINKY_OPEN_INTERPRETER_BOX_UNAVAILABLE/);
    assert.match(workflow, /Run GPTResearcher cold-install, readiness, and task smoke/);
    const gptStep = workflow.match(
        /- name: Run GPTResearcher cold-install, readiness, and task smoke[\s\S]*?(?=\n      - name:)/,
    )?.[0] || '';
    assert.ok(gptStep);
    assert.ok(gptStep.indexOf('/smoke-gpt-researcher.sh install') < gptStep.indexOf('--network=none'));
    assert.ok(gptStep.indexOf('--network=none') < gptStep.indexOf('/smoke-gpt-researcher.sh smoke'));
    assert.match(workflow, /bwrap-runner-proof-\$\{\{ matrix\.arch \}\}/);
    assert.match(workflow, /Assemble and inspect only the proven native digests/);
    assert.match(workflow, /assert\.equal\(index\.manifests\.length, 2\)/);
    assert.match(workflow, /members\.get\('linux\/amd64'\)/);
    assert.match(workflow, /members\.get\('linux\/arm64'\)/);
    assert.match(workflow, /candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(workflow, /Upload assembled candidate evidence/);
    assert.match(workflow, /release-evidence\.json/);
    assert.match(workflow, /candidateDigest: process\.env\.CANDIDATE_DIGEST/);
    assert.match(workflow, /consumerCodeBoundary: 'prepublication-code-only'/);
    assert.match(workflow, /if:\s*\$\{\{ inputs\.promote_stable == true \}\}/);
    const assemble = workflow.indexOf('Assemble and inspect only the proven native digests');
    const promote = workflow.indexOf('Move stable tag by exact proven candidate digest');
    const confirm = workflow.indexOf('Read-only post-promotion digest confirmation');
    assert.ok(assemble > 0 && assemble < promote && promote < confirm);
    assert.match(workflow, /password:\s*\$\{\{\s*secrets\.DOCKERHUB_TOKEN\s*\}\}/);
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) {
        assert.match(use[1], /^[0-9a-f]{40}$/, `workflow action is not SHA-pinned: ${use[0]}`);
    }

    const base = 'docker.io/library/node:24.20.0-trixie-slim@sha256:50c3b2f6988dfc307b86e5301d69611af31f4789bdf232863b07d3b02fe55ae0';
    assert.equal(dockerfile.split('\n')[0], `FROM ${base} AS node-runtime`);
    assert.ok(workflow.includes(`BASE_IMAGE: ${base}`));
    const pythonBase = 'docker.io/library/python:3.12.14-slim-trixie@sha256:78387bc3881b8273120a12ebe6c1ab22b018ccc2c9adf565ae1ac9b536e184ea';
    assert.ok(dockerfile.includes(`FROM ${pythonBase}`));
    assert.ok(workflow.includes(`PYTHON_BASE_IMAGE: ${pythonBase}`));
    assert.match(workflow, /pythonBaseImage: process\.env\.PYTHON_BASE_IMAGE/);
    assert.match(dockerfile, /test ! -e \/usr\/bin\/python3/);
    assert.match(dockerfile, /ln -s \/usr\/local\/bin\/python3 \/usr\/bin\/python3/);
    assert.doesNotMatch(dockerfile, /^\s*python3(?:-dev|-pip|-setuptools|-venv|-wheel)?\s*\\$/m);
    assert.match(workflow, /IMAGE_TAG: node24-python-trixie/);
    assert.match(workflow, /smoke-git-transport\.mjs/);
    assert.doesNotMatch(workflow, /node24-python-bookworm/);
    assert.match(dockerfile, /\blibcap2-bin\b/);
    assert.match(dockerfile, /^USER 1000:1000$/m);
    assert.match(workflow, /test "\$config_user" = 1000:1000/);
    assert.match(workflow, /--userns=keep-id:uid=1000,gid=1000/);
    assert.match(workflow, /--user=0:0 --network=none --read-only/);
    assert.match(workflow, /find \/home\/runner -xdev -type f -exec getcap/);
    assert.match(workflow, /find \/ -xdev -path \/home\/runner -prune -o -type f -exec getcap/);
    assert.doesNotMatch(gptStep, /gpt_opt|:\/opt/);
    for (const invocation of workflow.matchAll(/podman run ([^\n]+)/g)) {
        assert.ok(invocation[1].includes('--userns=keep-id:uid=1000,gid=1000')
            || invocation[1].includes('--user=0:0 --network=none --read-only'));
    }
    assert.match(dockerfile, /COPY\s+bin\/\s+\/opt\/bwrap-runner\/bin\//);
    assert.match(dockerfile, /COPY\s+lib\/\s+\/opt\/bwrap-runner\/lib\//);
    assert.match(dockerfile, /\/usr\/local\/bin\/bwrap-sandbox-exec/);

    assert.match(gptSmoke, /install-gpt-researcher\.sh/);
    assert.match(gptSmoke, /import gpt_researcher/);
    assert.match(gptSmoke, /"sameCheckoutInstall": True/);
    assert.match(gptSmoke, /"sourceModulesVerified": len\(modules\)/);
    assert.match(gptSmoke, /readiness\.sh/);
    assert.match(gptSmoke, /gpt-researcher-task-adapter-ok/);
    assert.match(gptSmoke, /sh \/consumer\/scripts\/run-research\.sh <\/dev\/null/);
    assert.match(gptSmoke, /"coldInstall":true/);
    assert.match(gptSmoke, /"network":"none","readiness":true,"minimalTask":true/);
});

test('livekit workflow builds the relocated Explorer source with centralized Dockerfile', () => {
    const workflow = read('.github/workflows/publish-livekit-server-agent.yml');
    const dockerfile = read('images/livekit-server-agent/Dockerfile');

    assert.match(workflow, /repository:\s*AssistOS-AI\/AssistOSExplorer/);
    assert.match(workflow, /path:\s*sources\/AssistOSExplorer/);
    assert.match(workflow, /ref:\s*\$\{\{ inputs\.source_ref \}\}/);
    assert.match(workflow, /source_ref:[\s\S]*?required:\s*true/);
    assert.match(workflow, /egress_image:[\s\S]*?required:\s*true/);
    assert.match(workflow, /docker\\\.io\/assistos\/livekit-egress@sha256/);
    assert.doesNotMatch(workflow, /source_ref:[\s\S]*?default:\s*['"]?main/);
    assert.match(workflow, /\^\[0-9a-f\]\{40\}\$/);
    assert.match(workflow, /refs\/heads\/main/);
    assert.doesNotMatch(workflow, /webmeetInfra|ploinky-proxy|refs\/heads\/ploinky-box/);
    assert.match(workflow, /git -C sources\/AssistOSExplorer rev-parse HEAD/);
    assert.match(workflow, /context:\s*\.\/sources\/AssistOSExplorer\/liveKitServerAgent/);
    assert.match(workflow, /file:\s*\.\/images\/livekit-server-agent\/Dockerfile/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/livekit-server-agent/);
    assert.match(workflow, /default: 'webmeet-infra'/);
    assert.match(workflow, /type=raw,value=\$\{\{ env\.IMAGE_TAG \}\}-\$\{\{ steps\.source\.outputs\.sha \}\}/);
    assert.match(workflow, /platforms: linux\/amd64,linux\/arm64/);
    assert.match(workflow, /docker\/login-action@v3/);
    assert.match(workflow, /- name: Build and push\s+id: build\s+uses: docker\/build-push-action@v6/);
    assert.match(workflow, /password:\s*\$\{\{\s*secrets\.DOCKERHUB_TOKEN\s*\}\}/);
    assert.match(workflow, /Smoke build local architecture/);
    assert.match(workflow, /docker build[\s\S]*sources\/AssistOSExplorer\/liveKitServerAgent/);
    assert.match(workflow, /for binary in livekit-server egress redis-server pulseaudio setpriv ps node npm git g\+\+ getent ip make curl nc tini/);
    assert.match(dockerfile, /Acquire::Retries "10"/);
    assert.match(dockerfile, /Acquire::https::Timeout "60"/);
    assert.match(dockerfile, /Components: main universe/);
    assert.match(dockerfile, /APT::Update::Error-Mode "any"/);
    assert.match(dockerfile, /command -v ps/);
    assert.match(workflow, /for retired in turnserver nginx certbot python3/);
    // Base images are pinned by manifest digest, not tag alone (webmeet
    // network-hardening trim: resolved via the Docker Hub registry v2 API,
    // see the comment block above the ARG lines in the Dockerfile itself).
    assert.match(dockerfile, /^ARG LIVEKIT_SERVER_IMAGE=livekit\/livekit-server:v1\.11\.0@sha256:[0-9a-f]{64}$/m);
    assert.match(dockerfile, /^ARG LIVEKIT_EGRESS_IMAGE$/m);
    assert.match(workflow, /--build-arg LIVEKIT_EGRESS_IMAGE=/);
    assert.match(workflow, /build-args:[\s\S]*LIVEKIT_EGRESS_IMAGE=/);
    assert.match(dockerfile, /livekit-egress-loopback\.contract/);
    assert.match(dockerfile, /sha256sum --check --strict/);
    assert.match(dockerfile, /^ARG NODE_BASE=node:24-bookworm-slim@sha256:[0-9a-f]{64}$/m);
    assert.match(dockerfile, /^ARG GIT_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG GXX_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG IPROUTE_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG LIBC_BIN_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG MAKE_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG NETCAT_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG TINI_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG REDIS_VERSION=\S+$/m);
    assert.match(dockerfile, /^ARG UBUNTU_SNAPSHOT=\d{8}T\d{6}Z$/m);
    assert.match(dockerfile, /snapshot\.ubuntu\.com\/ubuntu\/\$\{UBUNTU_SNAPSHOT\}/);
    assert.match(dockerfile, /"git=\$\{GIT_VERSION\}"/);
    assert.match(dockerfile, /"iproute2=\$\{IPROUTE_VERSION\}"/);
    assert.match(dockerfile, /"libc-bin=\$\{LIBC_BIN_VERSION\}"/);
    assert.match(dockerfile, /"redis-server=\$\{REDIS_VERSION\}"/);
    assert.match(dockerfile, /command -v getent/);
    assert.match(workflow, /outputs:\s+digest:\s*\$\{\{ steps\.build\.outputs\.digest \}\}/);
    assert.match(workflow, /\^sha256:\[0-9a-f\]\{64\}\$/);
    assert.match(workflow, /Published immutable image:/);
    assert.match(workflow, /GITHUB_STEP_SUMMARY/);
    assert.doesNotMatch(dockerfile, /scripts\/health\/livekit-server-agent-health\.sh/);
    assert.match(dockerfile, /ENTRYPOINT \["tini", "--"\]/);

    assert.match(dockerfile, /COPY\s+scripts\s+\/code\/scripts/);
    assert.match(dockerfile, /livekit-server/);
    assert.match(dockerfile, /\begress\b/);
    assert.match(dockerfile, /\bredis-server\b/);

    // This image contains only the SFU, Egress, Redis, and their build/runtime
    // dependencies. python3 was the runtime for a synthetic
    // "python3 -m http.server" health endpoint in liveKitServerAgent's
    // supervisor script that is being removed as part of the same
    // cross-repo change — re-check this assertion if a future change adds
    // back a python3-dependent script here.
    assert.doesNotMatch(dockerfile, /\bcoturn\b/);
    assert.doesNotMatch(dockerfile, /\bturnserver\b/);
    assert.doesNotMatch(dockerfile, /\bnginx\b/);
    assert.doesNotMatch(dockerfile, /\bcertbot\b/);
    assert.doesNotMatch(dockerfile, /\bpython3\b/);
});

test('retired Ploinky network-gateway build artifacts stay absent', () => {
    assert.equal(
        fs.existsSync(path.join(repoRoot, 'images/ploinky-network-gateway')),
        false,
    );
    assert.equal(
        fs.existsSync(path.join(repoRoot, '.github/workflows/publish-ploinky-network-gateway.yml')),
        false,
    );
    assert.doesNotMatch(read('README.md'), /ploinky-network-gateway/);
});

test('soul-gateway workflow builds source checkout with SQLite and baked gateway code', () => {
    const workflow = read('.github/workflows/publish-soul-gateway-image.yml');
    const dockerfile = read('images/soul-gateway/Dockerfile');

    assert.match(workflow, /repository:\s*AssistOS-AI\/proxies/);
    assert.match(workflow, /path:\s*sources\/proxies/);
    assert.match(workflow, /git -C sources\/proxies rev-parse --short=12 HEAD/);
    assert.match(workflow, /context:\s*\.\/sources\/proxies\/soul-gateway/);
    assert.match(workflow, /file:\s*\.\/images\/soul-gateway\/Dockerfile/);
    assert.match(workflow, /IMAGE_NAME:\s*assistos\/soul-gateway/);
    assert.match(workflow, /docker\/build-push-action@v6/);
    assert.match(workflow, /node -e "import\('node:sqlite'\)/);
    assert.match(workflow, /sqlite3 --version/);

    assert.match(dockerfile, /^ARG BASE_IMAGE=docker\.io\/assistos\/ploinky-node:24-bookworm-tools$/m);
    assert.match(dockerfile, /\bsqlite3\b/);
    assert.match(dockerfile, /WORKDIR \/opt\/soul-gateway/);
    assert.match(dockerfile, /COPY package\.json package-lock\.json \.\//);
    assert.match(dockerfile, /RUN npm ci --omit=dev/);
    assert.match(dockerfile, /COPY src \/opt\/soul-gateway\/src/);
    assert.match(dockerfile, /COPY startup\.sh install\.sh cli\.sh \/\opt\/soul-gateway\//);
});

test('ploinky-box image is a source-owned rootless Podman appliance', () => {
    const dockerfile = read('images/ploinky-box/Dockerfile');
    const readme = read('README.md');
    const instructions = dockerfileInstructions(dockerfile);
    const fromInstructions = instructions.filter(({ keyword }) => keyword === 'FROM');

    assert.match(
        dockerfile,
        /^ARG PODMAN_BASE=quay\.io\/podman\/stable@sha256:663e0dbf407987b7db3f20d3588c283a8228db17b282d2029a482d4d47e36964$/m,
    );
    assert.match(
        dockerfile,
        /^ARG NODE_RUNTIME_IMAGE=docker\.io\/library\/node:24-bookworm-slim@sha256:a9f5f7c91a432850b2a8a7797adf5eadb6c733ceed61167806cee7ea7fbc29df$/m,
    );
    assert.match(
        dockerfile,
        /^ARG CLOUDFLARED_IMAGE=docker\.io\/cloudflare\/cloudflared:2026\.7\.1@sha256:188bb03589a32affed3cf4d0590565ffe67b78866e6b5582574afab2b705bafe$/m,
    );
    assert.equal(fromInstructions.at(-1)?.source.trim(), 'FROM scratch AS runtime');
    assert.match(dockerfile, /^FROM \$PODMAN_BASE AS prepared-rootfs-base$/m);
    assert.match(dockerfile, /^FROM prepared-rootfs-base AS mcp-sdk-builder$/m);
    assert.match(dockerfile, /^FROM prepared-rootfs-base AS agentlib-builder$/m);
    assert.match(dockerfile, /^FROM prepared-rootfs-base AS webtty-builder$/m);
    assert.match(dockerfile, /^FROM prepared-rootfs-base AS prepared-rootfs$/m);
    assert.match(dockerfile, /^COPY --from=prepared-rootfs \/ \/$/m);
    for (const requiredPackage of [
        'bash', 'bind-utils', 'bzip2', 'ca-certificates', 'coreutils', 'curl',
        'diffutils', 'ffmpeg-free', 'file', 'findutils', 'fuse-overlayfs', 'gawk',
        'git', 'grep', 'gzip', 'iproute', 'iputils', 'jq', 'less', 'libcap',
        'lsof', 'nano', 'net-tools', 'netavark', 'nmap-ncat', 'openssh-clients',
        'patch', 'procps-ng', 'python3', 'rsync', 'sed', 'aardvark-dns', 'passt',
        'slirp4netns', 'tar', 'tree', 'unzip', 'util-linux-core',
        'util-linux-script', 'vim-minimal', 'wget', 'which', 'xz', 'zip',
    ]) {
        assert.match(dockerfile, new RegExp(`\\n\\s+${requiredPackage.replace('-', '\\-')} \\\\`));
    }
    const commandProbe = dockerfile.match(
        /for required_command in \\\n[\s\S]*?command -v "\$required_command" >\/dev\/null \\\n[\s\S]*?exit 1; \}; \\\n\s+done/,
    )?.[0] || '';
    assert.match(commandProbe, /missing required interactive command: \$required_command/);
    for (const requiredCommand of [
        'awk', 'bash', 'bzip2', 'curl', 'diff', 'dig', 'ffmpeg', 'file', 'find',
        'git', 'grep', 'gzip', 'host', 'jq', 'less', 'lsof', 'nano', 'nc',
        'netstat', 'node', 'npm', 'npx', 'nslookup', 'patch', 'ping', 'podman',
        'ps', 'python3', 'rsync', 'script', 'sed', 'setsid', 'ssh', 'ss', 'tar',
        'timeout', 'tree', 'unshare', 'unzip', 'vi', 'wget', 'which', 'xargs',
        'xz', 'zip',
    ]) {
        assert.match(commandProbe, new RegExp(`\\b${requiredCommand}\\b`));
    }
    assert.match(dockerfile, /rpm --setcaps shadow-utils/);
    assert.match(dockerfile, /sha256sum --check --strict/);
    assert.match(dockerfile, /cloudflared tunnel run --help/);
    assert.match(dockerfile, /--token-file/);
    assert.doesNotMatch(dockerfile, /^LABEL\s/m);
    assert.doesNotMatch(dockerfile, /^EXPOSE\s/m);
    assert.doesNotMatch(dockerfile, /io\.assistos\.ploinky\.runtime-contract/);
    assert.match(dockerfile, /printf 'assistos\/ploinky-box\\n' > \/etc\/ploinky-box/);
    for (const ownedTarget of [
        '/opt/ploinky/node_modules',
        '/run/ploinky',
        '/home/podman/.config/containers',
        '/home/podman/.local/share/containers/storage',
        '/home/podman/.local/share/ploinky-images',
    ]) {
        assert.ok(dockerfile.includes(ownedTarget), 'missing owned mount target ' + ownedTarget);
    }
    assert.match(
        dockerfile,
        /chown -R podman:podman[\s\S]*?\/opt\/ploinky[\s\S]*?\/run\/ploinky[\s\S]*?\/home\/podman\/\.config[\s\S]*?\/home\/podman\/\.local\/share\/containers[\s\S]*?\/home\/podman\/\.local\/share\/ploinky-images/,
    );
    // The immutable image carries no workspace path. The supervisor supplies
    // the selected host path as the bind destination, working directory, and
    // PLOINKY_WORKSPACE_ROOT of each created Box.
    assert.doesNotMatch(dockerfile, /(?:^|\s)\/workspace(?:\s|\/|$)/m);
    assert.doesNotMatch(dockerfile, /PLOINKY_WORKSPACE_ROOT=/);
    assert.match(dockerfile, /chmod 0700 \/run\/ploinky/);
    assert.match(
        dockerfile,
        /rm -f \/home\/podman\/\.config\/containers\/containers\.conf/,
    );
    // The entrypoint renders the user storage.conf that separates the durable
    // image cache from the disposable graphroot; an inherited copy would
    // silently win and repersist nested container state.
    assert.match(
        dockerfile,
        /rm -f[\s\S]{0,120}?\/home\/podman\/\.config\/containers\/storage\.conf/,
    );
    // Only the image cache is a durable mount; the graphroot must stay on the
    // Box writable layer so nested state dies with the outer Box.
    assert.doesNotMatch(dockerfile, /^VOLUME\s/m);
    assert.doesNotMatch(readme, /retained workspace-volume/i);
    assert.doesNotMatch(readme, /three (?:managed |explicitly )?named volumes/i);
    assert.doesNotMatch(readme, /durable named volume/i);
    assert.match(
        readme,
        /workspace-backed cache directories:[\s\S]*?\.ploinky\/box\/dependencies[\s\S]*?\/opt\/ploinky\/node_modules[\s\S]*?\.ploinky\/box\/images[\s\S]*?\/home\/podman\/\.local\/share\/ploinky-images/,
    );
    assert.match(
        dockerfile,
        /\.ploinky\/box\/images host bind[\s\S]*?\.ploinky\/box\/dependencies/,
    );
    assert.match(dockerfile, /^ENV PATH=\/opt\/ploinky\/bin:\/usr\/local\/bin:\/usr\/bin \\$/m);
    for (const requiredEnv of [
        'USER=podman',
        'HOME=/home/podman',
        'PLOINKY_DISABLE_HOST_SANDBOX=1',
        'container=oci',
        '_CONTAINERS_USERNS_CONFIGURED=""',
        'BUILDAH_ISOLATION=chroot',
    ]) {
        assert.ok(dockerfile.includes(requiredEnv), 'missing exact ENV ' + requiredEnv);
    }
    assert.match(
        dockerfile,
        /^COPY sources\/ploinky\/ploinky-box\/entrypoint\/ploinky-box-entrypoint \/usr\/local\/bin\/ploinky-box-entrypoint$/m,
    );
    assert.match(dockerfile, /^COPY sources\/ploinky\/ploinky-box\/dependencies\.lock\.json \/tmp\/ploinky-box-dependencies\.lock\.json$/m);
    assert.match(dockerfile, /^COPY sources\/ploinky\/ploinky-box\/mcp-sdk-bundle\.mjs \/tmp\/mcp-sdk-bundle\.mjs$/m);
    assert.match(dockerfile, /^COPY sources\/mcp-sdk \/tmp\/mcp-sdk$/m);
    assert.match(dockerfile, /mcp-sdk-bundle\.mjs prepare[\s\S]*?--lock \/tmp\/ploinky-box-dependencies\.lock\.json/);
    assert.match(dockerfile, /COPY --from=mcp-sdk-builder \/tmp\/mcp-sdk \/usr\/local\/lib\/ploinky\/mcp-sdk/);
    assert.match(dockerfile, /COPY --from=mcp-sdk-builder \/tmp\/mcp-sdk-bundle\.mjs \/usr\/local\/share\/ploinky\/mcp-sdk\/bundle-contract\.mjs/);
    assert.match(dockerfile, /test ! -e \/usr\/local\/lib\/ploinky\/mcp-sdk\/\.git/);
    assert.match(dockerfile, /mcp-sdk\/bundle-contract\.mjs verify[\s\S]*?--source \/usr\/local\/lib\/ploinky\/mcp-sdk/);
    assert.match(dockerfile, /^COPY sources\/achillesAgentLib \/opt\/ploinky-agentlib$/m);
    assert.match(dockerfile, /image-bundle\.mjs prepare[\s\S]*?--source \/opt\/ploinky-agentlib[\s\S]*?--metadata \/usr\/local\/share\/ploinky\/agentlib\/runtime-contract\.json[\s\S]*?repositories\.achillesAgentLib\.commit/);
    assert.match(dockerfile, /rm -rf \/opt\/ploinky-agentlib\/\.git/);
    assert.match(dockerfile, /chown -R 0:0 \/opt\/ploinky-agentlib \/usr\/local\/share\/ploinky\/agentlib/);
    assert.match(dockerfile, /find \/opt\/ploinky-agentlib \/usr\/local\/share\/ploinky\/agentlib -type f -exec chmod a-w/);
    assert.match(dockerfile, /USER podman\nRUN node \/usr\/local\/share\/ploinky\/agentlib\/image-bundle\.mjs verify/);
    assert.match(dockerfile, /COPY --from=agentlib-builder \/opt\/ploinky-agentlib \/opt\/ploinky-agentlib/);
    assert.match(dockerfile, /COPY --from=agentlib-builder \/usr\/local\/share\/ploinky\/agentlib \/usr\/local\/share\/ploinky\/agentlib/);
    assert.match(dockerfile, /test ! -e \/opt\/ploinky-agentlib\/\.git/);
    assert.match(dockerfile, /^COPY sources\/ploinky\/core-services\/webtty\/package\.json \/tmp\/webtty-build\/package\.json$/m);
    assert.match(dockerfile, /^COPY sources\/ploinky\/core-services\/webtty\/package-lock\.json \/tmp\/webtty-build\/package-lock\.json$/m);
    assert.match(dockerfile, /^COPY sources\/ploinky\/core-services\/webtty\/native-probe\.mjs \/usr\/local\/share\/ploinky\/webtty\/native-probe\.mjs$/m);
    assert.match(dockerfile, /ARG PLOINKY_SOURCE_SHA/);
    assert.match(dockerfile, /grep -Eq '\^\[0-9a-f\]\{40\}\$'/);
    assert.match(dockerfile, /npm ci --omit=dev --no-audit --no-fund/);
    assert.match(dockerfile, /--build-contract[\s\S]*?--package-lock[\s\S]*?--source-sha/);
    assert.match(dockerfile, /node \/usr\/local\/share\/ploinky\/webtty\/native-probe\.mjs --verify/);
    assert.match(dockerfile, /COPY --from=webtty-builder \/usr\/local\/lib\/ploinky\/webtty\/node_modules/);
    assert.match(dockerfile, /COPY --from=webtty-builder \/usr\/local\/share\/ploinky\/webtty\/native-probe\.mjs/);
    assert.match(dockerfile, /COPY --from=webtty-builder \/usr\/local\/share\/ploinky\/webtty\/runtime-contract\.json/);
    assert.match(dockerfile, /chown -R 0:0 \/usr\/local\/lib\/ploinky\/webtty \/usr\/local\/share\/ploinky\/webtty/);
    assert.match(dockerfile, /USER podman[\s\S]*?RUN node \/usr\/local\/share\/ploinky\/webtty\/native-probe\.mjs --verify[\s\S]*?USER root/);
    assert.match(dockerfile, /! command -v gcc/);
    assert.match(dockerfile, /! command -v g\+\+/);
    assert.match(dockerfile, /! command -v make/);
    assert.match(dockerfile, /-name \.npm -o -name \.cache -o -name node-gyp/);
    assert.match(dockerfile, /test ! -e \/tmp\/webtty-build/);
    assert.doesNotMatch(dockerfile, /spawn-helper/);
    assert.doesNotMatch(dockerfile, /NODE_PATH|WEBTTY_PORT|\b7681\b/);
    assert.match(dockerfile, /^RUN chmod 0755 \/usr\/local\/bin\/ploinky-box-entrypoint$/m);
    assert.equal(fs.existsSync(path.join(repoRoot, 'images/ploinky-box/entrypoint.sh')), false);
    assert.doesNotMatch(dockerfile, /COPY images\/ploinky-box\/entrypoint\.sh/);
    assert.match(dockerfile, /^USER podman$/m);
    const runtimeStage = dockerfile.slice(dockerfile.indexOf('FROM scratch AS runtime'));
    assert.match(runtimeStage, /^USER podman\nWORKDIR \/\nENTRYPOINT \["\/usr\/local\/bin\/ploinky-box-entrypoint"\]$/m);
    const runtimeInstructions = dockerfileInstructions(runtimeStage);
    assert.deepEqual(
        runtimeInstructions.filter(({ keyword }) => keyword === 'WORKDIR').map(({ source }) => source.trim()),
        ['WORKDIR /'],
    );
    assert.equal(instructions.some(({ keyword, source }) => keyword === 'WORKDIR' && /\/workspace\b/.test(source)), false);
    assert.match(dockerfile, /^ENTRYPOINT \["\/usr\/local\/bin\/ploinky-box-entrypoint"\]$/m);
    assert.equal(instructions.filter(({ keyword }) => keyword === 'VOLUME').length, 0);
    assert.equal(instructions.filter(({ keyword }) => keyword === 'EXPOSE').length, 0);
    assert.equal(instructions.filter(({ keyword }) => keyword === 'LABEL').length, 0);
    assert.equal(instructions.filter(({ keyword }) => keyword === 'CMD').length, 0);
});

test('ploinky-box publishes proven native candidates before explicit promotion', () => {
    const workflow = read('.github/workflows/publish-ploinky-box-image.yml');
    const buildJob = workflow.match(/\n  build:[\s\S]*?(?=\n  merge:)/)?.[0] || '';
    const mergeJob = workflow.match(/\n  merge:[\s\S]*?(?=\n  promote:)/)?.[0] || '';
    const promoteJob = workflow.match(/\n  promote:[\s\S]*$/)?.[0] || '';
    assert.match(workflow, /source_ref:[\s\S]*?required: true/);
    assert.match(workflow, /promote_stable:[\s\S]*?type: boolean[\s\S]*?default: false/);
    assert.match(workflow, /\^\[0-9a-f\]\{40\}\$/);
    assert.match(buildJob, /repository: AssistOS-AI\/ploinky[\s\S]*?ref: \$\{\{ needs\.resolve-source\.outputs\.source_sha \}\}/);
    assert.match(buildJob, /Resolve immutable MCP SDK input from the Ploinky lock/);
    assert.match(buildJob, /repository: \$\{\{ steps\.mcp_sdk\.outputs\.repository \}\}/);
    assert.match(buildJob, /ref: \$\{\{ steps\.mcp_sdk\.outputs\.commit \}\}/);
    assert.match(buildJob, /git -C sources\/mcp-sdk rev-parse HEAD/);
    assert.match(buildJob, /Resolve immutable AgentLib input from the Ploinky lock/);
    assert.match(buildJob, /repository: \$\{\{ steps\.agentlib\.outputs\.repository \}\}/);
    assert.match(buildJob, /ref: \$\{\{ steps\.agentlib\.outputs\.commit \}\}/);
    assert.match(buildJob, /git -C sources\/achillesAgentLib rev-parse HEAD/);
    assert.match(buildJob, /image-bundle\.mjs verify[\s\S]*?--expected-commit "\$AGENTLIB_SHA"/);
    assert.match(buildJob, /agentlib-probe\.json/);
    assert.match(buildJob, /immutable-agentlib\.json/);
    assert.match(buildJob, /persist-credentials: false/);
    assert.match(buildJob, /git[\s\S]*?status[\s\S]*?--porcelain=v1/);
    assert.match(read('.gitignore'), /^sources\/$/m);
    assert.match(buildJob, /runner: ubuntu-24\.04\n/);
    assert.match(buildJob, /runner: ubuntu-24\.04-arm/);
    for (const arch of ['amd64', 'arm64']) assert.match(buildJob, new RegExp('platform: linux/' + arch));
    assert.match(buildJob, /push-by-digest=true/);
    assert.match(buildJob, /name-canonical=true/);
    assert.match(buildJob, /provenance: false/);
    assert.match(buildJob, /PLOINKY_SOURCE_SHA=\$\{\{ needs\.resolve-source\.outputs\.source_sha \}\}/);
    assert.match(buildJob, /docker pull --platform "linux\/\$ARCH" "\$image"/);
    assert.match(buildJob, /--network none --read-only/);
    assert.match(buildJob, /--user 1000:1000/);
    assert.match(buildJob, /--cap-drop ALL --security-opt no-new-privileges/);
    assert.match(buildJob, /native-probe\.mjs --verify/);
    assert.match(buildJob, /verify-publication\.mjs native/);
    assert.match(buildJob, /Upload native runtime evidence\n        if: always\(\)/);
    assert.match(buildJob, /ploinky-box-native-\$\{\{ matrix\.arch \}\}/);
    assert.doesNotMatch(workflow, /setup-qemu|--privileged|seccomp=unconfined|\bnode --test\b|tests\/(?:unit|integration|e2e)\/|SMOKE_GRAPH_/);
    for (const repo of ['AssistOSExplorer', 'webmeetInfra', 'UmamiAgent', 'AchillesCLI', 'proxies', 'basic']) assert.doesNotMatch(buildJob, new RegExp(repo));
    assert.match(mergeJob, /needs:\s*\n\s+- resolve-source\s*\n\s+- build/);
    assert.match(mergeJob, /pattern: ploinky-box-native-\*/);
    assert.match(mergeJob, /verify-publication\.mjs proofs/);
    assert.match(mergeJob, /runtime-candidate-\$\{GITHUB_RUN_ID\}-\$\{GITHUB_RUN_ATTEMPT\}/);
    assert.match(mergeJob, /Prove the run-scoped staging tag is unused/);
    assert.match(mergeJob, /verify-publication\.mjs candidate/);
    assert.match(mergeJob, /cmp "\$evidence\/candidate-index\.json" "\$evidence\/immutable-index\.json"/);
    assert.match(mergeJob, /cp -R \/tmp\/ploinky-box-proofs "\$evidence\/native-proofs"/);
    assert.match(mergeJob, /Upload immutable candidate evidence/);
    assert.doesNotMatch(mergeJob, /--tag "docker\.io\/\$\{IMAGE_NAME\}:\$\{(?:IMAGE_TAG|COMPATIBILITY_IMAGE_TAG)\}"/);
    assert.match(promoteJob, /if: \$\{\{ inputs\.promote_stable == true \}\}/);
    assert.match(promoteJob, /needs: merge/);
    assert.match(promoteJob, /STAGING_DIGEST: \$\{\{ needs\.merge\.outputs\.digest \}\}/);
    assert.match(promoteJob, /--tag "docker\.io\/\$\{IMAGE_NAME\}:\$\{IMAGE_TAG\}"/);
    assert.match(promoteJob, /--tag "docker\.io\/\$\{IMAGE_NAME\}:\$\{COMPATIBILITY_IMAGE_TAG\}"/);
    assert.match(promoteJob, /test "\$latest_digest" = "\$STAGING_DIGEST"/);
    assert.match(promoteJob, /test "\$runtime_digest" = "\$STAGING_DIGEST"/);
    assert.doesNotMatch(promoteJob, /node --test|podman run|docker run/);
    for (const use of workflow.matchAll(/^\s*uses:\s*[^@\s]+@([^\s#]+)/gm)) assert.match(use[1], /^[0-9a-f]{40}$/);
});

test('latest channel documentation separates creation from hard-cut recovery', () => {
    const readme = read('README.md');

    assert.match(readme, /latest[^\n]*primary mutable release channel/);
    assert.match(readme, /runtime[^\n]*compatibility/);
    assert.match(readme, /consults the selected channel only when creating[\s\S]*?validated replacement/);
    assert.match(readme, /incompatible image or unrecognized configuration\s+drift is rejected before mutation/i);
    assert.match(readme, /explicit[\s\S]*?destroy followed by\s+recreate/);
    assert.match(readme, /release channel[\s\S]*?separately authorized registry release[\s\S]*?action/);
    assert.match(readme, /never a supervisor\s+transaction/);
    assert.match(readme, /Reuse,\s+status, stop, and destroy do not pull the channel/);
    assert.match(readme, /private WebTTY native contract/);
    assert.match(readme, /source SHA is provenance\s+only; runtime compatibility never compares it/);
    assert.doesNotMatch(
        readme,
        /(?:image name|tags?|labels?|marker|release channel)[^\n]*(?:runtime-contract|contract-[0-9]+)/i,
    );
});

test('ploinky-node does not install a container engine or client', () => {
    const dockerfile = read('images/ploinky-node/Dockerfile');
    const forbiddenTokens = [
        'podman',
        'docker-cli',
        'docker-ce',
        'docker-ce-cli',
        'docker.io',
        'moby-engine',
        'moby-cli',
    ];
    const forbiddenContainerEngine =
        /\b(?:podman|docker-cli|docker-ce|docker-ce-cli|docker\.io|moby-engine|moby-cli)\b/i;
    const runInstructions = dockerfileInstructions(dockerfile)
        .filter(({ keyword }) => keyword === 'RUN')
        .map(({ source }) => source)
        .join('\n');

    assert.doesNotMatch(runInstructions, forbiddenContainerEngine);

    const registryOnlyProbe = [
        'ARG NODE_BASE=docker.io/library/node:24-bookworm-slim',
        'FROM docker.io/library/node:24-bookworm-slim',
    ].join('\n');
    assert.deepEqual(
        dockerfileInstructions(registryOnlyProbe).filter(({ keyword }) => keyword === 'RUN'),
        [],
    );

    for (const token of forbiddenTokens) {
        const leadingWhitespaceProbe = dockerfileInstructions(
            `  RUN apt-get install -y ${token}`,
        )
            .filter(({ keyword }) => keyword === 'RUN')
            .map(({ source }) => source)
            .join('\n');
        assert.match(leadingWhitespaceProbe, forbiddenContainerEngine);
    }

    const continuationProbe = dockerfileInstructions(
        ['  RUN apt-get update \\', '    && apt-get install -y moby-cli'].join('\n'),
    )
        .filter(({ keyword }) => keyword === 'RUN')
        .map(({ source }) => source)
        .join('\n');
    assert.match(continuationProbe, forbiddenContainerEngine);
});
