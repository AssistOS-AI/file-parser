# Dependencies for graph skill scope persistence

Host-path workspace mounts, path admission, diagnostics, and their tests use
Node.js 22+ built-ins and repository-owned modules. They introduce no new
packages, external source, or system tools. Native verification uses the
existing rootless Podman runtime and a locally rebuilt Box image; no image
publication or shared deployment is required. The companion image patch keeps
the image's existing pinned dependencies and licenses unchanged.

AchillesAgentLib source selection and Box package checks use Node.js built-ins
and add no third-party packages. The `container-image-builds` Box workflow
selects the AchillesAgentLib and MCP SDK sources, resolving each repository's
remote default branch once (or taking an exact commit input), and packages them
into the image with their declared runtime dependencies and license files. The
image carries the existing `ploinky-agent-lib` package (MIT, with its upstream
LICENSE retained) and the MCP SDK, each with build-generated provenance
(repository, branch, commit and package version). Ploinky keeps no lock or
expected revision: it identifies the supplied libraries by the outer Box image
that carries them, and checks them only as packages. To update a library,
rebuild the Box image. A valid workspace checkout remains the development
override. Host Git and network access are not needed to acquire a fallback
library; other repository operations retain their own Git requirements. Startup
rejects an absent or unusable supplied package before admitting the graph.
Focused verification uses the existing Node test runner and fake container
engine, without installations.

The graph scope state implementation and its regression tests add no third-party dependencies. They use Node.js built-ins (`node:crypto`, `node:fs`, `node:path`, `node:os`, `node:test`, and `node:assert/strict`) and repository-owned modules. Node.js is a runtime prerequisite, not a bundled library; the focused tests were verified with Node.js 25.8.0 and the portable acceptance runner targets Node.js 22 or newer.

Existing application dependencies and installation behavior remain declared in `package.json`. This change does not install packages, download tools, or alter those dependencies. Scope-state reads and writes run in the existing host supervisor and require its workspace mutation lock. A missing saved scope is handled as legacy state; malformed state produces an explicit error before graph mutation.

Authority-helper command diagnostics use only Node.js built-ins (`node:crypto`
and `node:util`) and the existing diagnostic sanitizer. They add no third-party
dependencies or installation requirements. Their regression tests use the
existing fake Podman runner and Node.js test runner.

Box readiness separates stored container records from host diagnostics using
the existing Podman CLI's `container logs --timestamps` format. It adds no
packages or system services. Podman 5.4.0+ remains the supported native host
baseline; stored timestamps are retained for history checks, and host log-reader
errors prevent readiness even when the command exits successfully. The format
is defined by [Podman's log writer](https://github.com/containers/podman/blob/v5.8.6/libpod/logs/log.go).
Focused regression tests use Node.js built-ins. The opt-in native regression
uses an existing immutable local image with `/bin/sh` and the installed Podman
to check journald and k8s-file logging. It creates and removes only its labelled
fixtures, without image pulls, published ports or host mounts. Run it with
`PLOINKY_LOG_TEST_IMAGE=<immutable-image-id> node --test tests/integration/ploinkyBoxLogDiagnostics.test.mjs`.

The native Linux host preflight adds no third-party code or packages. It uses
Node.js filesystem/path APIs, the existing bounded process runner, and the
existing diagnostic sanitizer. The public launcher requires Node.js 22+ before
loading modules. The supported native host baseline is Podman 5.4.0+; its
selected runtime, networking, and configured storage helpers remain external
system prerequisites, with the effective paths read from `podman info`.
Rootless UID/GID helpers, namespace mappings, seccomp, and FUSE/TUN device access
are surveyed by the explicit `ploinky diagnose` and `ploinky repair` commands. Normal deployment
does not run this general host preflight. Host cgroup versions and controller
delegation are not prerequisites for the default Box runtime, which disables
nested cgroups and sets no outer CPU quota. Hardware-enabled execution requires
the verified cgroup-v2/runtime setup and each requested resource's delegated
controller. `ploinky diagnose` reports missing prerequisites and their manual
fixes. Unenforceable CPU, memory or process requests refuse the affected agent
rather than silently dropping the limit. Hardware limits add no native `flock`,
npm or production Python dependency: the store lock, preparation program and
cgroup readers use Node.js built-ins, and the nested runtime uses the existing
Podman and crun. Installation and
configuration guidance is in [README.md](README.md#prerequisites) and in each
failure message. These checks neither install packages nor alter host settings.
The host's configured packages retain their distribution/upstream licensing;
none is newly vendored or redistributed by this change. Regression tests use
fake filesystems and process runners and need no container engine.

`ploinky diagnose` adds no runtime package. Its report and isolated probes use
Node.js built-ins, the existing Podman CLI, validated Box image and bundled
tools. Host checks read selected configuration and installed security profiles;
they never install packages or modify policy. Deep probes may pull the existing
configured Box image, export an OCI archive and load that exact image into
temporary nested engines; no host registry credentials are transferred. The
configured registry's DNS/HTTPS endpoint is tested, and unavailable or
inapplicable checks are reported explicitly. The selected image's existing
licenses/notices remain with the image; no new image dependency is introduced.
Runtime tests need disk space for temporary image copies and remove only their
verified resources. Run the command on the host, in the selected workspace;
missing prerequisites produce bounded command/error/next-step results. The
probe implementation can be removed without changing ordinary deployment,
which retains the essential image, ownership, isolation and readiness contracts.

Privilege classification and `ploinky repair` add no third-party dependencies.
They use Node.js 22+ built-ins, repository-owned identity/lock/diagnostic code,
and the existing Podman CLI. Repair runs bounded argument-array probes before
each supported operation, never invokes sudo, and never executes remediation
text. Missing or incompatible host tools remain diagnostic failures with
separate administrator or user instructions. The only new Podman mutations are
pulling an absent configured registry image and, on macOS, starting an existing
selected rootless Machine. Existing cached images and Machine configuration are
preserved. The binding-file permission repair uses Node.js file descriptors
and filesystem APIs; it does not add a chmod subprocess dependency.

Repair's inspection-only preview uses the installed engine's current-state
queries without creating a Machine or temporary deployment containers. Its
post-repair verification reuses the existing full diagnostic probes and their
image/space requirements. Node's built-in test runner covers these operations
using fake engines and temporary user-owned files, without a running VM or
container engine. The remediation catalog and repair module can be removed
without changing ordinary deployment. Package installation suggestions are
instructions only; the selected system packages retain their upstream and
distribution licensing and no external tool or policy is newly bundled.

The focused tests substitute container operations and require no container engine or model backend. The broader acceptance harness can optionally use an existing Podman installation to provide Linux; its environment requirements are documented with that harness. No external code, licenses, or notices were added by this component.

The cross-repository propagation tests are available through `npm run test:local-skills`. Their explicit source and optional native-runtime prerequisites are recorded in [tests/integration/local-skills/dependencies.md](tests/integration/local-skills/dependencies.md). They add no third-party packages.

The managed AgentLib package adapter adds no dependencies. It uses Node.js
filesystem and path APIs to inspect npm package placements and replace cache-owned
copies with links to the already admitted library. Both `achillesAgentLib` and
`ploinky-agent-lib` resolve from that source; standalone packages keep their own
installation contracts. The adapter changes neither source manifests nor the
selected library, and its regression tests use temporary directories and the
existing mocked Box installer. No new package, external source, license, or
tool installation is required.

The `ploinky bind` Router publication adds no third-party package or system
service. It uses Node.js built-ins (`node:crypto`, `node:dgram`, `node:fs`,
`node:net`, `node:os`, and `node:path`), repository-owned modules, and the
existing rootless Podman `--publish`, `--env`, and `--label` options; there is
no separate host forwarding daemon. The saved binding is host-only state under
`~/.ploinky-box/router-bindings`. Regression tests use the Node.js test runner,
temporary directories, fake Podman runners, and fake network interfaces. Native
verification uses the already present validated Box image and the installed
Podman without pulling images or changing firewall, DNS, or tunnel settings.
The publication integration test creates isolated Box generations and verifies
real TCP/UDP listeners, LAN Host admission and loopback reversal. Run it with
`PLOINKY_BIND_PUBLICATION_TEST_IMAGE=<immutable-local-image-id> node --test tests/integration/ploinkyBoxBindPublication.test.mjs`.
WebChat uses the browser's built-in `crypto.getRandomValues()` when
`crypto.randomUUID()` is unavailable on plain-HTTP LAN origins; no UUID package
or weaker random source is introduced.

The WebSkel files under `webLibs/webskel` are generated from the canonical
https://github.com/AssistOS-AI/WebSkel source and retain its MIT LICENSE. UUID
compatibility is implemented in that source's `utils/uuid.mjs` and used by
`webSkel.js`; ESM and UMD outputs are regenerated with WebSkel's existing locked
Vite build. Refresh the generated files together after its source/build tests.
This adds no Ploinky runtime dependency or build-tool installation.

## Optional NVIDIA MPS support

GPU shares reuse the operator-installed NVIDIA driver tools
`nvidia-cuda-mps-control` and `nvidia-cuda-mps-server`, bound read-only from the
host into `/usr/local/nvidia/bin`. No npm packages or downloaded driver code are
added. The exact installed driver version and both tool fingerprints are
recorded and revalidated; the tool pair must match the host driver. Missing or
changed tools refuse sharing while ordinary GPU access remains available.

These tools are NVIDIA proprietary driver components. No copies or license
files are redistributed in this repository. License terms and supported
versions must be checked against the operator's installed driver distribution;
a universal tool version or license grant is not asserted here. Source and
updates are provided by NVIDIA at <https://developer.nvidia.com/deploy/mps>.
Install or update through the host's existing NVIDIA driver installation, then
restart the Box to rebuild its fingerprints and read-only binds. A Node.js
implementation cannot replace the driver daemon or CUDA control protocol.
Remove the optional dependency by clearing GPU shares; CPU/RAM limits do not
require MPS. Ploinky performs no package installation.

The optional live GPU probe uses the existing Python 3 standard library ctypes
to call the installed CUDA driver API. It needs no Python packages and is not a
runtime dependency. Its driver observations require an authorized isolated GPU
fixture. Python is PSF-licensed and operator-provided; no interpreter is bundled.

The test-only live verification runner (`tests/hardware-limits/verify.mjs`
`prepare-live`, `provision`, `live` and `cleanup`) adds no package dependency.
It uses the operator's existing Podman, `git` to freeze the committed
candidate and, for apparatus blocks, the system OpenSSH client with a pinned
known-hosts file; on the remote host it runs only the pinned Node.js and
`mkdir`, `dd`, `chmod`, `stat`, `cat`, `ls`, `sha256sum`, `tar` and `rm`. After every
dispatch, and before the owned staging root can be removed, it lists the remote run
directory and fetches only the run artifacts named in its own artifact form, as
bounded regular files verified by `sha256sum`. The
`apparatus-mps` block additionally runs the pinned host `nvidia-smi` as a
read-only XML query (the GPU idle gate) and reads the host's `/proc` and cgroup
tree; it never changes the compute mode and signals only the one MPS daemon of
its own Box, after proving it. Each action needs its own separate
execution-time authorization binding.

The `apparatus-local-llm` and `apparatus-vllm` blocks add no package dependency to
Ploinky. They run the committed local-llm candidate from its own pinned immutable
image, and drive it only through its MCP tools and the administrator route. While
the model generates they read the agent's cgroup interface files (`cpu.stat`,
`cpu.max`, `memory.*`) and the pinned host `nvidia-smi` XML query. The local-llm
repository's calibration tool (`local-llm/tools/vllm_mps_calibration.mjs`) uses
only Node.js built-ins and the vLLM installation the product itself makes from its
own pinned runner lock: the lock entry (wheels, about 3.9 GB for the pinned vLLM
version) is downloaded by the agent's own installer inside the owned Box and is
removed with the owned workspace. Nothing is installed on the host and nothing
unpinned is ever installed; a missing lock entry, driver, toolchain or disk is
reported as BLOCKED with the missing prerequisite. The Playground is not a
dependency: no browser or Playwright runtime is provisioned, and the cases call the
same MCP tool through the Router.
