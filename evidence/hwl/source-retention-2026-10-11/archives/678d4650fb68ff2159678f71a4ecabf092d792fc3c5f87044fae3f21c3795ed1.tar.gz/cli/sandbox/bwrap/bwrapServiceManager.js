import { resolveAgentRepositoryName } from '../../utils/agentRepositorySource.mjs';
import { execSync, spawn, spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
    assertManifestEnvProfileCompleteness,
    buildEnvMap,
    formatEnvFlag,
    getExposedNames,
    getManifestEnvNames,
    resolveVarValue
} from '../../utils/security/secretVars.js';
import { buildAgentPrincipalEnv, stripReservedAgentEnv } from '../../utils/security/agentIdentityEnv.js';
import { debugLog } from '../../utils/utils.js';
import {
    CONTAINER_CONFIG_PATH,
    computeEnvHash,
    getAgentContainerName,
    getConfiguredProjectPath,
    loadAgentsMap,
    parseManifestPorts,
    saveAgentsMap,
    syncAgentMcpConfig
} from '../docker/common.js';
import {
    DEFAULT_AGENT_ENTRY,
    readManifestAgentCommand,
    readManifestStartCommand
} from '../docker/agentCommands.js';
import {
    CODE_DIR,
    DEPS_DIR,
    LOGS_DIR,
    PLOINKY_DIR,
    PROFILE_FILE,
    ROUTING_FILE,
    SERVERS_CONFIG_FILE,
    PLOINKY_WORKSPACE_ROOT,
    PLOINKY_SKILL_SCOPE_ENV
} from '../../utils/config.js';
import { openSandboxLogHandle, readSandboxCrashLog } from '../sandboxLogFiles.js';
import { sanitizeDiagnosticText } from '../../utils/diagnosticText.js';
import { guardSpawnedChild } from '../../utils/childSpawn.js';
import {
    planRuntimeResources,
    applyRuntimeResourceEnv,
    ensurePersistentStorageHostDir
} from '../../utils/runtime/runtimeResourcePlanner.js';
import {
    controllerGuardMounts,
    controllerGuardTargets,
    normalizeRuntimeMountTarget,
} from '../../utils/runtime/controllerStateGuards.js';
import {
    assertCanonicalAgentDataPath,
    ensureAgentDataDirectory,
    isPathWithin,
} from '../../utils/runtime/agentDataPathPolicy.js';
import { deriveAgentPrincipalId } from '../../utils/security/agentIdentity.js';
import { ensureSharedHostDir } from '../docker/agentHooks.js';
import { resolveAgentHomeLayout } from '../docker/agentHomeLayout.js';
import {
    runPreContainerLifecycle,
    runProfileLifecycle
} from '../../utils/runtime/lifecycleHooks.js';
import {
    formatMissingSecretsError,
    getSecrets,
    validateSecrets
} from '../../utils/security/secretInjector.js';
import {
    getDefaultMountModes,
    getProfileEnvVars,
    mergeProfiles,
    resolveManifestRuntimeProfile
} from '../../utils/runtime/profileService.js';
import {
    assertHostSandboxNetworkCompatibility,
    assertNetworkStartupCompatibility,
} from '../networkContract.js';
import {
    getAgentWorkDir,
    getAgentCodePath,
    getAgentSkillsPath
} from '../../utils/workspaceStructure.js';
import {
    attachAdmittedDependencies,
    noCacheDependencyRecord,
    prepareRuntimeDependencies,
    runtimeDependencyReuseProblem,
    sandboxProcessIdentity,
} from '../../utils/dependencies/store/runtimeDependencies.mjs';
import {
    assertBwrapPidSlotAvailable,
    isBwrapProcessRunning,
    normalizeSandboxRuntimeIdentity,
    normalizeExpectedPredecessor,
    resolveSandboxSlotForStart,
    stopBwrapProcess,
    stopExactSandboxOrThrow,
    saveBwrapPid,
    clearBwrapPid,
    getBwrapPid
} from './bwrapFleet.js';
import {
    ensureManifestVolumeHostPath,
    readManifestVolumeOptions,
    resolveManifestVolumeHostPath
} from '../../utils/runtime/manifestVolumePolicy.js';
import { assertRouterEndpoint } from '../routerPort.js';
import {
    pruneStaleRuntimeEntries,
    runtimeSegment
} from '../../utils/runtime/runtimeStaging.js';
import {
    admitManifestRuntimeCapabilities,
    assertRuntimeAdmissionCurrent,
} from '../runtimeCapabilities.js';
import { assertHostModeGenerationCapability } from '../edgeGeneration.js';
import {
    agentLibAliasShadows,
    agentLibGrant,
    agentLibGrantEnv,
    agentLibReuseProblem,
    agentLibRuntimeRecord,
} from '../agentLibGrant.js';
import { detectHostRuntimeKey } from '../../utils/dependencies/dependencyRuntimeKey.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const AGENT_LIB_PATH = path.resolve(__dirname, '../../../Agent');
const AGENT_PRIVATE_KEY_CONTAINER_PATH = '/run/ploinky-agent.key';
const BWRAP_RUNTIME_ROOT = path.join(DEPS_DIR, 'bwrap-runtime');
const BWRAP_NODE_RUNTIME_PATH = '/opt/ploinky-node';

const BWRAP_PATH = '/usr/bin/bwrap';

function admitBwrapBoundary(agentName, manifest, agentPath, options, profileResolution) {
    const repoName = resolveAgentRepositoryName(agentPath);
    const optionBag = options && typeof options === 'object' ? options : {};
    const manifestPath = path.join(agentPath, 'manifest.json');
    const manifestBytes = optionBag.manifestBytes !== undefined
        ? Buffer.from(optionBag.manifestBytes)
        : (fs.existsSync(manifestPath)
            ? fs.readFileSync(manifestPath)
            : Buffer.from(JSON.stringify(manifest), 'utf8'));
    const admission = admitManifestRuntimeCapabilities(manifest, {
        manifestBytes,
        manifestPath,
        agentId: `${repoName}/${agentName}`,
        profileName: profileResolution.resolvedProfileName,
        profileConfig: profileResolution.profileConfig,
        network: profileResolution.network,
        runtimeKind: 'bwrap',
    });
    if (optionBag.runtimeAdmission) {
        assertRuntimeAdmissionCurrent(optionBag.runtimeAdmission, {
            manifestBytes,
            profileName: profileResolution.resolvedProfileName,
            runtimeKind: 'bwrap',
            descriptor: admission.descriptor,
        });
    }
    return Object.freeze({
        admission: optionBag.runtimeAdmission || admission,
        manifestBytes,
    });
}

function resolveBwrapRuntimeProfile(agentName, manifest, agentPath, options = {}, existingRecord = {}) {
    const repoName = resolveAgentRepositoryName(agentPath);
    const manifestPath = `manifest(${repoName}/${agentName})`;
    const resolution = options.profileResolution || resolveManifestRuntimeProfile(manifest, {
        agentName: `${repoName}/${agentName}`,
        profileName: options.profileName,
        persistedProfileName: existingRecord.profile,
        path: manifestPath,
    });
    assertNetworkStartupCompatibility(manifest, resolution.profileConfig, resolution.network, {
        path: manifestPath,
    });
    assertHostSandboxNetworkCompatibility(resolution.network, {
        path: `${manifestPath}.network`,
        runtime: 'bwrap',
    });
    return resolution;
}

function resolveSandboxRouterEndpoint(options = {}, networkMode = 'host') {
    if (options && typeof options === 'object' && Object.prototype.hasOwnProperty.call(options, 'routerHost')) {
        throw new Error('routerHost overrides are not supported; pass the validated routerEndpoint');
    }
    return assertRouterEndpoint(options?.routerEndpoint, networkMode, { explicitPort: options?.routerPort });
}

function resolveBwrapNodeRuntime(nodeExecPath = process.execPath) {
    let hostNodePath = path.resolve(nodeExecPath);
    try {
        hostNodePath = fs.realpathSync(hostNodePath);
    } catch (_) {
        // The existence check below provides the actionable error.
    }
    if (!fs.existsSync(hostNodePath)) {
        throw new Error(`[bwrap] host Node.js executable is missing: ${hostNodePath}`);
    }
    const hostBinPath = path.dirname(hostNodePath);
    const hostRuntimePath = path.dirname(hostBinPath);
    return {
        hostRuntimePath,
        sandboxRuntimePath: BWRAP_NODE_RUNTIME_PATH,
        sandboxBinPath: `${BWRAP_NODE_RUNTIME_PATH}/bin`,
    };
}

function bwrapNeedsDependencies(agentCodePath, manifest) {
    const agentHasPackageJson = fs.existsSync(path.join(agentCodePath, 'package.json'));
    return !readManifestStartCommand(manifest) || agentHasPackageJson;
}

/**
 * Obtain the sandbox dependency tree from the immutable store and publish
 * this service's reader receipt before launch.
 */
function resolveBwrapAgentNodeModules({
    agentCodePath,
    agentWorkDir,
    needsCoreDeps,
    containerName,
    runtimeIdentity,
    admittedRecord,
}) {
    if (!needsCoreDeps) {
        const fallback = path.join(agentWorkDir, 'node_modules');
        ensureAgentDataDirectory(fallback);
        return { nodeModulesDir: fallback, record: noCacheDependencyRecord('no-core-deps', { family: 'bwrap' }), prepared: null };
    }
    const prepared = prepareRuntimeDependencies({
        family: 'bwrap',
        runtimeKey: detectHostRuntimeKey('bwrap'),
        agentCodePath,
        registration: containerName,
        admittedRecord,
    }, {
        consumer: {
            kind: 'bwrap-service',
            key: `bwrap:${containerName}:${runtimeIdentity.instanceId}:${runtimeIdentity.enableGeneration}`,
            containerName,
            registration: containerName,
            phase: 'creating',
        },
    });
    return { nodeModulesDir: prepared.nodeModulesPath, record: prepared.record, prepared };
}

/** '' when the running sandbox already binds the desired generation. */
function bwrapDependencyReuseProblem({ agentName, manifest, record, containerName }, deps = {}) {
    const agentCodePath = resolveSymlinkPath(getAgentCodePath(agentName));
    return runtimeDependencyReuseProblem({
        record,
        family: 'bwrap',
        needsDependencies: bwrapNeedsDependencies(agentCodePath, manifest),
        agentCodePath,
        registration: containerName,
    }, deps);
}

function ensureBwrapAgentLibDir(instanceName, nodeModulesDir, options = {}) {
    const sourceAgentLibPath = options.sourceAgentLibPath || AGENT_LIB_PATH;
    const runtimeBase = options.runtimeRoot || BWRAP_RUNTIME_ROOT;
    const runtimeRoot = path.join(runtimeBase, runtimeSegment(instanceName));
    const stagedAgentLibPath = path.join(
        runtimeRoot,
        `Agent-${process.pid}-${Date.now()}${process.hrtime.bigint()}`
    );
    const sourceNodeModules = path.join(sourceAgentLibPath, 'node_modules');

    if (!fs.existsSync(nodeModulesDir)) {
        throw new Error(`[bwrap] prepared dependency cache is missing: ${nodeModulesDir}`);
    }

    fs.mkdirSync(runtimeRoot, { recursive: true });
    fs.cpSync(sourceAgentLibPath, stagedAgentLibPath, {
        recursive: true,
        filter(sourcePath) {
            const resolvedSource = path.resolve(sourcePath);
            return resolvedSource !== sourceNodeModules
                && !resolvedSource.startsWith(`${sourceNodeModules}${path.sep}`);
        }
    });

    // Bubblewrap cannot create /Agent/node_modules after /Agent has been
    // mounted read-only. The empty directory is the mount point for the
    // prepared dependency cache; the cache itself remains outside this copy.
    fs.mkdirSync(path.join(stagedAgentLibPath, 'node_modules'), { recursive: true });

    return stagedAgentLibPath;
}

/**
 * Guarantee the entries a nested bind will land on inside the source tree.
 *
 * bwrap applies a read-only bind at bind time, so it cannot create
 * `/code/node_modules`, `/code/skills` or a manifest volume target such as
 * `/code/debuglogs` inside an already read-only `/code` ("Can't mkdir
 * /code/node_modules: Read-only file system"). The empty host entries are the
 * mount points, as `ensureBwrapAgentLibDir` provides for /Agent/node_modules.
 * Podman does not need them because it stages a symlink tree for `/code` and
 * mounts into that. They stay empty: the dependency cache, the skills tree and
 * the volumes are mounted over them, never written into them.
 *
 * `relPath` is a normalized path below /code. The type of the last component
 * follows the bind source, as bwrap requires: a directory source needs a
 * directory, a file source needs a regular file (`file: true`). Every other
 * component is a directory. Missing components are created (the file
 * exclusively, so an entry that appears meanwhile is never truncated). An
 * existing entry of the right type is left untouched. A symlink at any
 * component, or an entry of the wrong type, is refused rather than followed,
 * because a bind through it would land on whatever the link resolves to.
 */
function ensureBwrapCodeMountPoint(agentCodePath, relPath, { file = false } = {}) {
    const segments = String(relPath || '').split('/').filter(Boolean);
    if (!segments.length || segments.some(segment => segment === '..' || segment === '.')) {
        throw new Error(`[bwrap] invalid /code mount point '${relPath}'`);
    }
    let current = agentCodePath;
    segments.forEach((segment, index) => {
        current = path.join(current, segment);
        const wantFile = file && index === segments.length - 1;
        let stat = null;
        try {
            stat = fs.lstatSync(current);
        } catch (error) {
            if (error?.code !== 'ENOENT') throw error;
        }
        if (!stat) {
            try {
                if (wantFile) fs.closeSync(fs.openSync(current, 'wx', 0o644));
                else fs.mkdirSync(current);
            } catch (error) {
                if (error?.code !== 'EEXIST') {
                    throw new Error(`[bwrap] cannot create the /code/${segments.join('/')} mount point ${current}: ${error.message}`);
                }
            }
            stat = fs.lstatSync(current);
        }
        if (wantFile ? !stat.isFile() : !stat.isDirectory()) {
            throw new Error(
                `[bwrap] ${current} is not a ${wantFile ? 'regular file' : 'directory'}, `
                + `so /code/${segments.join('/')} cannot be mounted over it. Remove or move it, then restart.`
            );
        }
    });
    return current;
}

/**
 * The path below /code that a manifest volume target names, or null when the
 * target is outside /code (or is /code itself). Dependencies are prepared by
 * Ploinky and mounted read-only at /code/node_modules, so a volume may not
 * target it; Podman refuses the same targets (assertPodmanCodeMountAllowed).
 */
function bwrapCodeVolumeRelativePath(containerPath) {
    const normalized = path.posix.normalize(String(containerPath || '').replace(/\\/g, '/'));
    if (!normalized.startsWith('/code/')) return null;
    const relPath = normalized.slice('/code/'.length).replace(/\/+$/, '');
    if (!relPath) return null;
    if (relPath === 'node_modules' || relPath.startsWith('node_modules/')) {
        throw new Error(
            `[bwrap] manifest volume '${containerPath}' targets reserved /code/node_modules. `
            + 'Dependencies are prepared by Ploinky and mounted read-only.'
        );
    }
    return relPath;
}

function resolveSymlinkPath(symlinkPath) {
    try {
        if (fs.existsSync(symlinkPath)) {
            const stat = fs.lstatSync(symlinkPath);
            if (stat.isSymbolicLink()) {
                return fs.realpathSync(symlinkPath);
            }
        }
    } catch (err) {
        debugLog(`Warning: could not resolve symlink ${symlinkPath}: ${err.message}`);
    }
    return symlinkPath;
}

function normalizeMountMode(mode, fallback) {
    if (mode === 'ro' || mode === 'rw') return mode;
    return fallback;
}

function getProfileMountModes(profile, profileConfig = {}) {
    const defaultMounts = getDefaultMountModes(profile);
    // Profile overrides must not make installed source writable.
    const codeMode = defaultMounts.code;
    const skillsMode = defaultMounts.skills;
    return {
        codeReadOnly: codeMode === 'ro',
        skillsReadOnly: skillsMode === 'ro'
    };
}

function isSameOrInside(candidate, parent) {
    if (!candidate || !parent) return false;
    const resolvedCandidate = path.resolve(candidate);
    const resolvedParent = path.resolve(parent);
    const relative = path.relative(resolvedParent, resolvedCandidate);
    return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
}

function addReadOnlyOverlay(args, hostPath, cwd, seen, projectTarget = cwd) {
    if (!hostPath || !isSameOrInside(hostPath, cwd) || !fs.existsSync(hostPath)) return;
    const resolved = path.resolve(hostPath);
    if (seen.has(resolved)) return;
    const relative = path.relative(path.resolve(cwd), resolved).split(path.sep).filter(Boolean);
    // Remapped into the sandbox, an overlay of the project root itself would
    // turn the whole project mount (an isolated agent's HOME) read-only.
    if (!relative.length && path.posix.normalize(projectTarget) !== path.resolve(cwd)) return;
    seen.add(resolved);
    // The overlay lands where the project is mounted in the sandbox. That is
    // the host path for global and devel agents, and /root for a static agent,
    // whose host-absolute path does not exist there and would otherwise be
    // created as a stray entry (through the writable /root bind when the
    // workspace itself lives below /root).
    args.push('--ro-bind', resolved, path.posix.join(projectTarget, ...relative));
}

function addProtectedWorkspaceOverlays(args, options) {
    const {
        agentCodePath,
        nodeModulesDir,
        cwd,
        projectTarget = cwd,
        protectAgentCodePath,
    } = options;
    const seen = new Set();
    const nodeModulesParent = nodeModulesDir ? path.dirname(nodeModulesDir) : '';

    addReadOnlyOverlay(args, DEPS_DIR, cwd, seen, projectTarget);
    addReadOnlyOverlay(args, nodeModulesParent, cwd, seen, projectTarget);
    addReadOnlyOverlay(args, path.join(agentCodePath || '', 'node_modules'), cwd, seen, projectTarget);
    addReadOnlyOverlay(args, CODE_DIR, cwd, seen, projectTarget);
    addReadOnlyOverlay(args, path.join(PLOINKY_DIR, 'seatbelt-runtime'), cwd, seen, projectTarget);
    addReadOnlyOverlay(args, PROFILE_FILE, cwd, seen, projectTarget);
    addReadOnlyOverlay(args, ROUTING_FILE, cwd, seen, projectTarget);
    addReadOnlyOverlay(args, SERVERS_CONFIG_FILE, cwd, seen, projectTarget);

    if (protectAgentCodePath) {
        addReadOnlyOverlay(args, agentCodePath, cwd, seen, projectTarget);
    }
}

/**
 * Build the bwrap argument array for running a Node.js agent in a sandbox.
 */
/**
 * Project and HOME binds, shared with the container runtimes. A static agent
 * projects the workspace at /root, so its private home moves to /home/agent
 * instead of competing for the same target.
 */
function resolveBwrapHomeLayout({ cwd, cwdMountTarget, agentHomeDir }) {
    return resolveAgentHomeLayout({
        cwd: cwd || agentHomeDir,
        cwdMountTarget: cwdMountTarget || cwd || agentHomeDir,
        agentHomeDir: agentHomeDir || cwd,
    });
}

/**
 * An isolated agent's project is its own persistent home, or the whole
 * workspace for the workspace's static agent. Any other directory means the
 * registry resolved another instance's data (for example an alias registered
 * before the canonical instance), which would be mounted writable at /root.
 */
function assertIsolatedProjectIsOwnHome({ cwd, cwdMountTarget, agentHomeDir, workspaceRoot }) {
    if (cwdMountTarget !== '/root' || !cwd || !agentHomeDir) return;
    const canonical = (value) => {
        const resolved = path.resolve(value);
        try { return fs.realpathSync(resolved); } catch (_) { return resolved; }
    };
    const project = canonical(cwd);
    if (project === canonical(agentHomeDir) || (workspaceRoot && project === canonical(workspaceRoot))) return;
    throw new Error(
        `[bwrap] isolated project '${cwd}' is neither the agent home '${agentHomeDir}' nor the workspace root; `
        + 'refusing to mount another instance\'s data at /root'
    );
}

/**
 * The writable binds bwrap compiles, in the order it emits them, so any alias of
 * the selected achillesAgentLib source can be shadowed read-only afterwards.
 */
function writableBwrapBinds({ agentCodePath, codeReadOnly, cwd, cwdMountTarget, agentHomeDir, sharedDir, volumes, volumeOptions }) {
    const binds = [];
    if (!codeReadOnly && agentCodePath) binds.push({ hostPath: agentCodePath, runtimePath: '/code' });
    if (sharedDir) binds.push({ hostPath: sharedDir, runtimePath: '/shared' });
    if (cwd || agentHomeDir) {
        for (const { source, target } of resolveBwrapHomeLayout({ cwd, cwdMountTarget, agentHomeDir }).binds) {
            binds.push({ hostPath: source, runtimePath: target });
        }
    }
    if (volumes && typeof volumes === 'object') {
        for (const [hostPath, containerPath] of Object.entries(volumes)) {
            const mountOptions = (volumeOptions || {})[containerPath] || {};
            if (mountOptions.readOnly === true) continue;
            binds.push({ hostPath: resolveManifestVolumeHostPath(hostPath), runtimePath: containerPath });
        }
    }
    return binds;
}

function appendControllerStateGuards(args, { workspaceRoot = PLOINKY_WORKSPACE_ROOT } = {}) {
    const bindings = [];
    const remainder = [];
    let insertionIndex = 0;
    for (let index = 0; index < args.length - 2; index += 1) {
        if (args[index] !== '--bind' && args[index] !== '--ro-bind') continue;
        bindings.push({
            hostPath: args[index + 1],
            runtimePath: normalizeRuntimeMountTarget(args[index + 2]),
            readOnly: args[index] === '--ro-bind',
        });
        index += 2;
    }
    const targets = controllerGuardTargets(bindings, { workspaceRoot });
    const guards = controllerGuardMounts(targets, { workspaceRoot, bindings });
    if (!guards.length) return targets;
    for (const guard of guards) {
        if (guard.replaceExisting) {
            for (const binding of bindings) {
                if (binding.runtimePath === guard.target) binding.readOnly = guard.readOnly;
            }
        } else {
            bindings.push({ hostPath: guard.source, runtimePath: guard.target, readOnly: guard.readOnly });
        }
    }
    // Bubblewrap applies mounts sequentially. Parent pins must precede existing
    // descendant grants, otherwise they hide dependency/source alias overlays.
    // Keep equal-target precedence and every non-bind argument unchanged.
    for (let index = 0; index < args.length; index += 1) {
        if (args[index] === '--bind' || args[index] === '--ro-bind') {
            index += 2;
            insertionIndex = remainder.length;
        } else remainder.push(args[index]);
    }
    const ordered = bindings.sort((left, right) => left.runtimePath.split('/').filter(Boolean).length - right.runtimePath.split('/').filter(Boolean).length);
    remainder.splice(insertionIndex, 0, ...ordered.flatMap(binding => [
        binding.readOnly ? '--ro-bind' : '--bind', binding.hostPath, binding.runtimePath,
    ]));
    args.splice(0, args.length, ...remainder);
    return targets;
}

function mergeBwrapManifestVolumes(manifest, profileConfig) {
    return {
        volumes: {
            ...(manifest?.volumes || {}),
            ...(profileConfig?.volumes || {}),
        },
        volumeOptions: {
            ...readManifestVolumeOptions(manifest),
            ...readManifestVolumeOptions(profileConfig),
        },
    };
}

function buildBwrapArgs(options) {
    const {
        agentCodePath,
        agentLibPath,
        nodeModulesDir,
        sharedDir,
        cwd,
        cwdMountTarget,
        agentHomeDir,
        nodeRuntimePath,
        skillsPath,
        envMap,
        codeReadOnly,
        skillsReadOnly,
        volumes,
        agentPrivateKeyPath,
        agentLibGrant: grant,
    } = options;

    if (!grant) {
        throw new Error('[bwrap] agent admission requires the selected achillesAgentLib grant');
    }
    const agentNodeModulesMountPoint = path.join(agentLibPath, 'node_modules');
    if (!fs.existsSync(agentNodeModulesMountPoint)) {
        throw new Error(
            `[bwrap] Agent runtime is missing the /Agent/node_modules mount point: ${agentNodeModulesMountPoint}`
        );
    }

    const args = [];

    // System libraries (read-only)
    args.push('--ro-bind', '/usr', '/usr');
    if (fs.existsSync('/lib')) args.push('--ro-bind', '/lib', '/lib');
    if (fs.existsSync('/lib64')) args.push('--ro-bind', '/lib64', '/lib64');

    // /bin and /sbin — could be real dirs or symlinks to /usr/bin
    try {
        const binStat = fs.lstatSync('/bin');
        if (binStat.isSymbolicLink()) {
            args.push('--symlink', fs.readlinkSync('/bin'), '/bin');
        } else {
            args.push('--ro-bind', '/bin', '/bin');
        }
    } catch (_) {
        args.push('--symlink', 'usr/bin', '/bin');
    }
    try {
        const sbinStat = fs.lstatSync('/sbin');
        if (sbinStat.isSymbolicLink()) {
            args.push('--symlink', fs.readlinkSync('/sbin'), '/sbin');
        } else {
            args.push('--ro-bind', '/sbin', '/sbin');
        }
    } catch (_) {
        args.push('--symlink', 'usr/sbin', '/sbin');
    }

    // Essential /etc files (read-only)
    const etcFiles = [
        '/etc/resolv.conf', '/etc/hosts', '/etc/passwd', '/etc/group',
        '/etc/nsswitch.conf', '/etc/ld.so.cache'
    ];
    for (const f of etcFiles) {
        if (fs.existsSync(f)) args.push('--ro-bind', f, f);
    }
    // SSL/TLS certificates and other /etc directories
    const etcDirs = ['/etc/ssl', '/etc/ca-certificates', '/etc/pki', '/etc/alternatives', '/etc/crypto-policies'];
    for (const d of etcDirs) {
        if (fs.existsSync(d)) args.push('--ro-bind', d, d);
    }

    // Special filesystems
    args.push('--proc', '/proc');
    args.push('--dev', '/dev');
    args.push('--tmpfs', '/tmp');

    // Use the same Node.js distribution that launched Ploinky and prepared the
    // bwrap dependency cache. This keeps the runtime ABI aligned and exposes
    // that distribution's npm to manifest install hooks without making the
    // host installation writable.
    const hostNodeRuntimePath = nodeRuntimePath || resolveBwrapNodeRuntime().hostRuntimePath;
    args.push('--dir', '/opt');
    args.push('--ro-bind', hostNodeRuntimePath, BWRAP_NODE_RUNTIME_PATH);

    // Agent library (always read-only)
    args.push('--ro-bind', agentLibPath, '/Agent');

    // The one selected achillesAgentLib source, at the stable path every mount
    // namespace agrees on. The agent cache symlink resolves into it.
    args.push('--ro-bind', grant.sourceDir, grant.runtimePath);

    // Agent code is read-only in every profile.
    if (codeReadOnly) {
        args.push('--ro-bind', agentCodePath, '/code');
    } else {
        args.push('--bind', agentCodePath, '/code');
    }

    // node_modules — read-only immutable store generation (cli/utils/dependencies/store).
    // Mounted at both paths so AgentServer.mjs (/Agent/server/) can resolve modules.
    if (codeReadOnly) ensureBwrapCodeMountPoint(agentCodePath, 'node_modules');
    args.push('--ro-bind', nodeModulesDir, '/code/node_modules');
    args.push('--ro-bind', nodeModulesDir, '/Agent/node_modules');

    // Shared directory
    args.push('--bind', sharedDir, '/shared');

    if (agentPrivateKeyPath && fs.existsSync(agentPrivateKeyPath)) {
        args.push('--ro-bind', agentPrivateKeyPath, AGENT_PRIVATE_KEY_CONTAINER_PATH);
    }

    // Project/workspace access is independent from the persistent agent home.
    // Isolated agents use the home bind as their project mount; global and
    // devel agents retain the selected project at its host-absolute path.
    const homeLayout = resolveBwrapHomeLayout({ cwd, cwdMountTarget, agentHomeDir });
    assertIsolatedProjectIsOwnHome({
        cwd, cwdMountTarget, agentHomeDir, workspaceRoot: options.workspaceRoot || PLOINKY_WORKSPACE_ROOT,
    });
    const storageWorkspaceRoot = path.dirname(path.dirname(path.resolve(sharedDir)));
    assertCanonicalAgentDataPath(sharedDir, { workspaceRoot: storageWorkspaceRoot });
    if (agentHomeDir) assertCanonicalAgentDataPath(agentHomeDir, { workspaceRoot: storageWorkspaceRoot });
    for (const { source, target } of homeLayout.binds) {
        // bwrap creates mount points on its own root, but the HOME target that
        // moves out of /root is created explicitly before anything binds to it.
        if (target === homeLayout.containerHome && target !== '/root') args.push('--dir', target);
        args.push('--bind', source, target);
    }

    // Skills directory (if exists)
    if (skillsPath && fs.existsSync(skillsPath)) {
        if (codeReadOnly) ensureBwrapCodeMountPoint(agentCodePath, 'skills');
        if (skillsReadOnly) {
            args.push('--ro-bind', skillsPath, '/code/skills');
        } else {
            args.push('--bind', skillsPath, '/code/skills');
        }
    }

    // Custom volumes from manifest
    if (volumes && typeof volumes === 'object') {
        const volumeOptions = options.volumeOptions || {};
        for (const [hostPath, containerPath] of Object.entries(volumes)) {
            const resolvedHostPath = resolveManifestVolumeHostPath(hostPath);
            const mountOptions = volumeOptions[containerPath]
                || volumeOptions[String(containerPath || '').replace(/\/+$/, '')]
                || {};
            ensureManifestVolumeHostPath(resolvedHostPath, containerPath, mountOptions);
            const codeRelPath = bwrapCodeVolumeRelativePath(containerPath);
            // The mount point must match the source: a file volume needs a file.
            if (codeRelPath && codeReadOnly) {
                ensureBwrapCodeMountPoint(agentCodePath, codeRelPath, { file: !fs.statSync(resolvedHostPath).isDirectory() });
            }
            args.push(mountOptions.readOnly === true ? '--ro-bind' : '--bind', resolvedHostPath, containerPath);
        }
    }

    // Runtime-resources persistent storage (declarative, provider-agnostic)
    if (options.runtimeResourcePlan && options.runtimeResourcePlan.persistentStorage) {
        const ps = options.runtimeResourcePlan.persistentStorage;
        ensurePersistentStorageHostDir(options.runtimeResourcePlan);
        args.push('--bind', ps.hostPath, ps.containerPath);
    }

    const projectSourceWritable = cwdMountTarget !== '/root'
        && isPathWithin(agentCodePath, cwd);
    addProtectedWorkspaceOverlays(args, {
        agentCodePath,
        nodeModulesDir,
        cwd,
        projectTarget: homeLayout.binds[0].target,
        protectAgentCodePath: codeReadOnly && !projectSourceWritable,
    });

    // Applied after every writable bind: a workspace or project mount that also
    // exposes the selected source would otherwise leave the same inode writable.
    for (const shadow of agentLibAliasShadows(grant, writableBwrapBinds({
        agentCodePath,
        codeReadOnly,
        cwd,
        cwdMountTarget,
        agentHomeDir,
        sharedDir,
        volumes,
        volumeOptions: options.volumeOptions,
    }))) {
        args.push('--ro-bind', shadow.hostPath, shadow.runtimePath);
    }

    // Apply the old-root opacity boundary after every ordinary bind.
    appendControllerStateGuards(args, { workspaceRoot: options.workspaceRoot });

    // Process isolation — do NOT unshare network (agents need host network)
    // NOTE: --die-with-parent is intentionally omitted. Agent processes must survive
    // the ploinky CLI exit (daemon mode). Cleanup is handled by ploinky stop/destroy
    // and the containerMonitor.
    // NOTE: --new-session is intentionally omitted. It creates a new PGID for the sandbox
    // child process, making process group kills miss the children. --unshare-pid already
    // provides PID namespace isolation which prevents sandbox processes from signaling
    // host processes.
    args.push('--unshare-pid');

    // Environment: clear all, then set explicitly
    args.push('--clearenv');
    // HOME follows the bind layout above, whatever the caller's map says.
    for (const [key, value] of Object.entries({ ...(envMap || {}), HOME: homeLayout.containerHome })) {
        if (value !== undefined && value !== null) {
            args.push('--setenv', key, String(value));
        }
    }

    // Working directory
    args.push('--chdir', '/code');

    return args;
}

/**
 * Build the full environment map for a bwrap agent.
 * Mirrors the env construction in startAgentContainer.
 */
function buildFullEnvMap(agentName, manifest, profileConfig, workspacePath, repoName, activeProfile, runtimeName = 'bwrap', runtimeResourcePlan = null, routerEndpoint = undefined, runtimeIdentity = undefined, agentLibGrantForEnv = null, containerHome = '/root') {
    const endpoint = assertRouterEndpoint(routerEndpoint, 'host');
    // Start with manifest env vars (resolved from secrets)
    const env = buildEnvMap(manifest, profileConfig, { agentName, repoName, forRuntime: true });

    // Ploinky internal vars
    env.PLOINKY_MCP_CONFIG_PATH = CONTAINER_CONFIG_PATH;
    env.AGENT_NAME = agentName;
    env.WORKSPACE_PATH = workspacePath;
    env.PLOINKY_WORKSPACE_ROOT = PLOINKY_WORKSPACE_ROOT;
    env.PLOINKY_RUNTIME = runtimeName;

    // Manifest-declared runtime.resources.env (post template expansion).
    if (runtimeResourcePlan) {
        const resourceEnv = applyRuntimeResourceEnv(runtimeResourcePlan);
        for (const [k, v] of Object.entries(resourceEnv)) {
            env[k] = v;
        }
    }

    // Per-agent identity is asserted LAST (below), after all config layers, so it
    // cannot be overridden by profile/manifest/secret env.

    // Profile env vars
    const profileEnv = profileConfig?.env;
    if (profileEnv && typeof profileEnv === 'object' && !Array.isArray(profileEnv)) {
        for (const [key, value] of Object.entries(profileEnv)) {
            if (key && value !== undefined && typeof value !== 'object' && !Object.prototype.hasOwnProperty.call(env, key)) {
                env[key] = String(value);
            }
        }
    }

    // System profile env vars
    const profileEnvVars = getProfileEnvVars(agentName, repoName, activeProfile, {
        containerName: `bwrap_${agentName}`,
        containerId: `bwrap_${agentName}`
    });
    if (profileEnvVars && typeof profileEnvVars === 'object') {
        for (const [key, value] of Object.entries(profileEnvVars)) {
            if (key) env[key] = value ?? '';
        }
    }

    // SSO client credentials
    const agentClientIdVar = `PLOINKY_AGENT_${agentName.toUpperCase().replace(/[^A-Z0-9]/g, '_')}_CLIENT_ID`;
    const agentClientSecretVar = `PLOINKY_AGENT_${agentName.toUpperCase().replace(/[^A-Z0-9]/g, '_')}_CLIENT_SECRET`;
    const agentClientId = resolveVarValue(agentClientIdVar) || resolveVarValue('PLOINKY_AGENT_CLIENT_ID');
    const agentClientSecret = resolveVarValue(agentClientSecretVar) || resolveVarValue('PLOINKY_AGENT_CLIENT_SECRET');
    if (agentClientId) env.PLOINKY_AGENT_CLIENT_ID = agentClientId;
    if (agentClientSecret) env.PLOINKY_AGENT_CLIENT_SECRET = agentClientSecret;

    // Profile secrets
    if (profileConfig?.secrets && profileConfig.secrets.length > 0) {
        const secretValidation = validateSecrets(profileConfig.secrets);
        if (!secretValidation.valid) {
            throw new Error(formatMissingSecretsError(secretValidation.missing, activeProfile));
        }
        const profileSecrets = getSecrets(profileConfig.secrets);
        if (profileSecrets) {
            for (const [key, value] of Object.entries(profileSecrets)) {
                if (key) env[key] = value ?? '';
            }
        }
    }

    // Essential system vars
    env.NODE_PATH = '/code/node_modules';
    env.HOME = containerHome;
    env.PATH = `${BWRAP_NODE_RUNTIME_PATH}/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin`;

    // Exact final-runner equivalence is not yet available for bwrap/seatbelt.
    // Strip every reserved input and emit only non-secret principal fields;
    // no descriptor, Router mirror, request secret, API key, or trust anchor is
    // constructed. Generated-local use therefore fails before key/socket work.
    stripReservedAgentEnv(env);
    Object.assign(env, PLOINKY_SKILL_SCOPE_ENV);
    const exactRuntimeIdentity = runtimeIdentity === undefined
        ? undefined
        : normalizeSandboxRuntimeIdentity(runtimeIdentity);
    Object.assign(
        env,
        buildAgentPrincipalEnv(
            deriveAgentPrincipalId(repoName, agentName),
            exactRuntimeIdentity,
        ),
    );

    // The achillesAgentLib contract is injected at the same final authoritative
    // layer as the other reserved runtime identity variables, after
    // stripReservedAgentEnv has removed any manifest or profile attempt to set it.
    if (agentLibGrantForEnv) {
        Object.assign(env, agentLibGrantEnv(agentLibGrantForEnv));
    }

    return env;
}

/**
 * Build the shell command that runs inside the bwrap sandbox.
 *
 * No runtime `npm install` — dependencies come from an immutable store
 * generation (`prepareRuntimeDependencies`) mounted read-only at /code/node_modules.
 * Only manifest-declared install hooks run here.
 */
function buildBwrapEntryCommand(agentName, manifest, profileConfig) {
    const { raw: explicitAgentCmd } = readManifestAgentCommand(manifest);
    const startCmd = readManifestStartCommand(manifest);
    const useStartEntry = Boolean(startCmd);

    const manifestInstallCmd = String(profileConfig?.install || manifest?.install || '').trim();

    let entryCmd;
    if (useStartEntry && explicitAgentCmd) {
        entryCmd = manifestInstallCmd
            ? `cd /code && ${manifestInstallCmd} && (${startCmd} &) && exec ${explicitAgentCmd}`
            : `cd /code && (${startCmd} &) && exec ${explicitAgentCmd}`;
    } else if (useStartEntry) {
        entryCmd = manifestInstallCmd
            ? `cd /code && ${manifestInstallCmd} && ${startCmd}`
            : `cd /code && ${startCmd}`;
    } else if (explicitAgentCmd) {
        entryCmd = manifestInstallCmd
            ? `cd /code && ${manifestInstallCmd} && ${explicitAgentCmd}`
            : `cd /code && ${explicitAgentCmd}`;
    } else {
        entryCmd = manifestInstallCmd
            ? `${manifestInstallCmd} && sh /Agent/server/AgentServer.sh`
            : 'sh /Agent/server/AgentServer.sh';
    }

    return entryCmd;
}

function shellQuote(value) {
    return `'${String(value).replace(/'/g, `'\\''`)}'`;
}

function buildShellCommand(argv) {
    return argv.map((arg) => shellQuote(arg)).join(' ');
}

function buildBwrapInteractiveCommand(workdir, entryCommand, options = {}) {
    const wd = workdir || '/code';
    const rawCommand = entryCommand && String(entryCommand).trim()
        ? String(entryCommand).trim()
        : 'exec /bin/bash || exec /bin/sh';
    const command = options.forceInteractiveShell && rawCommand === '/bin/sh'
        ? 'if command -v /bin/bash >/dev/null 2>&1; then exec /bin/bash -i; else exec /bin/sh -i; fi'
        : rawCommand;
    return `cd ${shellQuote(wd)} && ${command}`;
}

function sanitizeHistoryName(value) {
    return String(value || 'agent').replace(/[^A-Za-z0-9_.-]/g, '_');
}

function spawnBwrapInteractive(bwrapArgs, options = {}) {
    const usePty = options.usePty === true;
    const scriptPath = '/usr/bin/script';
    if (usePty && fs.existsSync(scriptPath)) {
        const command = buildShellCommand([BWRAP_PATH, ...bwrapArgs]);
        return spawnSync(scriptPath, ['-qfec', command, '/dev/null'], { stdio: 'inherit' });
    }
    return spawnSync(BWRAP_PATH, bwrapArgs, { stdio: 'inherit' });
}

/**
 * Start a bwrap-sandboxed agent process.
 */
function startBwrapProcess(agentName, manifest, agentPath, options = {}) {
    const repoName = resolveAgentRepositoryName(agentPath);
    const containerName = options.containerName || getAgentContainerName(agentName, repoName);
    const agentSnapshot = loadAgentsMap();
    const existingRecord = agentSnapshot[containerName] || {};
    const alias = options.alias || existingRecord.alias;
    const instanceName = alias || agentName;
    const runtimeIdentity = normalizeSandboxRuntimeIdentity(options);
    // A prepared registry record already names the exact instance's project, as
    // it does for containers; otherwise resolve it from the registry.
    const cwd = options.preservePreparedRegistryRecord === true && existingRecord.projectPath
        ? existingRecord.projectPath
        : getConfiguredProjectPath(agentName, repoName, alias);
    const isolatedHome = (existingRecord.runMode || 'isolated') === 'isolated';
    const agentHomeDir = getAgentWorkDir(instanceName);
    const cwdMountTarget = isolatedHome ? '/root' : cwd;
    const workspacePath = isolatedHome ? '/root' : cwd;
    const homeLayout = resolveBwrapHomeLayout({ cwd, cwdMountTarget, agentHomeDir });

    // Profile and network are resolved atomically before any sandbox work.
    const profileRecord = existingRecord;
    const profileResolution = resolveBwrapRuntimeProfile(agentName, manifest, agentPath, options, profileRecord);
    const activeProfile = profileResolution.resolvedProfileName;
    const profileConfig = profileResolution.profileConfig;
    admitBwrapBoundary(agentName, manifest, agentPath, options, profileResolution);
    assertHostModeGenerationCapability({
        agentId: deriveAgentPrincipalId(repoName, agentName),
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        routeKey: alias || agentName,
        containerName,
    }, { preparedCapability: options.preparedHostModeCapability });
    assertBwrapPidSlotAvailable(containerName);
    const routerEndpoint = resolveSandboxRouterEndpoint(options, profileResolution.network.mode);

    assertManifestEnvProfileCompleteness(manifest, profileConfig, { agentName, repoName, profileName: activeProfile });
    const envHash = computeEnvHash(manifest, profileConfig, routerEndpoint.env, { agentName, repoName });
    const { codeReadOnly, skillsReadOnly } = getProfileMountModes(activeProfile, profileConfig || {});
    const sharedDir = ensureSharedHostDir();

    const runtimeResourcePlan = planRuntimeResources(manifest, { agentName, repoName });
    const nodeRuntime = resolveBwrapNodeRuntime();

    // Pre-container lifecycle (workspace init, symlinks, preinstall HOST hook)
    const preLifecycle = runPreContainerLifecycle(agentName, repoName, agentPath, activeProfile);
    if (!preLifecycle.success) {
        throw new Error(`[profile] ${agentName}: pre-container lifecycle failed: ${preLifecycle.errors.join('; ')}`);
    }

    // Resolve source links after the lifecycle refreshes them.
    const agentCodePath = resolveSymlinkPath(getAgentCodePath(agentName));
    const agentSkillsPath = resolveSymlinkPath(getAgentSkillsPath(agentName));

    // Ensure work directory and MCP config
    ensureAgentDataDirectory(agentHomeDir);
    syncAgentMcpConfig(containerName, path.resolve(agentPath), instanceName, { workDir: agentHomeDir });

    // Resolve node dependencies from the immutable dependency store.
    // Non-Node agents (start-only, no package.json) still get an empty
    // node_modules so the mount resolves.
    const agentHasPackageJson = fs.existsSync(path.join(agentCodePath, 'package.json'));
    const startCmd = readManifestStartCommand(manifest);
    const needsCoreDeps = !startCmd || agentHasPackageJson;
    const dependencies = resolveBwrapAgentNodeModules({
        agentCodePath,
        agentWorkDir: agentHomeDir,
        needsCoreDeps,
        containerName,
        runtimeIdentity,
        admittedRecord: profileRecord,
    });
    const nodeModulesDir = dependencies.nodeModulesDir;
    const bwrapAgentRoot = path.join(BWRAP_RUNTIME_ROOT, runtimeSegment(instanceName));
    fs.mkdirSync(bwrapAgentRoot, { recursive: true });
    pruneStaleRuntimeEntries(bwrapAgentRoot);
    const agentLibPath = ensureBwrapAgentLibDir(instanceName, nodeModulesDir);
    const bwrapRuntimeKey = detectHostRuntimeKey('bwrap');
    const grant = agentLibGrant(bwrapRuntimeKey);

    // Port resolution — with shared host network, hostPort === containerPort
    // Must happen before env map so PORT is set correctly
    const { portMappings } = parseManifestPorts(manifest, profileConfig);
    let allPortMappings = [...portMappings];
    if (!allPortMappings.length) {
        const hostPort = options.preferredHostPort || existingRecord?.config?.ports?.[0]?.hostPort || (10000 + Math.floor(Math.random() * 50000));
        allPortMappings = [{ containerPort: hostPort, hostPort }];
    }
    const hostPort = allPortMappings[0]?.hostPort;

    // Build environment map
    const envMap = buildFullEnvMap(agentName, manifest, profileConfig, workspacePath, repoName, activeProfile, 'bwrap', runtimeResourcePlan, routerEndpoint, runtimeIdentity, grant, homeLayout.containerHome);
    const agentPrivateKeyPath = envMap.__PLOINKY_AGENT_PRIVATE_KEY_HOST_PATH || '';
    delete envMap.__PLOINKY_AGENT_PRIVATE_KEY_HOST_PATH;

    // Set PORT env var so the agent binds to the correct host port
    if (hostPort) {
        envMap.PORT = String(hostPort);
    }

    // Build bwrap arguments
    const manifestStorage = mergeBwrapManifestVolumes(manifest, profileConfig);
    const bwrapArgs = buildBwrapArgs({
        agentCodePath,
        agentLibPath,
        nodeModulesDir,
        sharedDir,
        cwd,
        cwdMountTarget,
        agentHomeDir,
        nodeRuntimePath: nodeRuntime.hostRuntimePath,
        skillsPath: agentSkillsPath,
        envMap,
        codeReadOnly,
        skillsReadOnly,
        volumes: manifestStorage.volumes,
        volumeOptions: manifestStorage.volumeOptions,
        runtimeResourcePlan,
        agentPrivateKeyPath,
        agentLibGrant: grant,
    });

    // Build the entry command
    const entryCmd = buildBwrapEntryCommand(agentName, manifest, profileConfig);

    // Add the command to run
    bwrapArgs.push('--', 'sh', '-c', entryCmd);

    const logsDir = LOGS_DIR;

    console.log(`[bwrap] ${agentName}: starting sandbox (profile=${activeProfile}, cwd='${cwd}')`);
    debugLog(`[bwrap] ${agentName}: entry command: sh -c "${entryCmd}"`);

    // Spawn detached bwrap process
    assertHostModeGenerationCapability({
        agentId: deriveAgentPrincipalId(repoName, agentName),
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        routeKey: alias || agentName,
        containerName,
    }, { preparedCapability: options.preparedHostModeCapability });
    // The final log name is derived from this launch's identity tuple and its
    // finalized pid, so it is only knowable once the child exists. Spawn
    // against an exclusive 0600 temporary file and publish it with a
    // no-replace hard link; the child keeps its own descriptor throughout.
    const logHandle = openSandboxLogHandle({
        containerName,
        logsDir,
        workspaceRoot: PLOINKY_WORKSPACE_ROOT,
    });
    let child;
    try {
        child = spawn(BWRAP_PATH, bwrapArgs, {
            detached: true,
            stdio: logHandle.stdio
        });
        guardSpawnedChild(child, {
            label: `[bwrap] ${agentName}: bwrap process`,
            onError: (error) => debugLog(
                `[bwrap] ${agentName}: child process error: ${sanitizeDiagnosticText(error)}`,
            ),
        });
        const logFile = logHandle.finalize(child.pid, runtimeIdentity);
        debugLog(`[bwrap] ${agentName}: log file: ${logFile}`);

        // Wait briefly and verify the process didn't crash immediately.
        spawnSync('sleep', ['0.5']);
        let processAlive = false;
        try {
            const statusContent = fs.readFileSync(`/proc/${child.pid}/status`, 'utf8');
            const stateLine = statusContent.split('\n').find(l => l.startsWith('State:')) || '';
            processAlive = !stateLine.includes('Z (zombie)');
        } catch {
            processAlive = false;
        }
        if (!processAlive) {
            let reason = 'unknown error';
            try {
                reason = readSandboxCrashLog(containerName, {
                    runtime: 'bwrap', pid: child.pid, ...runtimeIdentity,
                }, { logsDir }) || reason;
            } catch {}
            throw new Error(`bwrap process exited immediately: ${sanitizeDiagnosticText(reason)}`);
        }

        saveBwrapPid(containerName, child.pid, runtimeIdentity);
        logHandle.commit();
        child.unref();
    } catch (error) {
        if (child?.pid) {
            try { process.kill(-child.pid, 'SIGKILL'); } catch (_) { }
            try { process.kill(child.pid, 'SIGKILL'); } catch (_) { }
        }
        logHandle.discard();
        if (!child?.pid) dependencies.prepared?.release();
        throw error;
    }
    if (dependencies.prepared) {
        try {
            dependencies.prepared.updateConsumer({ process: sandboxProcessIdentity(child.pid), phase: 'running' });
        } catch (error) {
            debugLog(`[bwrap] ${agentName}: dependency receipt process update deferred: ${error?.message || error}`);
        }
    }
    console.log(`[bwrap] ${agentName}: started with PID ${child.pid}`);

    try {
    // Save to agents map
    const agents = loadAgentsMap();
    const currentRecord = agents[containerName] || existingRecord;
    const declaredEnvNames = [
        ...getManifestEnvNames(manifest, profileConfig, { forRuntime: true }),
        ...getExposedNames(manifest, profileConfig, { forRuntime: true })
    ];

    agents[containerName] = {
        agentName,
        repoName,
        runtime: 'bwrap',
        pid: child.pid,
        containerImage: 'host (bwrap)',
        envHash,
        createdAt: currentRecord.createdAt || new Date().toISOString(),
        projectPath: cwd,
        runMode: existingRecord.runMode,
        develRepo: existingRecord.develRepo,
        profile: activeProfile,
        type: 'agent',
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        runtimeStaging: {
            agentLibPath
        },
        agentLib: agentLibRuntimeRecord(grant),
        dependencies: dependencies.record,
        config: {
            binds: [
                { source: agentLibPath, target: '/Agent', ro: true },
                { source: grant.sourceDir, target: grant.runtimePath, ro: true },
                { source: agentCodePath, target: '/code', ro: codeReadOnly },
                { source: nodeModulesDir, target: '/code/node_modules', ro: true },
                { source: nodeModulesDir, target: '/Agent/node_modules', ro: true },
                { source: sharedDir, target: '/shared' },
                ...(fs.existsSync(agentSkillsPath) ? [{ source: agentSkillsPath, target: '/skills', ro: skillsReadOnly }] : []),
                ...homeLayout.binds
            ],
            env: Array.from(new Set(declaredEnvNames)).map((name) => ({ name })),
            ports: allPortMappings,
        }
    };
    if (currentRecord.auth) {
        agents[containerName].auth = currentRecord.auth;
    }

    if (currentRecord.alias || options.alias) {
        agents[containerName].alias = options.alias || currentRecord.alias;
    }
    if (options.preservePreparedRegistryRecord !== true) saveAgentsMap(agents);

    // Run profile lifecycle hooks (hosthook_aftercreation, postinstall HOST hooks)
    // Note: install hooks run inside the bwrap entrypoint, not via podman exec
    try {
        if (profileConfig) {
            const lifecycleResult = runProfileLifecycle(agentName, activeProfile, {
                containerName,
                agentPath,
                repoName,
                manifest,
                skipInstallHooks: true  // Install runs inside bwrap entrypoint
            });
            if (!lifecycleResult.success) {
                const details = lifecycleResult.errors.join('; ');
                console.warn(`[bwrap] ${agentName}: lifecycle warning: ${details}`);
            }
        }
    } catch (error) {
        console.warn(`[bwrap] ${agentName}: lifecycle hook error: ${error.message}`);
    }

    syncAgentMcpConfig(containerName, path.resolve(agentPath), instanceName, { workDir: agentHomeDir });

    const returnPort = allPortMappings.find((p) => p.containerPort === 7000)?.hostPort || allPortMappings[0]?.hostPort || 0;
    return {
        containerName,
        hostPort: returnPort,
        createdByThisLaunch: true,
        registryRecord: structuredClone(agents[containerName]),
    };
    } catch (error) {
        const stopped = stopBwrapProcess(containerName, { expectedIdentity: runtimeIdentity });
        if (!stopped && isBwrapProcessRunning(containerName, runtimeIdentity)) {
            error.message = `${error.message}; exact sandbox candidate cleanup failed`;
            error.exactCleanupFailed = true;
        }
        throw error;
    }
}

/**
 * Idempotent service start — check if already running, compare env hash, start/restart as needed.
 * Returns { containerName, hostPort } matching the shape from ensureAgentService.
 */
function ensureBwrapService(agentName, manifest, agentPath, options = {}) {
    let preferredHostPort;
    let containerOverride;
    let aliasOverride;
    let forceRecreate = false;
    let profileNameOverride;
    let expectedPredecessor = null;

    if (typeof options === 'number') {
        preferredHostPort = options;
    } else if (options && typeof options === 'object') {
        preferredHostPort = options.preferredHostPort;
        containerOverride = options.containerName;
        aliasOverride = options.alias;
        forceRecreate = options.forceRecreate === true;
        profileNameOverride = options.profileName;
        expectedPredecessor = normalizeExpectedPredecessor(options.expectedPredecessor);
    }

    const repoName = resolveAgentRepositoryName(agentPath);
    const containerName = containerOverride || getAgentContainerName(agentName, repoName);
    const snapshot = loadAgentsMap();
    const existingRecord = snapshot[containerName] || {};
    const runtimeIdentity = normalizeSandboxRuntimeIdentity(options);

    if (!aliasOverride && existingRecord.alias) {
        aliasOverride = existingRecord.alias;
    }

    // Profile config and host-network compatibility are validated even when the
    // existing sandbox can otherwise be reused.
    const profileResolution = resolveBwrapRuntimeProfile(agentName, manifest, agentPath, {
        ...(options && typeof options === 'object' ? options : {}),
        profileName: profileNameOverride,
    }, existingRecord);
    const activeProfile = profileResolution.resolvedProfileName;
    const profileConfig = profileResolution.profileConfig;
    const runtimeBoundary = admitBwrapBoundary(
        agentName,
        manifest,
        agentPath,
        options,
        profileResolution,
    );
    assertHostModeGenerationCapability({
        agentId: deriveAgentPrincipalId(repoName, agentName),
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        routeKey: aliasOverride || agentName,
        containerName,
    }, { preparedCapability: options.preparedHostModeCapability });
    const routerEndpoint = resolveSandboxRouterEndpoint(options, profileResolution.network.mode);

    assertManifestEnvProfileCompleteness(manifest, profileConfig, { agentName, repoName, profileName: activeProfile });
    const { portMappings } = parseManifestPorts(manifest, profileConfig);
    let allPortMappings = [...portMappings];
    if (!allPortMappings.length) {
        const hostPort = preferredHostPort || existingRecord?.config?.ports?.[0]?.hostPort || (10000 + Math.floor(Math.random() * 50000));
        allPortMappings = [{ containerPort: hostPort, hostPort }];
    }

    // What holds the runtime key decides what may be stopped. Only the exact
    // requested successor or the caller's expected predecessor is ever
    // signalled; any other live tuple, or a slot that cannot be verified,
    // throws before a signal is sent or a PID record is touched.
    const slot = resolveSandboxSlotForStart(containerName, {
        successor: runtimeIdentity,
        expectedPredecessor,
    });
    let exactRuntimeRunning = slot.kind === 'successor';

    if (slot.kind === 'predecessor') {
        console.log(`[bwrap] ${agentName}: runtime generation changed, replacing the expected predecessor sandbox...`);
        stopExactSandboxOrThrow(containerName, expectedPredecessor);
    } else if (forceRecreate && exactRuntimeRunning) {
        console.log(`[bwrap] ${agentName}: force recreating...`);
        stopExactSandboxOrThrow(containerName, runtimeIdentity);
        exactRuntimeRunning = false;
    }

    // Check if already running
    if (exactRuntimeRunning) {
        // Compare env hash
        const desired = computeEnvHash(manifest, profileConfig, routerEndpoint.env, { agentName, repoName });
        const current = existingRecord.envHash || '';
        // The AgentLib selection is not derivable from the manifest or profile,
        // so a changed source is invisible to the env hash and must be compared
        // on its own.
        const agentLibProblem = agentLibReuseProblem(
            existingRecord,
            agentLibGrant(detectHostRuntimeKey('bwrap')),
        );
        // Dependency trees are immutable generations: a changed or invalid
        // admitted generation means a new sandbox, never a mutated bind.
        const dependencyProblem = (desired && desired !== current) || agentLibProblem
            ? ''
            : bwrapDependencyReuseProblem({ agentName, manifest, record: existingRecord, containerName });
        if (desired && desired !== current) {
            console.log(`[bwrap] ${agentName}: env hash changed, restarting...`);
            stopExactSandboxOrThrow(containerName, runtimeIdentity);
        } else if (agentLibProblem) {
            console.log(`[bwrap] ${agentName}: achillesAgentLib selection changed (${agentLibProblem}), restarting...`);
            stopExactSandboxOrThrow(containerName, runtimeIdentity);
        } else if (dependencyProblem) {
            console.log(`[bwrap] ${agentName}: dependency generation changed (${dependencyProblem}), restarting...`);
            stopExactSandboxOrThrow(containerName, runtimeIdentity);
        } else {
            debugLog(`[bwrap] ${agentName}: already running (PID ${getBwrapPid(containerName, runtimeIdentity)})`);
            const hostPort = allPortMappings[0]?.hostPort || 0;
            const instanceName = aliasOverride || agentName;
            syncAgentMcpConfig(containerName, agentPath, instanceName, {
                workDir: getAgentWorkDir(instanceName)
            });
            return {
                containerName,
                hostPort,
                createdByThisLaunch: false,
                registryRecord: structuredClone(existingRecord),
            };
        }
    }

    // Start the process
    return startBwrapProcess(agentName, manifest, agentPath, {
        preferredHostPort: allPortMappings[0]?.hostPort,
        containerName,
        alias: aliasOverride,
        profileName: activeProfile,
        profileResolution,
        routerEndpoint,
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        preservePreparedRegistryRecord: options.preservePreparedRegistryRecord,
        runtimeAdmission: runtimeBoundary.admission,
        manifestBytes: runtimeBoundary.manifestBytes,
        preparedHostModeCapability: options.preparedHostModeCapability,
    });
}

/**
 * Spawn an interactive bwrap session (for `ploinky cli` / `ploinky shell`).
 * Creates a NEW bwrap sandbox with the same mount layout as the running agent,
 * but runs the given command instead of the agent server.
 * Uses --die-with-parent so the session is cleaned up when the parent exits.
 */
function attachBwrapInteractive(agentName, manifest, agentPath, workdir, entryCommand, options = {}) {
    const repoName = resolveAgentRepositoryName(agentPath);
    const containerName = options.containerName || getAgentContainerName(agentName, repoName);
    const agents = loadAgentsMap();
    const record = agents[containerName];

    if (!record || record.runtime !== 'bwrap') {
        throw new Error(`[bwrap] ${agentName}: not running as bwrap agent`);
    }
    const runtimeIdentity = normalizeSandboxRuntimeIdentity(record);

    // Use the running record's persisted profile unless the caller explicitly
    // selected another valid profile for this interactive sandbox.
    const profileResolution = resolveBwrapRuntimeProfile(agentName, manifest, agentPath, options, record);
    const activeProfile = profileResolution.resolvedProfileName;
    const profileConfig = profileResolution.profileConfig;
    admitBwrapBoundary(agentName, manifest, agentPath, options, profileResolution);
    assertHostModeGenerationCapability({
        agentId: deriveAgentPrincipalId(repoName, agentName),
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        routeKey: record.alias || agentName,
        containerName,
    });
    const routerEndpoint = resolveSandboxRouterEndpoint(options, profileResolution.network.mode);

    // Resolve paths
    const agentCodePath = resolveSymlinkPath(getAgentCodePath(agentName));
    const agentSkillsPath = resolveSymlinkPath(getAgentSkillsPath(agentName));
    const instanceName = record.alias || agentName;
    const projectPath = record.projectPath || getConfiguredProjectPath(agentName, repoName, record.alias);
    const isolatedHome = (record.runMode || 'isolated') === 'isolated';
    const agentHomeDir = getAgentWorkDir(instanceName);
    const cwdMountTarget = isolatedHome ? '/root' : projectPath;
    const workspacePath = isolatedHome ? '/root' : projectPath;
    const homeLayout = resolveBwrapHomeLayout({ cwd: projectPath, cwdMountTarget, agentHomeDir });
    const sharedDir = ensureSharedHostDir();
    ensureAgentDataDirectory(agentHomeDir);
    const needsCoreDeps = bwrapNeedsDependencies(agentCodePath, manifest);
    // An interactive session reuses the service's admitted generation
    // read-only under its own receipt; it never builds or repairs a tree.
    const attached = attachAdmittedDependencies(record, {
        consumer: {
            kind: 'bwrap-attachment',
            containerName,
            registration: containerName,
            process: sandboxProcessIdentity(process.pid),
        },
    });
    let nodeModulesDir;
    if (attached) {
        nodeModulesDir = attached.nodeModulesPath;
    } else if (!needsCoreDeps) {
        nodeModulesDir = path.join(agentHomeDir, 'node_modules');
        ensureAgentDataDirectory(nodeModulesDir);
    } else {
        throw new Error(`[bwrap] ${agentName}: the running service has no admitted dependency generation; restart it first`);
    }
    try {
    const bwrapAgentRoot = path.join(BWRAP_RUNTIME_ROOT, runtimeSegment(instanceName));
    fs.mkdirSync(bwrapAgentRoot, { recursive: true });
    const serviceAgentLibPath = record.runtimeStaging?.agentLibPath;
    pruneStaleRuntimeEntries(bwrapAgentRoot, {
        keepPaths: serviceAgentLibPath ? [serviceAgentLibPath] : []
    });
    const agentLibPath = ensureBwrapAgentLibDir(instanceName, nodeModulesDir);
    const grant = agentLibGrant(detectHostRuntimeKey('bwrap'));
    const { codeReadOnly, skillsReadOnly } = getProfileMountModes(activeProfile, profileConfig || {});

    // Build environment (same as running agent)
    const runtimeResourcePlan = planRuntimeResources(manifest, { agentName, repoName });
    const nodeRuntime = resolveBwrapNodeRuntime();
    assertManifestEnvProfileCompleteness(manifest, profileConfig, { agentName, repoName, profileName: activeProfile });
    const envMap = buildFullEnvMap(agentName, manifest, profileConfig, workspacePath, repoName, activeProfile, 'bwrap', runtimeResourcePlan, routerEndpoint, runtimeIdentity, grant, homeLayout.containerHome);
    const agentPrivateKeyPath = envMap.__PLOINKY_AGENT_PRIVATE_KEY_HOST_PATH || '';
    delete envMap.__PLOINKY_AGENT_PRIVATE_KEY_HOST_PATH;
    const hostPort = record.config?.ports?.[0]?.hostPort;
    if (hostPort) envMap.PORT = String(hostPort);
    const forceInteractiveShell = entryCommand && String(entryCommand).trim() === '/bin/sh' && process.stdin.isTTY;
    if (forceInteractiveShell) {
        for (const key of ['TERM', 'COLORTERM', 'LINES', 'COLUMNS']) {
            if (process.env[key]) envMap[key] = process.env[key];
        }
        envMap.HISTFILE = `/shared/.ploinky-${sanitizeHistoryName(agentName)}-shell-history`;
        envMap.HISTSIZE = '5000';
        envMap.HISTFILESIZE = '10000';
        envMap.PS1 = '$ ';
    }

    // Build bwrap args (same mounts as the running agent)
    const manifestStorage = mergeBwrapManifestVolumes(manifest, profileConfig);
    const bwrapArgs = buildBwrapArgs({
        agentCodePath,
        agentLibPath,
        nodeModulesDir,
        sharedDir,
        cwd: projectPath,
        cwdMountTarget,
        agentHomeDir,
        nodeRuntimePath: nodeRuntime.hostRuntimePath,
        skillsPath: agentSkillsPath,
        envMap,
        codeReadOnly,
        skillsReadOnly,
        volumes: manifestStorage.volumes,
        volumeOptions: manifestStorage.volumeOptions,
        runtimeResourcePlan,
        agentPrivateKeyPath,
        agentLibGrant: grant,
    });

    // For interactive sessions, die-with-parent IS appropriate
    // (unlike daemon agents which must outlive the CLI)
    bwrapArgs.push('--die-with-parent');

    // Build command
    const sandboxWorkdir = isolatedHome ? '/root' : projectPath;
    const shellCommand = buildBwrapInteractiveCommand(sandboxWorkdir, entryCommand, { forceInteractiveShell });
    bwrapArgs.push('--', 'sh', '-lc', shellCommand);

    debugLog(`[bwrap] ${agentName}: interactive session: sh -lc ${JSON.stringify(shellCommand)}`);

    try {
        assertHostModeGenerationCapability({
            agentId: deriveAgentPrincipalId(repoName, agentName),
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            routeKey: record.alias || agentName,
            containerName,
        });
        options.onReady?.();
        const result = spawnBwrapInteractive(bwrapArgs, { usePty: process.stdin.isTTY });
        return result.status ?? 0;
    } finally {
        try {
            fs.rmSync(agentLibPath, { recursive: true, force: true });
        } catch (_) {}
    }
    } finally {
        attached?.release();
    }
}

export {
    ensureBwrapService,
    resolveBwrapRuntimeProfile,
    startBwrapProcess,
    appendControllerStateGuards,
    mergeBwrapManifestVolumes,
    buildBwrapArgs,
    buildFullEnvMap,
    buildBwrapInteractiveCommand,
    buildShellCommand,
    ensureBwrapAgentLibDir,
    resolveBwrapNodeRuntime,
    bwrapDependencyReuseProblem,
    attachBwrapInteractive,
    BWRAP_PATH
};
