import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { isMainThread } from 'node:worker_threads';
import { createNetworkLifecycleAdapter } from '../networkLifecycle.js';
import { networkContractHash } from '../networkContract.js';
import { effectiveInstanceKey } from '../../utils/workspaceDependencyGraph.js';
import { MpsError } from './mpsEligibility.mjs';
import { isMpsClientAlias, MPS_GENERATION_LABEL } from './mps.mjs';

/** A daemon transition must not discard an unjournaled CUDA client's server. */
export function assertKnownMpsClients({ runtime, registry = {}, state = null, query = spawnSync } = {}) {
    if (!['podman', 'docker'].includes(runtime)) throw new MpsError('MPS inventory requires a supported nested engine');
    const reply = query(runtime, ['ps', '-a', '--no-trunc', '--filter', 'label=ploinky.mpsgeneration', '--format', '{{.ID}}'], {
        encoding: 'utf8', timeout: 5000, maxBuffer: 64 * 1024, stdio: ['ignore', 'pipe', 'pipe'],
    });
    const text = String(reply.stdout || '').trim();
    if (reply.status !== 0 || reply.error || reply.signal || Buffer.byteLength(text) > 64 * 1024) throw new MpsError('The complete MPS client inventory is unavailable');
    const ids = text ? text.split(/\r?\n/) : [];
    if (ids.length > 512 || ids.some((id) => !/^[a-f0-9]{64}$/.test(id)) || new Set(ids).size !== ids.length) throw new MpsError('MPS client inventory has ambiguous identities');
    const known = new Set([...Object.values(registry).map((record) => record?.containerId),
        ...(state?.oldClients || []).map((client) => client.containerId), ...(state?.pendingClients || []).map((client) => client.containerId)]);
    if (ids.some((id) => !known.has(id))) throw new MpsError('An MPS client is outside the exact registry and transition journal. Recover this Box on the host before changing its daemon.');
    return ids;
}

/**
 * The alias to inspect or drain one journaled client with. The exact current
 * registry record (same key, instanceId, enableGeneration and containerId)
 * decides; a journaled alias that disagrees with it is an identity change.
 * Without an exact record only the journaled alias can be used, and a journal
 * written before aliases were recorded cannot prove one.
 */
export function resolveMpsClientAlias(client, record) {
    const journaled = Object.hasOwn(client, 'alias') ? client.alias : undefined;
    if (journaled !== undefined && !isMpsClientAlias(journaled)) throw new MpsError('MPS client alias is invalid', 'identity_changed');
    const exact = record && record.instanceId === client.instanceId && record.enableGeneration === client.enableGeneration
        && record.containerId === client.containerId;
    if (exact) {
        const current = record.alias === undefined || record.alias === null ? '' : record.alias;
        if (!isMpsClientAlias(current)) throw new MpsError('MPS client registry alias is invalid', 'identity_changed');
        if (journaled !== undefined && journaled !== current) throw new MpsError('MPS client alias changed since it was journaled', 'identity_changed');
        return current;
    }
    if (journaled === undefined) throw new MpsError('MPS client has neither an exact registry record nor a journaled alias', 'identity_changed');
    return journaled;
}

export function inspectMpsClient(client, { network, runtime, alias = client.alias, createAdapter = createNetworkLifecycleAdapter } = {}) {
    if (!/^[a-f0-9]{64}$/.test(String(client.containerId || ''))) throw new MpsError('MPS inspection needs an immutable client ID', 'identity_changed');
    // Never the canonical identity by default: an aliased instance has its own.
    if (!isMpsClientAlias(alias)) throw new MpsError('MPS inspection needs the exact client alias', 'identity_changed');
    const [repoName, agentName] = String(client.ref || '').split('/');
    return createAdapter({ runtime }).inspectContainerContract(client.containerId, network, agentName, {
        instanceKey: effectiveInstanceKey(repoName, agentName, alias), contractHash: networkContractHash(network),
        instanceId: client.instanceId, enableGeneration: client.enableGeneration, requireRuntimeIdentity: true,
    });
}

const IMMUTABLE_ID = /^[a-f0-9]{64}$/;
export const sameMpsTuple = (left, right) => Boolean(left && right) && left.key === right.key && left.instanceId === right.instanceId
    && left.enableGeneration === right.enableGeneration && left.containerId === right.containerId;

/*
 * The launching operation of a created candidate. A launch whose caller waits
 * for readiness after releasing the lifecycle locks (a no-wait child) leaves
 * its readiness entry visible to other coordinations while it is still
 * starting. Such an entry records its owner: the launching process (PID, its
 * kernel start time where /proc exposes it, and a per-process token) and one
 * operation ID. The entry is settled only when that owner is proven gone:
 * the process no longer exists or is another incarnation of the PID, or, in
 * this process, the operation was released. An entry without an owner was
 * written under locks its launcher held through readiness, so a coordination
 * that now holds those locks sees a finished attempt.
 */
const PROCESS_TOKEN = randomUUID();
const liveOperations = new Set();
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

/*
 * Every thread of a process has its own module instance (the Router runs Apply
 * and Marketplace enable in worker threads), so `liveOperations` is invisible
 * to the other threads. Each operation therefore also records its state in one
 * private file of a per-process directory, which every thread reads: 'live'
 * while it runs, 'released' once it ended. A thread that finds no file proves
 * nothing and treats the owner as live; only an explicit release is gone.
 */
const SHARED_OWNER_DIRECTORY = path.join(os.tmpdir(), `ploinky-mps-owners-${process.pid}`);
function writeSharedOperation(operationId, state, { directory = SHARED_OWNER_DIRECTORY, fsApi = fs } = {}) {
    try {
        fsApi.mkdirSync(directory, { recursive: true, mode: 0o700 });
        fsApi.writeFileSync(path.join(directory, operationId), state, { mode: 0o600 });
    } catch (_) { /* unwritable: the other threads keep treating the owner as live */ }
}
function sharedOperationReleased(operationId, { directory = SHARED_OWNER_DIRECTORY, fsApi = fs } = {}) {
    try { return String(fsApi.readFileSync(path.join(directory, operationId), 'utf8')) === 'released'; } catch (_) { return false; }
}
// One main thread owns the directory: it removes a leftover of an earlier
// incarnation of this PID at load and its own at exit.
if (isMainThread) {
    try { fs.rmSync(SHARED_OWNER_DIRECTORY, { recursive: true, force: true }); } catch (_) {}
    process.once('exit', () => { try { fs.rmSync(SHARED_OWNER_DIRECTORY, { recursive: true, force: true }); } catch (_) {} });
}

export function readProcessStartTime(pid, { fsApi = fs } = {}) {
    try {
        const text = String(fsApi.readFileSync(`/proc/${pid}/stat`, 'utf8'));
        const fields = text.slice(text.lastIndexOf(')') + 2).split(' ');
        return /^\d{1,20}$/.test(fields[19] || '') ? fields[19] : null;
    } catch (_) { return null; }
}

/** Register one launch operation of this process as live and return its owner record. */
export function mpsLaunchOwner({ readStartTime = readProcessStartTime } = {}) {
    const operationId = randomUUID();
    liveOperations.add(operationId);
    writeSharedOperation(operationId, 'live');
    return { pid: process.pid, startTime: readStartTime(process.pid), processToken: PROCESS_TOKEN, operationId };
}

/** The launch operation finished (acknowledged, failed or settled). */
export function releaseMpsLaunchOwner(owner) {
    if (owner && owner.processToken === PROCESS_TOKEN) {
        liveOperations.delete(owner.operationId);
        // Visible to the other threads of this process.
        if (UUID.test(String(owner.operationId))) writeSharedOperation(owner.operationId, 'released');
    }
}

/**
 * 'released' (no owner recorded), 'gone' (proven) or 'live'. Anything that
 * cannot be proven gone, including a malformed owner, is 'live'.
 */
export function mpsOwnerState(owner, { kill = (pid) => process.kill(pid, 0), readStartTime = readProcessStartTime } = {}) {
    if (owner === undefined || owner === null) return 'released';
    if (typeof owner !== 'object' || !Number.isSafeInteger(owner.pid) || owner.pid < 1 || !UUID.test(String(owner.processToken))
        || !UUID.test(String(owner.operationId)) || (owner.startTime !== null && !/^\d{1,20}$/.test(String(owner.startTime)))) return 'live';
    if (owner.processToken === PROCESS_TOKEN) return liveOperations.has(owner.operationId) ? 'live' : 'gone';
    if (owner.pid === process.pid) {
        // This PID runs this process, with another token: either another
        // thread of this process (the Router runs Apply and Marketplace
        // enable in worker threads, each with its own module instance and
        // token, so its live operation is unknown here) or an earlier
        // incarnation of the PID. Only a different process start time proves
        // the latter, or the operation's own recorded release (shared through
        // the per-process directory); anything unprovable is live.
        const own = owner.startTime ? readStartTime(process.pid) : null;
        if (owner.startTime && own && own !== owner.startTime) return 'gone';
        return sharedOperationReleased(owner.operationId) ? 'gone' : 'live';
    }
    try { kill(owner.pid); } catch (error) { if (error?.code === 'ESRCH') return 'gone'; }
    const current = owner.startTime ? readStartTime(owner.pid) : null;
    if (owner.startTime && current && current !== owner.startTime) return 'gone';
    return 'live';
}

/**
 * Journaled created candidates: 'readiness' entries with an immutable ID that
 * the registry does not publish for their key. A failed readiness or a crash
 * leaves them behind while the registry still names the predecessor; they are
 * settled through their own exact tuple, never through the registry record.
 * An entry the registry publishes is an ordinary client whose receipt is
 * pending, and an uncreated intent has no immutable ID.
 */
export function createdMpsCandidates(state, registry = {}) {
    return (Array.isArray(state?.pendingClients) ? state.pendingClients : []).filter((entry) => entry?.phase === 'readiness'
        && IMMUTABLE_ID.test(String(entry.containerId || ''))
        && !sameMpsTuple({ ...entry }, registry[entry.key]?.type === 'agent' ? { key: entry.key, ...registry[entry.key] } : null));
}

/** Presence by immutable ID only, for a client without a resolvable network. */
export function inspectMpsClientPresence(client, { runtime, createAdapter = createNetworkLifecycleAdapter } = {}) {
    if (!IMMUTABLE_ID.test(String(client?.containerId || ''))) throw new MpsError('MPS inspection needs an immutable client ID', 'identity_changed');
    const [, agentName] = String(client.ref || '').split('/');
    // An empty contract hash proves absence or reports presence as foreign;
    // it never accepts a runtime it cannot fully identify.
    const observed = createAdapter({ runtime }).inspectContainerContract(client.containerId, null, agentName || 'unknown', { contractHash: '' });
    return observed.state === 'absent' ? { state: 'absent', id: null } : { state: 'present', id: observed.id || null };
}

/**
 * A journaled share client whose manifest can no longer be resolved, judged
 * only by its recorded identity: the exact immutable ID, this workspace's
 * ownership and network contract labels, the recorded instance identity and
 * the MPS generation it was launched under. Anything unproven is not 'exact'.
 */
export function inspectRecordedMpsClient(client, { runtime, run, createAdapter = createNetworkLifecycleAdapter } = {}) {
    if (!IMMUTABLE_ID.test(String(client?.containerId || ''))) throw new MpsError('MPS inspection needs an immutable client ID', 'identity_changed');
    const observed = createAdapter({ runtime, ...(run ? { run } : {}) }).inspectRecordedAgentRuntime(client.containerId, { instanceId: client.instanceId, enableGeneration: client.enableGeneration });
    if (observed.state !== 'exact') return observed;
    if (!client.mpsGeneration || String(observed.labels?.[MPS_GENERATION_LABEL] || '') !== client.mpsGeneration) return { state: 'owned-drift', id: observed.id, reason: 'mps-generation' };
    return observed;
}

/** Stop that exact recorded client by its immutable ID and prove it stopped. */
export function stopRecordedMpsClient(client, { runtime, run = defaultEngineRun, timeoutSeconds = 30 } = {}) {
    if (!IMMUTABLE_ID.test(String(client?.containerId || ''))) throw new MpsError('MPS stop needs an immutable client ID', 'identity_changed');
    const stopped = run(runtime, ['container', 'stop', '--time', String(timeoutSeconds), client.containerId], { timeoutMs: (timeoutSeconds + 15) * 1000 });
    if (!stopped.ok) throw new MpsError(`The recorded MPS client ${client.key} could not be stopped by its immutable ID`, 'identity_changed');
    const inspected = run(runtime, ['container', 'inspect', client.containerId], { timeoutMs: 10_000 });
    let record = null;
    try { record = JSON.parse(String(inspected.stdout || ''))?.[0] || null; } catch (_) {}
    if (!inspected.ok || !record || (record.Id || record.ID) !== client.containerId || record.State?.Running === true) {
        throw new MpsError(`The recorded MPS client ${client.key} is not proven stopped`, 'identity_changed');
    }
    return { state: 'stopped', id: client.containerId };
}

function defaultEngineRun(runtime, args, { timeoutMs = 10_000 } = {}) {
    const reply = spawnSync(runtime, args, { encoding: 'utf8', timeout: timeoutMs, maxBuffer: 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe'] });
    return { ok: reply.status === 0 && !reply.error && !reply.signal, status: reply.status, stdout: String(reply.stdout || ''), stderr: String(reply.stderr || '') };
}

/** The registry-shaped exact identity a created candidate was launched with. */
export function mpsCandidateRecord(candidate) {
    const [repoName, agentName] = String(candidate.ref || '').split('/');
    if (!repoName || !agentName || !isMpsClientAlias(candidate.alias ?? '')) throw new MpsError('A journaled MPS candidate has no exact identity', 'identity_changed');
    return { type: 'agent', repoName, agentName, alias: candidate.alias || '', instanceId: candidate.instanceId, enableGeneration: candidate.enableGeneration, containerId: candidate.containerId };
}

/**
 * Settle one created candidate: absent means it is already gone; a present
 * runtime whose launching operation is not proven gone is still starting and
 * is left untouched ('in-flight'); otherwise the exact runtime (labels,
 * instance identity and immutable ID) is removed by that ID; anything else is
 * refused without effects.
 */
export function settleCreatedMpsCandidate(candidate, { inspect, remove, ownerState = mpsOwnerState }) {
    const observation = inspect(candidate);
    if (observation?.state === 'absent') return 'absent';
    if (ownerState(candidate.owner) === 'live') return 'in-flight';
    if (observation?.state !== 'exact' || observation.id !== candidate.containerId) {
        throw new MpsError(`The journaled MPS candidate ${candidate.key} is not its exact created runtime. Recover this Box on the host before changing its daemon.`, 'identity_changed');
    }
    mpsCandidateRecord(candidate);
    const removed = remove(candidate);
    if (removed?.state !== 'removed' && removed?.state !== 'absent') throw new MpsError(`The journaled MPS candidate ${candidate.key} could not be removed by its immutable ID`, 'identity_changed');
    return 'removed';
}

/** Drop exactly that candidate's journal entry after its cleanup succeeded. */
export function dropSettledMpsCandidate(store, candidate) {
    const current = store.read();
    if (!current) return;
    store.write({ ...current, pendingClients: (current.pendingClients || []).filter((entry) => !(entry.phase === 'readiness' && sameMpsTuple(entry, candidate))) });
}
