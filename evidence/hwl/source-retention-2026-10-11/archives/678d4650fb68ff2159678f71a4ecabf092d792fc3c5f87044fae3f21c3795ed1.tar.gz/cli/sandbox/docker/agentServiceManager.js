import { ensureRepositoryLink } from '../../utils/repositoryInstall.mjs';
import { prepareLinkedRepositories } from '../../utils/linkInstall.mjs';
import { resolveAgentRepositoryName } from '../../utils/agentRepositorySource.mjs';
import { execSync, spawnSync } from 'child_process';
import { createHash, randomUUID } from 'node:crypto';
import fs from 'fs';
import { dependencyRefreshOperation, hasAgentPackageJson } from '../../utils/dependencies/dependencyRefresh.mjs';
import path from 'path';
import { fileURLToPath } from 'url';
import { isDeepStrictEqual } from 'node:util';
import { retireNoWaitRunMarker } from '../../commands/noWaitMarkerLifecycle.js';
import {
    assertManifestEnvProfileCompleteness,
    buildEnvMap,
    buildEnvFlags,
    formatEnvFlag,
    getExposedNames,
    getManifestEnvNames,
    resolveManifestImage,
    resolveVarValue
} from '../../utils/security/secretVars.js';
import {
    buildAgentCredentialEnv,
    buildAgentPrincipalEnv,
    RESERVED_AGENT_ENV_NAMES,
} from '../../utils/security/agentIdentityEnv.js';
import {
    GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE,
    GENERATED_ROUTER_LOCAL_STREAMING,
    GENERATED_ROUTER_DESCRIPTOR_SCHEMA,
    GENERATED_ROUTER_TRANSPORT_VERSION,
    buildGeneratedRouterDescriptorEnv,
    createGeneratedRouterDescriptorPayload,
    readVerifiedGeneratedRouterDescriptorFile,
    semanticTopologyDigest,
    signGeneratedRouterDescriptorEnvelope,
    writeGeneratedRouterDescriptorFile,
} from '../../utils/security/generatedRouterDescriptor.js';
import { debugLog } from '../../utils/utils.js';
import {
    CONTAINER_CONFIG_PATH,
    containerExists,
    computeEnvHash,
    createHostSandboxStartupError,
    flagsToArgs,
    getAgentContainerName,
    getConfiguredProjectPath,
    getContainerLabel,
    getAgentMcpConfigPath,
    getRuntime,
    getRuntimeForAgent,
    ensureImagePresent,
    imageExists,
    isContainerRunning,
    isPloinkyBoxRuntime,
    isSandboxRuntime,
    loadAgentsMap,
    managedContainerLabelArgs,
    parseHostPort,
    parseManifestPorts,
    saveAgentsMap,
    syncAgentMcpConfig
} from './common.js';
import {
    PROBE_CONTROL_CONTAINER_ROOT,
    clearLivenessState,
    ensureHealthProbeHostDir,
    healthProbeHostDir,
    prepareHealthProbeHostDirForLaunch,
    retireRuntimeRelaySocket,
    runContainerScriptReadiness,
} from './healthProbes.js';
import { removeExactRegisteredContainer, stopAndRemove } from './containerFleet.js';
import {
    TARGETED_DRAIN_ACKNOWLEDGEMENT,
    drainAndRemoveTargetedContainer,
    drainTargetedContainer,
} from './targetedContainerLifecycle.js';
import {
    admitManifestRuntimeCapabilities,
    assertRuntimeAdmissionCurrent,
    createHardwareLaunchGuard,
    limitsHashReuseReason,
    renderContainerSecurityArgs,
    renderRuntimePolicyArgs,
} from '../runtimeCapabilities.js';
import {
    formatReplacementReason,
    hashMismatchDetail,
    limitsHashDetail,
    logRuntimeReplacement,
    shortenHashes,
} from '../runtimeReplacementLog.js';
import { DEFAULT_AGENT_ENTRY, launchAgentSidecar, readManifestAgentCommand, readManifestStartCommand, splitCommandArgs } from './agentCommands.js';
import { hasExactAgentHomeLayout, resolveAgentHomeLayout } from './agentHomeLayout.js';
import { buildAgentShellArgs } from './agentShell.js';
import { AGENTS_DATA_DIR, PLOINKY_DIR, PLOINKY_WORKSPACE_ROOT, PLOINKY_SKILL_SCOPE_ENV, SHARED_DIR } from '../../utils/config.js';
import {
    planRuntimeResources,
    applyRuntimeResourceEnv,
    ensurePersistentStorageHostDir
} from '../../utils/runtime/runtimeResourcePlanner.js';
import {
    assertCanonicalAgentDataPath,
    ensureAgentDataDirectory,
} from '../../utils/runtime/agentDataPathPolicy.js';
import {
    controllerGuardMounts,
    controllerGuardTargets,
    normalizeRuntimeMountTarget,
    prepareControllerGuardMountpointCleanup,
    protectedControllerStateRoots,
} from '../../utils/runtime/controllerStateGuards.js';
import { deriveAgentPrincipalId } from '../../utils/security/agentIdentity.js';
import { ensureSharedHostDir, runPostinstallHook } from './agentHooks.js';
import {
    authorityHelperPlacementFromContext,
    cleanupStaleLeaves,
} from '../hardwareLimits/delegation.mjs';
import { captureHardwareContext } from '../hardwareLimits/requestedLimits.mjs';
import { LIMITS_HASH_LABEL } from '../hardwareLimits/resolve.mjs';
import { readAppliedObservation } from '../hardwareLimits/runtimeState.mjs';
import { hasMpsLaunch, readMpsLaunch, verifyMpsLaunch, mpsLaunchArgs } from '../hardwareLimits/mpsLaunch.mjs';
import { bwrapDependencyReuseProblem, ensureBwrapService } from '../bwrap/bwrapServiceManager.js';
import {
    clearBwrapPidIfExact,
    normalizeExpectedPredecessor,
    observeSandboxRuntime,
    stopExactSandboxProcess,
} from '../bwrap/bwrapFleet.js';
import { ensureSeatbeltService, seatbeltDependencyReuseProblem } from '../seatbelt/seatbeltServiceManager.js';
import { detectShellForImage, SHELL_FALLBACK_DIRECT } from './shellDetection.js';
import {
    detectRuntimeKeyForAgent,
    isNoNodeRuntimeKey,
    NO_NODE_RUNTIME_KEY,
} from '../../utils/dependencies/dependencyRuntimeKey.js';
import {
    admittedDependencyRecord,
    noCacheDependencyRecord,
    prepareRuntimeDependencies,
    runtimeDependencyReuseProblem,
} from '../../utils/dependencies/store/runtimeDependencies.mjs';
import { containerToolchainIdentity } from '../../utils/dependencies/store/installContract.mjs';
import {
    agentLibCacheLinkProblem,
    ensureAgentLibCacheLink,
} from '../../utils/dependencies/agentLibLink.js';
import {
    runPreContainerLifecycle,
    runProfileLifecycle
} from '../../utils/runtime/lifecycleHooks.js';
import {
    formatMissingSecretsError,
    getSecrets,
    validateSecrets
} from '../../utils/security/secretInjector.js';
import {
    getDefaultMountModes,
    getProfileEnvVars,
    resolveManifestRuntimeProfile
} from '../../utils/runtime/profileService.js';
import { resolveAgentExecutionMode, resolveAgentReadinessProtocol } from '../../utils/runtime/startupReadiness.js';
import {
    getAgentWorkDir,
    getAgentCodePath,
    getAgentSkillsPath
} from '../../utils/workspaceStructure.js';
import {
    prepareFreshRuntimeRoot,
    runtimeSegment
} from '../../utils/runtime/runtimeStaging.js';
import {
    assertManifestStorageAdmission,
    ensureManifestVolumeHostPath,
    resolveManifestVolumeHostPath
} from '../../utils/runtime/manifestVolumePolicy.js';
import {
    isLlmRuntimeManifest,
    prepareLlmStartup,
    resolveLlmRuntimeAdmissionContext,
} from './llmRuntimeIntegration.js';
import {
    assertHostSandboxNetworkCompatibility,
    assertNetworkStartupCompatibility,
    canonicalizeNetwork,
    networkContractHash,
} from '../networkContract.js';
import {
    assertNetworkLifecycleCapability,
    createNetworkLifecycleAdapter,
    withNetworkLifecycleLock,
} from '../networkLifecycle.js';
import { effectiveInstanceKey } from '../../utils/workspaceDependencyGraph.js';
import {
    INITIAL_ROUTER_PORT,
    ROUTER_ENV_NAMES,
    assertRouterEndpoint,
    buildRouterEndpoint,
} from '../routerPort.js';
import {
    abortEdgeRoutingPreparation,
    assertAdditivePreparedRuntimeIdentity,
    assertHostModeGenerationCapability,
    assertPreparedRuntimeIdentity,
    createRouterAttestationGenerationLease,
    edgeRuntimeEnvironment,
    edgeTopologyMount,
    inactivateEdgeRoutingGeneration,
    prepareAdditiveEdgeRoutingGeneration,
    prepareEdgeRoutingGeneration as prepareEdgeRoutingGenerationRaw,
    prepareHostModeCapabilityForInactiveGeneration,
    withEdgeGenerationApplyLock,
} from '../edgeGeneration.js';
import { readRoutingConfig, writeRoutingConfig } from '../../server/routingFile.js';
import {
    attestRouterAuthority,
    buildRouterAuthorityTopologyIntent,
    managedImageUserNamespace,
    ROUTER_AUTHORITY_HELPER_IMAGE,
    runContainerAuthorityProbe,
} from '../routerAuthorityAttestation.js';
import { isInsideBox } from '../../../ploinky-box/lib/boxMarker.mjs';
import {
    agentLibAliasShadows,
    agentLibGrant,
    agentLibGrantEnv,
    agentLibReuseProblem,
    agentLibRuntimeRecord,
} from '../agentLibGrant.js';
import {
    assertCandidateLifecycleTransition,
    isCandidateCleanupReceiptDocument,
    RUNTIME_CLEANUP_RECEIPT_VERSION,
} from '../runtimeCleanupReceipt.js';

import { readRuntimeCandidate, writeRuntimeCandidate, retireRuntimeCandidate } from '../runtimeCandidateStore.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const AGENT_LIB_PATH = path.resolve(__dirname, '../../../Agent');
const AGENT_CONTROL_ENTRYPOINT = '/Agent/server/AgentEntrypoint.sh';
const LLM_RUNTIME_SHARED_PATH = path.join(PLOINKY_WORKSPACE_ROOT, 'llm-runtime', 'shared');
const AUTHORIZED_CLEANUP_RECEIPTS = new WeakMap();
const CONSUMED_CLEANUP_RECEIPTS = new WeakSet();
const FAILED_RUNTIME_IDENTITY_ROTATIONS = new WeakMap();

function freezeCleanupReceipt(value) {
    if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
    for (const child of Object.values(value)) freezeCleanupReceipt(child);
    return Object.freeze(value);
}

function invalidCleanupReceipt(message) {
    const error = new Error(message);
    error.code = 'PLOINKY_RUNTIME_CLEANUP_RECEIPT_INVALID';
    return error;
}

// Receipt minting remains inside the lifecycle owner. No exported helper can
// authorize cleanup by constructing a field-identical object.
function issueCandidateCleanupReceipt(document) {
    const receipt = freezeCleanupReceipt({
        version: RUNTIME_CLEANUP_RECEIPT_VERSION,
        scope: 'candidate',
        ...document,
    });
    if (!isCandidateCleanupReceiptDocument(receipt)) {
        throw invalidCleanupReceipt('candidate cleanup lifecycle produced an invalid receipt');
    }
    AUTHORIZED_CLEANUP_RECEIPTS.set(receipt, Object.freeze({ operationId: receipt.operationId }));
    return receipt;
}

function beginCandidateLifecycle({
    runtimeKind,
    candidateName,
    contractHash,
    runtimeIdentity,
    predecessorId = '',
} = {}) {
    return issueCandidateCleanupReceipt({
        operationId: randomUUID(),
        runtimeKind,
        phase: 'resolve',
        creationAttempted: false,
        candidateName,
        contractHash,
        runtimeIdentity: structuredClone(runtimeIdentity || {}),
        state: 'not-created-proven',
        ...(predecessorId ? { predecessorId } : {}),
        inspectionComplete: false,
        ownershipProof: {},
    });
}

function assertCandidateCleanupReceipt(receipt, expected = {}) {
    if (!receipt || !AUTHORIZED_CLEANUP_RECEIPTS.has(receipt)
        || CONSUMED_CLEANUP_RECEIPTS.has(receipt)
        || !isCandidateCleanupReceiptDocument(receipt)) {
        throw invalidCleanupReceipt('candidate cleanup requires one live internally-issued phase receipt');
    }
    for (const field of ['runtimeKind', 'candidateName', 'candidateId', 'contractHash']) {
        if (expected[field] !== undefined
            && String(receipt[field] || '') !== String(expected[field] || '')) {
            throw invalidCleanupReceipt(`candidate cleanup receipt ${field} does not match the exact runtime candidate`);
        }
    }
    if (expected.runtimeIdentity) {
        for (const [field, value] of Object.entries(expected.runtimeIdentity)) {
            if (String(receipt.runtimeIdentity?.[field] || '') !== String(value || '')) {
                throw invalidCleanupReceipt(`candidate cleanup receipt runtimeIdentity.${field} does not match the exact runtime candidate`);
            }
        }
    }
    return receipt;
}

function advanceCandidateLifecycle(receipt, changes = {}) {
    assertCandidateCleanupReceipt(receipt);
    const nextDocument = {
        ...receipt,
        ...changes,
        version: RUNTIME_CLEANUP_RECEIPT_VERSION,
        operationId: receipt.operationId,
        runtimeKind: receipt.runtimeKind,
        scope: 'candidate',
        candidateName: receipt.candidateName,
        contractHash: receipt.contractHash,
        runtimeIdentity: structuredClone(receipt.runtimeIdentity),
        ownershipProof: structuredClone(changes.ownershipProof ?? receipt.ownershipProof),
    };
    const candidate = freezeCleanupReceipt(nextDocument);
    assertCandidateLifecycleTransition(receipt, candidate);
    CONSUMED_CLEANUP_RECEIPTS.add(receipt);
    AUTHORIZED_CLEANUP_RECEIPTS.set(candidate, Object.freeze({ operationId: candidate.operationId }));
    return candidate;
}

function consumeCandidateCleanupReceipt(receipt, expected = {}) {
    const validated = assertCandidateCleanupReceipt(receipt, expected);
    CONSUMED_CLEANUP_RECEIPTS.add(receipt);
    return validated;
}

function attachRestartCandidate(error, candidate) {
    const failure = error && typeof error === 'object'
        ? error
        : new Error(String(error || 'managed runtime launch failed'));
    const prior = failure.ploinkyRestartCandidate && typeof failure.ploinkyRestartCandidate === 'object'
        ? failure.ploinkyRestartCandidate
        : {};
    Object.defineProperty(failure, 'ploinkyRestartCandidate', {
        configurable: true,
        enumerable: false,
        writable: false,
        value: Object.freeze({ ...prior, ...candidate }),
    });
    return failure;
}

function runtimeCandidateContractHash(admission, runtimeIdentity, network, runtimeKind) {
    const bytes = Buffer.from(JSON.stringify({
        admission: admission?.descriptor || null,
        runtimeIdentity,
        network,
        runtimeKind,
    }));
    return `sha256:${createHash('sha256').update(bytes).digest('hex')}`;
}
function resolveLlmRuntimeSharedPath(agentPath) {
    // Prefer the shared runtime that ships inside the agent's own repo so
    // clone-based deploys (llm-runtime under .ploinky/repos) mount the real
    // runtime-agent; fall back to the workspace-root sibling (dev layout).
    try {
        const repoShared = path.join(path.dirname(agentPath), 'shared');
        if (fs.existsSync(path.join(repoShared, 'runtime-agent'))) return repoShared;
    } catch (_) { /* fall through to dev-layout default */ }
    return LLM_RUNTIME_SHARED_PATH;
}
const AGENT_PRIVATE_KEY_CONTAINER_PATH = '/run/ploinky-agent.key';
const PODMAN_STAGED_NODE_OPTIONS = ['--preserve-symlinks', '--preserve-symlinks-main'];
const PODMAN_RUNTIME_ROOT = path.join(PLOINKY_DIR, 'container-runtime');
const ROUTER_DESCRIPTOR_HOST_DIR = path.join(PLOINKY_DIR, 'run', 'router-descriptors');

function pathTypeForSymlink(sourcePath) {
    try {
        return fs.statSync(sourcePath).isDirectory() ? 'dir' : 'file';
    } catch (_) {
        return 'file';
    }
}

function normalizeStagedRelPath(relPath) {
    return String(relPath || '')
        .replace(/\\/g, '/')
        .replace(/^\/+/, '')
        .replace(/\/+$/, '');
}

function hasStagedOverrideDescendant(relPath, overrideRelPaths) {
    const prefix = relPath ? `${relPath}/` : '';
    for (const overridePath of overrideRelPaths) {
        if (overridePath.startsWith(prefix) && overridePath !== relPath) {
            return true;
        }
    }
    return false;
}

function stageSourceTreeWithOverrides(sourceDir, stagedDir, overrideRelPaths, baseRel = '') {
    if (!fs.existsSync(sourceDir)) return;
    fs.mkdirSync(stagedDir, { recursive: true });
    for (const entry of fs.readdirSync(sourceDir, { withFileTypes: true })) {
        const relPath = normalizeStagedRelPath(baseRel ? `${baseRel}/${entry.name}` : entry.name);
        if (!relPath || overrideRelPaths.has(relPath)) continue;

        const sourcePath = path.join(sourceDir, entry.name);
        const stagedPath = path.join(stagedDir, entry.name);
        if (hasStagedOverrideDescendant(relPath, overrideRelPaths)) {
            if (!entry.isDirectory()) throw new Error(`Cannot stage a code override below non-directory ${relPath}`);
            stageSourceTreeWithOverrides(sourcePath, stagedPath, overrideRelPaths, relPath);
            continue;
        }
        fs.symlinkSync(sourcePath, stagedPath, pathTypeForSymlink(sourcePath));
    }
}

function writeStagedSymlink(stagedCodePath, relPath, hostPath) {
    const normalizedRelPath = normalizeStagedRelPath(relPath);
    if (!normalizedRelPath) return;
    const linkPath = path.join(stagedCodePath, ...normalizedRelPath.split('/'));
    fs.mkdirSync(path.dirname(linkPath), { recursive: true });
    try {
        fs.rmSync(linkPath, { recursive: true, force: true });
    } catch (_) {}
    fs.symlinkSync(hostPath, linkPath, pathTypeForSymlink(hostPath));
}

function normalizeCodeLinkSpec(value) {
    if (value && typeof value === 'object' && !Array.isArray(value)) {
        return {
            hostPath: value.hostPath,
            targetPath: value.targetPath || value.hostPath,
            readOnly: value.readOnly === true
        };
    }
    return {
        hostPath: value,
        targetPath: value,
        readOnly: false
    };
}

function assertPodmanCodeMountAllowed(relPath, containerPath = '') {
    const normalizedRelPath = normalizeStagedRelPath(relPath);
    if (normalizedRelPath === 'node_modules' || normalizedRelPath.startsWith('node_modules/')) {
        throw new Error(
            `[podman] manifest volume '${containerPath || `/code/${normalizedRelPath}`}' targets reserved /code/node_modules. `
            + 'Dependencies are prepared by Ploinky and mounted read-only.'
        );
    }
}

function setPodmanTargetMount(mounts, hostPath, readOnly, targetPath = hostPath) {
    if (!hostPath) return;
    const resolvedHostPath = path.resolve(hostPath);
    if (!fs.existsSync(resolvedHostPath)) return;
    if (mounts.has(resolvedHostPath)) {
        mounts.delete(resolvedHostPath);
    }
    mounts.set(resolvedHostPath, {
        source: resolvedHostPath,
        target: path.resolve(targetPath),
        ro: readOnly === true
    });
}

function buildPodmanStagedTargetMounts(options = {}) {
    const {
        agentCodePath,
        nodeModulesDir,
        codeLinks = new Map(),
        linkedRepositories = [],
        codeReadOnly = false,
        writableProjectSource = false,
    } = options;
    const mounts = new Map();

    // /code remains read-only. For global/devel agents the same host source is
    // also deliberately exposed through the writable project/workspace path;
    // protect only the isolated source path when no writable project exists.
    setPodmanTargetMount(mounts, agentCodePath, codeReadOnly && !writableProjectSource);
    for (const [relPath, rawSpec] of codeLinks.entries()) {
        const normalizedRelPath = normalizeStagedRelPath(relPath);
        if (!normalizedRelPath) continue;
        assertPodmanCodeMountAllowed(normalizedRelPath);
        const spec = normalizeCodeLinkSpec(rawSpec);
        setPodmanTargetMount(mounts, spec.hostPath, spec.readOnly, spec.targetPath);
    }

    for (const repo of linkedRepositories) {
        setPodmanTargetMount(mounts, repo.source, repo.readOnly, repo.target);
    }

    // Dependency caches are protected even when a broader workspace/cwd bind is rw.
    setPodmanTargetMount(mounts, nodeModulesDir, true);
    return Array.from(mounts.values());
}

function podmanMountSuffix(readOnly) {
    // Podman remote on macOS has parsed absolute self-mounts incorrectly with
    // ':ro,z', creating paths that end in 'o,z'. ':z,ro' preserves the target.
    return readOnly ? ':z,ro' : ':z';
}

function shouldPodmanChownManifestVolume(resolvedHostPath, options = {}) {
    if (options?.readOnly === true) return false;
    if (options?.podmanChown === true) return true;
    if (options?.podmanChown === false) return false;

    const dataRoot = path.resolve(AGENTS_DATA_DIR);
    const resolved = path.resolve(resolvedHostPath);
    return isPathWithin(resolved, dataRoot);
}

function podmanManifestVolumeMountSuffix(resolvedHostPath, options = {}) {
    if (options?.readOnly === true) return ':z,ro';
    return shouldPodmanChownManifestVolume(resolvedHostPath, options) ? ':z,U' : ':z';
}

function manifestVolumeMountSuffix(runtime, resolvedHostPath, options = {}) {
    if (runtime === 'podman') {
        return podmanManifestVolumeMountSuffix(resolvedHostPath, options);
    }
    return options?.readOnly === true ? ':ro' : '';
}

function readVolumeOptions(source) {
    return source?.volumeOptions && typeof source.volumeOptions === 'object'
        ? source.volumeOptions
        : {};
}

function mergeManifestVolumes(manifest, profileConfig = null) {
    return {
        ...(manifest?.volumes && typeof manifest.volumes === 'object' ? manifest.volumes : {}),
        ...(profileConfig?.volumes && typeof profileConfig.volumes === 'object' ? profileConfig.volumes : {}),
    };
}

function mergeManifestVolumeOptions(manifest, profileConfig = null) {
    return {
        ...readVolumeOptions(manifest),
        ...readVolumeOptions(profileConfig),
    };
}

function getVolumeOptionsForContainerPath(volumeOptions, containerPath) {
    return volumeOptions[containerPath]
        || volumeOptions[String(containerPath || '').replace(/\/+$/, '')]
        || {};
}

function collectManifestVolumeEntries(manifest, profileConfig = null) {
    const volumes = mergeManifestVolumes(manifest, profileConfig);
    const volumeOptions = mergeManifestVolumeOptions(manifest, profileConfig);
    return Object.entries(volumes).map(([hostPath, containerPath]) => ({
        hostPath,
        containerPath,
        resolvedHostPath: resolveManifestVolumeHostPath(hostPath),
        options: getVolumeOptionsForContainerPath(volumeOptions, containerPath),
    }));
}

function ensurePodmanStagedAgentLibDir(agentName, nodeModulesDir, options = {}) {
    if (!options || typeof options.runtimeRoot !== 'string' || !options.runtimeRoot) {
        throw new Error('ensurePodmanStagedAgentLibDir: options.runtimeRoot is required');
    }
    const runtimeRoot = options.runtimeRoot;
    const stagedAgentLibPath = path.join(runtimeRoot, `Agent-${process.pid}-${Date.now()}`);
    const sourceNodeModules = path.join(AGENT_LIB_PATH, 'node_modules');

    fs.mkdirSync(runtimeRoot, { recursive: true });
    fs.cpSync(AGENT_LIB_PATH, stagedAgentLibPath, {
        recursive: true,
        filter(sourcePath) {
            const resolvedSource = path.resolve(sourcePath);
            return resolvedSource !== sourceNodeModules
                && !resolvedSource.startsWith(`${sourceNodeModules}${path.sep}`);
        }
    });
    fs.symlinkSync(nodeModulesDir, path.join(stagedAgentLibPath, 'node_modules'), 'dir');
    if (options.linkedRepositories?.length) {
        fs.mkdirSync(path.join(stagedAgentLibPath, 'linked'));
        for (const repo of options.linkedRepositories) {
            const installed = ensureRepositoryLink(path.join(stagedAgentLibPath, repo.link), repo.target, stagedAgentLibPath, {
                linkParent: path.dirname(path.join('/Agent', repo.link)),
            });
            if (installed.status === 'conflict') throw new Error('link-install destination conflicts with existing content');
        }
    }
    return stagedAgentLibPath;
}

function ensurePodmanStagedCodeDir(agentName, agentCodePath, nodeModulesDir, codeLinks = new Map(), options = {}) {
    if (!options || typeof options.runtimeRoot !== 'string' || !options.runtimeRoot) {
        throw new Error('ensurePodmanStagedCodeDir: options.runtimeRoot is required');
    }
    const runtimeRoot = options.runtimeRoot;
    const stagedCodePath = path.join(runtimeRoot, `code-${process.pid}-${Date.now()}`);
    const normalizedLinks = new Map();
    for (const [relPath, hostPath] of codeLinks.entries()) {
        const normalizedRelPath = normalizeStagedRelPath(relPath);
        if (normalizedRelPath) {
            assertPodmanCodeMountAllowed(normalizedRelPath);
            normalizedLinks.set(normalizedRelPath, normalizeCodeLinkSpec(hostPath).targetPath);
        }
    }
    normalizedLinks.set('node_modules', nodeModulesDir);

    fs.mkdirSync(stagedCodePath, { recursive: true });
    stageSourceTreeWithOverrides(agentCodePath, stagedCodePath, new Set(normalizedLinks.keys()));
    for (const [relPath, hostPath] of normalizedLinks.entries()) {
        writeStagedSymlink(stagedCodePath, relPath, hostPath);
    }
    return stagedCodePath;
}

function resolveReusablePodmanStagedMounts(existingRecord, runtimeRoot, expectedNodeModulesDir = null) {
    const binds = Array.isArray(existingRecord?.config?.binds) ? existingRecord.config.binds : [];
    const resolvedRoot = path.resolve(String(runtimeRoot || ''));
    if (!resolvedRoot || !fs.existsSync(resolvedRoot)) return null;

    const resolveTarget = (target, prefix) => {
        const matches = binds.filter((bind) => String(bind?.target || '') === target);
        if (matches.length !== 1) return null;
        const source = path.resolve(String(matches[0]?.source || ''));
        if (!isPathWithin(source, resolvedRoot)
            || !new RegExp(`^${prefix}-\\d+-\\d+$`).test(path.basename(source))) return null;
        try {
            const identity = fs.lstatSync(source);
            if (!identity.isDirectory() || identity.isSymbolicLink()) return null;
            const realSource = fs.realpathSync(source);
            const realRoot = fs.realpathSync(resolvedRoot);
            if (!isPathWithin(realSource, realRoot)) return null;
        } catch (_) {
            return null;
        }
        return source;
    };

    const agentLibMountPath = resolveTarget('/Agent', 'Agent');
    const codeMountPath = resolveTarget('/code', 'code');
    if (!agentLibMountPath || !codeMountPath) return null;
    if (expectedNodeModulesDir) {
        // Staged trees are reusable only when their dependency links still
        // name the exact admitted payload.
        for (const staged of [agentLibMountPath, codeMountPath]) {
            try {
                if (fs.readlinkSync(path.join(staged, 'node_modules')) !== expectedNodeModulesDir) return null;
            } catch (_) {
                return null;
            }
        }
    }
    return Object.freeze({ agentLibMountPath, codeMountPath });
}

function codeRelativeMountPath(containerPath) {
    const normalized = String(containerPath || '').replace(/\\/g, '/').replace(/\/+/g, '/');
    if (!normalized.startsWith('/code/')) return null;
    return normalizeStagedRelPath(normalized.slice('/code/'.length));
}

function isPathWithin(childPath, parentPath) {
    const relativePath = path.relative(parentPath, childPath);
    return relativePath === ''
        || (relativePath && !relativePath.startsWith('..') && !path.isAbsolute(relativePath));
}

function decodeFormattedEnvValue(rawValue) {
    const raw = String(rawValue || '');
    if (raw.length >= 2 && raw.startsWith('"') && raw.endsWith('"')) {
        return raw
            .slice(1, -1)
            .replace(/\\n/g, '\n')
            .replace(/\\(["\\$`])/g, '$1');
    }
    return raw;
}

function getLastFormattedEnvValue(envStrings, name) {
    const prefix = `-e ${name}=`;
    for (let i = envStrings.length - 1; i >= 0; i -= 1) {
        const entry = String(envStrings[i] || '');
        if (entry.startsWith(prefix)) {
            return decodeFormattedEnvValue(entry.slice(prefix.length));
        }
    }
    return '';
}

function mergeNodeOptions(existingValue, requiredOptions = []) {
    const parts = String(existingValue || '').split(/\s+/).filter(Boolean);
    const seen = new Set(parts);
    for (const option of requiredOptions) {
        if (!option || seen.has(option)) continue;
        parts.push(option);
        seen.add(option);
    }
    return parts.join(' ');
}

function resolveDependencyCachePreparation({
    needsCoreDeps = false,
    agentHasPackageJson = false,
    isLlmRuntime = false,
    runtimeKey = '',
} = {}) {
    if (!needsCoreDeps) {
        return { prepare: false, fatal: false, reason: 'no-core-deps' };
    }
    if (!isNoNodeRuntimeKey(runtimeKey)) {
        return { prepare: true, fatal: false, reason: 'node-runtime' };
    }
    if (agentHasPackageJson) {
        return {
            prepare: false,
            fatal: true,
            reason: 'no-node-image',
            message: 'container image has no Node binary but the agent has package.json dependencies',
        };
    }
    if (isLlmRuntime) {
        return {
            prepare: false,
            fatal: true,
            reason: 'no-node-image',
            message: 'container image has no Node binary but the LLM runtime requires Node dependency preparation',
        };
    }
    return { prepare: false, fatal: false, reason: 'no-node-image' };
}

/**
 * Resolve a symlink path to its actual target.
 * If the path is not a symlink or doesn't exist, returns the original path.
 * @param {string} symlinkPath - The path that might be a symlink
 * @returns {string} The resolved real path, or original if not a symlink
 */
function resolveSymlinkPath(symlinkPath) {
    try {
        if (fs.existsSync(symlinkPath)) {
            const stat = fs.lstatSync(symlinkPath);
            if (stat.isSymbolicLink()) {
                return fs.realpathSync(symlinkPath);
            }
        }
    } catch (err) {
        debugLog(`Warning: could not resolve symlink ${symlinkPath}: ${err.message}`);
    }
    return symlinkPath;
}

function buildRuntimeRouterEnv(runtime, options = {}) {
    const mode = String(options.networkMode || 'default').trim().toLowerCase();
    if (Object.prototype.hasOwnProperty.call(options, 'routerHost')) {
        throw new Error('routerHost overrides are not supported; pass the validated routerEndpoint');
    }
    const endpoint = assertRouterEndpoint(options.routerEndpoint, mode, {
        explicitPort: options.routerPort,
    });
    if (!endpoint) return {};
    return {
        ...endpoint.env,
        ...edgeRuntimeEnvironment(mode),
        PLOINKY_ROUTER_HOST: endpoint.host,
        PLOINKY_ROUTER_PORT: '8080',
    };
}

function buildDefaultPodmanNetworkArgs(platform = process.platform) {
    return [
        '--network', platform === 'darwin' ? 'pasta' : 'pasta:--map-gw',
        ...(platform === 'darwin' ? ['--no-hosts'] : []),
    ];
}

// Remove only empty libpod-ID leaves under the two owned cgroup parents whose
// full IDs the engine no longer lists. Without a complete live-ID listing
// nothing is removed; nonempty or foreign leftovers are reported, never killed.
function removeStaleHardwareLeaves(runtime) {
    const listed = spawnSync(runtime, ['ps', '-a', '--no-trunc', '--format', '{{.ID}}'], { encoding: 'utf8', timeout: 10_000 });
    if (listed.status !== 0 || listed.error) {
        debugLog('[hardware-limits] stale leaf cleanup skipped: the engine container list is unavailable');
        return;
    }
    try {
        const liveIds = new Set(String(listed.stdout || '').split(/\s+/).filter((id) => /^[a-f0-9]{64}$/.test(id)));
        const { retained } = cleanupStaleLeaves({ liveIds });
        for (const entry of retained) debugLog(`[hardware-limits] stale leaf ${entry.leaf} retained: ${entry.reason}`);
    } catch (error) {
        debugLog(`[hardware-limits] stale leaf cleanup failed: ${error?.message || error}`);
    }
}

function buildBoxPodmanHostArgs({
    fsApi = fs,
    markerPath,
    managedNetwork = false,
} = {}) {
    const markerOptions = { fsApi };
    if (markerPath) markerOptions.markerPath = markerPath;
    if (!isInsideBox(markerOptions)) return [];
    // Managed default/bridge launches receive this exact mapping from the
    // network lifecycle transaction. Adding it here as well produces two
    // HostConfig.ExtraHosts entries, which the fail-closed verifier rejects.
    if (managedNetwork) return [];
    return ['--add-host', 'host.containers.internal:host-gateway'];
}
function appendRuntimeRouterEnvFlags(envStrings, routerEnv) {
    for (const [name, value] of Object.entries(routerEnv || {})) {
        envStrings.push(formatEnvFlag(name, value));
    }
}

function replaceRuntimeRouterEnvFlags(envStrings, routerEnv) {
    const prefixes = ROUTER_ENV_NAMES.map((name) => `-e ${name}=`);
    for (let index = envStrings.length - 1; index >= 0; index -= 1) {
        if (prefixes.some((prefix) => String(envStrings[index] || '').startsWith(prefix))) {
            envStrings.splice(index, 1);
        }
    }
    appendRuntimeRouterEnvFlags(envStrings, routerEnv);
}

function stripReservedAndRestoreRuntimeRouterEnvFlags(envStrings, routerEnv) {
    const reservedPrefixes = RESERVED_AGENT_ENV_NAMES.map((name) => `-e ${name}=`);
    for (let index = envStrings.length - 1; index >= 0; index -= 1) {
        const entry = String(envStrings[index] || '');
        if (reservedPrefixes.some((prefix) => entry.startsWith(prefix))
            || entry.startsWith('-e PLOINKY_ENV_SOURCE_PLOINKY_')) {
            envStrings.splice(index, 1);
        }
    }
    appendRuntimeRouterEnvFlags(envStrings, routerEnv);
}

function ensureManifestVolumeHostPaths(manifest, profileConfig = null) {
    for (const { resolvedHostPath, containerPath, options } of collectManifestVolumeEntries(manifest, profileConfig)) {
        ensureManifestVolumeHostPath(resolvedHostPath, containerPath, options);
    }
}

/**
 * Get mount mode based on active profile.
 * Installed code and skills are read-only in every profile.
 * @param {string} profile - The active profile
 * @param {string} runtime - Container runtime (docker/podman)
 * @param {object} profileConfig - Profile configuration
 * @returns {{ codeMountMode: string, skillsMountMode: string, codeReadOnly: boolean, skillsReadOnly: boolean }}
 */
function getProfileMountModes(profile, runtime, profileConfig = {}) {
    const defaultMounts = getDefaultMountModes(profile);
    // Profile overrides must not make installed source writable.
    const codeMode = defaultMounts.code;
    const skillsMode = defaultMounts.skills;
    const roSuffix = runtime === 'podman' ? ':z,ro' : ':ro';
    const rwSuffix = runtime === 'podman' ? ':z' : '';

    return {
        codeMountMode: codeMode === 'ro' ? roSuffix : rwSuffix,
        skillsMountMode: skillsMode === 'ro' ? roSuffix : rwSuffix,
        codeReadOnly: codeMode === 'ro',
        skillsReadOnly: skillsMode === 'ro'
    };
}

function normalizeMountMode(mode, fallback) {
    if (mode === 'ro' || mode === 'rw') {
        return mode;
    }
    return fallback;
}

function buildRuntimeNetworkPlan(runtime, manifestNetwork, options = {}) {
    const network = canonicalizeNetwork(manifestNetwork, { path: options.path || 'manifest.network' });
    if (network.mode === 'host') {
        return {
            mode: 'host',
            args: ['--network', 'host'],
            useHostNetwork: true,
            boxNetworkCompat: false,
            hashEnv: { PLOINKY_NETWORK_MODE: 'host' },
        };
    }
    if (network.mode === 'none') {
        return {
            mode: 'none',
            args: ['--network', 'none'],
            useHostNetwork: false,
            boxNetworkCompat: false,
            hashEnv: { PLOINKY_NETWORK_MODE: 'none' },
        };
    }
    return {
        mode: network.mode,
        args: [],
        useHostNetwork: false,
        boxNetworkCompat: true,
        requiresManagedNetwork: true,
        hashEnv: { PLOINKY_NETWORK_MODE: network.mode },
    };
}

function normalizeProfileEnv(env) {
    if (!env || typeof env !== 'object' || Array.isArray(env)) {
        return {};
    }
    const normalized = {};
    for (const [key, value] of Object.entries(env)) {
        if (!key) continue;
        // Handle complex env specs with varName/default - skip these as they're handled by buildEnvFlags
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            // Complex spec like { varName: "...", default: "..." } - skip, handled by buildEnvFlags
            continue;
        }
        normalized[String(key)] = value === undefined ? '' : String(value);
    }
    return normalized;
}

function appendEnvFlagsFromMap(envFlags, envMap) {
    if (!envMap || typeof envMap !== 'object' || Array.isArray(envMap)) {
        return;
    }
    for (const [name, value] of Object.entries(envMap)) {
        if (!name) continue;
        envFlags.push(formatEnvFlag(String(name), value ?? ''));
    }
}

function removeContainerForRecreate(runtime, containerName, label, record = null) {
    let exactRecord = record || loadAgentsMap()[containerName];
    try {
        const pending = exactRecord?.instanceId && exactRecord?.enableGeneration
            ? readRuntimeCandidate(containerName, exactRecord)
            : null;
        if (pending) {
            if (/^[a-f0-9]{64}$/.test(String(exactRecord.containerId || ''))
                && exactRecord.containerId !== pending.containerId
                && exactRecord.containerId !== pending.predecessorContainerId) {
                throw new Error('registered container ID conflicts with the persisted failed launch');
            }
            exactRecord = { ...exactRecord, ...pending.registryRecord };
        }
        const result = removeExactRegisteredContainer(containerName, exactRecord, { runtime, recoverIncompleteIdentity: true });
        if (result?.removed !== true && result?.state !== 'absent') {
            throw new Error(`exact predecessor removal returned '${result?.state || 'unknown'}'`);
        }
        if (pending) retireRuntimeCandidate(pending);
        clearLivenessState(containerName);
        return result;
    } catch (cause) {
        const error = new Error(
            `[${label}] preserved container '${containerName}' because exact immutable ownership/removal was not proven: ${cause?.message || cause}`,
            { cause },
        );
        error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
        throw error;
    }
}

function normalizeTargetedRestart(value) {
    if (value === undefined || value === null || value === false) return null;
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        throw new Error('targetedRestart must be an internal coordinated-restart contract object');
    }
    if (value.acknowledgement !== TARGETED_DRAIN_ACKNOWLEDGEMENT) {
        throw new Error(`targetedRestart.acknowledgement must be '${TARGETED_DRAIN_ACKNOWLEDGEMENT}'`);
    }
    if (!Array.isArray(value.affectedSelectors) || value.affectedSelectors.length < 1) {
        throw new Error('targetedRestart.affectedSelectors must identify at least one exact selector');
    }
    if (typeof value.assertSelectorsInactive !== 'function') {
        throw new Error('targetedRestart.assertSelectorsInactive must prove the exact affected selectors are inactive');
    }
    return Object.freeze({
        acknowledgement: value.acknowledgement,
        affectedSelectors: Object.freeze([...value.affectedSelectors]),
        assertSelectorsInactive: value.assertSelectorsInactive,
        ...(value.timeoutMs === undefined ? {} : { timeoutMs: value.timeoutMs }),
    });
}

export function removeAgentContainerForRecreate(containerName, label = 'executionModeChanged') {
    const runtime = getRuntime();
    return removeContainerForRecreate(runtime, containerName, label);
}

function buildPersistentAgentRunArgs({
    runtime,
    containerName,
    envHash,
    containerWorkdir,
    agentLibMountPath,
    codeMountPath,
    codeMountMode = '',
    useNestedDependencyMounts = false,
    preparedNodeModulesDir = '',
    sharedDir,
    healthProbeHostDir,
    cwd,
    cwdMountTarget,
    agentHomeDir = '',
    agentLibGrant: grant = null,
} = {}) {
    if (!grant) {
        throw new Error('agent admission requires the selected achillesAgentLib grant');
    }
    if (!healthProbeHostDir) {
        throw new Error('agent admission requires its dedicated health-probe control directory');
    }
    const storageWorkspaceRoot = path.dirname(path.dirname(path.resolve(sharedDir)));
    assertCanonicalAgentDataPath(sharedDir, { workspaceRoot: storageWorkspaceRoot });
    assertCanonicalAgentDataPath(agentHomeDir, { workspaceRoot: storageWorkspaceRoot });
    const homeLayout = resolveAgentHomeLayout({ cwd, cwdMountTarget, agentHomeDir });
    const nodeModulesMount = runtime === 'podman' ? ':z,ro' : ':ro';
    const readOnlyMount = runtime === 'podman' ? ':z,ro' : ':ro';
    const args = [
        'run', '-d', '--init', '--name', containerName,
        ...managedContainerLabelArgs(),
        '--label', `ploinky.envhash=${envHash}`,
        // Nested Podman must materialize only the binds authorized below. OCI
        // VOLUME declarations would otherwise create unmanaged anonymous mounts.
        ...(runtime === 'podman' ? ['--image-volume=ignore'] : []),
        '-w', containerWorkdir,
        // Agent library (always ro)
        '-v', `${agentLibMountPath}:/Agent${runtime === 'podman' ? ':z,ro' : ':ro'}`,
        // Code directory is read-only in every profile.
        '-v', `${codeMountPath}:/code${codeMountMode}`,
        ...(useNestedDependencyMounts ? [
            // node_modules mounts - ESM resolution walks up from script location
            // Mount at both /code/node_modules (for agent code) and /Agent/node_modules (for AgentServer.mjs)
            '-v', `${preparedNodeModulesDir}:/code/node_modules${nodeModulesMount}`,
            '-v', `${preparedNodeModulesDir}:/Agent/node_modules${nodeModulesMount}`,
        ] : []),
        // Shared directory
        '-v', `${sharedDir}:/shared${runtime === 'podman' ? ':z' : ''}`,
        // A per-container control channel carries requests, results, and exact
        // cancellation to the broker in the container's main process tree.
        // Health checks therefore create no target OCI exec sessions.
        '-v', `${healthProbeHostDir}:${PROBE_CONTROL_CONTAINER_ROOT}${runtime === 'podman' ? ':z' : ''}`,
        ...homeLayout.binds.flatMap(({ source, target }) => [
            '-v', `${source}:${target}${runtime === 'podman' ? ':z' : ''}`,
        ]),
    ];
    // The one selected achillesAgentLib source at the stable path, followed by a
    // read-only shadow over every writable alias that already exposes the same
    // inode. Both come after the writable binds so the shadows actually win.
    args.push('-v', `${grant.sourceDir}:${grant.runtimePath}${readOnlyMount}`);
    const writableBinds = [
        ...(codeMountMode.includes('ro') ? [] : [{ hostPath: codeMountPath, runtimePath: '/code' }]),
        { hostPath: sharedDir, runtimePath: '/shared' },
        { hostPath: healthProbeHostDir, runtimePath: PROBE_CONTROL_CONTAINER_ROOT },
        ...homeLayout.binds.map(({ source, target }) => ({ hostPath: source, runtimePath: target })),
    ];
    for (const shadow of agentLibAliasShadows(grant, writableBinds)) {
        args.push('-v', `${shadow.hostPath}:${shadow.runtimePath}${readOnlyMount}`);
    }
    return args;
}

function managedUserNamespaceFromAttestation(attested) {
    const target = attested?.evidence?.target;
    if (!target || typeof target.user !== 'string') {
        throw new Error('managed candidate attestation lacks the image user projection');
    }
    return managedImageUserNamespace(target.user);
}

function managedBindMountFromValue(value) {
    const text = String(value || '');
    const parts = text.split(':');
    if (parts.length < 2) throw new Error(`managed runtime volume '${text}' is invalid`);
    const source = path.resolve(parts.shift());
    const destination = normalizeRuntimeMountTarget(parts.shift());
    const options = parts.join(':').split(',').filter(Boolean);
    return Object.freeze({ source, destination, rw: !options.includes('ro') });
}

function appendExactManagedBindMount(args, value) {
    const incoming = managedBindMountFromValue(value);
    for (let index = 0; index < args.length - 1; index += 1) {
        if (args[index] !== '-v' && args[index] !== '--volume') continue;
        const existingValue = String(args[index + 1] || '');
        const existing = managedBindMountFromValue(existingValue);
        if (existing.destination !== incoming.destination) continue;
        const mountOptions = spec => String(spec).split(':').slice(2).join(':').split(',').filter(Boolean).sort().join(',');
        if (existing.source === incoming.source && mountOptions(existingValue) === mountOptions(value)) return false;
        throw new Error(`managed runtime volume target '${incoming.destination}' has conflicting bind grants`);
    }
    args.push('-v', String(value));
    return true;
}

function appendControllerStateGuards(args, runtime, {
    workspaceRoot,
    canonicalRuntimeWorkspaceGuards = isPloinkyBoxRuntime(),
} = {}) {
    const bindings = expectedBindMountsFromArgs(args).map(mount => ({
        hostPath: mount.source,
        runtimePath: mount.destination,
        readOnly: !mount.rw,
    }));
    const guardOptions = { workspaceRoot, bindings };
    const targets = controllerGuardTargets(bindings, guardOptions);
    // Narrow repository grants can still cause the container engine to create
    // the canonical workspace parents. Guard those synthetic parents too so
    // the retired paths remain read-only even when no broad bind exposes them.
    if (!targets.length && canonicalRuntimeWorkspaceGuards) {
        for (const protectedRoot of protectedControllerStateRoots(workspaceRoot)) {
            targets.push(Object.freeze({
                key: protectedRoot.key,
                target: protectedRoot.hostPath,
                protectedHostPath: protectedRoot.hostPath,
            }));
        }
    }
    for (const guard of controllerGuardMounts(targets, guardOptions)) {
        if (guard.replaceExisting) {
            for (let index = 0; index < args.length - 1; index += 1) {
                if (args[index] !== '-v' && args[index] !== '--volume') continue;
                const mount = managedBindMountFromValue(args[index + 1]);
                if (mount.destination !== guard.target) continue;
                const parts = String(args[index + 1]).split(':');
                const options = parts.slice(2).join(':').split(',').filter(option => option && option !== 'rw' && option !== 'ro');
                if (guard.readOnly) options.push('ro');
                args[index + 1] = `${parts[0]}:${mount.destination}${options.length ? `:${options.join(',')}` : ''}`;
            }
            continue;
        }
        const suffix = runtime === 'podman'
            ? (guard.readOnly ? ':z,ro' : ':z') : (guard.readOnly ? ':ro' : '');
        appendExactManagedBindMount(args, `${guard.source}:${guard.target}${suffix}`);
    }
    return targets;
}

function expectedBindMountsFromArgs(args, descriptorHostFile = '') {
    const specs = [];
    for (let index = 0; index < args.length - 1; index += 1) {
        if (args[index] !== '-v' && args[index] !== '--volume') continue;
        specs.push(managedBindMountFromValue(args[index + 1]));
    }
    if (descriptorHostFile) {
        specs.push(Object.freeze({
            source: path.resolve(descriptorHostFile),
            destination: GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE,
            rw: false,
        }));
    }
    return Object.freeze(specs);
}

function hasExactManagedMountContract(record, expectedMounts) {
    const actual = Array.isArray(record?.Mounts) ? record.Mounts : [];
    if (actual.length !== expectedMounts.length) return false;
    const expectedByTarget = new Map();
    for (const mount of expectedMounts) {
        let destination;
        try { destination = normalizeRuntimeMountTarget(mount.destination); } catch { return false; }
        if (expectedByTarget.has(destination)) return false;
        expectedByTarget.set(destination, mount);
    }
    const observedTargets = new Set();
    for (const mount of actual) {
        let destination;
        try { destination = normalizeRuntimeMountTarget(mount?.Destination); } catch { return false; }
        const expected = expectedByTarget.get(destination);
        if (!expected || observedTargets.has(destination)
            || String(mount?.Type || 'bind') !== 'bind'
            || path.resolve(String(mount?.Source || '')) !== expected.source
            || Boolean(mount?.RW) !== expected.rw) {
            return false;
        }
        observedTargets.add(destination);
    }
    return observedTargets.size === expectedByTarget.size;
}

function hasExactManagedEnv(record, expectedEnv) {
    const values = new Map();
    for (const entry of record?.Config?.Env || []) {
        const text = String(entry || '');
        const separator = text.indexOf('=');
        const name = separator < 1 ? text : text.slice(0, separator);
        const value = separator < 1 ? '' : text.slice(separator + 1);
        const current = values.get(name) || [];
        current.push(value);
        values.set(name, current);
    }
    return Object.entries(expectedEnv).every(([name, value]) => {
        const observed = values.get(name) || [];
        return observed.length === 1 && observed[0] === String(value);
    });
}

function manifestUsesHealthProbeBroker(manifest) {
    return ['liveness', 'readiness'].some((type) => (
        typeof manifest?.health?.[type]?.script === 'string'
        && manifest.health[type].script.trim() !== ''
    ));
}

// The managed control inputs a container is created with. They are part of the
// environment hash, so every producer (creation, adoption) and every consumer
// (service reuse, graph reuse) must take them from here.
function buildManagedControlEnv(manifest) {
    return Object.freeze({
        PLOINKY_HEALTH_PROBE_BROKER: manifestUsesHealthProbeBroker(manifest) ? '1' : '0',
    });
}

// The ONE construction of a container's environment hash. The label written at
// creation, the hash expected at managed adoption, the service-level reuse
// check and the graph reuse check all call it, so they cannot hash different
// inputs. `runtimeRouterEnv` is the Router endpoint env of an unmanaged start;
// `generatedRouter` ({ payload, principalId, instanceId, enableGeneration })
// adds the signed semantic descriptor and identity of a managed network.
// Security inputs (identity, principal, descriptor semantics and everything
// computeEnvHash reads from the manifest, profile and secrets) stay in the hash.
function computeAgentEnvHash(manifest, profileConfig, {
    agentName,
    repoName,
    runtimeNetworkPlan,
    runtimeRouterEnv = {},
    generatedRouter = null,
}, computeEnvHashImpl = computeEnvHash) {
    const payload = generatedRouter?.payload;
    return computeEnvHashImpl(manifest, profileConfig, {
        ...(generatedRouter ? {} : runtimeRouterEnv),
        ...runtimeNetworkPlan.hashEnv,
        ...buildManagedControlEnv(manifest),
        ...(generatedRouter ? {
            PLOINKY_ROUTER_SEMANTIC_TOPOLOGY_DIGEST: payload.semanticTopologyDigest,
            PLOINKY_ROUTER_DESCRIPTOR_SCHEMA: payload.schema,
            PLOINKY_ROUTER_TRANSPORT_VERSION: payload.transportVersion,
            PLOINKY_ROUTER_LOCAL_STREAMING: payload.localStreaming,
            PLOINKY_AGENT_PRINCIPAL: generatedRouter.principalId,
            PLOINKY_AGENT_INSTANCE_ID: generatedRouter.instanceId,
            PLOINKY_AGENT_ENABLE_GENERATION: generatedRouter.enableGeneration,
        } : {}),
    }, { agentName, repoName });
}

function inspectImageEntrypoint(runtime, image, spawn = spawnSync) {
    const result = spawn(runtime, [
        'image', 'inspect', '--format', '{{json .Config.Entrypoint}}', image,
    ], { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });
    if (result?.error || result?.status !== 0) {
        const detail = String(result?.stderr || result?.error?.message || result?.status || 'unknown').trim();
        throw new Error(`[image] cannot inspect entrypoint for ${image}: ${detail}`);
    }
    let parsed;
    try {
        parsed = JSON.parse(String(result.stdout || '').trim() || 'null');
    } catch (cause) {
        throw new Error(`[image] entrypoint inspection for ${image} returned invalid JSON`, { cause });
    }
    if (parsed === null) return Object.freeze([]);
    const values = Array.isArray(parsed) ? parsed : [parsed];
    if (values.some((value) => typeof value !== 'string' || value.length === 0)) {
        throw new Error(`[image] entrypoint inspection for ${image} returned an invalid command`);
    }
    return Object.freeze(values.map(String));
}

function managedAdoptionMismatch(reason) {
    const error = new Error(`managed runtime adoption requires replacement: ${reason}`);
    error.code = 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH';
    return error;
}

function requireManagedAdoptionDirectory(directory, label, { requireOwner = false } = {}) {
    try {
        const identity = requireOwner ? fs.lstatSync(directory) : fs.statSync(directory);
        if (!identity.isDirectory()
            || (requireOwner && (identity.isSymbolicLink() || identity.uid !== process.geteuid()))) {
            throw managedAdoptionMismatch(`${label} is not the exact existing host directory`);
        }
    } catch (error) {
        if (error?.code === 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH') throw error;
        throw managedAdoptionMismatch(`${label} is unavailable: ${error?.message || error}`);
    }
    return directory;
}

function assertManagedAdoptionMcpConfig(agentPath, agentWorkDir) {
    const source = getAgentMcpConfigPath(agentPath);
    if (!source) return;
    const target = path.join(agentWorkDir, 'mcp-config.json');
    try {
        const targetIdentity = fs.statSync(target);
        if (!targetIdentity.isFile()
            || !fs.readFileSync(source).equals(fs.readFileSync(target))) {
            throw managedAdoptionMismatch('persisted MCP config no longer matches the admitted agent source');
        }
    } catch (error) {
        if (error?.code === 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH') throw error;
        throw managedAdoptionMismatch(`persisted MCP config is unavailable: ${error?.message || error}`);
    }
}

function assertManagedAdoptionManifestVolume(resolvedHostPath, containerPath, options = {}) {
    let identity;
    try {
        identity = fs.statSync(resolvedHostPath);
    } catch (error) {
        throw managedAdoptionMismatch(
            `manifest volume '${containerPath || resolvedHostPath}' is unavailable: ${error?.message || error}`,
        );
    }
    if (options?.generated === true && options.required === true) {
        if ((identity.isFile() && identity.size === 0)
            || (identity.isDirectory() && fs.readdirSync(resolvedHostPath).length === 0)) {
            throw managedAdoptionMismatch(
                `required generated volume '${containerPath || resolvedHostPath}' is empty`,
            );
        }
    }
    if (typeof options?.chmod === 'number'
        && (identity.mode & 0o777) !== (options.chmod & 0o777)) {
        throw managedAdoptionMismatch(
            `manifest volume '${containerPath || resolvedHostPath}' permissions drifted`,
        );
    }
    const writableSubdirs = Array.isArray(options?.makeWorldWritableSubdirs)
        ? options.makeWorldWritableSubdirs
        : [];
    for (const sub of writableSubdirs) {
        const subDir = path.join(resolvedHostPath, String(sub));
        const subIdentity = (() => {
            try { return fs.statSync(subDir); } catch (_) { return null; }
        })();
        if (!subIdentity?.isDirectory()
            || (typeof options?.chmod === 'number'
                && (subIdentity.mode & 0o777) !== (options.chmod & 0o777))) {
            throw managedAdoptionMismatch(
                `manifest volume subdirectory '${containerPath || resolvedHostPath}/${sub}' drifted`,
            );
        }
    }
}

function managedAdoptionLlmPaths(llmStartup) {
    if (!llmStartup?.enabled) return llmStartup;
    const identityRoot = path.join(AGENTS_DATA_DIR, llmStartup.identity);
    const modelDir = requireManagedAdoptionDirectory(
        path.join(identityRoot, 'models'),
        'LLM model directory',
    );
    const stateDir = requireManagedAdoptionDirectory(
        path.join(identityRoot, 'runtime'),
        'LLM runtime state directory',
    );
    const stateFile = path.join(stateDir, 'selected-architecture.json');
    try {
        const persisted = JSON.parse(fs.readFileSync(stateFile, 'utf8'));
        if (JSON.stringify(persisted) !== JSON.stringify(llmStartup.statePayload)) {
            throw managedAdoptionMismatch('LLM selected architecture state drifted');
        }
    } catch (error) {
        if (error?.code === 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH') throw error;
        throw managedAdoptionMismatch(`LLM selected architecture state is unavailable: ${error?.message || error}`);
    }
    return Object.freeze({ ...llmStartup, modelDir, stateDir });
}

/**
 * Dependency reuse decision for any admitted runtime record (container,
 * bwrap or seatbelt). No-wait adoption and every runtime reuse path share it.
 */
function admittedRuntimeDependencyProblem({ agentName, manifest, profileConfig, record, containerName }, deps = {}) {
    const runtime = String(record?.runtime || '');
    if (runtime === 'bwrap') return bwrapDependencyReuseProblem({ agentName, manifest, record, containerName }, deps);
    if (runtime === 'seatbelt') return seatbeltDependencyReuseProblem({ agentName, manifest, record, containerName }, deps);
    let image = '';
    try {
        image = resolveManifestImage(manifest, profileConfig, { agentName, repoName: record?.repoName });
    } catch (_) {
        image = String(record?.containerImage || '');
    }
    return containerDependencyReuseProblem({
        agentName, manifest, profileConfig, record, runtime: runtime || getRuntime(), image, containerName,
    }, deps);
}

/**
 * The record that proves predecessor ownership for a same-name replacement:
 * the exact pre-rotation record, but only for the very container ID that is
 * still registered. Anything else falls back to the registered record (whose
 * rotated tuple then fails the ownership proof and preserves the container).
 */
function selectPredecessorRemovalRecord(registeredRecord, predecessorRecord) {
    const registeredId = String(registeredRecord?.containerId || '');
    if (predecessorRecord && registeredId && String(predecessorRecord.containerId || '') === registeredId) {
        return predecessorRecord;
    }
    return registeredRecord;
}

/** The actual container mounts include the admitted store payload read-only. */
function hasAdmittedDependencyMount(inspected, record) {
    const admitted = admittedDependencyRecord(record);
    if (admitted.mode !== 'store') return true;
    const expected = path.resolve(admitted.nodeModulesPath || '');
    const mounts = Array.isArray(inspected?.Mounts) ? inspected.Mounts : [];
    const matching = mounts.filter((mount) => path.resolve(String(mount?.Source || '/')) === expected);
    return matching.length > 0 && matching.every((mount) => mount.RW === false);
}

function inspectContainerImageId(runtime, image) {
    try {
        return containerToolchainIdentity({ runtime, image }).identity.imageId;
    } catch (_) {
        return null;
    }
}

/**
 * Container dependency reuse decision for an admitted runtime: '' when its
 * mounted tree is the desired immutable generation, otherwise a reason that
 * requires replacement. Read-only (no receipts, builds or probes containers).
 */
function containerDependencyReuseProblem({
    agentName,
    manifest,
    profileConfig,
    record,
    runtime,
    image,
    containerName,
}, deps = {}) {
    const agentCodePath = resolveSymlinkPath(getAgentCodePath(agentName));
    const agentHasPackageJson = fs.existsSync(path.join(agentCodePath, 'package.json'));
    const llmRuntime = isLlmRuntimeManifest(manifest, profileConfig);
    const needsDependencies = !readManifestStartCommand(manifest) || agentHasPackageJson || llmRuntime;
    return runtimeDependencyReuseProblem({
        record,
        family: 'container',
        needsDependencies,
        agentCodePath,
        registration: containerName,
        engine: runtime,
        image: llmRuntime ? (record?.containerImage || image) : image,
        noNodeAllowed: !agentHasPackageJson && !llmRuntime,
    }, deps);
}

/**
 * The hardware order of one managed agent launch (plan §8.1, §8.3), shared by
 * every startAgentContainer path: each create argv goes through the launch
 * guard (hardware input recheck, then the engine prefix) immediately before
 * the engine create, stale leaves are removed for a hardware-placed agent,
 * and once `launch` returns the launched (or adopted) runtime, its actual
 * leaf is read back and the inputs are rechecked before the candidate can be
 * returned. `launch` receives the guarded create for the managed transaction
 * or the host/none create.
 */
export function runHardwareGuardedLaunch(hardwareLaunch, {
    placed = false,
    removeStaleLeaves = () => {},
    buildCreateArgs,
    spawnCreate,
    launch,
    beforeMutation = () => {},
}) {
    const createContainer = (plan, launchState, createOptions) => {
        beforeMutation();
        const guarded = hardwareLaunch.createArgs(buildCreateArgs(plan, launchState));
        if (placed) removeStaleLeaves();
        return spawnCreate(guarded, launchState, createOptions);
    };
    const launched = launch(createContainer);
    hardwareLaunch.afterLaunch({ containerId: launched.containerId, adopted: launched.adopted === true });
    return launched;
}

export function verifyReusableHardwareRuntime(runtimeAdmission, {
    containerName, containerId, runtime, network, record, key, ref, alias = null, mpsLaunch,
}, {
    createGuard = createHardwareLaunchGuard,
    inactivate = inactivateEdgeRoutingGeneration,
    removeExact = removeExactGenerationCandidate,
    query = (command, args) => {
        const result = spawnSync(command, args, { encoding: 'utf8', timeout: 10_000 });
        return { ok: result.status === 0 && !result.error, stdout: String(result.stdout || '') };
    },
} = {}) {
    try {
        createGuard(runtimeAdmission, { key, observationKey: containerName, ref, alias, runtime, query, instanceId: record.instanceId, enableGeneration: record.enableGeneration, mpsLaunch }).afterLaunch({ containerId, adopted: true });
    } catch (error) {
        // A reused runtime is still an affected runtime. Revoke authorization
        // before removing only its captured immutable identity.
        try { inactivate('hardware-reuse-readback-failed', { preserveSelectedGeneration: true }); } catch (cleanupError) {
            appendExactCleanupFailure(error, `routing inactivation: ${cleanupError.message}`);
            throw error;
        }
        let exactCleanupPerformed = false;
        try {
            const cleanup = removeExact({ containerName, containerId, network, record });
            exactCleanupPerformed = cleanup?.removed === true || cleanup?.state === 'absent';
            if (!exactCleanupPerformed) throw new Error('exact reused-runtime removal was not proven');
        } catch (cleanupError) {
            appendExactCleanupFailure(error, cleanupError.message);
        }
        throw attachRestartCandidate(error, {
            containerName, containerId, runtimeNetwork: structuredClone(network),
            registryRecord: structuredClone(record), exactCleanupPerformed,
        });
    }
}

// This private handoff is created only by ensureAgentService and is usable
// under its still-live lock. Independent service calls get a fresh adapter.
const SERVICE_NETWORK_LIFECYCLE = Symbol('serviceNetworkLifecycle');

/**
 * The image a launch creates its container from, and the image identity the dependency installer records. A GPU share
 * launch creates from the prepared image's immutable ID (the hardware launch capability); the installer identity is the
 * resolved reference either way.
 */
export function selectLaunchImages({ resolvedImage, launch = null } = {}) {
    return Object.freeze({ image: launch ? launch.imageId : resolvedImage, installerImage: resolvedImage });
}

function startAgentContainer(agentName, manifest, agentPath, options = {}) {
    const repoName = resolveAgentRepositoryName(agentPath);
    const containerName = options.containerName || getAgentContainerName(agentName, repoName);
    const managedControlEnv = buildManagedControlEnv(manifest);
    const agentSnapshot = loadAgentsMap();
    const existingRecord = agentSnapshot[containerName] || {};
    const preservePreparedRegistryRecord = assertPreparedRegistryRecordPreservation(
        existingRecord,
        options,
        { ownerRef: `${repoName}/${agentName}` },
    );
    const launchRecord = preservePreparedRegistryRecord
        ? (options.preparedRegistryRecord || existingRecord)
        : existingRecord;
    const runtimeIdentity = options.runtimeIdentity;
    if (!runtimeIdentity?.instanceId || !runtimeIdentity?.enableGeneration) {
        throw new Error(`startAgentContainer(${agentName}) requires an exact instanceId and enableGeneration`);
    }
    const adoptManagedRuntimeOnly = options.adoptManagedRuntimeOnly === true;
    // Hardware refusals name the exact admitted instance (the registry key a
    // staged candidate belongs to) and its alias, as graph admission does.
    const hardwareInstanceKey = String(options.hardwareInstanceKey || '') || admittedInstanceKeyFor(containerName);
    const hardwareAlias = String(options.alias || launchRecord.alias || '');
    // Resolve profile and network as one selection. Explicit CLI and persisted
    // profile names fail closed; only a missing global profile falls back to
    // this manifest's default profile.
    const profileResolution = options.profileResolution || resolveManifestRuntimeProfile(manifest, {
        agentName: `${repoName}/${agentName}`,
        profileName: options.profileName,
        persistedProfileName: launchRecord.profile,
        path: `manifest(${repoName}/${agentName})`,
    });
    const activeProfile = profileResolution.resolvedProfileName;
    const profileConfig = profileResolution.profileConfig;
    const manifestNetwork = profileResolution.network;
    const manifestPath = path.join(agentPath, 'manifest.json');
    const exactManifestBytes = fs.existsSync(manifestPath)
        ? fs.readFileSync(manifestPath)
        : Buffer.from(JSON.stringify(manifest || {}));
    const exactManifest = JSON.parse(exactManifestBytes.toString('utf8'));
    if (!isDeepStrictEqual(exactManifest, manifest)) {
        const error = new Error(`startAgentContainer(${agentName}) manifest bytes changed before physical admission`);
        error.code = 'PLOINKY_RUNTIME_INPUT_CHANGED';
        error.status = 409;
        throw error;
    }
    // The backend executable is resolved only after generic policy admission;
    // runtime-specific argument rendering is then compiled from the same bytes.
    admitManifestRuntimeCapabilities(manifest, {
        manifestBytes: exactManifestBytes,
        manifestPath,
        agentId: `${repoName}/${agentName}`,
        profileName: activeProfile,
        profileConfig,
        network: manifestNetwork,
        runtimeKind: 'container',
        instanceKey: hardwareInstanceKey,
        alias: hardwareAlias,
    });
    const runtime = getRuntime();
    const llmAdmissionContext = resolveLlmRuntimeAdmissionContext({
        runtime,
        manifest,
        profileConfig,
        agentName,
        alias: options.alias,
        env: process.env,
    });
    const runtimeAdmission = admitManifestRuntimeCapabilities(manifest, {
        manifestBytes: exactManifestBytes,
        manifestPath,
        agentId: `${repoName}/${agentName}`,
        profileName: activeProfile,
        profileConfig,
        network: manifestNetwork,
        runtime,
        runtimeKind: 'container',
        catalogPolicy: llmAdmissionContext.catalogPolicy,
        catalogIdentity: llmAdmissionContext.catalogIdentity,
        instanceKey: hardwareInstanceKey,
        alias: hardwareAlias,
    });
    if (options.runtimeAdmission) {
        assertRuntimeAdmissionCurrent(options.runtimeAdmission, {
            manifestBytes: exactManifestBytes,
            profileName: activeProfile,
            runtimeKind: 'container',
            descriptor: runtimeAdmission.descriptor,
        });
    }
    const hardwareLaunch = createHardwareLaunchGuard(runtimeAdmission, {
        key: hardwareInstanceKey,
        observationKey: containerName,
        mpsLaunch: options.mpsLaunch,
        ref: `${repoName}/${agentName}`,
        alias: hardwareAlias || null,
        runtime,
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        query: (command, queryArgs) => {
            const result = spawnSync(command, queryArgs, { encoding: 'utf8', timeout: 10_000 });
            return { ok: result.status === 0 && !result.error, stdout: String(result.stdout || '') };
        },
    });
    const instanceName = options.alias || launchRecord.alias || agentName;
    const { raw: explicitAgentCmd } = readManifestAgentCommand(manifest);
    const startCmd = readManifestStartCommand(manifest);
    const useStartEntry = Boolean(startCmd);
    const launchExplicitSidecar = Boolean(startCmd && explicitAgentCmd);
    if (adoptManagedRuntimeOnly && !String(launchRecord.projectPath || '').trim()) {
        throw managedAdoptionMismatch('registered projectPath is missing');
    }
    const cwd = (preservePreparedRegistryRecord || adoptManagedRuntimeOnly) && launchRecord.projectPath
        ? launchRecord.projectPath
        : getConfiguredProjectPath(agentName, repoName, options.alias);
    const isolatedHome = (launchRecord.runMode || 'isolated') === 'isolated';
    const agentHomeDir = getAgentWorkDir(instanceName);
    const containerCwd = isolatedHome ? '/root' : cwd;
    const cwdMountTarget = isolatedHome ? '/root' : cwd;
    const homeLayout = resolveAgentHomeLayout({ cwd, cwdMountTarget, agentHomeDir });
    const llmRuntimeSharedPath = resolveLlmRuntimeSharedPath(agentPath);
    assertNetworkStartupCompatibility(manifest, profileConfig, manifestNetwork, {
        path: `manifest(${repoName}/${agentName})`,
    });
    assertManifestEnvProfileCompleteness(manifest, profileConfig, { agentName, repoName, profileName: activeProfile });
    const runtimeNetworkPlan = buildRuntimeNetworkPlan(runtime, manifestNetwork);
    if (runtimeNetworkPlan.mode === 'host') {
        // A denied host-mode request must not execute a manifest-controlled host
        // hook or perform any image/dependency/runtime work.
        assertHostModeGenerationCapability({
            agentId: deriveAgentPrincipalId(repoName, agentName),
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            routeKey: instanceName,
            containerName,
        }, { preparedCapability: options.preparedHostModeCapability });
    }
    const sharedDir = adoptManagedRuntimeOnly
        ? requireManagedAdoptionDirectory(SHARED_DIR, 'shared runtime directory')
        : ensureSharedHostDir();
    // Ensure workspace structure exists and run preinstall [HOST] before any
    // image-dependent work. Hooks may build local images or seed vars that image
    // resolution and dependency-cache probes consume.
    const preLifecycle = adoptManagedRuntimeOnly
        ? { success: true, errors: [] }
        : runPreContainerLifecycle(agentName, repoName, agentPath, activeProfile);
    if (!preLifecycle.success) {
        throw new Error(`[profile] ${agentName}: pre-container lifecycle failed: ${preLifecycle.errors.join('; ')}`);
    }

    // LLM-runtime agents receive their image from the hardware-aware catalog
    // (resolved below), so a manifest `container` placeholder that cannot resolve
    // here (e.g. ${PLOINKY_BASE_LOCAL_IMAGE} with no value) must not be fatal.
    let manifestImage = null;
    try {
        manifestImage = resolveManifestImage(manifest, profileConfig, { agentName, repoName });
    } catch (err) {
        if (!isLlmRuntimeManifest(manifest, profileConfig)) throw err;
    }
    let image = manifestImage;
    const useProfileLifecycle = Boolean(profileConfig);
    const routerEndpoint = assertRouterEndpoint(options.routerEndpoint, runtimeNetworkPlan.mode, {
        explicitPort: options.routerPort,
    });
    const runtimeRouterEnv = buildRuntimeRouterEnv(runtime, {
        routerEndpoint,
        routerPort: options.routerPort,
        networkMode: runtimeNetworkPlan.mode,
    });
    const envHash = computeAgentEnvHash(manifest, profileConfig, {
        agentName, repoName, runtimeNetworkPlan, runtimeRouterEnv,
    });

    // LLM runtime opt-in: catalog-driven image, hardware-aware policy, reuse hash.
    // Resolved BEFORE dependency cache prep so the cache uses the selected image.
    const llmRuntimeManifest = isLlmRuntimeManifest(manifest, profileConfig);
    let llmStartup = { enabled: false };
    if (llmRuntimeManifest) {
        const effectiveNetworkForLlm = profileConfig?.network ?? manifest?.network ?? null;
        llmStartup = prepareLlmStartup({
            runtime,
            manifest,
            profileConfig,
            agentName,
            alias: options.alias,
            env: process.env,
            agentWorkDirRoot: AGENTS_DATA_DIR,
            manifestEnvNames: [
                ...getManifestEnvNames(manifest, profileConfig, { forRuntime: true }),
                ...getExposedNames(manifest, profileConfig, { forRuntime: true }),
            ],
            envHash,
            effectiveNetwork: effectiveNetworkForLlm,
            resolvedSelection: llmAdmissionContext.startup?.selection,
            resolvedHardware: llmAdmissionContext.startup?.hardware,
            admittedRuntimePolicy: runtimeAdmission.descriptor.runtimePolicy,
            writeState: !adoptManagedRuntimeOnly,
            createDirectories: !adoptManagedRuntimeOnly,
        });
        if (adoptManagedRuntimeOnly) {
            llmStartup = managedAdoptionLlmPaths(llmStartup);
        }
        if (llmStartup.enabled && llmStartup.imageRef) {
            image = llmStartup.imageRef;
            debugLog(`[llm-runtime] ${agentName}: catalog-selected image ${image} (arch ${llmStartup.selection.architectureId})`);
        }
    }

    if (!image) {
        throw new Error(`[image] ${agentName}: no container image resolved (manifest container unresolved and no catalog image selected).`);
    }

    // The container is created from the immutable image ID of a GPU share launch; the dependency installer's identity
    // (runtime-key probe and cache stamp) stays the resolved image reference in every path, so a recreate by ID is not an
    // "installer image changed" for the cache the reference start prepared.
    const { image: launchImage, installerImage } = selectLaunchImages({
        resolvedImage: image,
        launch: runtimeAdmission.descriptor.hardwareGpu ? readMpsLaunch(options.mpsLaunch, hardwareInstanceKey, runtimeAdmission.descriptor.hardwareGpu) : null,
    });
    image = launchImage;

    // Get profile mount modes (profile overrides default if provided)
    const {
        codeMountMode,
        skillsMountMode,
        codeReadOnly,
        skillsReadOnly
    } = getProfileMountModes(activeProfile, runtime, profileConfig || {});

    // New workspace structure paths
    const agentWorkDir = agentHomeDir;
    const agentCodePathSymlink = getAgentCodePath(agentName);
    const agentSkillsPathSymlink = getAgentSkillsPath(agentName);

    // Resolve symlinks to get actual paths - ensures container mounts work correctly
    // The paths might be symlinks like $CWD/code/agent -> .ploinky/repos/repo/agent
    const agentCodePath = resolveSymlinkPath(agentCodePathSymlink);
    const agentSkillsPath = resolveSymlinkPath(agentSkillsPathSymlink);

    if (adoptManagedRuntimeOnly) {
        requireManagedAdoptionDirectory(agentHomeDir, 'persistent agent home');
        assertManagedAdoptionMcpConfig(path.resolve(agentPath), agentWorkDir);
    } else {
        // Ensure persistent state and MCP config before creating a runtime.
        ensureAgentDataDirectory(agentHomeDir);
        syncAgentMcpConfig(containerName, path.resolve(agentPath), instanceName, { workDir: agentWorkDir });
    }

    // INSTALL PHASE — runtime containers never run npm install. Dependency
    // preparation happens here, before runtime boot, via a dedicated cache.
    const agentHasPackageJson = fs.existsSync(path.join(agentCodePath, 'package.json'));
    const needsCoreDeps = !useStartEntry || agentHasPackageJson || llmRuntimeManifest;
    let preparedNodeModulesDir = path.join(agentWorkDir, 'node_modules');
    // Every dependency tree comes from the immutable store. A healthy managed
    // runtime is adopted only when it already mounts the desired generation;
    // adoption is read-only and never publishes receipts or probes images.
    let dependencyRecord = null;
    let preparedDependencies = null;
    if (needsCoreDeps) {
        const admittedDependencies = adoptManagedRuntimeOnly ? admittedDependencyRecord(launchRecord) : null;
        const runtimeKey = adoptManagedRuntimeOnly
            ? (admittedDependencies?.runtimeKey || NO_NODE_RUNTIME_KEY)
            : detectRuntimeKeyForAgent(manifest, repoName, agentName, profileConfig, installerImage);
        const dependencyPlan = resolveDependencyCachePreparation({
            needsCoreDeps,
            agentHasPackageJson,
            isLlmRuntime: llmRuntimeManifest,
            runtimeKey,
        });
        if (dependencyPlan.fatal) {
            throw new Error(`[deps] ${agentName}: ${dependencyPlan.message}.`);
        }
        if (adoptManagedRuntimeOnly) {
            const problem = containerDependencyReuseProblem({
                agentName, manifest, profileConfig, record: launchRecord, runtime, image: installerImage, containerName,
            });
            if (problem) throw managedAdoptionMismatch(`dependency generation drifted (${problem})`);
            dependencyRecord = admittedDependencies;
            if (dependencyPlan.prepare) {
                preparedNodeModulesDir = admittedDependencies.nodeModulesPath;
            } else {
                requireManagedAdoptionDirectory(preparedNodeModulesDir, 'agent node_modules directory');
            }
        } else if (dependencyPlan.prepare) {
            preparedDependencies = prepareRuntimeDependencies({
                family: 'container',
                runtimeKey,
                engine: runtime,
                image: installerImage,
                agentCodePath,
                registration: containerName,
                admittedRecord: launchRecord,
            }, {
                consumer: {
                    kind: 'container',
                    key: `container:${containerName}:${runtimeIdentity.instanceId}:${runtimeIdentity.enableGeneration}`,
                    engine: runtime,
                    containerName,
                    registration: containerName,
                    phase: 'creating',
                },
            });
            preparedNodeModulesDir = preparedDependencies.nodeModulesPath;
            dependencyRecord = preparedDependencies.record;
            debugLog(`[deps] ${agentName}: dependency generation ${dependencyRecord.generationId.slice(0, 12)} ready at ${preparedNodeModulesDir} (${preparedDependencies.status})`);
        } else {
            debugLog(`[deps] ${agentName}: Skipping dependency cache prep (${dependencyPlan.reason})`);
            if (!fs.existsSync(preparedNodeModulesDir)) {
                ensureAgentDataDirectory(preparedNodeModulesDir);
            }
            dependencyRecord = noCacheDependencyRecord(dependencyPlan.reason, {
                family: 'container',
                runtimeKey,
                imageId: inspectContainerImageId(runtime, installerImage),
            });
        }
    } else {
        debugLog(`[deps] ${agentName}: Skipping dependency cache prep (uses start command, no package.json)`);
        if (adoptManagedRuntimeOnly) {
            requireManagedAdoptionDirectory(preparedNodeModulesDir, 'agent node_modules directory');
        } else if (!fs.existsSync(preparedNodeModulesDir)) {
            ensureAgentDataDirectory(preparedNodeModulesDir);
        }
        dependencyRecord = adoptManagedRuntimeOnly
            ? admittedDependencyRecord(launchRecord)
            : noCacheDependencyRecord('no-core-deps', { family: 'container' });
    }

    // Manifest / profile install hook (e.g. coral-agent's installPrerequisites.sh)
    const manifestInstallCmd = String(profileConfig?.install || manifest?.install || '').trim();
    const combinedInstallCmd = manifestInstallCmd;

    const linkedRepositories = prepareLinkedRepositories(manifest, {
        workspaceRoot: PLOINKY_WORKSPACE_ROOT,
        create: !adoptManagedRuntimeOnly,
        writable: !isolatedHome,
    });
    const stageLinkedCode = runtime === 'podman' || linkedRepositories.length > 0;
    const podmanCodeLinks = new Map();
    const manifestVolumeMounts = [];
    for (const { resolvedHostPath, containerPath, options } of collectManifestVolumeEntries(manifest, profileConfig)) {
        if (adoptManagedRuntimeOnly) {
            assertManagedAdoptionManifestVolume(resolvedHostPath, containerPath, options);
        } else {
            ensureManifestVolumeHostPath(resolvedHostPath, containerPath, options);
        }
        const codeRelPath = stageLinkedCode ? codeRelativeMountPath(containerPath) : null;
        if (linkedRepositories.length && (containerPath === '/Agent' || containerPath === '/Agent/linked' || containerPath.startsWith('/Agent/linked/')
            || linkedRepositories.some(repo => containerPath === repo.target || containerPath.startsWith(repo.target + '/')))) {
            throw new Error('Manifest volume conflicts with link-install repository mounts');
        }
        if (codeRelPath) {
            assertPodmanCodeMountAllowed(codeRelPath, containerPath);
            podmanCodeLinks.set(codeRelPath, {
                hostPath: resolvedHostPath,
                readOnly: options?.readOnly === true,
            });
        } else {
            manifestVolumeMounts.push({ resolvedHostPath, containerPath, options });
        }
    }

    const skillsPathExists = fs.existsSync(agentSkillsPath);
    const skillsPathInsideCode = skillsPathExists && isPathWithin(agentSkillsPath, agentCodePath);
    if (stageLinkedCode && skillsPathExists && !skillsPathInsideCode) {
        podmanCodeLinks.set('skills', { hostPath: agentSkillsPath, readOnly: skillsReadOnly });
    }

    let agentLibMountPath = AGENT_LIB_PATH;
    let codeMountPath = agentCodePath;
    const useNestedDependencyMounts = !stageLinkedCode;
    // Container and nested-Podman agents see the selected achillesAgentLib
    // source at the stable path inside their own mount namespace. The family
    // alone determines that path, so this must not force a container probe on
    // agents that need no dependency cache.
    const containerAgentLibGrant = agentLibGrant('container');
    // A start-only agent with no package.json still receives the same bare
    // package-resolution adapter as dependency-bearing agents. No branch that
    // skips npm may leave an empty node_modules directory behind.
    const agentLibCachePath = path.dirname(preparedNodeModulesDir);
    if (dependencyRecord?.mode === 'store') {
        // The immutable object already carries its verified AgentLib links. A
        // mounted tree is never repaired or relinked in place.
    } else if (adoptManagedRuntimeOnly) {
        const linkProblem = agentLibCacheLinkProblem(
            agentLibCachePath,
            containerAgentLibGrant.runtimePath,
        );
        if (linkProblem) throw managedAdoptionMismatch(linkProblem);
    } else {
        ensureAgentLibCacheLink(
            agentLibCachePath,
            containerAgentLibGrant.runtimePath,
        );
    }
    let podmanStagedTargetMounts = [];
    if (stageLinkedCode) {
        if (adoptManagedRuntimeOnly) {
            requireManagedAdoptionDirectory(PODMAN_RUNTIME_ROOT, 'Podman runtime staging root');
        } else {
            fs.mkdirSync(PODMAN_RUNTIME_ROOT, { recursive: true });
        }
        const podmanRuntimeRoot = path.join(PODMAN_RUNTIME_ROOT, runtimeSegment(containerName));
        const reusableStagedMounts = options.reuseStagedMounts === true
            ? resolveReusablePodmanStagedMounts(existingRecord, podmanRuntimeRoot, preparedNodeModulesDir)
            : null;
        if (reusableStagedMounts) {
            agentLibMountPath = reusableStagedMounts.agentLibMountPath;
            codeMountPath = reusableStagedMounts.codeMountPath;
        } else if (adoptManagedRuntimeOnly) {
            throw managedAdoptionMismatch('exact Podman staged mounts are unavailable');
        } else {
            prepareFreshRuntimeRoot(podmanRuntimeRoot, PODMAN_RUNTIME_ROOT);
            agentLibMountPath = ensurePodmanStagedAgentLibDir(agentName, preparedNodeModulesDir, {
                linkedRepositories,
                runtimeRoot: podmanRuntimeRoot
            });
            codeMountPath = ensurePodmanStagedCodeDir(agentName, agentCodePath, preparedNodeModulesDir, podmanCodeLinks, {
                runtimeRoot: podmanRuntimeRoot
            });
        }
        // Podman cannot use Docker-style nested /code/node_modules mounts on the
        // staged symlink tree. Mount each symlink target at its real path instead,
        // with source/dependency targets read-only when the profile requires it.
        podmanStagedTargetMounts = buildPodmanStagedTargetMounts({
            agentCodePath,
            nodeModulesDir: preparedNodeModulesDir,
            codeLinks: podmanCodeLinks,
            linkedRepositories,
            codeReadOnly,
            writableProjectSource: !isolatedHome && isPathWithin(agentCodePath, cwd),
        });
    }

    if (!adoptManagedRuntimeOnly) {
        ensureAgentDataDirectory(agentHomeDir);
    }
    const healthProbeDirectory = adoptManagedRuntimeOnly
        ? requireManagedAdoptionDirectory(
            healthProbeHostDir(containerName),
            'health-probe control directory',
            { requireOwner: true },
        )
        : ensureHealthProbeHostDir(containerName);

    // Build volume mount arguments using new workspace structure
    // Prepared node_modules are mounted read-only; runtime containers never mutate deps.
    const containerWorkdir = isolatedHome ? '/root' : (String(manifest?.workdir || '/code').trim() || '/code');
    const args = buildPersistentAgentRunArgs({
        runtime,
        containerName,
        envHash,
        containerWorkdir,
        agentLibMountPath,
        codeMountPath,
        codeMountMode,
        useNestedDependencyMounts,
        preparedNodeModulesDir,
        sharedDir,
        healthProbeHostDir: healthProbeDirectory,
        cwd,
        cwdMountTarget,
        agentHomeDir,
        agentLibGrant: containerAgentLibGrant,
    });
    const topologyMount = edgeTopologyMount();
    if (adoptManagedRuntimeOnly) {
        requireManagedAdoptionDirectory(topologyMount.source, 'edge topology directory');
    } else {
        fs.mkdirSync(topologyMount.source, { recursive: true, mode: 0o700 });
    }
    args.push('-v', `${topologyMount.source}:${topologyMount.target}${runtime === 'podman' ? ':z,ro' : ':ro'}`);

    // LLM runtime: expose persistent model storage at /models and selected
    // architecture/runtime state at /runtime. These are identity-specific so
    // agent aliases keep separate caches and process state.
    if (llmStartup.enabled && llmStartup.modelDir) {
        args.push('-v', `${llmStartup.modelDir}:/models${runtime === 'podman' ? ':z' : ''}`);
    }
    if (llmStartup.enabled && llmStartup.stateDir) {
        args.push('-v', `${llmStartup.stateDir}:/runtime${runtime === 'podman' ? ':z' : ''}`);
    }
    if (llmStartup.enabled && fs.existsSync(llmRuntimeSharedPath)) {
        args.push('-v', `${llmRuntimeSharedPath}:/Agent/llm-runtime${runtime === 'podman' ? ':z,ro' : ':ro'}`);
    }

    if (stageLinkedCode) {
        for (const mount of podmanStagedTargetMounts) {
            args.push('-v', `${mount.source}:${mount.target}${runtime === 'podman' ? podmanMountSuffix(mount.ro) : (mount.ro ? ':ro' : ':rw')}`);
        }
    }

    // Mount skills directory if it exists
    if (skillsPathExists && !skillsPathInsideCode && !stageLinkedCode) {
        args.push('-v', `${agentSkillsPath}:/code/skills${skillsMountMode}`);
    }
    const useHostNetwork = runtimeNetworkPlan.useHostNetwork;
    const containerSecurityArgs = renderContainerSecurityArgs(runtimeAdmission.descriptor);
    if (containerSecurityArgs.length) {
        args.splice(1, 0, ...containerSecurityArgs);
    }
    const runtimePolicyArgs = renderRuntimePolicyArgs(runtimeAdmission.descriptor, { runtime });
    if (runtimePolicyArgs.length) {
        args.splice(1, 0, ...runtimePolicyArgs);
    }

    // LLM runtime: emit catalog-derived runtime policy args (platform, devices,
    // memory, shm, gpus, ipc) and labels (architecture, catalog, policy hash,
    // image digest, reuse hash). These go BEFORE the image so they apply to
    // `run`. Non-LLM agents are untouched.
    if (llmStartup.enabled) {
        for (const [labelKey, labelValue] of Object.entries(llmStartup.labels || {})) {
            if (labelValue === '' || labelValue === null || labelValue === undefined) continue;
            args.splice(1, 0, '--label', `${labelKey}=${labelValue}`);
        }
    }

    const serviceNetworkLifecycle = options[SERVICE_NETWORK_LIFECYCLE];
    if (serviceNetworkLifecycle) {
        assertNetworkLifecycleCapability(options.networkLifecycleCapability);
        if (serviceNetworkLifecycle.capability !== options.networkLifecycleCapability
            || serviceNetworkLifecycle.runtime !== runtime) {
            throw new Error('service network lifecycle handoff does not match the locked runtime');
        }
    }
    const networkLifecycle = serviceNetworkLifecycle?.adapter || createNetworkLifecycleAdapter({ runtime });
    const unmanagedNetworkLifecyclePlan = runtimeNetworkPlan.requiresManagedNetwork
        ? null
        : {
            mode: runtimeNetworkPlan.mode,
            args: runtimeNetworkPlan.args,
            attachments: [],
            created: [],
        };
    args.splice(1, 0, ...networkLifecycle.agentIdentityLabelArgs(manifestNetwork, runtimeIdentity));

    for (const { resolvedHostPath, containerPath, options } of manifestVolumeMounts) {
        ensureManifestVolumeHostPath(resolvedHostPath, containerPath, options);
        const mountSuffix = manifestVolumeMountSuffix(runtime, resolvedHostPath, options);
        appendExactManagedBindMount(args, `${resolvedHostPath}:${containerPath}${mountSuffix}`);
    }
    if (runtime === 'podman') {
        const boxHostArgs = buildBoxPodmanHostArgs({
            managedNetwork: runtimeNetworkPlan.requiresManagedNetwork === true,
        });
        if (boxHostArgs.length) args.splice(1, 0, ...boxHostArgs);
    }

    const { publishArgs: manifestPorts, portMappings } = parseManifestPorts(manifest, profileConfig);
    const runtimePorts = (options && Array.isArray(options.publish)) ? options.publish : [];
    const runtimePortMappings = (options && Array.isArray(options.publishMappings)) ? options.publishMappings : [];
    const effectivePortMappings = [...portMappings, ...runtimePortMappings];
    assertHostPortContract(runtimeNetworkPlan.mode, effectivePortMappings);
    const pubs = (useHostNetwork || runtimeNetworkPlan.mode === 'none')
        ? []
        : [...manifestPorts, ...runtimePorts];
    for (const p of pubs) {
        if (!p) continue;
        args.splice(1, 0, '-p', String(p));
    }

    // Manifest-driven runtime resources (persistent storage + declared env).
    // Replaces former agentName-specific runtime wiring with manifest-driven resources.
    const resourcePlan = planRuntimeResources(manifest, { agentName, repoName });
    if (resourcePlan.persistentStorage) {
        if (adoptManagedRuntimeOnly) {
            requireManagedAdoptionDirectory(
                resourcePlan.persistentStorage.hostPath,
                'persistent runtime storage',
            );
            if (typeof resourcePlan.persistentStorage.chmod === 'number') {
                const mode = fs.statSync(resourcePlan.persistentStorage.hostPath).mode & 0o777;
                if (mode !== (resourcePlan.persistentStorage.chmod & 0o777)) {
                    throw managedAdoptionMismatch('persistent runtime storage permissions drifted');
                }
            }
        } else {
            ensurePersistentStorageHostDir(resourcePlan);
        }
        assertCanonicalAgentDataPath(resourcePlan.persistentStorage.hostPath);
        args.push('-v', `${resourcePlan.persistentStorage.hostPath}:${resourcePlan.persistentStorage.containerPath}${runtime === 'podman' ? ':z' : ''}`);
    }

    // Apply controller-state guards after every broad, manifest, staged, and
    // resource bind so no later agent-controlled mount can expose old state.
    appendControllerStateGuards(args, runtime);

    const envStrings = [
        ...buildEnvFlags(manifest, profileConfig, { agentName, repoName, profileName: activeProfile, forRuntime: true }),
        formatEnvFlag('PLOINKY_MCP_CONFIG_PATH', CONTAINER_CONFIG_PATH)
    ];
    envStrings.push(formatEnvFlag('AGENT_NAME', agentName));
    envStrings.push(formatEnvFlag('WORKSPACE_PATH', isolatedHome ? '/root' : cwd));
    envStrings.push(formatEnvFlag('PLOINKY_WORKSPACE_ROOT', PLOINKY_WORKSPACE_ROOT));
    envStrings.push(formatEnvFlag('HOME', homeLayout.containerHome));
    // Apply env from manifest.runtime.resources.env (templates expanded).
    for (const [envKey, envValue] of Object.entries(applyRuntimeResourceEnv(resourcePlan))) {
        envStrings.push(formatEnvFlag(envKey, envValue));
    }

    const profileEnv = normalizeProfileEnv(profileConfig?.env);
    // Primitive profile env values are already resolved by buildEnvFlags above.
    // Appending them again here would let defaults override operator-provided
    // vars, for example clearing an explicit gateway base URL override with "".

    const profileEnvVars = getProfileEnvVars(agentName, repoName, activeProfile, {
        containerName,
        containerId: containerName
    });
    appendEnvFlagsFromMap(envStrings, profileEnvVars);

    const agentClientIdVar = `PLOINKY_AGENT_${agentName.toUpperCase().replace(/[^A-Z0-9]/g, '_')}_CLIENT_ID`;
    const agentClientSecretVar = `PLOINKY_AGENT_${agentName.toUpperCase().replace(/[^A-Z0-9]/g, '_')}_CLIENT_SECRET`;
    const agentClientId = resolveVarValue(agentClientIdVar) || resolveVarValue('PLOINKY_AGENT_CLIENT_ID');
    const agentClientSecret = resolveVarValue(agentClientSecretVar) || resolveVarValue('PLOINKY_AGENT_CLIENT_SECRET');

    if (agentClientId) {
        envStrings.push(formatEnvFlag('PLOINKY_AGENT_CLIENT_ID', agentClientId));
    }
    if (agentClientSecret) {
        envStrings.push(formatEnvFlag('PLOINKY_AGENT_CLIENT_SECRET', agentClientSecret));
    }

    if (profileConfig?.secrets && profileConfig.secrets.length > 0) {
        const secretValidation = validateSecrets(profileConfig.secrets);
        if (!secretValidation.valid) {
            throw new Error(formatMissingSecretsError(secretValidation.missing, activeProfile));
        }
        const profileSecrets = getSecrets(profileConfig.secrets);
        appendEnvFlagsFromMap(envStrings, profileSecrets);
    }

    // Router discovery is runtime-owned. Remove every manifest/profile/secret
    // value first; none mode remains empty while routable modes receive only
    // the already validated canonical endpoint.
    // Router discovery and every credential remain absent until the exact
    // managed-network listener attestation succeeds under the network lock.
    // Unmanaged/unsupported paths therefore remain safely non-key-capable.
    replaceRuntimeRouterEnvFlags(envStrings, {});
    if (llmStartup.enabled) {
        envStrings.push(formatEnvFlag('HF_HOME', '/models/hf-cache'));
        envStrings.push(formatEnvFlag('PLOINKY_MODELS_DIR', '/models/artifacts'));
        envStrings.push(formatEnvFlag('PLOINKY_DERIVED_DIR', '/models/derived'));
        envStrings.push(formatEnvFlag('PLOINKY_RUNTIME_DIR', '/runtime'));
        envStrings.push(formatEnvFlag('PLOINKY_LAUNCHERS_DIR', '/opt/ploinky/launchers'));
        envStrings.push(formatEnvFlag('PLOINKY_MCP_PORT', '9000'));
        envStrings.push(formatEnvFlag('PLOINKY_LLM_PUBLIC_PORT', '9000'));
        envStrings.push(formatEnvFlag('PLOINKY_LLM_MCP_PORT', '9001'));
        envStrings.push(formatEnvFlag('PLOINKY_LLM_CONTROL_PORT', '9002'));
        envStrings.push(formatEnvFlag('PLOINKY_INFERENCE_PORT', '8080'));
    }

    // DS015/DS013: strip any reserved identity/master env FLAG a config layer
    // emitted (manifest env, runtime resources, profile env/secrets), then
    // re-assert the authoritative Router locators and agent identity LAST so no
    // config can redirect the runtime, inject a master key, or override the
    // agent's derived secret.
    stripReservedAndRestoreRuntimeRouterEnvFlags(envStrings, {});
    for (const [key, value] of Object.entries(PLOINKY_SKILL_SCOPE_ENV)) envStrings.push(formatEnvFlag(key, value));
    // Only non-secret principal fields exist before topology attestation.
    for (const [key, value] of Object.entries(buildAgentPrincipalEnv(
        deriveAgentPrincipalId(repoName, agentName),
        runtimeIdentity,
    ))) {
        envStrings.push(formatEnvFlag(key, value));
    }
    envStrings.push(formatEnvFlag('HOME', homeLayout.containerHome));
    // The achillesAgentLib contract is asserted at the same final authoritative
    // layer, after stripReservedAndRestoreRuntimeRouterEnvFlags has removed any
    // config-layer attempt to point the agent at a different source.
    for (const [key, value] of Object.entries(agentLibGrantEnv(containerAgentLibGrant))) {
        envStrings.push(formatEnvFlag(key, value));
    }
    for (const [key, value] of Object.entries(managedControlEnv)) {
        envStrings.push(formatEnvFlag(key, value));
    }

    const envFlags = flagsToArgs(envStrings);
    if (envFlags.length) args.push(...envFlags);
    if (runtime === 'podman') {
        const nodeOptions = mergeNodeOptions(
            getLastFormattedEnvValue(envStrings, 'NODE_OPTIONS'),
            PODMAN_STAGED_NODE_OPTIONS
        );
        args.push(...flagsToArgs([formatEnvFlag('NODE_OPTIONS', nodeOptions)]));
    }
    // NODE_PATH is needed because AgentServer.mjs runs from /Agent/server/, not /code/
    // Node.js module resolution walks up from script location, so it won't find /code/node_modules
    args.push('-e', `NODE_PATH=/code/node_modules`);
    if (runtimeAdmission.descriptor.hardwareGpu) args.push(...mpsLaunchArgs(options.mpsLaunch, hardwareInstanceKey, runtimeAdmission.descriptor.hardwareGpu));

    let entrySummary = DEFAULT_AGENT_ENTRY;
    if (!adoptManagedRuntimeOnly) {
        const manifestEntrypoint = typeof manifest?.entrypoint === 'string' ? manifest.entrypoint.trim() : '';
        // Every managed container owns its health and runtime-relay brokers in the
        // main process tree. Preserve the exact manifest override or immutable
        // image entrypoint as the wrapper's child command.
        ensureImagePresent(image, { runtime });
        const mainEntrypoint = manifestEntrypoint
            ? Object.freeze([manifestEntrypoint])
            : inspectImageEntrypoint(runtime, image);
        args.push('--entrypoint', AGENT_CONTROL_ENTRYPOINT);
        args.push(image);
        const mainCommandIndex = args.length;
        if (useStartEntry) {
            const startArgs = splitCommandArgs(startCmd);
            if (!startArgs.length) {
                throw new Error(`[start] ${agentName}: manifest.start is defined but empty.`);
            }
            // Run install command before start script if defined
            if (combinedInstallCmd) {
                console.log(`[install] ${agentName}: entrypoint deps + manifest hooks`);
                const fullCmd = `cd ${containerCwd} && ${combinedInstallCmd} && ${startArgs.join(' ')}`;
                args.push('sh', '-c', fullCmd);
                entrySummary = `sh -c "cd ${containerCwd} && <install> && ${startArgs.join(' ')}"`;

            } else {
                args.push(...startArgs);
                entrySummary = startArgs.join(' ');
            }
        } else if (explicitAgentCmd) {
            const shellPath = detectShellForImage(agentName, image, runtime);
            if (shellPath === SHELL_FALLBACK_DIRECT) {
                throw new Error(`[start] ${agentName}: no supported shell found to execute agent command.`);
            }
            // Run install command before agent command
            if (combinedInstallCmd) {
                console.log(`[install] ${agentName}: entrypoint deps + manifest hooks`);
            }
            const fullCmd = combinedInstallCmd
                ? `cd ${containerCwd} && ${combinedInstallCmd} && ${explicitAgentCmd}`
                : `cd ${containerCwd} && ${explicitAgentCmd}`;
            args.push(...buildAgentShellArgs(fullCmd, shellPath));
            entrySummary = combinedInstallCmd
                ? `${shellPath} -c "cd ${containerCwd} && <install> && ${explicitAgentCmd}"`
                : `${shellPath} -c "cd ${containerCwd} && ${explicitAgentCmd}"`;
        } else {
            // Run preinstall + install in main container before default agent server
            if (combinedInstallCmd) {
                args.push('sh', '-c', `${combinedInstallCmd} && exec sh /Agent/server/AgentServer.sh`);
                entrySummary = `sh -c "<install> && exec sh /Agent/server/AgentServer.sh"`;
            } else {
                args.push('sh', '/Agent/server/AgentServer.sh');
            }
        }
        args.splice(mainCommandIndex, 0, ...mainEntrypoint);
        entrySummary = `${AGENT_CONTROL_ENTRYPOINT} -> ${[
            ...mainEntrypoint,
            ...args.slice(mainCommandIndex + mainEntrypoint.length),
        ].join(' ')}`;
    }

    const principalId = deriveAgentPrincipalId(repoName, agentName);
    const computeSemanticEnvHash = (payload) => computeAgentEnvHash(manifest, profileConfig, {
        agentName,
        repoName,
        runtimeNetworkPlan,
        generatedRouter: {
            payload,
            principalId,
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
        },
    });
    const prepareGeneratedRouterAttestation = (plan) => {
        if (runtime !== 'podman' || !['default', 'bridge'].includes(plan?.mode)) {
            throw new Error('generated-local Router credentials require the exact verified managed Podman transaction');
        }
        const generationLease = createRouterAttestationGenerationLease({
            ...(runtimeIdentity.preparationLease
                ? { preparationLease: runtimeIdentity.preparationLease }
                : {}),
            expectedOwner: {
                containerName,
                principal: principalId,
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
            },
        });
        const intent = buildRouterAuthorityTopologyIntent({
            networkMode: plan.mode,
            runtimeProof: plan.runtimeProof,
            networkFingerprint: plan.networkFingerprint,
            runtimeKind: 'container',
            edgeTopologyFile: runtimeRouterEnv.PLOINKY_EDGE_TOPOLOGY_FILE,
            authRouteKey: generationLease.snapshot?.routing?.static?.agent,
        });
        const attested = attestRouterAuthority({
            intent,
            generationLease,
            runProbe: ({
                intent: probeIntent,
                nonce,
                registerObservation,
                consumeObservation,
            }) => runContainerAuthorityProbe({
                runtime,
                plan,
                image,
                intent: probeIntent,
                nonce,
                registerObservation,
                consumeObservation,
                placement: authorityHelperPlacementFromContext(
                    captureHardwareContext({ insideBox: isInsideBox(), runtimeKind: 'container' }),
                ),
            }),
        });
        // The first commit is owned by attestRouterAuthority immediately after
        // both observations. The second occurs directly before any signing-key
        // access or API-key minting.
        generationLease.checkpoint('pre-credentials');
        return Object.freeze({ generationLease, intent, attested });
    };
    const prepareGeneratedRouterLaunch = (plan) => {
        const { generationLease, intent, attested } = prepareGeneratedRouterAttestation(plan);
        const launchId = randomUUID();
        const payload = createGeneratedRouterDescriptorPayload({
            agentPrincipal: principalId,
            attestationId: attested.attestationId,
            edgeTopologyFile: intent.edgeTopologyFile,
            generationId: runtimeIdentity.enableGeneration,
            instanceId: runtimeIdentity.instanceId,
            internalRouterUrl: intent.internalRouterUrl,
            issuedAtUnixMs: Date.now(),
            launchId,
            listenerClass: intent.listenerClass,
            networkFingerprint: intent.networkFingerprint,
            physicalOrigin: intent.physicalOrigin,
            publicAuthority: intent.publicAuthority,
            requestAuthority: intent.requestAuthority,
            routerHost: intent.routerHost,
            routerPort: intent.routerPort,
            runtimeProof: intent.runtimeProof,
            socketLocalAddressClass: intent.socketLocalAddressClass,
            topology: intent.topology,
        });
        const signed = signGeneratedRouterDescriptorEnvelope(payload);
        const descriptorHostFile = path.join(ROUTER_DESCRIPTOR_HOST_DIR, `${launchId}.json`);
        writeGeneratedRouterDescriptorFile(descriptorHostFile, signed.bytes);
        const descriptorIdentity = fs.lstatSync(descriptorHostFile);
        if (!descriptorIdentity.isFile() || descriptorIdentity.isSymbolicLink()
            || (descriptorIdentity.mode & 0o777) !== 0o600) {
            throw new Error('generated Router descriptor launch artifact identity is invalid');
        }
        let cleaned = false;
        const cleanup = () => {
            if (cleaned) return;
            try {
                const current = fs.lstatSync(descriptorHostFile);
                if (!current.isFile() || current.isSymbolicLink()
                    || current.dev !== descriptorIdentity.dev
                    || current.ino !== descriptorIdentity.ino
                    || (current.mode & 0o777) !== 0o600) {
                    throw new Error('generated Router descriptor launch artifact identity changed before cleanup');
                }
                fs.unlinkSync(descriptorHostFile);
                cleaned = true;
            } catch (error) {
                if (error?.code !== 'ENOENT') throw error;
                cleaned = true;
            }
        };
        try {
            const launchEnv = Object.freeze({
                ...buildGeneratedRouterDescriptorEnv(payload),
                ...buildAgentCredentialEnv(principalId, runtimeIdentity),
            });
            const semanticEnvHash = computeSemanticEnvHash(payload);
            return Object.freeze({
                attested,
                cleanup,
                descriptorHostFile,
                env: launchEnv,
                envHash: semanticEnvHash,
                generationLease,
            });
        } catch (error) {
            cleanup();
            throw error;
        }
    };

    const inspectGeneratedRouterAdoption = ({ plan, record }) => {
        const { generationLease, intent, attested } = prepareGeneratedRouterAttestation(plan);
        try {
            const descriptorMounts = (record?.Mounts || []).filter((mount) => (
                String(mount?.Destination || '') === GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE
            ));
            if (descriptorMounts.length !== 1 || descriptorMounts[0]?.RW !== false) {
                return { adopted: false, reason: 'descriptor-mount' };
            }
            const descriptorHostFile = path.resolve(String(descriptorMounts[0]?.Source || ''));
            const verified = readVerifiedGeneratedRouterDescriptorFile(descriptorHostFile);
            const payload = verified.payload;
            const expectedSemanticDigest = semanticTopologyDigest({
                listenerClass: intent.listenerClass,
                localStreaming: GENERATED_ROUTER_LOCAL_STREAMING,
                networkFingerprint: intent.networkFingerprint,
                physicalOrigin: intent.physicalOrigin,
                publicAuthority: intent.publicAuthority,
                requestAuthority: intent.requestAuthority,
                runtimeProof: intent.runtimeProof,
                socketLocalAddressClass: intent.socketLocalAddressClass,
                topology: intent.topology,
                transportVersion: GENERATED_ROUTER_TRANSPORT_VERSION,
            });
            const exactPayload = payload.agentPrincipal === principalId
                && payload.instanceId === runtimeIdentity.instanceId
                && payload.generationId === runtimeIdentity.enableGeneration
                && payload.edgeTopologyFile === intent.edgeTopologyFile
                && payload.schema === GENERATED_ROUTER_DESCRIPTOR_SCHEMA
                && payload.transportVersion === GENERATED_ROUTER_TRANSPORT_VERSION
                && payload.localStreaming === GENERATED_ROUTER_LOCAL_STREAMING
                && payload.semanticTopologyDigest === expectedSemanticDigest;
            if (!exactPayload) return { adopted: false, reason: 'descriptor-semantics' };

            const descriptorEnv = buildGeneratedRouterDescriptorEnv(payload);
            const credentialEnv = buildAgentCredentialEnv(principalId, runtimeIdentity);
            const expectedEnv = Object.freeze({
                ...descriptorEnv,
                ...credentialEnv,
                ...managedControlEnv,
            });
            const expectedMounts = expectedBindMountsFromArgs(args, descriptorHostFile);
            const expectedEnvHash = computeSemanticEnvHash(payload);
            if (!hasExactManagedEnv(record, expectedEnv)) {
                return { adopted: false, reason: 'generated-env-contract' };
            }
            if (record?.HostConfig?.Init !== true
                || String(record?.Image || '') !== String(attested.evidence.target.image || '')
                || String(record?.Config?.User || '') !== String(attested.evidence.target.user || '')
                || JSON.stringify(record?.Config?.Entrypoint || [])
                    !== JSON.stringify([AGENT_CONTROL_ENTRYPOINT])
                || String(record?.HostConfig?.Annotations?.['io.podman.annotations.userns'] || '')
                    !== managedUserNamespaceFromAttestation(attested)
                || String(record?.Config?.WorkingDir || '') !== containerWorkdir
                || String(record?.Config?.Labels?.['ploinky.envhash'] || record?.Labels?.['ploinky.envhash'] || '') !== expectedEnvHash
                || !hasExactManagedMountContract(record, expectedMounts)) {
                return { adopted: false, reason: 'runtime-contract' };
            }
            generationLease.checkpoint('pre-runtime');
            return {
                adopted: true,
                launch: Object.freeze({
                    adopted: true,
                    attested,
                    descriptorHostFile,
                    env: expectedEnv,
                    generationLease,
                    payload,
                }),
                finalize(finalRecord) {
                    const finalVerified = readVerifiedGeneratedRouterDescriptorFile(descriptorHostFile);
                    if (finalVerified.identity.dev !== verified.identity.dev
                        || finalVerified.identity.ino !== verified.identity.ino
                        || finalVerified.identity.size !== verified.identity.size
                        || finalVerified.payload.semanticTopologyDigest !== expectedSemanticDigest
                        || finalVerified.payload.agentPrincipal !== principalId
                        || finalVerified.payload.instanceId !== runtimeIdentity.instanceId
                        || finalVerified.payload.generationId !== runtimeIdentity.enableGeneration
                        || String(finalRecord?.Config?.WorkingDir || '') !== containerWorkdir
                        || String(finalRecord?.Config?.Labels?.['ploinky.envhash'] || finalRecord?.Labels?.['ploinky.envhash'] || '') !== expectedEnvHash
                        || !hasExactManagedEnv(finalRecord, expectedEnv)
                        || !hasExactManagedMountContract(finalRecord, expectedMounts)) {
                        throw new Error('managed adoption descriptor changed during final inspection');
                    }
                    generationLease.checkpoint('post-inspection');
                    if (generationLease.complete !== true) {
                        throw new Error('managed adoption did not complete all Router generation checkpoints');
                    }
                },
            };
        } catch (error) {
            return { adopted: false, reason: `descriptor-invalid:${error?.code || error?.message || 'unknown'}` };
        }
    };

    let pendingGuardMountpointCleanup = null;
    const prepareGuardMountpointCleanupBeforeStart = () => {
        if (pendingGuardMountpointCleanup) {
            throw new Error('controller guard mountpoint cleanup is already pending');
        }
        pendingGuardMountpointCleanup = prepareControllerGuardMountpointCleanup();
    };
    const cleanupGuardMountpointsAfterStart = () => {
        const cleanup = pendingGuardMountpointCleanup;
        pendingGuardMountpointCleanup = null;
        if (!cleanup) throw new Error('controller guard mountpoint cleanup was not prepared before runtime start');
        cleanup();
    };

    const preStartGeneratedRouterLaunch = ({ launch }) => {
        if (!launch) throw new Error('managed generated-local launch is missing before runtime start');
        launch.generationLease.checkpoint('pre-runtime');
        prepareGuardMountpointCleanupBeforeStart();
    };

    const finalizeGeneratedRouterLaunch = ({ launch, record }) => {
        if (!launch) throw new Error('managed generated-local launch is missing its attested launch state');
        const expectedMounts = expectedBindMountsFromArgs(args, launch.descriptorHostFile);
        if (!hasExactManagedEnv(record, { ...launch.env, ...managedControlEnv })) {
            throw new Error('managed candidate generated Router env failed exact inspection');
        }
        const descriptorMounts = (record?.Mounts || []).filter((mount) => (
            String(mount?.Destination || '') === GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE
        ));
        if (descriptorMounts.length !== 1
            || path.resolve(String(descriptorMounts[0]?.Source || '')) !== path.resolve(launch.descriptorHostFile)
            || descriptorMounts[0]?.RW !== false
            || record?.HostConfig?.Init !== true
            || String(record?.Image || '') !== String(launch.attested.evidence.target.image || '')
            || String(record?.Config?.User || '') !== String(launch.attested.evidence.target.user || '')
            || JSON.stringify(record?.Config?.Entrypoint || [])
                !== JSON.stringify([AGENT_CONTROL_ENTRYPOINT])
            || String(record?.HostConfig?.Annotations?.['io.podman.annotations.userns'] || '')
                !== managedUserNamespaceFromAttestation(launch.attested)
            || String(record?.Config?.WorkingDir || '') !== containerWorkdir
            || String(record?.Config?.Labels?.['ploinky.envhash'] || record?.Labels?.['ploinky.envhash'] || '') !== launch.envHash
            || !hasExactManagedMountContract(record, expectedMounts)) {
            throw new Error('managed candidate image/init/user/descriptor inspection failed');
        }
        launch.generationLease.checkpoint('post-inspection');
        if (launch.generationLease.complete !== true) {
            throw new Error('managed candidate did not complete all Router generation checkpoints');
        }
    };

    const detachedIndex = args.indexOf('-d');
    if (detachedIndex !== -1) args.splice(detachedIndex, 1);
    args[0] = 'create';
    if (!adoptManagedRuntimeOnly) {
        console.log(`[start] ${agentName}: ${runtime} create (cwd='${cwd}') -> ${entrySummary}`);
    }
    // The create argv of one candidate (managed launch state included) and its
    // create-attempted receipt. runHardwareGuardedLaunch passes it through the
    // hardware guard before spawnCreate runs the engine create.
    const buildCreateArgs = (plan, launch) => {
        if (runtimeAdmission.descriptor.hardwareGpu) verifyMpsLaunch(options.mpsLaunch, hardwareInstanceKey, runtimeAdmission.descriptor.hardwareGpu);
        const createArgs = [...args];
        if (plan?.args?.length) createArgs.splice(1, 0, ...plan.args);
        if (launch) {
            for (let index = 0; index < createArgs.length - 1; index += 1) {
                if (createArgs[index] === '--label' && String(createArgs[index + 1]).startsWith('ploinky.envhash=')) {
                    createArgs[index + 1] = `ploinky.envhash=${launch.envHash}`;
                }
            }
            const imageIndex = createArgs.indexOf(image);
            if (imageIndex < 1) throw new Error('managed candidate image position is unavailable');
            const userNamespace = managedUserNamespaceFromAttestation(launch.attested);
            createArgs.splice(imageIndex, 0,
                ...(userNamespace ? [`--userns=${userNamespace}`] : []),
                '-v', `${launch.descriptorHostFile}:${GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE}:z,ro`,
                ...flagsToArgs(Object.entries(launch.env).map(([name, value]) => formatEnvFlag(name, value))),
            );
        } else if (['default', 'bridge'].includes(plan?.mode)) {
            throw new Error('managed generated-local launch state is required before container creation');
        }
        if (cleanupReceipt.phase !== 'pre-create') {
            cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, { phase: 'pre-create' });
        }
        cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, {
            phase: 'create-attempted',
            creationAttempted: true,
            state: 'preserved-ambiguous',
            inspectionComplete: false,
        });
        return createArgs;
    };
    // The engine create of an argv the hardware guard already produced.
    const spawnCreate = (createArgs, launch, { recordCreatedId = () => {} } = {}) => {
        // Creation is reached only after the exact predecessor is gone (or was
        // proved absent). Retire its two fixed control-plane artifacts here so
        // shared-filesystem socket projection cannot leak across generations.
        // Per-request directories remain untouched and fail closed separately.
        prepareHealthProbeHostDirForLaunch(containerName);
        const res = withNetworkLifecycleLock(() => {
            const cleanupGuardMountpoints = prepareControllerGuardMountpointCleanup();
            try {
                const res = spawnSync(runtime, createArgs, { stdio: ['inherit', 'pipe', 'inherit'], encoding: 'utf8' });
                if (res.status === 0) {
                    const createdId = String(res.stdout || '').trim();
                    if (!/^[a-f0-9]{64}$/.test(createdId)) {
                        throw new Error(`${runtime} create did not return one full immutable container ID`);
                    }
                    launchedContainerId = createdId;
                    recordCreatedId(createdId);
                    recordCreatedIdentity({ containerId: createdId, launch });
                }
                return res;
            } finally {
                cleanupGuardMountpoints();
            }
        }, { waitMs: 15 * 60 * 1000 });
        if (res.status !== 0) throw new Error(`${runtime} create failed with code ${res.status}`);
        return launchedContainerId;
    };
    let cleanupReceipt = beginCandidateLifecycle({
        runtimeKind: 'container',
        candidateName: containerName,
        contractHash: runtimeCandidateContractHash(
            runtimeAdmission,
            runtimeIdentity,
            manifestNetwork,
            'container',
        ),
        runtimeIdentity: {
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            profile: activeProfile,
            backend: runtime,
            network: manifestNetwork,
        },
        predecessorId: String(existingRecord.containerId || ''),
    });
    let launchedContainerId = '';
    let generatedLaunch = null;
    let adoptedExistingRuntime = false;
    let durableCandidate = null;
    let createdRegistryRecord = null;
    let createdIdentityPersisted = false;
    const recordCreatedIdentity = ({ containerId, launch = null, record = null }) => {
        if (launchedContainerId && launchedContainerId !== containerId) {
            throw new Error(`created candidate '${containerName}' changed its immutable ID before persistence`);
        }
        launchedContainerId = containerId;
        generatedLaunch = launch;
        if (record && cleanupReceipt.phase === 'create-attempted') cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, {
            phase: 'candidate-observed',
            creationAttempted: true,
            state: 'retryable-exact-id',
            candidateId: containerId,
            inspectionComplete: true,
            ownershipProof: {
                immutableId: true,
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
            },
        });
        if (createdIdentityPersisted) return;
        if (preparedDependencies) {
            try {
                preparedDependencies.updateConsumer({ containerId, phase: 'created' });
            } catch (error) {
                // The receipt already roots the object by container name.
                debugLog(`[deps] ${agentName}: dependency receipt container update deferred: ${error?.message || error}`);
            }
        }
        createdRegistryRecord = {
            ...launchRecord,
            type: 'agent', agentName, repoName, runtime, containerId,
            ...(options.alias ? { alias: options.alias } : {}),
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            ...(dependencyRecord ? { dependencies: dependencyRecord } : {}),
            config: {
                ...launchRecord.config,
                binds: launch?.descriptorHostFile ? [{
                    source: launch.descriptorHostFile,
                    target: GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE,
                    ro: true,
                    generatedRouterDescriptor: true,
                }] : [],
            },
        };
        // Persist before start/install can fail. Prepared launches retain their
        // signed registry source and use this separate immutable recovery record.
        durableCandidate = {
            operationId: cleanupReceipt.operationId,
            predecessorContainerId: String(cleanupReceipt.predecessorId || ''),
            containerName, containerId, runtime,
            runtimeNetwork: manifestNetwork,
            registryRecord: createdRegistryRecord,
            preparationLease: runtimeIdentity.preparationLease || options.preparationLease || null,
        };
        durableCandidate = writeRuntimeCandidate(durableCandidate);
        if (options.preserveRegistryRecord !== true) {
            const agents = loadAgentsMap();
            agents[containerName] = createdRegistryRecord;
            saveAgentsMap(agents);
        }
        createdIdentityPersisted = true;
    };
    // A non-Node target image needs the fixed Node helper to attest its exact
    // read-only volume topology. Pull it before any lifecycle/network lock; the
    // later probe uses only the already-present immutable image ID.
    if (adoptManagedRuntimeOnly) {
        if (!imageExists(ROUTER_AUTHORITY_HELPER_IMAGE, runtime)) {
            throw managedAdoptionMismatch('Router authority helper image is not already present');
        }
        if (!imageExists(image, runtime)) {
            throw managedAdoptionMismatch('admitted runtime image is not already present');
        }
    } else {
        ensureImagePresent(ROUTER_AUTHORITY_HELPER_IMAGE, { runtime });
    }
    try {
    // Every create passes through the hardware guard (input recheck, then the
    // engine prefix) immediately before the engine create; afterwards the
    // actual leaf is read back (an adopted runtime too) and the inputs are
    // rechecked before the candidate can be returned for route publication.
    // A refusal or a stale admission removes this candidate in the cleanup
    // below.
    runHardwareGuardedLaunch(hardwareLaunch, {
        beforeMutation: options.beforeHardwareMutation,
        placed: Boolean(runtimeAdmission.descriptor.hardwarePlacement),
        removeStaleLeaves: () => removeStaleHardwareLeaves(runtime),
        buildCreateArgs,
        spawnCreate,
        launch: (createContainer) => {
            if (runtimeNetworkPlan.requiresManagedNetwork) {
                // Resolve both the target and fixed probe images before the network
                // transaction. The helper never pulls and never executes target-image
                // entrypoints, including start-only images without Node.js.
                if (!adoptManagedRuntimeOnly) ensureImagePresent(image, { runtime });
                const transaction = {
                    network: manifestNetwork,
                    canonicalAgentId: agentName,
                    instanceKey: effectiveInstanceKey(repoName, agentName, options.alias || ''),
                    containerName,
                    runtimeIdentity,
                    inspectAdoption: inspectGeneratedRouterAdoption,
                    networkLockWaitMs: options.networkLockWaitMs,
                        networkLifecycleCapability: options.networkLifecycleCapability,
                        beforeDestructiveWork: options.beforeHardwareMutation,
                };
                const launched = adoptManagedRuntimeOnly
                    ? networkLifecycle.adoptManagedContainerTransaction(transaction)
                    : networkLifecycle.runManagedContainerTransaction({
                        ...transaction,
                        createContainer,
                        prepareLaunch: prepareGeneratedRouterLaunch,
                        preStartLaunch: preStartGeneratedRouterLaunch,
                        postStartLaunch: cleanupGuardMountpointsAfterStart,
                        finalizeLaunch: finalizeGeneratedRouterLaunch,
                        onContainerCreated: recordCreatedIdentity,
                        commandPrefix: hardwareLaunch.commandPrefix(),
                    });
                if (adoptManagedRuntimeOnly && launched?.adopted !== true) {
                    const mismatch = new Error(
                        `managed candidate '${containerName}' failed exact active-generation adoption: ${String(launched?.reason || 'mismatch')}`,
                    );
                    mismatch.code = 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH';
                    throw mismatch;
                }
                launchedContainerId = String(launched?.containerId || '');
                generatedLaunch = launched?.launch || launched?.adoption?.launch || null;
                adoptedExistingRuntime = launched?.adopted === true;
                if (!adoptManagedRuntimeOnly) clearLivenessState(containerName);
            } else {
                // All manifest/profile/port/image/mount validation above is complete.
                // Only now is the old host/none container deliberately replaced.
                options.beforeHardwareMutation?.();
                cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, {
                    phase: 'predecessor-inspected',
                    inspectionComplete: true,
                    ownershipProof: { predecessorRegistryIdentity: true },
                });
                // A coordinated same-name replacement rotates the registered tuple
                // before launch while the container still carries its predecessor's
                // labels. Prove ownership with the exact pre-rotation record that
                // ensureAgentService observed, and only for that same container ID.
                const predecessorRecord = selectPredecessorRemovalRecord(existingRecord, options.predecessorRegistryRecord);
                const predecessorRemoval = removeContainerForRecreate(
                    runtime,
                    containerName,
                    `startAgentContainer:${agentName}`,
                    predecessorRecord,
                );
                cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, {
                    phase: 'predecessor-removed',
                    predecessorId: String(existingRecord.containerId || ''),
                    ownershipProof: { predecessorRegistryIdentity: true, predecessorRemoved: predecessorRemoval.state },
                });
                launchedContainerId = withNetworkLifecycleLock(() => {
                    const createdId = createContainer(unmanagedNetworkLifecyclePlan);
                    return String(networkLifecycle.finalizeContainer(containerName, unmanagedNetworkLifecyclePlan, {
                        network: manifestNetwork,
                        runtimeIdentity,
                        expectedContainerId: createdId,
                        onCreated: recordCreatedIdentity,
                        beforeStart: prepareGuardMountpointCleanupBeforeStart,
                        afterStart: cleanupGuardMountpointsAfterStart,
                        commandPrefix: hardwareLaunch.commandPrefix(),
                    }) || '');
                }, { waitMs: 15 * 60 * 1000 });
            }
            if (!launchedContainerId) {
                throw new Error(`startAgentContainer(${agentName}) did not capture an immutable container ID`);
            }
            return { containerId: launchedContainerId, adopted: adoptedExistingRuntime };
        },
    });
    } catch (error) {
        let exactCleanupPerformed = error?.ploinkyContainerTransaction?.exactCleanupPerformed === true;
        launchedContainerId ||= String(error?.ploinkyContainerTransaction?.containerId || '');
        if (!runtimeNetworkPlan.requiresManagedNetwork && launchedContainerId) {
            try {
                const cleanup = removeExactGenerationCandidate({
                    containerName, containerId: launchedContainerId,
                    network: manifestNetwork,
                    record: createdRegistryRecord || { agentName, repoName, ...runtimeIdentity },
                });
                exactCleanupPerformed = cleanup.removed === true || cleanup.state === 'absent';
            } catch (cleanupError) { appendExactCleanupFailure(error, cleanupError.message); }
        }
        if (exactCleanupPerformed && durableCandidate) {
            try { retireRuntimeCandidate(durableCandidate); } catch (cleanupError) {
                appendExactCleanupFailure(error, cleanupError.message);
            }
        }
        if (exactCleanupPerformed && ['create-attempted', 'candidate-observed'].includes(cleanupReceipt.phase)) {
            cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, {
                phase: 'readiness', state: 'removed-proven', inspectionComplete: true,
                ownershipProof: { ...cleanupReceipt.ownershipProof, exactAbsenceProven: true },
            });
        }
        throw attachRestartCandidate(error, {
            containerName,
            ...(launchedContainerId ? { containerId: launchedContainerId } : {}),
            runtimeNetwork: structuredClone(manifestNetwork),
            registryRecord: createdRegistryRecord || {
                type: 'agent', agentName, repoName, runtime,
                ...(launchedContainerId ? { containerId: launchedContainerId } : {}),
                ...(options.alias ? { alias: options.alias } : {}),
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
            },
            cleanupReceipt,
            durableCandidate,
            exactCleanupPerformed,
        });
    }
    if (adoptManagedRuntimeOnly && adoptedExistingRuntime) {
        return {
            containerName,
            containerId: launchedContainerId,
            createdByThisLaunch: false,
            runtimeNetwork: structuredClone(manifestNetwork),
            registryRecord: structuredClone({
                ...existingRecord,
                runtime,
                containerId: launchedContainerId,
            }),
        };
    }
    if (cleanupReceipt.phase !== 'candidate-observed') cleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, adoptedExistingRuntime
        ? {
            phase: 'candidate-observed',
            state: 'not-created-proven',
            inspectionComplete: true,
            ownershipProof: { adoptedExistingRuntime: true },
        }
        : {
            phase: 'candidate-observed',
            creationAttempted: true,
            state: 'retryable-exact-id',
            candidateId: launchedContainerId,
            inspectionComplete: true,
            ownershipProof: {
                immutableId: true,
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
            },
        });
    const exactLaunchReceipt = Object.freeze({
        containerName,
        containerId: launchedContainerId,
        runtimeNetwork: structuredClone(manifestNetwork),
        cleanupReceipt,
        durableCandidate,
        registryRecord: Object.freeze({
            ...(createdRegistryRecord || {}),
            runtime,
            containerId: launchedContainerId,
            type: 'agent',
            agentName,
            repoName,
            ...(options.alias ? { alias: options.alias } : {}),
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
        }),
    });
    const cleanupExactLaunch = (error) => {
        let exactCleanupPerformed = false;
        let finalCleanupReceipt = cleanupReceipt;
        try {
            const cleanup = networkLifecycle.removeExactContainer(
                containerName,
                manifestNetwork,
                agentName,
                {
                    expectedContainerId: launchedContainerId,
                    instanceKey: effectiveInstanceKey(repoName, agentName, options.alias || ''),
                    contractHash: networkContractHash(manifestNetwork),
                    instanceId: runtimeIdentity.instanceId,
                    enableGeneration: runtimeIdentity.enableGeneration,
                },
            );
            exactCleanupPerformed = cleanup.removed === true || cleanup.state === 'absent';
            if (!exactCleanupPerformed) {
                appendExactCleanupFailure(error, cleanup.reason || cleanup.state || 'ownership mismatch');
            }
        } catch (cleanupError) {
            appendExactCleanupFailure(error, cleanupError?.message || cleanupError);
        }
        try {
            finalCleanupReceipt = advanceCandidateLifecycle(cleanupReceipt, exactCleanupPerformed
                ? {
                    phase: 'readiness',
                    state: 'removed-proven',
                    inspectionComplete: true,
                    ownershipProof: { ...cleanupReceipt.ownershipProof, exactAbsenceProven: true },
                }
                : {
                    phase: 'readiness',
                    state: 'preserved-ambiguous',
                    ownershipProof: { ...cleanupReceipt.ownershipProof, exactAbsenceProven: false },
                });
        } catch (receiptError) {
            appendExactCleanupFailure(error, `receipt transition: ${receiptError?.message || receiptError}`);
        }
        if (exactCleanupPerformed && durableCandidate) {
            try { retireRuntimeCandidate(durableCandidate); } catch (cleanupError) {
                appendExactCleanupFailure(error, cleanupError.message);
            }
        }
        if (exactCleanupPerformed && generatedLaunch?.cleanup) {
            try { generatedLaunch.cleanup(); } catch (cleanupError) {
                appendExactCleanupFailure(error, `descriptor cleanup: ${cleanupError?.message || cleanupError}`);
            }
        } else if (!exactCleanupPerformed && generatedLaunch?.cleanup) {
            appendExactCleanupFailure(error, 'descriptor preserved because exact candidate absence was not proven');
        }
        clearLivenessState(containerName);
        throw attachRestartCandidate(error, {
            ...exactLaunchReceipt,
            cleanupReceipt: finalCleanupReceipt,
            exactCleanupPerformed,
        });
    };
    const agents = loadAgentsMap();
    const declaredEnvNames2 = [
        ...getManifestEnvNames(manifest, profileConfig, { forRuntime: true }),
        ...getExposedNames(manifest, profileConfig, { forRuntime: true }),
        ...Object.keys(profileEnv)
    ];
    const llmRuntimeEnvNames = llmStartup.enabled
        ? ['HF_HOME', 'PLOINKY_MODELS_DIR', 'PLOINKY_DERIVED_DIR', 'PLOINKY_RUNTIME_DIR', 'PLOINKY_LAUNCHERS_DIR', 'PLOINKY_MCP_PORT', 'PLOINKY_LLM_PUBLIC_PORT', 'PLOINKY_LLM_MCP_PORT', 'PLOINKY_LLM_CONTROL_PORT', 'PLOINKY_INFERENCE_PORT']
        : [];
    const persistedRecord = agents[containerName] || launchRecord;
    agents[containerName] = {
        agentName,
        repoName,
        containerImage: image,
        ...(manifestImage && manifestImage !== image ? { manifestImage } : {}),
        ...(llmStartup.enabled ? {
            llmRuntime: {
                architectureId: llmStartup.selection.architectureId,
                catalogId: llmStartup.selection.catalogId,
                catalogRef: llmStartup.selection.catalogRef,
                platform: llmStartup.selection.platform,
                imageDigest: llmStartup.imageDigest,
                policyHash: llmStartup.policyHash,
                reuseHash: llmStartup.reuseHash,
            },
        } : {}),
        createdAt: persistedRecord.createdAt || new Date().toISOString(),
        projectPath: cwd,
        runMode: persistedRecord.runMode,
        develRepo: persistedRecord.develRepo,
        profile: activeProfile,
        type: 'agent',
        runtime,
        containerId: launchedContainerId,
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        agentLib: agentLibRuntimeRecord(containerAgentLibGrant),
        ...(dependencyRecord ? { dependencies: dependencyRecord } : {}),
        config: {
            binds: [
                { source: agentLibMountPath, target: '/Agent', ro: true },
                {
                    source: containerAgentLibGrant.sourceDir,
                    target: containerAgentLibGrant.runtimePath,
                    ro: true,
                },
                { source: topologyMount.source, target: topologyMount.target, ro: true },
                ...(generatedLaunch ? [{
                    source: generatedLaunch.descriptorHostFile,
                    target: GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE,
                    ro: true,
                    generatedRouterDescriptor: true,
                }] : []),
                { source: codeMountPath, target: '/code', ro: codeReadOnly },
                ...(useNestedDependencyMounts ? [
                    { source: preparedNodeModulesDir, target: '/code/node_modules', ro: true },
                    { source: preparedNodeModulesDir, target: '/Agent/node_modules', ro: true },
                ] : []),
                ...(stageLinkedCode ? podmanStagedTargetMounts : []),
                { source: sharedDir, target: '/shared' },
                ...(llmStartup.enabled && llmStartup.modelDir ? [{ source: llmStartup.modelDir, target: '/models' }] : []),
                ...(llmStartup.enabled && llmStartup.stateDir ? [{ source: llmStartup.stateDir, target: '/runtime' }] : []),
                ...(llmStartup.enabled && fs.existsSync(llmRuntimeSharedPath) ? [{ source: llmRuntimeSharedPath, target: '/Agent/llm-runtime', ro: true }] : []),
                ...(skillsPathExists && !skillsPathInsideCode && !stageLinkedCode ? [{ source: agentSkillsPath, target: '/code/skills', ro: skillsReadOnly }] : []),
                ...homeLayout.binds,
            ],
            env: Array.from(new Set([...declaredEnvNames2, ...llmRuntimeEnvNames])).map((name) => ({ name })),
            ports: runtimeNetworkPlan.mode === 'host' || runtimeNetworkPlan.mode === 'none'
                ? []
                : effectivePortMappings,
        }
    };
    if (persistedRecord.auth) {
        agents[containerName].auth = persistedRecord.auth;
    }

    if (persistedRecord.alias) {
        agents[containerName].alias = persistedRecord.alias;
    }
    if (options.preserveRegistryRecord !== true) saveAgentsMap(agents);
    const registryRecord = structuredClone(agents[containerName]);
    try {
        if (useProfileLifecycle) {
            const lifecycleResult = runProfileLifecycle(agentName, activeProfile, {
                    containerName,
                    agentPath,
                    repoName,
                    manifest,
                    skipInstallHooks: true
                });
            if (!lifecycleResult.success) {
                const details = lifecycleResult.errors.join('; ');
                throw new Error(`[profile] ${agentName}: lifecycle failed (${details})`);
            }
        } else {
            // Preinstall already ran before container start. Runtime containers no
            // longer install dependencies; only postinstall hooks run after boot.
            runPostinstallHook(agentName, containerName, manifest, cwd);
        }
    } catch (error) {
        cleanupExactLaunch(error);
    }
    if (launchExplicitSidecar) {
        try {
            launchAgentSidecar({ containerName, agentCommand: explicitAgentCmd, agentName });
        } catch (error) {
            cleanupExactLaunch(error);
        }
    }
    try {
        syncAgentMcpConfig(containerName, path.resolve(agentPath), agentName);
    } catch (error) {
        cleanupExactLaunch(error);
    }
    return {
        containerName,
        containerId: launchedContainerId,
        createdByThisLaunch: !adoptedExistingRuntime,
        runtimeNetwork: structuredClone(manifestNetwork),
        registryRecord,
        cleanupReceipt,
        durableCandidate,
    };
}

function resolveHostPort(containerName, existingRecord, containerPortCandidates) {
    const fromRecord = resolveHostPortFromRecord(existingRecord, containerPortCandidates);
    if (fromRecord) return fromRecord;
    return resolveHostPortFromRuntime(containerName, containerPortCandidates);
}

function resolveHostPortFromRecord(record, containerPortCandidates) {
    const ports = record?.config?.ports;
    if (!Array.isArray(ports) || !ports.length) return 0;
    for (const containerPort of containerPortCandidates) {
        const match = ports.find((p) => p && p.containerPort === containerPort);
        if (match?.hostPort) {
            return match.hostPort;
        }
    }
    return ports[0]?.hostPort || 0;
}

function resolveHostPortFromRuntime(containerName, containerPortCandidates) {
    const runtime = getRuntime();
    for (const containerPort of containerPortCandidates) {
        try {
            const portMap = execSync(`${runtime} port ${containerName} ${containerPort}/tcp`, { stdio: 'pipe' }).toString().trim();
            const hostPort = parseHostPort(portMap);
            if (hostPort) {
                return hostPort;
            }
        } catch (_) {
            // ignore and try next
        }
    }
    return 0;
}

function resolvePublishedPortMappings(containerName, portMappings) {
    if (!Array.isArray(portMappings) || portMappings.length === 0) {
        return [];
    }
    return portMappings.map((mapping) => {
        const hostPort = Number(mapping?.hostPort);
        const containerPort = Number(mapping?.containerPort);
        if (!Number.isFinite(containerPort) || containerPort <= 0) {
            return mapping;
        }
        if (Number.isFinite(hostPort) && hostPort > 0) {
            return mapping;
        }
        const resolvedHostPort = resolveHostPortFromRuntime(containerName, [containerPort]);
        return resolvedHostPort > 0
            ? { ...mapping, hostPort: resolvedHostPort }
            : mapping;
    });
}

function resolveImplicitAgentServerPort(profileConfig = {}, resolvedEnv = null) {
    let rawPort = resolvedEnv && Object.hasOwn(resolvedEnv, 'PORT')
        ? resolvedEnv.PORT
        : profileConfig?.env?.PORT;
    if (rawPort && typeof rawPort === 'object' && !Array.isArray(rawPort)) {
        rawPort = Object.hasOwn(rawPort, 'value')
            ? rawPort.value
            : rawPort.default;
    }
    if (rawPort === undefined || rawPort === null || String(rawPort).trim() === '') {
        return 7000;
    }
    const text = String(rawPort).trim();
    if (!/^[0-9]+$/.test(text)) {
        throw new Error(`implicit AgentServer PORT must be an integer from 1 through 65535, got '${text}'`);
    }
    const port = Number(text);
    if (!Number.isSafeInteger(port) || port < 1 || port > 65535) {
        throw new Error(`implicit AgentServer PORT must be an integer from 1 through 65535, got '${text}'`);
    }
    return port;
}

function shouldCreateImplicitAgentServerPublish(
    manifest,
    manifestPorts = [],
    networkMode = 'default',
    portMappings = [],
    agentServerPort = 7000,
) {
    if (networkMode === 'host' || networkMode === 'none') return false;
    if (Array.isArray(portMappings) && portMappings.some(
        (mapping) => Number(mapping?.containerPort) === Number(agentServerPort),
    )) {
        return false;
    }
    return resolveAgentExecutionMode(manifest).type !== 'start_only';
}

function appendUniquePortMapping(portMappings, mapping) {
    const current = Array.isArray(portMappings) ? [...portMappings] : [];
    const containerPort = Number(mapping?.containerPort);
    const protocol = String(mapping?.protocol || 'tcp').trim().toLowerCase() || 'tcp';
    const exists = current.some((entry) => (
        Number(entry?.containerPort) === containerPort
        && (String(entry?.protocol || 'tcp').trim().toLowerCase() || 'tcp') === protocol
    ));
    return exists ? current : [...current, mapping];
}

function assertHostPortContract(networkMode, portMappings) {
    if (networkMode !== 'host') return;
    const remapped = (portMappings || []).find((mapping) => (
        Number(mapping?.hostPort) !== Number(mapping?.containerPort)
    ));
    if (remapped) {
        throw new Error(
            `direct host network mode cannot remap external port ${remapped.hostPort} to private port ${remapped.containerPort}; the ports must match`,
        );
    }
}

export function assertPreparedRegistryRecordPreservation(existingRecord, options = {}, {
    ownerRef = 'agent',
} = {}) {
    if (options.preservePreparedRegistryRecord !== true) return false;
    const stagedInstanceId = String(existingRecord?.instanceId || '');
    const stagedEnableGeneration = String(existingRecord?.enableGeneration || '');
    const requestedInstanceId = String(options.instanceId || stagedInstanceId);
    const requestedEnableGeneration = String(options.enableGeneration || stagedEnableGeneration);
    if (options.preparationLease?.mode === 'additive'
        && requestedInstanceId
        && requestedEnableGeneration) {
        const preparedRecord = assertAdditivePreparedRuntimeIdentity(options.preparationLease, {
            containerName: options.containerName,
            instanceId: requestedInstanceId,
            enableGeneration: requestedEnableGeneration,
        });
        const canonicalProvided = options.preparedRegistryRecord
            ? JSON.parse(JSON.stringify(options.preparedRegistryRecord))
            : null;
        if (!canonicalProvided || !isDeepStrictEqual(preparedRecord, canonicalProvided)) {
            throw new Error(
                `preserving the additive registry record for ${ownerRef} requires the exact immutable prepared record`,
            );
        }
        return true;
    }
    if (!stagedInstanceId || !stagedEnableGeneration
        || requestedInstanceId !== stagedInstanceId
        || requestedEnableGeneration !== stagedEnableGeneration) {
        throw new Error(
            `preserving the prepared registry record for ${ownerRef} requires its exact staged instanceId/enableGeneration`,
        );
    }
    return true;
}

function capturePreparedRegistryRecord(containerName, runtimeIdentity) {
    if (!runtimeIdentity?.preparationLease) return null;
    const prepared = assertPreparedRuntimeIdentity(runtimeIdentity.preparationLease, {
        containerName,
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
    });
    // Additive preparation deliberately leaves the active predecessor's
    // mutable registry untouched. Its immutable candidate record is therefore
    // the staged launch authority until the additive commit publishes it.
    if (runtimeIdentity.preparationLease.mode === 'additive') {
        return structuredClone(prepared);
    }
    const record = loadAgentsMap()?.[containerName];
    if (!record || record.type !== 'agent'
        || String(record.instanceId || '') !== String(runtimeIdentity.instanceId || '')
        || String(record.enableGeneration || '') !== String(runtimeIdentity.enableGeneration || '')
        || !isDeepStrictEqual(record, prepared)) {
        throw new Error(
            `prepared runtime for '${containerName}' lost its exact immutable staged registry record before launch`,
        );
    }
    return structuredClone(record);
}

function mintReplacementRuntimeIdentity(existingRecord, uuid = randomUUID) {
    const instanceId = String(uuid() || '').trim();
    const enableGeneration = String(uuid() || '').trim();
    if (!instanceId || !enableGeneration
        || instanceId === enableGeneration
        || instanceId === String(existingRecord?.instanceId || '')
        || instanceId === String(existingRecord?.enableGeneration || '')
        || enableGeneration === String(existingRecord?.instanceId || '')
        || enableGeneration === String(existingRecord?.enableGeneration || '')) {
        throw new Error('replacement runtime identity mint did not produce a fresh instanceId and enableGeneration');
    }
    return Object.freeze({ instanceId, enableGeneration });
}

// The exact admitted instance key behind a runtime container name: a staged
// replacement candidate (NAME__candidate_<12 hex>) belongs to NAME, the
// registry key graph admission recorded.
export function admittedInstanceKeyFor(containerName) {
    return String(containerName || '').trim().replace(/__candidate_[a-f0-9]{12}$/i, '');
}

export function replacementCandidateContainerName(containerName, instanceId) {
    const exactContainerName = String(containerName || '').trim();
    const exactInstanceId = String(instanceId || '').trim();
    if (!exactContainerName || !exactInstanceId) {
        throw new Error('replacement candidate naming requires an exact predecessor name and instanceId');
    }
    const stableBase = admittedInstanceKeyFor(exactContainerName);
    const suffix = createHash('sha256').update(exactInstanceId).digest('hex').slice(0, 12);
    return `${stableBase}__candidate_${suffix}`;
}

export function getFailedRuntimeIdentityRotation(error) {
    return error && typeof error === 'object'
        ? FAILED_RUNTIME_IDENTITY_ROTATIONS.get(error) || null
        : null;
}

export function coordinateReplacementRuntimeIdentity({
    containerName,
    existingRecord,
    reason = 'runtime-replacement',
    networkLifecycleCapability,
    stageAlongsidePredecessor = false,
    preserveActiveAuthorization = stageAlongsidePredecessor,
    runtimeNetwork = null,
    predecessorContainerId = '',
    portMappings = [],
} = {}, {
    assertNetworkCapability = assertNetworkLifecycleCapability,
    prepare = prepareAdditiveEdgeRoutingGeneration,
    prepareReplacement = prepareEdgeRoutingGenerationRaw,
    inactivate = inactivateEdgeRoutingGeneration,
    loadRegistry = loadAgentsMap,
    loadRouting = readRoutingConfig,
    saveRegistry = saveAgentsMap,
    saveRouting = writeRoutingConfig,
    withApplyLock = withEdgeGenerationApplyLock,
    retireNoWaitMarker = retireNoWaitRunMarker,
    uuid = randomUUID,
} = {}) {
    const exactContainerName = String(containerName || '').trim();
    if (!exactContainerName) {
        throw new Error('coordinated runtime replacement requires an exact container name');
    }
    // Fixed host publications cannot be acquired by a staged candidate while
    // its predecessor owns them. Rotate through the inactive same-name path,
    // whose managed transaction removes the exact predecessor before launch.
    if (portMappings.some((mapping) => Number(mapping?.hostPort) > 0)) {
        stageAlongsidePredecessor = false;
        preserveActiveAuthorization = false;
    }
    if (preserveActiveAuthorization && !stageAlongsidePredecessor) {
        throw new Error('preserving active replacement authorization requires a distinct staged runtime');
    }
    assertNetworkCapability(networkLifecycleCapability);

    const coordinationReason = `runtime-identity-rotation:${String(reason || 'runtime-replacement')}:${exactContainerName}`;
    let runtimeIdentity;
    let candidateContainerName = exactContainerName;
    let prepared;
    let stagedRotation = null;
    let rotationPhase = 'registry-save';
    try {
    withApplyLock((applyLockCapability) => {
        if (!preserveActiveAuthorization) {
            inactivate(coordinationReason, { applyLockCapability });
        }
        const agents = loadRegistry();
        const current = agents?.[exactContainerName];
        if (!current || current.type !== 'agent') {
            throw new Error(`runtime replacement for '${exactContainerName}' requires one exact registered agent record`);
        }
        if (String(current.instanceId || '') !== String(existingRecord?.instanceId || '')
            || String(current.enableGeneration || '') !== String(existingRecord?.enableGeneration || '')) {
            throw new Error(`runtime identity for '${exactContainerName}' changed before coordinated replacement`);
        }

        runtimeIdentity = mintReplacementRuntimeIdentity(current, uuid);
        candidateContainerName = stageAlongsidePredecessor
            ? replacementCandidateContainerName(exactContainerName, runtimeIdentity.instanceId)
            : exactContainerName;
        if (candidateContainerName !== exactContainerName && agents[candidateContainerName]) {
            throw new Error(`replacement candidate name '${candidateContainerName}' is already registered`);
        }
        if (candidateContainerName !== exactContainerName) delete agents[exactContainerName];
        agents[candidateContainerName] = {
            ...current,
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
        };
        const routing = candidateContainerName !== exactContainerName ? loadRouting() : null;
        if (routing) {
            for (const route of Object.values(routing?.routes || {})) {
                if (route && route.container === exactContainerName) {
                    route.container = candidateContainerName;
                }
            }
        }
        if (preserveActiveAuthorization) {
            prepared = prepare({
                agents,
                routing,
                reason: coordinationReason,
                applyLockCapability,
            });
            return;
        }
        // The current marker authorizes observations of the predecessor tuple.
        // Retire it before a non-additive write replaces or removes that tuple.
        // Additive preparation above retains the active predecessor until commit.
        retireNoWaitMarker(exactContainerName, { expectedRecord: current });
        // Capture before the write: persistence can succeed and then throw.
        // This receipt records only this coordinator's attempted rotation;
        // consumers must still match the exact live staged registry record.
        // Additive preparation never claims a mutable registry rotation.
        stagedRotation = freezeCleanupReceipt({
            containerName: candidateContainerName,
            stagedRegistryRecord: structuredClone(agents[candidateContainerName]),
            predecessorContainerName: exactContainerName,
            predecessorRegistryRecord: structuredClone(current),
            predecessorContainerId: String(predecessorContainerId || current.containerId || ''),
            runtimeNetwork: runtimeNetwork ? structuredClone(runtimeNetwork) : null,
        });
        saveRegistry(agents, { coordinate: false, applyLockCapability });
        rotationPhase = 'route-save';
        if (routing) saveRouting(routing, { coordinate: false });
        rotationPhase = 'prepare';
        try {
            prepared = prepareReplacement({
                reason: coordinationReason,
                applyLockCapability,
            });
        } catch (error) {
            try {
                inactivate(`${coordinationReason}:prepare-failed`, {
                    applyLockCapability,
                    preserveSelectedGeneration: true,
                });
            } catch (_) {}
            throw error;
        }
    });
    rotationPhase = 'validation';
    const preparedRecord = prepared?.generation?.agents?.[candidateContainerName];
    const preparationMatchesMode = preserveActiveAuthorization
        ? prepared?.selector?.state === 'active' && prepared?.preparationLease?.mode === 'additive'
        : prepared?.selector?.state === 'inactive' && prepared?.preparationLease?.mode !== 'additive';
    if (!preparationMatchesMode
        || (candidateContainerName !== exactContainerName
            && prepared?.generation?.agents?.[exactContainerName] !== undefined)
        || String(preparedRecord?.instanceId || '') !== runtimeIdentity.instanceId
        || String(preparedRecord?.enableGeneration || '') !== runtimeIdentity.enableGeneration) {
        let aborted = false;
        try {
            if (prepared?.preparationLease) {
                abortEdgeRoutingPreparation(prepared.preparationLease, {
                    reason: `${coordinationReason}:identity-mismatch`,
                });
                aborted = true;
            }
        } catch (_) {}
        if (!preserveActiveAuthorization && !aborted) {
            try {
                inactivate(`${coordinationReason}:identity-mismatch`, {
                    preserveSelectedGeneration: true,
                });
            } catch (_) {}
        }
        throw new Error(preserveActiveAuthorization
            ? `coordinated replacement candidate did not retain the active predecessor with the fresh runtime identity for '${exactContainerName}'`
            : `coordinated replacement candidate did not remain inactive with the fresh runtime identity for '${exactContainerName}'`);
    }
    return Object.freeze({
        ...runtimeIdentity,
        candidateContainerName,
        predecessorContainerName: exactContainerName,
        ...(prepared?.preparationLease ? { preparationLease: prepared.preparationLease } : {}),
        preparedRegistryRecord: structuredClone(preparedRecord),
    });
    } catch (error) {
        if (!stagedRotation) throw error;
        const failure = error && typeof error === 'object' ? error : new Error(String(error));
        FAILED_RUNTIME_IDENTITY_ROTATIONS.set(failure, Object.freeze({ ...stagedRotation, phase: rotationPhase }));
        throw failure;
    }
}

export function resolveReplacementRuntimeIdentity({
    containerName,
    existingRecord,
    existingRuntime = false,
    recreateReason = null,
    preservePreparedRegistryRecord = false,
    targetedRestart = false,
    requestedInstanceId = '',
    requestedEnableGeneration = '',
    networkLifecycleCapability,
    stageAlongsidePredecessor = false,
    preserveActiveAuthorization = stageAlongsidePredecessor,
    runtimeNetwork = null,
    predecessorContainerId = '',
    portMappings = [],
} = {}, dependencies = {}) {
    if (!targetedRestart && !preservePreparedRegistryRecord
        && existingRuntime && !recreateReason) {
        const instanceId = String(existingRecord?.instanceId || '').trim();
        const enableGeneration = String(existingRecord?.enableGeneration || '').trim();
        if (!instanceId || !enableGeneration) {
            throw new Error('runtime reuse requires the exact registered instanceId and enableGeneration');
        }
        return Object.freeze({
            instanceId,
            enableGeneration,
            ...(dependencies.preparationLease
                ? { preparationLease: dependencies.preparationLease }
                : {}),
        });
    }
    if (!targetedRestart && !preservePreparedRegistryRecord && (
        existingRuntime && recreateReason
        || !existingRuntime && existingRecord?.type === 'agent' && !preservePreparedRegistryRecord
    )) {
        return coordinateReplacementRuntimeIdentity({
            containerName,
            existingRecord,
            reason: recreateReason || 'registered-runtime-missing',
            networkLifecycleCapability,
            stageAlongsidePredecessor,
            preserveActiveAuthorization,
            runtimeNetwork,
            predecessorContainerId,
            portMappings,
        }, dependencies);
    }
    if (targetedRestart || preservePreparedRegistryRecord) {
        return Object.freeze({
            instanceId: String(requestedInstanceId || existingRecord?.instanceId || ''),
            enableGeneration: String(requestedEnableGeneration || existingRecord?.enableGeneration || ''),
            ...(dependencies.preparationLease ? { preparationLease: dependencies.preparationLease } : {}),
        });
    }
    const uuid = dependencies.uuid || randomUUID;
    return mintReplacementRuntimeIdentity({}, uuid);
}

export function assertAgentServiceNotDraining(containerName, {
    targetedRestart = false,
    loadRouting = readRoutingConfig,
} = {}) {
    if (targetedRestart) return;
    const draining = Object.values(loadRouting()?.routes || {}).some((route) => (
        route?.container === containerName && route.draining === true
    ));
    if (draining) {
        const error = new Error(`agent '${containerName}' still requires an acknowledged targeted drain; automatic replacement is blocked`);
        error.code = 'PLOINKY_AGENT_DRAINING';
        throw error;
    }
}

/**
 * ensureAgentService's LLM runtime reuse decision (plan §8.3): the reuse probe
 * receives the same admitted policy (stored overrides included) and the same
 * resolved selection/hardware as creation, so a limited LLM agent is not
 * replaced on every start. Returns 'llmReuseHashChanged' or ''.
 */
export function serviceLlmReuseReason({
    runtime,
    manifest,
    profileConfig,
    agentName,
    alias,
    containerName,
    envHash,
    serviceAdmission,
    serviceLlmAdmissionContext,
    env = process.env,
    agentWorkDirRoot = AGENTS_DATA_DIR,
    prepareLlmStartupImpl = prepareLlmStartup,
    getContainerLabelImpl = getContainerLabel,
}) {
    const probe = prepareLlmStartupImpl({
        runtime,
        manifest,
        profileConfig,
        agentName,
        alias,
        env,
        agentWorkDirRoot,
        manifestEnvNames: [
            ...getManifestEnvNames(manifest, profileConfig, { forRuntime: true }),
            ...getExposedNames(manifest, profileConfig, { forRuntime: true }),
        ],
        envHash,
        effectiveNetwork: profileConfig?.network ?? manifest?.network ?? null,
        writeState: false,
        createDirectories: false,
        // Same admitted policy and resolved selection/hardware as creation,
        // so reuse agrees with it.
        resolvedSelection: serviceLlmAdmissionContext?.startup?.selection,
        resolvedHardware: serviceLlmAdmissionContext?.startup?.hardware,
        admittedRuntimePolicy: serviceAdmission.descriptor.runtimePolicy,
    });
    if (!probe.enabled) return '';
    const currentReuse = getContainerLabelImpl(containerName, 'ploinky.reusehash');
    return probe.reuseHash && probe.reuseHash !== currentReuse ? 'llmReuseHashChanged' : '';
}

/**
 * ensureAgentService's strict admission before any backend selection, lock or
 * runtime mutation. It takes the exact options ensureAgentService receives;
 * `admissionContext` (Box marker and hardware context) is supplied only where
 * the caller already captured them, as graph admission does. A hardware
 * refusal raised here carries the exact admitted instance key and alias, so
 * the start contains it like a metadata refusal.
 */
export function admitAgentServicePreflight(agentName, manifest, agentPath, options = {}, admissionContext = {}) {
    const preflightRepoName = resolveAgentRepositoryName(agentPath);
    const preflightManifestPath = path.join(agentPath, 'manifest.json');
    const preflightManifestBytes = fs.existsSync(preflightManifestPath)
        ? fs.readFileSync(preflightManifestPath)
        : Buffer.from(JSON.stringify(manifest || {}));
    const preflightExactManifest = JSON.parse(preflightManifestBytes.toString('utf8'));
    if (!isDeepStrictEqual(preflightExactManifest, manifest)) {
        const error = new Error(`ensureAgentService(${agentName}) manifest bytes changed before admission`);
        error.code = 'PLOINKY_RUNTIME_INPUT_CHANGED';
        error.status = 409;
        throw error;
    }
    const preflightContainerName = options.containerName
        || getAgentContainerName(agentName, preflightRepoName);
    const mutablePreflightRecord = loadAgentsMap()[preflightContainerName] || {};
    // An additive candidate is intentionally absent from mutable agents.json
    // until atomic activation. Carry its exact prepared record through the
    // read-only profile/admission preflight; the preparation lease validates
    // that record authoritatively below before any runtime mutation.
    const preflightRecord = options.preservePreparedRegistryRecord === true
        && options.preparedRegistryRecord
        ? options.preparedRegistryRecord
        : mutablePreflightRecord;
    // Every refusal this admission raises names the exact admitted instance:
    // the registry key (a staged replacement candidate belongs to it) and
    // the instance alias, as graph admission records them.
    const hardwareInstanceKey = String(options.hardwareInstanceKey || '')
        || (mutablePreflightRecord.type === 'agent' ? preflightContainerName : admittedInstanceKeyFor(preflightContainerName));
    const hardwareAlias = String(options.alias || preflightRecord.alias || '');
    const preflightProfile = resolveManifestRuntimeProfile(manifest, {
        agentName: `${preflightRepoName}/${agentName}`,
        profileName: options.profileName,
        persistedProfileName: preflightRecord.profile,
        path: `manifest(${preflightRepoName}/${agentName})`,
    });
    assertManifestStorageAdmission(manifest, preflightProfile.profileConfig);
    // Reject manifest-declared capabilities before even selecting a backend.
    // A second admission below adds the read-only catalog selection.
    admitManifestRuntimeCapabilities(manifest, {
        manifestBytes: preflightManifestBytes,
        manifestPath: preflightManifestPath,
        agentId: `${preflightRepoName}/${agentName}`,
        profileName: preflightProfile.resolvedProfileName,
        profileConfig: preflightProfile.profileConfig,
        network: preflightProfile.network,
        runtimeKind: 'container',
        instanceKey: hardwareInstanceKey,
        alias: hardwareAlias,
        ...admissionContext,
    });
    const preflightAgentRuntime = getRuntimeForAgent(manifest);
    const preflightRuntimeKind = isSandboxRuntime(preflightAgentRuntime)
        ? preflightAgentRuntime
        : 'container';
    const preflightLlmAdmissionContext = preflightRuntimeKind === 'container'
        ? resolveLlmRuntimeAdmissionContext({
            runtime: preflightAgentRuntime,
            manifest,
            profileConfig: preflightProfile.profileConfig,
            agentName,
            alias: options.alias,
            env: process.env,
        })
        : { catalogPolicy: null, catalogIdentity: null };
    const preflightAdmission = admitManifestRuntimeCapabilities(manifest, {
        manifestBytes: preflightManifestBytes,
        manifestPath: preflightManifestPath,
        agentId: `${preflightRepoName}/${agentName}`,
        profileName: preflightProfile.resolvedProfileName,
        profileConfig: preflightProfile.profileConfig,
        network: preflightProfile.network,
        runtime: preflightAgentRuntime,
        runtimeKind: preflightRuntimeKind,
        catalogPolicy: preflightLlmAdmissionContext.catalogPolicy,
        catalogIdentity: preflightLlmAdmissionContext.catalogIdentity,
        instanceKey: hardwareInstanceKey,
        alias: hardwareAlias,
        ...admissionContext,
    });
    if (options.runtimeAdmission) {
        assertRuntimeAdmissionCurrent(options.runtimeAdmission, {
            manifestBytes: preflightManifestBytes,
            profileName: preflightProfile.resolvedProfileName,
            runtimeKind: preflightRuntimeKind,
            descriptor: preflightAdmission.descriptor,
        });
    }
    return Object.freeze({
        preflightRepoName,
        preflightManifestPath,
        preflightManifestBytes,
        preflightProfile,
        preflightAgentRuntime,
        preflightRuntimeKind,
        preflightAdmission,
        hardwareInstanceKey,
        hardwareAlias,
    });
}

function ensureAgentService(agentName, manifest, agentPath, options = {}) {
    if (!options || typeof options !== 'object'
        || !Object.prototype.hasOwnProperty.call(options, 'routerEndpoint')
        || options.routerEndpoint === undefined) {
        const error = new Error('ensureAgentService requires a validated routerEndpoint; pass explicit null for network mode none');
        error.code = 'PLOINKY_ROUTER_ENDPOINT_REQUIRED';
        throw error;
    }
    const {
        preflightRepoName,
        preflightManifestPath,
        preflightManifestBytes,
        preflightAgentRuntime,
        preflightRuntimeKind,
        preflightAdmission,
        hardwareInstanceKey,
    } = admitAgentServicePreflight(agentName, manifest, agentPath, options);
    const mpsRecord = loadAgentsMap()[options.containerName || getAgentContainerName(agentName, preflightRepoName)];
    const appliedMps = mpsRecord?.containerId ? readAppliedObservation(options.containerName || getAgentContainerName(agentName, preflightRepoName), mpsRecord.containerId) : null;
    if (!hasMpsLaunch(options.mpsLaunch) && (preflightAdmission.descriptor.hardwareGpu || appliedMps?.mpsGeneration)) {
        return import('../hardwareLimits/mpsLifecycle.mjs').then(({ ensureMpsAgentService }) => ensureMpsAgentService(agentName, manifest, agentPath, options));
    }
    const targetedRestart = normalizeTargetedRestart(options.targetedRestart);
    if (!options.networkLifecycleCapability) {
        return withNetworkLifecycleLock(
            (networkLifecycleCapability) => ensureAgentService(agentName, manifest, agentPath, {
                ...options,
                networkLifecycleCapability,
                runtimeAdmission: options.runtimeAdmission || preflightAdmission,
            }),
            { waitMs: Math.max(0, Number(options.networkLockWaitMs || 0)) },
        );
    }
    assertNetworkLifecycleCapability(options.networkLifecycleCapability);
    let preferredHostPort;
    let containerOverride;
    let aliasOverride;
    let forceRecreate = false;
    let profileNameOverride;
    let routerEndpointOverride;
    let networkLockWaitMs;
    preferredHostPort = options.preferredHostPort;
    containerOverride = options.containerName;
    aliasOverride = options.alias;
    // Container and bwrap runtimes compare their admitted immutable dependency
    // generation with the desired one before any reuse. Seatbelt keeps the
    // package-presence recreation guard: its source-tree node_modules link is
    // shared by every consumer of that source and cannot switch generations
    // underneath another live consumer.
    forceRecreate = options.forceRecreate === true
        || (preflightAgentRuntime === 'seatbelt'
            && Boolean(dependencyRefreshOperation()) && hasAgentPackageJson(agentPath));
    const forceRecreateCause = options.forceRecreate === true
        ? String(options.forceRecreateReason || 'requested by the caller')
        : (forceRecreate ? 'dependency refresh of an agent with a package.json' : '');
    profileNameOverride = options.profileName;
    routerEndpointOverride = options.routerEndpoint;
    if (Object.prototype.hasOwnProperty.call(options, 'routerHost')) {
        throw new Error('routerHost overrides are not supported; pass the validated routerEndpoint');
    }
    networkLockWaitMs = options.networkLockWaitMs;

    const repoName = resolveAgentRepositoryName(agentPath);
    const containerName = containerOverride || getAgentContainerName(agentName, repoName);
    assertAgentServiceNotDraining(containerName, { targetedRestart: Boolean(targetedRestart) });
    const snapshot = loadAgentsMap();
    const existingRecord = snapshot[containerName] || {};
    const preservePreparedRegistryRecord = assertPreparedRegistryRecordPreservation(
        existingRecord,
        options,
        { ownerRef: `${repoName}/${agentName}` },
    );
    const launchRecord = preservePreparedRegistryRecord
        ? (options.preparedRegistryRecord || existingRecord)
        : existingRecord;
    if (!aliasOverride && launchRecord.alias) {
        aliasOverride = launchRecord.alias;
    }

    // Resolve profile and network before backend dispatch so every runtime uses
    // the same effective selection. Explicit CLI and persisted profiles are
    // strict; an unavailable global profile alone may fall back to default.
    const profileResolution = resolveManifestRuntimeProfile(manifest, {
        agentName: `${repoName}/${agentName}`,
        profileName: profileNameOverride,
        persistedProfileName: launchRecord.profile,
        path: `manifest(${repoName}/${agentName})`,
    });
    const activeProfile = profileResolution.resolvedProfileName;
    const profileConfig = profileResolution.profileConfig;
    const manifestNetwork = profileResolution.network;
    const serviceLlmAdmissionContext = preflightRuntimeKind === 'container'
        ? resolveLlmRuntimeAdmissionContext({
            runtime: preflightAgentRuntime,
            manifest,
            profileConfig,
            agentName,
            alias: aliasOverride,
            env: process.env,
        })
        : { catalogPolicy: null, catalogIdentity: null };
    const serviceAdmission = admitManifestRuntimeCapabilities(manifest, {
        manifestBytes: preflightManifestBytes,
        manifestPath: preflightManifestPath,
        agentId: `${repoName}/${agentName}`,
        profileName: activeProfile,
        profileConfig,
        network: manifestNetwork,
        runtime: preflightAgentRuntime,
        runtimeKind: 'container',
        catalogPolicy: serviceLlmAdmissionContext.catalogPolicy,
        catalogIdentity: serviceLlmAdmissionContext.catalogIdentity,
        instanceKey: hardwareInstanceKey,
        alias: aliasOverride || '',
    });
    if (options.runtimeAdmission && preflightRuntimeKind === 'container') {
        assertRuntimeAdmissionCurrent(options.runtimeAdmission, {
            manifestBytes: preflightManifestBytes,
            profileName: activeProfile,
            runtimeKind: 'container',
            descriptor: serviceAdmission.descriptor,
        });
    }
    assertNetworkStartupCompatibility(manifest, profileConfig, manifestNetwork, {
        path: `manifest(${repoName}/${agentName})`,
    });
    const routerEndpoint = assertRouterEndpoint(routerEndpointOverride, manifestNetwork.mode);

    // Host sandboxes share the host network namespace. Fail closed unless the
    // effective manifest/profile contract explicitly selects host networking.
    const agentRuntime = getRuntimeForAgent(manifest);
    let sandboxAdmission = null;
    if (agentRuntime === 'bwrap' || agentRuntime === 'seatbelt') {
        if (options.runtimeAdmission) {
            assertRuntimeAdmissionCurrent(options.runtimeAdmission, {
                manifestBytes: preflightManifestBytes,
                profileName: activeProfile,
                runtimeKind: agentRuntime,
            });
        }
        sandboxAdmission = options.runtimeAdmission || admitManifestRuntimeCapabilities(manifest, {
            manifestBytes: preflightManifestBytes,
            manifestPath: preflightManifestPath,
            agentId: `${repoName}/${agentName}`,
            profileName: activeProfile,
            profileConfig,
            network: manifestNetwork,
            runtimeKind: agentRuntime,
            instanceKey: hardwareInstanceKey,
            alias: aliasOverride || '',
        });
    }
    if (agentRuntime === 'bwrap' || agentRuntime === 'seatbelt') {
        let sandboxRuntimeIdentity = null;
        let sandboxStagedRegistryRecord = null;
        let sandboxRequiresEdgeActivation = false;
        let sandboxCleanupReceipt = null;
        // The manager's own return, once it has one: only a runtime this call
        // launched (createdByThisLaunch) is ever a candidate to clean up.
        let sandboxLaunch = null;
        try {
            assertHostSandboxNetworkCompatibility(manifestNetwork, {
                path: `manifest(${repoName}/${agentName}).network`,
                runtime: agentRuntime,
            });
            if (targetedRestart) {
                throw new Error(`targeted drain/restart is unsupported for ${agentRuntime} runtimes`);
            }
            const registeredIdentity = String(existingRecord.instanceId || '').trim()
                && String(existingRecord.enableGeneration || '').trim()
                ? {
                    instanceId: String(existingRecord.instanceId),
                    enableGeneration: String(existingRecord.enableGeneration),
                }
                : null;
            // The tuple the caller proves it is replacing. Graph launches pass
            // null: their predecessor was already removed by the graph removal
            // step, so the slot must be empty or hold the exact successor.
            // Passing nothing is the same as null: a caller gets no authority
            // over a runtime it did not name.
            const expectedPredecessor = normalizeExpectedPredecessor(options.expectedPredecessor);
            const slotObservation = observeSandboxRuntime(containerName);
            // An unknown slot is never absence: refuse before any identity is
            // rotated, any receipt is written or any signal is sent.
            if (slotObservation.state === 'unknown') {
                throw sandboxOwnershipUnknownError(containerName, slotObservation);
            }
            const anyRuntimeRunning = slotObservation.state === 'live-exact';
            const runningAtEntry = Boolean(registeredIdentity)
                && anyRuntimeRunning
                && slotObservation.record.instanceId === registeredIdentity.instanceId
                && slotObservation.record.enableGeneration === registeredIdentity.enableGeneration;
            const desiredEnvHash = computeEnvHash(manifest, profileConfig, routerEndpoint?.env || {}, {
                agentName,
                repoName,
            });
            const currentEnvHash = String(existingRecord.envHash || '');
            let sandboxRecreateReason = forceRecreate
                ? 'forceRecreate'
                : (!runningAtEntry
                    ? (anyRuntimeRunning ? 'runtimeIdentityDrift' : 'sandboxRuntimeStopped')
                    : (desiredEnvHash && desiredEnvHash !== currentEnvHash ? 'envHashChanged' : null));
            // A changed bwrap dependency generation is a new sandbox with a
            // coordinated identity, never a rebind of the running one.
            if (!sandboxRecreateReason
                && (agentRuntime === 'bwrap' ? bwrapDependencyReuseProblem : seatbeltDependencyReuseProblem)(
                    { agentName, manifest, record: existingRecord, containerName },
                )) {
                sandboxRecreateReason = 'dependencyGenerationChanged';
            }
            if (anyRuntimeRunning && sandboxRecreateReason) {
                logRuntimeReplacement(`${repoName}/${agentName}`, formatReplacementReason(
                    sandboxRecreateReason,
                    sandboxRecreateReason === 'envHashChanged'
                        ? hashMismatchDetail('envHash', currentEnvHash, desiredEnvHash)
                        : (sandboxRecreateReason === 'forceRecreate' ? forceRecreateCause : ''),
                ));
            }
            const requiresEdgeActivation = Boolean(existingRecord?.type === 'agent' && sandboxRecreateReason);
            if (sandboxRecreateReason && anyRuntimeRunning) {
                // A replacement stops the occupant, so only the tuple the caller
                // named, or the exact successor a prepared record requests, may
                // be there. Anything else is refused before the registry rotates.
                const occupant = slotObservation.record;
                const named = (tuple) => Boolean(tuple)
                    && occupant.instanceId === tuple.instanceId
                    && occupant.enableGeneration === tuple.enableGeneration;
                const requestedSuccessor = String(options.instanceId || '') && String(options.enableGeneration || '')
                    ? { instanceId: String(options.instanceId), enableGeneration: String(options.enableGeneration) }
                    : null;
                if (!named(expectedPredecessor) && !named(requestedSuccessor)) {
                    const busy = new Error(`sandbox runtime ${containerName} is bound to a live process that is neither the requested successor nor the expected predecessor; no signal was sent`);
                    busy.code = 'PLOINKY_SANDBOX_PID_SLOT_BUSY';
                    throw busy;
                }
            }
            const runtimeIdentity = resolveReplacementRuntimeIdentity({
                containerName,
                existingRecord,
                existingRuntime: anyRuntimeRunning,
                recreateReason: sandboxRecreateReason,
                runtimeNetwork: manifestNetwork,
                predecessorContainerId: existingRecord.containerId || '',
                networkLifecycleCapability: options.networkLifecycleCapability,
                preservePreparedRegistryRecord,
                requestedInstanceId: String(options.instanceId || existingRecord.instanceId || ''),
                requestedEnableGeneration: String(options.enableGeneration || existingRecord.enableGeneration || ''),
            }, { preparationLease: options.preparationLease });
            sandboxRuntimeIdentity = runtimeIdentity;
            sandboxStagedRegistryRecord = capturePreparedRegistryRecord(containerName, runtimeIdentity);
            sandboxRequiresEdgeActivation = requiresEdgeActivation;
            sandboxCleanupReceipt = beginCandidateLifecycle({
                runtimeKind: agentRuntime,
                candidateName: containerName,
                contractHash: runtimeCandidateContractHash(
                    sandboxAdmission,
                    runtimeIdentity,
                    manifestNetwork,
                    agentRuntime,
                ),
                runtimeIdentity: {
                    instanceId: runtimeIdentity.instanceId,
                    enableGeneration: runtimeIdentity.enableGeneration,
                    profile: activeProfile,
                    backend: agentRuntime,
                    network: manifestNetwork,
                },
            });
            let preparedHostModeCapability = options.preparedHostModeCapability;
            const exactOwner = {
                agentId: deriveAgentPrincipalId(repoName, agentName),
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
                routeKey: aliasOverride || agentName,
                containerName,
            };
            if (!preparedHostModeCapability && requiresEdgeActivation) {
                preparedHostModeCapability = prepareHostModeCapabilityForInactiveGeneration(exactOwner, {
                    preparationLease: runtimeIdentity.preparationLease,
                });
            }
            assertHostModeGenerationCapability(exactOwner, { preparedCapability: preparedHostModeCapability });
            const sandboxOptions = {
                ...options,
                containerName,
                alias: aliasOverride,
                profileName: activeProfile,
                profileResolution,
                routerEndpoint,
                forceRecreate: Boolean(sandboxRecreateReason),
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
                preservePreparedRegistryRecord: preservePreparedRegistryRecord || requiresEdgeActivation,
                preparedHostModeCapability,
                runtimeAdmission: sandboxAdmission,
                manifestBytes: preflightManifestBytes,
                expectedPredecessor,
            };
            sandboxCleanupReceipt = advanceCandidateLifecycle(sandboxCleanupReceipt, {
                phase: 'create-attempted',
                creationAttempted: true,
                state: 'preserved-ambiguous',
            });
            const result = agentRuntime === 'bwrap'
                ? ensureBwrapService(agentName, manifest, agentPath, sandboxOptions)
                : ensureSeatbeltService(agentName, manifest, agentPath, sandboxOptions);
            sandboxLaunch = result;
            sandboxCleanupReceipt = advanceCandidateLifecycle(sandboxCleanupReceipt, {
                phase: 'candidate-observed',
                state: 'retryable-exact-id',
                candidateId: `${runtimeIdentity.instanceId}:${runtimeIdentity.enableGeneration}`,
                inspectionComplete: true,
                ownershipProof: {
                    processIdentity: true,
                    instanceId: runtimeIdentity.instanceId,
                    enableGeneration: runtimeIdentity.enableGeneration,
                },
            });
            return {
                ...result,
                runtimeNetwork: structuredClone(manifestNetwork),
                requiresEdgeActivation,
                cleanupReceipt: sandboxCleanupReceipt,
                ...(runtimeIdentity.preparationLease ? { preparationLease: runtimeIdentity.preparationLease } : {}),
                ...(sandboxStagedRegistryRecord
                    ? { stagedRegistryRecord: structuredClone(sandboxStagedRegistryRecord) }
                    : {}),
            };
        } catch (err) {
            // Identity staging failed before a sandbox candidate was launched.
            // Preserve the coordinator's provenance and never mistake the
            // predecessor's still-running process for a failed new candidate.
            if (getFailedRuntimeIdentityRotation(err)) throw err;
            const failure = createHostSandboxStartupError(agentName, agentRuntime, err);
            const identity = {
                instanceId: String(sandboxRuntimeIdentity?.instanceId || options.instanceId || existingRecord.instanceId || ''),
                enableGeneration: String(sandboxRuntimeIdentity?.enableGeneration || options.enableGeneration || existingRecord.enableGeneration || ''),
            };
            // Only a runtime this call launched is a candidate. A reused healthy
            // runtime, the registered predecessor and a runtime the manager
            // refused to touch are never stopped by a failure after them.
            const candidateIdentity = {
                instanceId: String(sandboxRuntimeIdentity?.instanceId || ''),
                enableGeneration: String(sandboxRuntimeIdentity?.enableGeneration || ''),
            };
            const cleanupOutcome = resolveSandboxFailureCleanup({
                containerName,
                launch: sandboxLaunch,
                error: err,
                candidateIdentity,
            });
            const exactCleanupPerformed = cleanupOutcome.performed;
            if (cleanupOutcome.detail) appendExactCleanupFailure(failure, cleanupOutcome.detail);
            // A receipt that never reached create-attempted describes a call that
            // launched nothing; there is no transition to record.
            if (sandboxCleanupReceipt?.creationAttempted === true) {
                try {
                    sandboxCleanupReceipt = advanceCandidateLifecycle(sandboxCleanupReceipt, exactCleanupPerformed
                        ? {
                            phase: 'readiness',
                            state: 'removed-proven',
                            inspectionComplete: true,
                            ownershipProof: { processIdentity: true, exactAbsenceProven: true },
                        }
                        : {
                            phase: 'readiness',
                            state: 'preserved-ambiguous',
                            ownershipProof: { processIdentity: false, exactAbsenceProven: false },
                        });
                } catch (receiptError) {
                    appendExactCleanupFailure(failure, `receipt transition: ${receiptError?.message || receiptError}`);
                }
            }
            throw attachRestartCandidate(failure, {
                containerName,
                runtimeNetwork: structuredClone(manifestNetwork),
                registryRecord: {
                    type: 'agent',
                    runtime: agentRuntime,
                    agentName,
                    repoName,
                    ...(aliasOverride ? { alias: aliasOverride } : {}),
                    ...identity,
                },
                requiresEdgeActivation: sandboxRequiresEdgeActivation,
                exactCleanupPerformed,
                ...(sandboxStagedRegistryRecord
                    ? { stagedRegistryRecord: structuredClone(sandboxStagedRegistryRecord) }
                    : {}),
                ...(sandboxCleanupReceipt ? { cleanupReceipt: sandboxCleanupReceipt } : {}),
                ...((sandboxRuntimeIdentity?.preparationLease || options.preparationLease)
                    ? { preparationLease: sandboxRuntimeIdentity?.preparationLease || options.preparationLease }
                    : {}),
            });
        }
    }

    const runtime = getRuntime();
    // Reuse this observation only for preliminary decisions under the lock.
    // Contract inspection and the launch transaction re-read exact identity,
    // running state, network membership and generated descriptor authority.
    const existingRuntimeAtEntry = containerExists(containerName);
    assertManifestEnvProfileCompleteness(manifest, profileConfig, { agentName, repoName, profileName: activeProfile });
    // LLM-runtime agents get their real image from the hardware-aware catalog in
    // startAgentContainer; tolerate an unresolved manifest container placeholder
    // here (this `image` is only a record fallback below).
    let image = '';
    try {
        image = resolveManifestImage(manifest, profileConfig, { agentName, repoName });
    } catch (err) {
        if (!isLlmRuntimeManifest(manifest, profileConfig)) throw err;
    }
    const runtimeRouterEnv = buildRuntimeRouterEnv(runtime, {
        routerEndpoint,
        networkMode: manifestNetwork.mode,
    });
    const runtimeNetworkPlan = buildRuntimeNetworkPlan(runtime, manifestNetwork);
    const computeContainerEnvHash = () => computeAgentEnvHash(manifest, profileConfig, {
        agentName, repoName, runtimeNetworkPlan, runtimeRouterEnv,
    });

    const { publishArgs: manifestPorts, portMappings } = parseManifestPorts(manifest, profileConfig);
    assertHostPortContract(runtimeNetworkPlan.mode, portMappings);
    const resolvedProfileEnv = buildEnvMap(manifest, profileConfig, {
        agentName,
        repoName,
        profileName: activeProfile,
        forRuntime: true,
    });
    const agentServerPort = resolveImplicitAgentServerPort(profileConfig, resolvedProfileEnv);
    const containerPortCandidates = portMappings
        .map((mapping) => mapping?.containerPort)
        .filter((port) => typeof port === 'number' && port > 0);
    if (shouldCreateImplicitAgentServerPublish(
        manifest,
        manifestPorts,
        runtimeNetworkPlan.mode,
        portMappings,
        agentServerPort,
    )) {
        containerPortCandidates.unshift(agentServerPort);
    }

    const { raw: explicitAgentCmd } = readManifestAgentCommand(manifest);
    const startCmd = readManifestStartCommand(manifest);
    const withParallelAgent = Boolean(startCmd && explicitAgentCmd);
    let recreateReason = targetedRestart ? 'targetedRestart' : (forceRecreate ? 'forceRecreate' : null);
    // Secret-free detail for the one replacement line printed below.
    let recreateDetail = targetedRestart ? '' : forceRecreateCause;
    const requestedEnableGeneration = String(options.enableGeneration || existingRecord.enableGeneration || randomUUID());
    const requestedInstanceId = String(options.instanceId || existingRecord.instanceId || '');
    if (existingRuntimeAtEntry && (!existingRecord.instanceId || !existingRecord.enableGeneration)) {
        recreateReason ||= 'missingRuntimeIdentity';
    }
    if (existingRuntimeAtEntry && (
        (options.instanceId && options.instanceId !== existingRecord.instanceId)
        || (options.enableGeneration && options.enableGeneration !== existingRecord.enableGeneration)
    )) {
        recreateReason ||= 'runtimeIdentityChanged';
    }

    if (existingRuntimeAtEntry && !runtimeNetworkPlan.requiresManagedNetwork) {
        const desired = computeContainerEnvHash();
        const current = getContainerLabel(containerName, 'ploinky.envhash');
        if (desired && desired !== current) {
            debugLog(`[ensureAgentService] ${agentName}: env hash changed (current=${current || '<none>'}, desired=${desired.slice(0, 12)}…), recreating container`);
            if (!recreateReason) recreateDetail = hashMismatchDetail('envHash', current, desired);
            recreateReason ||= 'envHashChanged';
        }
    }

    // The AgentLib selection lives outside the manifest and profile, so the env
    // hash cannot see a changed source. Compare it directly: a fingerprint
    // change must replace this container, not reuse it against old bytes.
    if (existingRuntimeAtEntry) {
        const agentLibProblem = agentLibReuseProblem(existingRecord, agentLibGrant('container'));
        if (agentLibProblem) {
            debugLog(`[ensureAgentService] ${agentName}: ${agentLibProblem}, recreating container`);
            if (!recreateReason) recreateDetail = shortenHashes(agentLibProblem);
            recreateReason ||= 'agentLibSelectionChanged';
        }
    }

    // Dependency trees are immutable store generations. A changed, missing,
    // unrecorded or corrupt admitted generation (or a new rebuild token) replaces
    // the runtime; the mounted tree is never mutated. This precedes every
    // reuse path below: host/none early return, validation-only managed
    // adoption and prepared-lease reuse.
    if (existingRuntimeAtEntry && !recreateReason) {
        const dependencyProblem = containerDependencyReuseProblem({
            agentName,
            manifest,
            profileConfig,
            record: launchRecord,
            runtime,
            image,
            containerName,
        });
        if (dependencyProblem) {
            debugLog(`[ensureAgentService] ${agentName}: ${dependencyProblem}, recreating container`);
            recreateReason ||= 'dependencyGenerationChanged';
        }
    }

    // Hardware limits: creation, adoption and reuse compare one admitted
    // descriptor's limits hash (empty without hardware placement).
    if (existingRuntimeAtEntry) {
        const limitsReason = limitsHashReuseReason(serviceAdmission.descriptor, getContainerLabel(containerName, LIMITS_HASH_LABEL));
        if (limitsReason) {
            debugLog(`[ensureAgentService] ${agentName}: hardware limits changed, recreating container`);
            if (!recreateReason) {
                recreateDetail = limitsHashDetail(serviceAdmission.descriptor, getContainerLabel(containerName, LIMITS_HASH_LABEL));
            }
            recreateReason ||= limitsReason;
        }
    }

    // LLM runtime: include architecture/catalog/digest/policy in reuse comparison.
    if (existingRuntimeAtEntry && isLlmRuntimeManifest(manifest, profileConfig)) {
        try {
            const llmReuseReason = serviceLlmReuseReason({
                runtime,
                manifest,
                profileConfig,
                agentName,
                alias: aliasOverride,
                containerName,
                envHash: computeContainerEnvHash(),
                serviceAdmission,
                serviceLlmAdmissionContext,
            });
            if (llmReuseReason) {
                debugLog(`[ensureAgentService] ${agentName}: LLM reuse hash changed, recreating container`);
                recreateReason ||= llmReuseReason;
            }
        } catch (err) {
            debugLog(`[ensureAgentService] ${agentName}: LLM reuse-hash check skipped: ${err?.message || err}`);
        }
    }

    // Ownership is independent of the selected transport. Host/none containers
    // still carry the workspace + contract labels, so inspect them before any
    // reuse, start, or replacement decision. Only creation/replacement for
    // default/bridge enters the managed-network transaction below.
    const networkLifecycle = createNetworkLifecycleAdapter({ runtime });
    let inspectedContainerId = null;
    let managedReconciliationPreparationLease = options.preparationLease;
    let adoptManagedRuntimeOnly = false;
    if (existingRuntimeAtEntry) {
        const contractInspection = networkLifecycle.inspectContainerContract(containerName, manifestNetwork, agentName, {
            instanceKey: effectiveInstanceKey(repoName, agentName, aliasOverride || ''),
            contractHash: networkContractHash(manifestNetwork),
            instanceId: existingRecord.instanceId,
            enableGeneration: existingRecord.enableGeneration,
            requireRuntimeIdentity: true,
        });
        if (contractInspection.state === 'foreign') {
            throw new Error(`refusing to replace foreign/unsupported exact-name container '${containerName}': managed agent identity labels do not match`);
        }
        inspectedContainerId = contractInspection.id;
        if (contractInspection.state === 'owned-drift') {
            const driftReason = contractInspection.reason === 'runtime-identity'
                ? 'runtimeIdentityDrift'
                : 'networkContractDrift';
            debugLog(`[ensureAgentService] ${agentName}: managed runtime contract drifted (${driftReason}); recreating container`);
            recreateReason ||= driftReason;
        } else if (!contractInspection.running) {
            // A stopped runtime is an instance replacement, not a process-resume
            // optimization. Its old identity is inactivated and rotated before
            // any host/none/managed process can start again.
            recreateReason ||= 'runtimeStopped';
        }
    }

    if (existingRuntimeAtEntry && !recreateReason) {
        debugLog(`[ensureAgentService] ${agentName}: container exists, checking if running...`);
        let canReuseExisting = true;
        const reuseInspection = networkLifecycle.inspectContainerContract(containerName, manifestNetwork, agentName, {
            instanceKey: effectiveInstanceKey(repoName, agentName, aliasOverride || ''),
            contractHash: networkContractHash(manifestNetwork),
            instanceId: existingRecord.instanceId,
            enableGeneration: existingRecord.enableGeneration,
            requireRuntimeIdentity: true,
        });
        if (reuseInspection.state === 'foreign') {
            throw new Error(`refusing to reuse foreign/unsupported exact-name container '${containerName}': managed agent identity labels do not match`);
        }
        if (reuseInspection.state !== 'exact' || !inspectedContainerId || reuseInspection.id !== inspectedContainerId) {
            canReuseExisting = false;
            recreateReason ||= 'runtimeChangedDuringInspection';
        } else if (!reuseInspection.running) {
            // Never resume a stopped container under its predecessor identity.
            // Re-enter the coordinated inactive-generation replacement path.
            canReuseExisting = false;
            recreateReason ||= 'runtimeStoppedAfterInspection';
        }
        if (canReuseExisting && runtimeNetworkPlan.requiresManagedNetwork) {
            // Healthy managed reuse is a validation-only adoption against the
            // exact active generation. It must neither create a preparation
            // lease nor move the public selector away from its active state.
            adoptManagedRuntimeOnly = !managedReconciliationPreparationLease;
            canReuseExisting = false;
        }
        if (canReuseExisting && !runtimeNetworkPlan.requiresManagedNetwork) {
            // Host/none skip semantic managed-network adoption. Verify their
            // actual HOME and project binds before taking the early reuse path,
            // including containers created with the former static HOME layout.
            const desiredProject = preservePreparedRegistryRecord && launchRecord.projectPath
                ? launchRecord.projectPath
                : getConfiguredProjectPath(agentName, repoName, aliasOverride);
            const desiredHomeLayout = resolveAgentHomeLayout({
                cwd: desiredProject,
                cwdMountTarget: (launchRecord.runMode || 'isolated') === 'isolated' ? '/root' : desiredProject,
                agentHomeDir: getAgentWorkDir(aliasOverride || agentName),
            });
            const inspection = spawnSync(runtime, ['inspect', reuseInspection.id], {
                encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'], timeout: 5_000,
            });
            let inspectedRecords;
            try { inspectedRecords = JSON.parse(inspection.stdout || ''); } catch (_) {}
            if (inspection.error || inspection.status !== 0 || !Array.isArray(inspectedRecords)
                || inspectedRecords.length !== 1
                || String(inspectedRecords[0]?.Id || inspectedRecords[0]?.ID || '') !== reuseInspection.id) {
                throw new Error(`cannot verify exact HOME layout for '${containerName}'; preserving existing runtime`);
            }
            if (!hasExactAgentHomeLayout(inspectedRecords[0], desiredHomeLayout)) {
                canReuseExisting = false;
                recreateReason ||= 'agentHomeLayoutChanged';
            } else if (!hasAdmittedDependencyMount(inspectedRecords[0], launchRecord)) {
                // The record is launch authority; the actual mount topology
                // must name the same immutable payload before early reuse.
                canReuseExisting = false;
                recreateReason ||= 'dependencyMountDrifted';
            }
            if (!canReuseExisting) debugLog(`[ensureAgentService] ${agentName}: host/none reuse rejected (${recreateReason})`);
        }
        if (canReuseExisting) {
            verifyReusableHardwareRuntime(serviceAdmission, {
                containerName, containerId: reuseInspection.id, runtime,
                network: manifestNetwork,
                record: { ...existingRecord, containerId: reuseInspection.id },
                key: hardwareInstanceKey, ref: `${repoName}/${agentName}`, alias: aliasOverride || null, mpsLaunch: options.mpsLaunch,
            });
            debugLog(`[ensureAgentService] ${agentName}: returning early (container exists)`);
            if (runtimeNetworkPlan.mode === 'host') {
                assertHostModeGenerationCapability({
                    agentId: deriveAgentPrincipalId(repoName, agentName),
                    instanceId: String(existingRecord.instanceId || ''),
                    enableGeneration: String(existingRecord.enableGeneration || ''),
                    routeKey: aliasOverride || agentName,
                    containerName,
                }, { preparedCapability: options.preparedHostModeCapability });
            }
            const hostPort = runtimeNetworkPlan.mode === 'host'
                ? (containerPortCandidates[0] || 0)
                : (containerPortCandidates.length
                    ? resolveHostPort(containerName, existingRecord, containerPortCandidates)
                    : 0);
            syncAgentMcpConfig(containerName, agentPath, agentName);
            const registryRecord = {
                ...existingRecord,
                runtime,
                containerId: reuseInspection.id,
            };
            return {
                containerName,
                containerId: reuseInspection.id,
                hostPort,
                createdByThisLaunch: false,
                registryRecord: structuredClone(registryRecord),
            };
        }
    }
    if (existingRuntimeAtEntry && !containerExists(containerName)) {
        recreateReason ||= 'runtimeDisappearedAfterInspection';
    }
    // Every replacement of an existing runtime says why, once, before the
    // predecessor is touched. A fresh create (nothing to replace) is silent.
    if (existingRuntimeAtEntry && recreateReason) {
        logRuntimeReplacement(`${repoName}/${agentName}`, formatReplacementReason(recreateReason, recreateDetail));
    }

    let additionalPorts = [];
    let additionalPortMappings = [];
    let allPortMappings = [...portMappings];

    if (shouldCreateImplicitAgentServerPublish(
        manifest,
        manifestPorts,
        runtimeNetworkPlan.mode,
        portMappings,
        agentServerPort,
    )) {
        const hostPort = Number(preferredHostPort || 0);
        const agentServerMapping = {
            containerPort: agentServerPort,
            hostPort,
            hostIp: '127.0.0.1',
            protocol: 'tcp',
        };
        additionalPorts = [`127.0.0.1:${hostPort || ''}:${agentServerPort}`];
        additionalPortMappings.push(agentServerMapping);
        allPortMappings = appendUniquePortMapping(allPortMappings, agentServerMapping);
    }

    const requiresEdgeActivation = !targetedRestart && (
        (existingRuntimeAtEntry && Boolean(recreateReason))
        || (!existingRuntimeAtEntry && existingRecord?.type === 'agent' && !preservePreparedRegistryRecord)
        || Boolean(managedReconciliationPreparationLease)
    );
    const replacementPolicy = {
        portMappings: allPortMappings,
        stageAlongsidePredecessor: options.stageAlongsidePredecessor === undefined
            ? runtimeNetworkPlan.requiresManagedNetwork
            : options.stageAlongsidePredecessor === true,
        preserveActiveAuthorization: options.preserveActiveAuthorization === undefined
            ? (options.stageAlongsidePredecessor === undefined
                ? runtimeNetworkPlan.requiresManagedNetwork
                : options.stageAlongsidePredecessor === true)
            : options.preserveActiveAuthorization === true,
    };
    const runtimeIdentity = resolveReplacementRuntimeIdentity({
        containerName,
        existingRecord,
        existingRuntime: existingRuntimeAtEntry,
        recreateReason,
        runtimeNetwork: manifestNetwork,
        predecessorContainerId: String(inspectedContainerId || existingRecord.containerId || ''),
        networkLifecycleCapability: options.networkLifecycleCapability,
        preservePreparedRegistryRecord,
        targetedRestart: Boolean(targetedRestart),
        requestedInstanceId,
        requestedEnableGeneration,
        ...replacementPolicy,
    }, { preparationLease: managedReconciliationPreparationLease });
    if (runtimeIdentity.candidateContainerName
        && runtimeIdentity.candidateContainerName !== containerName) {
        const replacementPredecessor = Object.freeze({
            containerName,
            containerId: String(inspectedContainerId || existingRecord.containerId || ''),
            runtimeNetwork: structuredClone(manifestNetwork),
            registryRecord: structuredClone({
                ...existingRecord,
                runtime,
                containerId: String(inspectedContainerId || existingRecord.containerId || ''),
            }),
        });
        try {
            return ensureAgentService(agentName, manifest, agentPath, {
                ...options,
                hardwareInstanceKey,
                containerName: runtimeIdentity.candidateContainerName,
                forceRecreate: true,
                preservePreparedRegistryRecord: true,
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
                preparationLease: runtimeIdentity.preparationLease,
                preparedRegistryRecord: runtimeIdentity.preparedRegistryRecord,
                replacementPredecessor,
            });
        } catch (error) {
            throw attachRestartCandidate(error, {
                containerName: runtimeIdentity.candidateContainerName,
                runtimeNetwork: structuredClone(manifestNetwork),
                registryRecord: structuredClone(runtimeIdentity.preparedRegistryRecord),
                stagedRegistryRecord: structuredClone(runtimeIdentity.preparedRegistryRecord),
                requiresEdgeActivation: true,
                preparationLease: runtimeIdentity.preparationLease,
                replacementPredecessor,
                exactCleanupPerformed: error?.ploinkyRestartCandidate?.exactCleanupPerformed === true,
            });
        }
    }
    let started = null;
    let stagedRegistryRecord = null;
    try {
    stagedRegistryRecord = capturePreparedRegistryRecord(containerName, runtimeIdentity);
    const preserveRuntimeRegistryRecord = Boolean(targetedRestart)
        || preservePreparedRegistryRecord
        || Boolean(runtimeIdentity.preparationLease);
    let preparedHostModeCapability = options.preparedHostModeCapability;
    if (runtimeNetworkPlan.mode === 'host') {
        const exactOwner = {
            agentId: deriveAgentPrincipalId(repoName, agentName),
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            routeKey: aliasOverride || agentName,
            containerName,
        };
        if (!preparedHostModeCapability && requiresEdgeActivation) {
            preparedHostModeCapability = prepareHostModeCapabilityForInactiveGeneration(exactOwner, {
                preparationLease: runtimeIdentity.preparationLease,
            });
        }
        assertHostModeGenerationCapability(exactOwner, { preparedCapability: preparedHostModeCapability });
    }

    if (targetedRestart) {
        options.beforeHardwareMutation?.();
        const drainOptions = {
            runtime,
            reason: `coordinated-targeted-restart:${containerName}`,
            acknowledgement: targetedRestart.acknowledgement,
            affectedSelectors: targetedRestart.affectedSelectors,
            assertSelectorsInactive: targetedRestart.assertSelectorsInactive,
            retireControlSocket: retireRuntimeRelaySocket,
            ...(targetedRestart.timeoutMs === undefined ? {} : { timeoutMs: targetedRestart.timeoutMs }),
        };
        if (runtimeNetworkPlan.requiresManagedNetwork) {
            // The managed transaction preserves a stopped predecessor for
            // diagnostics/rollback, but never restarts it after this drain.
            drainTargetedContainer(containerName, drainOptions);
        } else {
            drainAndRemoveTargetedContainer(containerName, drainOptions);
        }
        clearLivenessState(containerName);
    }

        started = startAgentContainer(agentName, manifest, agentPath, {
            publish: additionalPorts,
            publishMappings: additionalPortMappings,
            containerName,
            hardwareInstanceKey,
            alias: aliasOverride,
            profileName: activeProfile,
            profileResolution,
            routerEndpoint,
            networkLockWaitMs,
            runtimeIdentity,
            instanceId: runtimeIdentity.instanceId,
            enableGeneration: runtimeIdentity.enableGeneration,
            preparedHostModeCapability,
            preserveRegistryRecord: preserveRuntimeRegistryRecord,
            reuseStagedMounts: existingRuntimeAtEntry && !recreateReason,
            networkLifecycleCapability: options.networkLifecycleCapability,
            runtimeAdmission: options.runtimeAdmission || serviceAdmission,
            beforeHardwareMutation: options.beforeHardwareMutation,
            mpsLaunch: options.mpsLaunch,
            preparedRegistryRecord: launchRecord,
            preservePreparedRegistryRecord,
            preparationLease: options.preparationLease,
            adoptManagedRuntimeOnly,
            ...(existingRuntimeAtEntry && recreateReason && !targetedRestart && !preservePreparedRegistryRecord
                ? { predecessorRegistryRecord: structuredClone(existingRecord) }
                : {}),
            [SERVICE_NETWORK_LIFECYCLE]: {
                runtime,
                capability: options.networkLifecycleCapability,
                adapter: networkLifecycle,
            },
        });
    if (adoptManagedRuntimeOnly) {
        if (started?.createdByThisLaunch !== false) {
            throw new Error(`managed runtime adoption for '${containerName}' unexpectedly created a candidate`);
        }
        const hostPort = containerPortCandidates.length
            ? resolveHostPort(containerName, existingRecord, containerPortCandidates)
            : 0;
        return {
            ...started,
            hostPort,
            createdByThisLaunch: false,
            requiresEdgeActivation: false,
            registryRecord: structuredClone({
                ...existingRecord,
                runtime,
                containerId: started.containerId,
            }),
        };
    }
    allPortMappings = resolvePublishedPortMappings(containerName, allPortMappings);
    const agentCodePath = getAgentCodePath(agentName);
    const agentSkillsPath = getAgentSkillsPath(agentName);
    const profileEnv = normalizeProfileEnv(profileConfig?.env);
    const { codeReadOnly, skillsReadOnly } = getProfileMountModes(activeProfile, runtime, profileConfig || {});

    const agents = loadAgentsMap();
    const startedRecord = started?.registryRecord || agents[containerName] || {};
    const declaredEnvNames3 = [
        ...getManifestEnvNames(manifest, profileConfig, { forRuntime: true }),
        ...getExposedNames(manifest, profileConfig, { forRuntime: true }),
        ...Object.keys(profileEnv)
    ];
    let projPath = preservePreparedRegistryRecord && launchRecord.projectPath
        ? launchRecord.projectPath
        : getConfiguredProjectPath(agentName, repoName, aliasOverride);
    if (!projPath) {
        projPath = launchRecord.projectPath;
    }
    const finalInstanceName = aliasOverride || launchRecord.alias || agentName;
    const finalIsolatedHome = (launchRecord.runMode || 'isolated') === 'isolated';
    const finalAgentWorkDir = getAgentWorkDir(finalInstanceName);
    const finalWorkTarget = finalIsolatedHome ? '/root' : projPath;
    const finalHomeLayout = resolveAgentHomeLayout({
        cwd: projPath,
        cwdMountTarget: finalWorkTarget,
        agentHomeDir: finalAgentWorkDir,
    });
    const hasStartedBinds = Array.isArray(startedRecord.config?.binds) && startedRecord.config.binds.length > 0;
    const startedEnvNames = Array.isArray(startedRecord.config?.env)
        ? startedRecord.config.env.map((entry) => String(entry?.name || '').trim()).filter(Boolean)
        : [];
    if (!hasStartedBinds && runtime === 'podman') {
        // Podman relies on the staged code/Agent dirs and the per-target
        // self-mounts created in startAgentContainer. The literal fallback
        // below would record unstaged paths and miss the dependency cache
        // self-mount; refuse rather than silently writing a broken record.
        throw new Error(
            `[ensureAgentService] ${agentName}: missing podman bind record after startAgentContainer; refusing to write a fallback bind list.`
        );
    }
    if (!startedRecord.agentLib) {
        throw new Error(
            `[ensureAgentService] ${agentName}: runtime admission returned no AgentLib generation record.`
        );
    }
    agents[containerName] = {
        agentName,
        repoName,
        containerImage: startedRecord.containerImage || image,
        ...(startedRecord.manifestImage ? { manifestImage: startedRecord.manifestImage } : {}),
        ...(startedRecord.llmRuntime ? { llmRuntime: startedRecord.llmRuntime } : {}),
        createdAt: launchRecord.createdAt || new Date().toISOString(),
        projectPath: projPath,
        runMode: launchRecord.runMode,
        develRepo: launchRecord.develRepo,
        profile: activeProfile,
        type: 'agent',
        runtime,
        containerId: started.containerId,
        instanceId: runtimeIdentity.instanceId,
        enableGeneration: runtimeIdentity.enableGeneration,
        agentLib: structuredClone(startedRecord.agentLib),
        // The admitted dependency generation is launch authority for every
        // later reuse decision; losing it would force a replacement per start.
        ...(startedRecord.dependencies ? { dependencies: structuredClone(startedRecord.dependencies) } : {}),
        config: {
            binds: hasStartedBinds ? startedRecord.config.binds : [
                { source: AGENT_LIB_PATH, target: '/Agent', ro: true },
                { source: agentCodePath, target: '/code', ro: codeReadOnly },
                ...(fs.existsSync(agentSkillsPath) ? [{ source: agentSkillsPath, target: '/code/skills', ro: skillsReadOnly }] : []),
                ...finalHomeLayout.binds,
            ],
            env: Array.from(new Set([...declaredEnvNames3, ...startedEnvNames])).map((name) => ({ name })),
            ports: runtimeNetworkPlan.mode === 'host' || runtimeNetworkPlan.mode === 'none' ? [] : allPortMappings,
        }
    };
    if (launchRecord.auth) {
        agents[containerName].auth = launchRecord.auth;
    }
    if (aliasOverride) {
        agents[containerName].alias = aliasOverride;
    }
    if (!preserveRuntimeRegistryRecord) saveAgentsMap(agents);

    syncAgentMcpConfig(containerName, agentPath, finalInstanceName, { workDir: finalAgentWorkDir });
    if (!preserveRuntimeRegistryRecord && started?.durableCandidate) {
        retireRuntimeCandidate(started.durableCandidate);
    }
    const returnPort = runtimeNetworkPlan.mode === 'host'
        ? (allPortMappings.find((p) => p.containerPort === agentServerPort)?.containerPort
            || allPortMappings[0]?.containerPort
            || 0)
        : allPortMappings.find((p) => p.containerPort === agentServerPort)?.hostPort
        || allPortMappings[0]?.hostPort
        || 0;
        return {
            containerName,
            containerId: started?.containerId,
            runtimeNetwork: structuredClone(manifestNetwork),
            hostPort: returnPort,
            createdByThisLaunch: started?.createdByThisLaunch !== false,
            registryRecord: structuredClone(agents[containerName]),
            cleanupReceipt: started?.cleanupReceipt,
            durableCandidate: started?.durableCandidate,
            requiresEdgeActivation,
            ...(runtimeIdentity.preparationLease ? { preparationLease: runtimeIdentity.preparationLease } : {}),
            ...(stagedRegistryRecord
                ? { stagedRegistryRecord: structuredClone(stagedRegistryRecord) }
                : {}),
            ...(options.replacementPredecessor
                ? { replacementPredecessor: structuredClone(options.replacementPredecessor) }
                : {}),
        };
    } catch (error) {
        if (error?.code === 'PLOINKY_SEMANTIC_ADOPTION_MISMATCH'
            && runtimeNetworkPlan.requiresManagedNetwork
            && (!runtimeIdentity.preparationLease
                || runtimeIdentity.preparationLease.mode === 'additive')
            && options.semanticAdoptionRetry !== true) {
            if (runtimeIdentity.preparationLease) {
                abortEdgeRoutingPreparation(runtimeIdentity.preparationLease, {
                    reason: `semantic-adoption-mismatch:${containerName}`,
                });
            }
            const rotated = coordinateReplacementRuntimeIdentity({
                containerName,
                existingRecord,
                reason: 'semanticDescriptorMismatch',
                runtimeNetwork: manifestNetwork,
                predecessorContainerId: String(inspectedContainerId || existingRecord.containerId || ''),
                networkLifecycleCapability: options.networkLifecycleCapability,
                ...replacementPolicy,
            });
            return ensureAgentService(agentName, manifest, agentPath, {
                ...options,
                hardwareInstanceKey,
                forceRecreate: true,
                containerName: rotated.candidateContainerName,
                preservePreparedRegistryRecord: true,
                instanceId: rotated.instanceId,
                enableGeneration: rotated.enableGeneration,
                preparationLease: rotated.preparationLease,
                preparedRegistryRecord: rotated.preparedRegistryRecord,
                replacementPredecessor: rotated.candidateContainerName !== containerName ? {
                    containerName,
                    containerId: String(inspectedContainerId || existingRecord.containerId || ''),
                    runtimeNetwork: structuredClone(manifestNetwork),
                    registryRecord: structuredClone({
                        ...existingRecord,
                        runtime,
                        containerId: String(inspectedContainerId || existingRecord.containerId || ''),
                    }),
                } : undefined,
                semanticAdoptionRetry: true,
            });
        }
        const {
            exactCleanupPerformed,
            cleanupReceipt,
            candidateId,
            candidateRecord,
            durableCandidate,
        } = cleanupFailedServiceCandidate(error, {
            started,
            containerName,
            network: manifestNetwork,
            fallbackRecord: {
                type: 'agent',
                agentName,
                repoName,
                ...(aliasOverride ? { alias: aliasOverride } : {}),
                instanceId: runtimeIdentity.instanceId,
                enableGeneration: runtimeIdentity.enableGeneration,
            },
        });
        throw attachRestartCandidate(error, {
            containerName,
            durableCandidate,
            ...(candidateId ? { containerId: candidateId } : {}),
            runtimeNetwork: structuredClone(manifestNetwork),
            registryRecord: structuredClone(candidateRecord),
            requiresEdgeActivation,
            exactCleanupPerformed,
            ...(stagedRegistryRecord
                ? { stagedRegistryRecord: structuredClone(stagedRegistryRecord) }
                : {}),
            ...(cleanupReceipt ? { cleanupReceipt } : {}),
            ...(runtimeIdentity.preparationLease ? { preparationLease: runtimeIdentity.preparationLease } : {}),
        });
    }
}

function removeExactGenerationCandidate({
    containerName,
    containerId,
    network,
    record,
} = {}) {
    const cleanup = createNetworkLifecycleAdapter({ runtime: getRuntime() }).removeExactContainer(
        containerName,
        network,
        record.agentName,
        {
            expectedContainerId: containerId,
            instanceKey: effectiveInstanceKey(record.repoName, record.agentName, record.alias || ''),
            contractHash: networkContractHash(network),
            instanceId: record.instanceId,
            enableGeneration: record.enableGeneration,
        },
    );
    if (cleanup.removed !== true && cleanup.state !== 'absent') {
        throw new Error(`exact failed candidate was preserved (${cleanup.reason || cleanup.state || 'ownership mismatch'})`);
    }
    clearLivenessState(containerName);
    return cleanup;
}

export function retireExactAgentRuntimePredecessor(predecessor, {
    networkLifecycleCapability,
} = {}) {
    assertNetworkLifecycleCapability(networkLifecycleCapability);
    const containerName = String(predecessor?.containerName || '').trim();
    const containerId = String(predecessor?.containerId || '').trim();
    const record = predecessor?.registryRecord;
    if (!containerName || !containerId || !predecessor?.runtimeNetwork
        || !record || record.type !== 'agent'
        || String(record.containerId || '') !== containerId
        || !String(record.instanceId || '').trim()
        || !String(record.enableGeneration || '').trim()) {
        throw new Error('exact predecessor retirement requires its name, immutable ID, network, and registry identity');
    }
    return removeExactGenerationCandidate({
        containerName,
        containerId,
        network: predecessor.runtimeNetwork,
        record,
    });
}

/**
 * Whether the runtime a failed sandbox start may have left behind is proven
 * gone. Only a runtime this call launched is ever stopped.
 *  - The manager returned (`launch`): a reused runtime is not a candidate; a
 *    runtime this call launched is stopped by its exact tuple.
 *  - The manager threw: it removed what it launched and flags a failure
 *    (`exactCleanupFailed`). Without that flag the exact tuple is observed
 *    again: only a verified absence (or a runtime that is not this call's, a
 *    foreign tuple or a reused exact one) counts as clean. `unknown` never does.
 */
export function resolveSandboxFailureCleanup({
    containerName,
    launch,
    error,
    candidateIdentity,
    observeImpl = observeSandboxRuntime,
    stopImpl = stopExactSandboxProcess,
} = {}) {
    const hasCandidate = Boolean(candidateIdentity?.instanceId && candidateIdentity?.enableGeneration);
    try {
        if (launch === null || launch === undefined) {
            if (error?.exactCleanupFailed === true) return { performed: false, detail: '' };
            if (!hasCandidate) return { performed: true, detail: '' };
            const observed = observeImpl(containerName, { expectedIdentity: candidateIdentity });
            return observed.state === 'unknown'
                ? { performed: false, detail: `candidate ownership could not be verified (${observed.reason})` }
                : { performed: true, detail: '' };
        }
        if (launch.createdByThisLaunch !== true || !hasCandidate) return { performed: true, detail: '' };
        // Only the exact candidate tuple is ever stopped. A foreign occupant
        // proves the candidate absent and stays untouched; an unknown slot
        // proves nothing and is never cleanup.
        const observed = observeImpl(containerName, { expectedIdentity: candidateIdentity });
        if (observed.state === 'absent' || observed.state === 'live-foreign') return { performed: true, detail: '' };
        if (observed.state === 'live-exact') {
            const stopped = stopImpl(containerName, candidateIdentity);
            return { performed: stopped.state === 'absent' || stopped.state === 'stopped', detail: '' };
        }
        return { performed: false, detail: `candidate ownership could not be verified (${observed.reason})` };
    } catch (cleanupError) {
        return { performed: false, detail: String(cleanupError?.message || cleanupError) };
    }
}

function sandboxRemovalAmbiguityError(containerName, detail) {
    const error = new Error(`sandbox runtime '${containerName}': ${detail}`);
    error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
    return error;
}

function sandboxOwnershipUnknownError(containerName, observed) {
    const error = new Error(
        `sandbox runtime '${containerName}' ownership could not be verified (${observed.reason}); no signal was sent and its PID record was kept`,
    );
    error.code = observed.reason === 'invalid-record'
        ? 'PLOINKY_SANDBOX_PID_RECORD_INVALID'
        : 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
    return error;
}

/**
 * Removes the exact native (Seatbelt or bwrap) predecessor a registry record
 * names. The record's own runtime selects this path; the successor's backend
 * never does. Returns { removed, state, reason } and never throws for an
 * ownership outcome:
 *   absent   no live process owns this tuple (no record, a stale or zombie
 *            record, or a live process under another tuple: the slot is
 *            exclusive, so that tuple's owner is not this predecessor)
 *   removed  the exact process was observed gone after termination
 *   unknown  the PID record or process could not be verified; nothing was sent
 *   refused / failed  the exact process was not stopped
 * `process` is the pid/start identity captured when the receipt was written.
 * When the PID record still carries the predecessor tuple it must equal it.
 */
export function removeExactSandboxPredecessor(containerName, predecessorRecord, {
    process: capturedProcess = predecessorRecord?.process,
    observeImpl = observeSandboxRuntime,
    stopImpl = stopExactSandboxProcess,
    timeout = 5000,
} = {}) {
    const name = String(containerName || '').trim();
    const record = predecessorRecord;
    if (!name || !record || record.type !== 'agent' || !isSandboxRuntime(record.runtime)
        || !String(record.instanceId || '').trim() || !String(record.enableGeneration || '').trim()) {
        throw new Error('exact sandbox predecessor removal requires its runtime key, native runtime and immutable tuple');
    }
    const identity = {
        instanceId: String(record.instanceId),
        enableGeneration: String(record.enableGeneration),
    };
    const observed = observeImpl(name, { expectedIdentity: identity });
    if (observed.state === 'unknown') {
        return { removed: false, state: 'unknown', reason: observed.reason };
    }
    const carriesTuple = observed.record
        && observed.record.instanceId === identity.instanceId
        && observed.record.enableGeneration === identity.enableGeneration;
    if (carriesTuple && capturedProcess
        && (observed.record.pid !== capturedProcess.pid
            || observed.record.processIdentity !== capturedProcess.processIdentity)) {
        return { removed: false, state: 'unknown', reason: 'captured-process-mismatch' };
    }
    if (observed.state === 'absent') {
        // The predecessor's own stale record (exited, zombie, reused PID) goes
        // by compare-and-delete; a record of another tuple is never touched.
        if (carriesTuple) clearBwrapPidIfExact(observed.record);
        return { removed: false, state: 'absent', reason: observed.reason };
    }
    if (observed.state === 'live-foreign') {
        return { removed: false, state: 'absent', reason: 'slot-held-by-another-tuple' };
    }
    const stopped = stopImpl(name, identity, { timeout });
    if (stopped.state === 'stopped') return { removed: true, state: 'removed', reason: stopped.reason };
    if (stopped.state === 'absent') return { removed: false, state: 'absent', reason: stopped.reason };
    return { removed: false, state: stopped.state, reason: stopped.reason };
}

export function cleanupExactAgentRuntimeCandidate(candidate) {
    const containerName = String(candidate?.containerName || '').trim();
    const record = candidate?.registryRecord;
    if (!containerName || !record || record.type !== 'agent'
        || !String(record.instanceId || '').trim()
        || !String(record.enableGeneration || '').trim()) {
        throw new Error('exact runtime candidate cleanup requires its name and immutable registry identity');
    }
    const runtimeKind = record.runtime === 'bwrap' || record.runtime === 'seatbelt'
        ? record.runtime
        : 'container';
    const cleanupReceipt = consumeCandidateCleanupReceipt(candidate?.cleanupReceipt, {
        runtimeKind,
        candidateName: containerName,
        runtimeIdentity: {
            instanceId: String(record.instanceId),
            enableGeneration: String(record.enableGeneration),
        },
        ...(runtimeKind === 'container' && candidate?.containerId
            ? { candidateId: String(candidate.containerId) }
            : {}),
    });
    if (cleanupReceipt.state === 'absent-proven' || cleanupReceipt.state === 'removed-proven'
        || cleanupReceipt.state === 'not-created-proven') {
        if (candidate?.durableCandidate) retireRuntimeCandidate(candidate.durableCandidate);
        return { removed: false, state: cleanupReceipt.state };
    }
    if (cleanupReceipt.state !== 'retryable-exact-id' || cleanupReceipt.inspectionComplete !== true) {
        const error = new Error('exact runtime candidate ownership is ambiguous; preserving it for operator reconciliation');
        error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
        throw error;
    }
    if (record.runtime === 'bwrap' || record.runtime === 'seatbelt') {
        const outcome = removeExactSandboxPredecessor(containerName, record);
        if (outcome.state === 'absent') {
            // Nothing owned by this tuple is live. A different tuple holding
            // the slot is its owner's, and is left exactly as found.
            return { removed: false, state: 'absent' };
        }
        if (outcome.state !== 'removed') {
            throw sandboxRemovalAmbiguityError(
                containerName,
                `exact sandbox candidate remained live or unverified after cleanup (${outcome.state}: ${outcome.reason})`,
            );
        }
        clearLivenessState(containerName);
        return { removed: true, state: 'removed' };
    }
    const containerId = String(candidate?.containerId || '').trim();
    if (!containerId || !candidate?.runtimeNetwork) {
        throw new Error('exact container candidate cleanup requires its immutable ID and runtime network');
    }
    const cleanup = removeExactGenerationCandidate({
        containerName,
        containerId,
        network: candidate.runtimeNetwork,
        record,
    });
    if (candidate?.durableCandidate) retireRuntimeCandidate(candidate.durableCandidate);
    return cleanup;
}

function appendExactCleanupFailure(error, detail) {
    if (error && typeof error === 'object') {
        error.message = `${error.message}; exact candidate cleanup failed: ${detail}`;
        // Also recorded structurally, so a contained hardware refusal can
        // never hide a candidate that was left behind.
        const prior = Array.isArray(error.exactCleanupFailures) ? error.exactCleanupFailures : [];
        Object.defineProperty(error, 'exactCleanupFailures', {
            configurable: true,
            enumerable: false,
            writable: true,
            value: [...prior, String(detail)],
        });
    }
}

/**
 * A failed exact-candidate cleanup recorded on a launch error (or its cause
 * chain): the details and the candidate left behind, or null.
 */
export function exactCleanupFailureOf(error) {
    let current = error;
    for (let depth = 0; current && typeof current === 'object' && depth < 8; depth += 1) {
        if (Array.isArray(current.exactCleanupFailures) && current.exactCleanupFailures.length) {
            const candidate = current.ploinkyRestartCandidate || {};
            return Object.freeze({
                details: [...current.exactCleanupFailures],
                containerName: String(candidate.containerName || ''),
                containerId: String(candidate.containerId || ''),
            });
        }
        current = current.cause;
    }
    return null;
}

/**
 * ensureAgentService's cleanup of a failed launch: any candidate the launch
 * created and did not remove itself (a post-launch refusal of a managed
 * network candidate, which startAgentContainer leaves to this caller) is
 * removed through its exact ownership checks, and its durable record is
 * retired. A failed removal is appended to the error, never dropped.
 */
export function cleanupFailedServiceCandidate(error, {
    started = null,
    containerName,
    network,
    fallbackRecord,
    removeCandidate = removeExactGenerationCandidate,
    retireCandidate = retireRuntimeCandidate,
} = {}) {
    let exactCleanupPerformed = error?.ploinkyRestartCandidate?.exactCleanupPerformed === true;
    const cleanupReceipt = started?.cleanupReceipt
        || error?.ploinkyRestartCandidate?.cleanupReceipt;
    const candidateId = String(started?.containerId || error?.ploinkyRestartCandidate?.containerId || '');
    const candidateRecord = started?.registryRecord || error?.ploinkyRestartCandidate?.registryRecord || fallbackRecord;
    if (!exactCleanupPerformed && candidateId) {
        try {
            const cleanup = removeCandidate({
                containerName,
                containerId: candidateId,
                network,
                record: candidateRecord,
            });
            exactCleanupPerformed = cleanup.removed === true || cleanup.state === 'absent';
        } catch (cleanupError) {
            appendExactCleanupFailure(error, cleanupError?.message || cleanupError);
        }
    }
    const durableCandidate = started?.durableCandidate || error?.ploinkyRestartCandidate?.durableCandidate;
    if (exactCleanupPerformed && durableCandidate) {
        try { retireCandidate(durableCandidate); } catch (cleanupError) {
            appendExactCleanupFailure(error, cleanupError.message);
        }
    }
    return { exactCleanupPerformed, cleanupReceipt, candidateId, candidateRecord, durableCandidate };
}

function restartGenerationCapabilityRuntime({
    generation,
    owner,
    affectedSelectors,
    assertSelectorsInactive,
    preparedHostModeCapability,
    networkLifecycleCapability,
} = {}, {
    ensureService = ensureAgentService,
    isRunning = isContainerRunning,
    resolveProfile = resolveManifestRuntimeProfile,
    resolveReadinessProtocol = resolveAgentReadinessProtocol,
    runScriptReadiness = runContainerScriptReadiness,
    removeCandidate = removeExactGenerationCandidate,
    assertLifecycleCapability = assertNetworkLifecycleCapability,
} = {}) {
    if (!generation || !owner || !preparedHostModeCapability) {
        throw new Error('coordinated capability-runtime restart requires an immutable generation, owner, and prepared capability');
    }
    assertLifecycleCapability(networkLifecycleCapability);
    const exactOwner = (generation.compiled?.security?.hostNetworkCapabilities || []).find((entry) => (
        entry.agentId === owner.agentId
        && entry.instanceId === owner.instanceId
        && entry.enableGeneration === owner.enableGeneration
        && entry.routeKey === owner.routeKey
        && entry.containerName === owner.containerName
    ));
    if (!exactOwner) {
        throw new Error('coordinated capability-runtime restart owner is not present in the immutable generation');
    }
    const route = generation.routing?.routes?.[owner.routeKey];
    const manifest = generation.manifests?.[owner.routeKey];
    const record = generation.agents?.[owner.containerName];
    if (!route || !manifest || !record || record.type !== 'agent'
        || String(route.container || '') !== owner.containerName
        || `agent:${record.repoName}/${record.agentName}` !== owner.agentId
        || String(record.instanceId || '') !== owner.instanceId
        || String(record.enableGeneration || '') !== owner.enableGeneration) {
        throw new Error('coordinated capability-runtime restart could not resolve one exact captured runtime record');
    }
    const agentPath = String(route.hostPath || '').trim();
    if (!agentPath) throw new Error('coordinated capability-runtime restart owner has no captured manifest path');
    const profileResolution = resolveProfile(manifest, {
        agentName: `${record.repoName}/${record.agentName}`,
        profileName: record.profile || undefined,
        path: `manifest(${record.repoName}/${record.agentName})`,
    });
    if (profileResolution.network.mode !== 'host') {
        throw new Error('media capability runtime must resolve to exact host network mode');
    }
    const result = ensureService(record.agentName, manifest, agentPath, {
        containerName: owner.containerName,
        alias: record.alias || undefined,
        profileName: profileResolution.resolvedProfileName,
        profileResolution,
        routerEndpoint: buildRouterEndpoint('host', INITIAL_ROUTER_PORT),
        forceRecreate: true,
        instanceId: owner.instanceId,
        enableGeneration: owner.enableGeneration,
        preparedHostModeCapability,
        targetedRestart: {
            acknowledgement: TARGETED_DRAIN_ACKNOWLEDGEMENT,
            affectedSelectors,
            assertSelectorsInactive,
        },
        networkLifecycleCapability,
    });
    try {
        if (result?.containerName !== owner.containerName
            || !String(result?.containerId || '')
            || !isRunning(owner.containerName)) {
            throw new Error(`coordinated capability-runtime restart did not start exact container '${owner.containerName}' with an immutable ID`);
        }
        const readinessProtocol = resolveReadinessProtocol(manifest);
        if (readinessProtocol !== 'script') {
            throw new Error('media capability runtime requires an exact semantic script readiness probe before generation activation');
        }
        const readiness = runScriptReadiness(record.agentName, owner.containerName, manifest?.health?.readiness);
        if (readiness && typeof readiness.then === 'function') {
            throw new Error('media capability runtime readiness must complete synchronously before selector commit');
        }
        if (readiness?.status !== 'success') {
            const detail = readiness?.detail ? `, output='${readiness.detail}'` : '';
            throw new Error(`media capability runtime semantic readiness failed (${readiness?.reason || 'unknown failure'}${detail})`);
        }
    } catch (error) {
        if (result?.containerName === owner.containerName && String(result?.containerId || '')) {
            try {
                removeCandidate({
                    containerName: owner.containerName,
                    containerId: result.containerId,
                    network: profileResolution.network,
                    record,
                });
            } catch (cleanupError) {
                appendExactCleanupFailure(error, cleanupError?.message || cleanupError);
            }
        } else {
            appendExactCleanupFailure(error, 'candidate receipt did not contain the expected name and immutable ID');
        }
        throw error;
    }
    return result;
}

export function isGenerationCapabilityRuntimeEffective({
    generation,
    owner,
} = {}, {
    exists = containerExists,
    isRunning = isContainerRunning,
    inspectContainerContract,
} = {}) {
    if (!generation || !owner) return false;
    const exactOwner = (generation.compiled?.security?.hostNetworkCapabilities || []).find((entry) => (
        entry.agentId === owner.agentId
        && entry.instanceId === owner.instanceId
        && entry.enableGeneration === owner.enableGeneration
        && entry.routeKey === owner.routeKey
        && entry.containerName === owner.containerName
    ));
    if (!exactOwner) return false;
    const route = generation.routing?.routes?.[owner.routeKey];
    const manifest = generation.manifests?.[owner.routeKey];
    const record = generation.agents?.[owner.containerName];
    if (!route || !manifest || !record || record.type !== 'agent'
        || String(route.container || '') !== owner.containerName
        || `agent:${record.repoName}/${record.agentName}` !== owner.agentId
        || String(record.instanceId || '') !== owner.instanceId
        || String(record.enableGeneration || '') !== owner.enableGeneration) {
        return false;
    }
    const profileResolution = resolveManifestRuntimeProfile(manifest, {
        agentName: `${record.repoName}/${record.agentName}`,
        profileName: record.profile || undefined,
        path: `manifest(${record.repoName}/${record.agentName})`,
    });
    if (profileResolution.network.mode !== 'host'
        || !exists(owner.containerName)
        || !isRunning(owner.containerName)) {
        return false;
    }
    const inspect = inspectContainerContract || createNetworkLifecycleAdapter({ runtime: getRuntime() })
        .inspectContainerContract;
    const inspection = inspect(owner.containerName, profileResolution.network, record.agentName, {
        instanceKey: effectiveInstanceKey(record.repoName, record.agentName, record.alias || ''),
        contractHash: networkContractHash(profileResolution.network),
        instanceId: owner.instanceId,
        enableGeneration: owner.enableGeneration,
        requireRuntimeIdentity: true,
    });
    return inspection?.state === 'exact';
}

export {
    assertPodmanCodeMountAllowed,
    appendControllerStateGuards,
    appendExactManagedBindMount,
    appendUniquePortMapping,
    buildPersistentAgentRunArgs,
    buildBoxPodmanHostArgs,
    buildDefaultPodmanNetworkArgs,
    buildPodmanStagedTargetMounts,
    buildManagedControlEnv,
    buildRuntimeNetworkPlan,
    buildRuntimeRouterEnv,
    codeRelativeMountPath,
    computeAgentEnvHash,
    collectManifestVolumeEntries,
    ensureAgentService,
    ensureManifestVolumeHostPath,
    ensurePodmanStagedCodeDir,
    ensurePodmanStagedAgentLibDir,
    resolveReusablePodmanStagedMounts,
    expectedBindMountsFromArgs,
    hasExactManagedEnv,
    hasExactManagedMountContract,
    inspectImageEntrypoint,
    manifestUsesHealthProbeBroker,
    mergeNodeOptions,
    manifestVolumeMountSuffix,
    podmanManifestVolumeMountSuffix,
    podmanMountSuffix,
    resolveDependencyCachePreparation,
    resolveHostPort,
    resolveHostPortFromRecord,
    resolveHostPortFromRuntime,
    resolveImplicitAgentServerPort,
    resolvePublishedPortMappings,
    containerDependencyReuseProblem,
    hasAdmittedDependencyMount,
    admittedRuntimeDependencyProblem,
    selectPredecessorRemovalRecord,
    resolveAgentHomeLayout,
    restartGenerationCapabilityRuntime,
    replaceRuntimeRouterEnvFlags,
    shouldCreateImplicitAgentServerPublish,
    startAgentContainer,
    stripReservedAndRestoreRuntimeRouterEnvFlags,
};
