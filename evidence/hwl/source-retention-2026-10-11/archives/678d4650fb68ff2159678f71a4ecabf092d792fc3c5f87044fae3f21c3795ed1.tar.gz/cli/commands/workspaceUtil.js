import { resolveAgentRepositoryName, resolveAgentRepositoryPath } from '../utils/agentRepositorySource.mjs';
import fs from 'fs';
import { CLI_OUTPUT_BOUNDARY } from '../server/webchat/startupOutput.js';
import path from 'path';
import net from 'net';
import { randomUUID } from 'node:crypto';
import { spawn, execSync } from 'child_process';
import { fileURLToPath } from 'url';
import * as utils from '../utils/utils.js';
import * as agentsSvc from '../utils/agents.js';
import * as workspaceSvc from '../utils/workspace.js';
import * as dockerSvc from '../sandbox/docker/index.js';
import {
  computeEnvHash,
  getContainerLabel,
  getRuntime,
  getRuntimeForAgent,
  isSandboxRuntime,
  loadAgentsMap,
  probeContainerRuntime,
} from '../sandbox/docker/common.js';
import {
  buildRuntimeNetworkPlan,
  buildRuntimeRouterEnv,
  computeAgentEnvHash,
  exactCleanupFailureOf,
  removeExactSandboxPredecessor,
  resolvePublishedPortMappings,
} from '../sandbox/docker/agentServiceManager.js';
import { inspectExactContainer, removeExactRegisteredContainer } from '../sandbox/docker/containerFleet.js';
import { observeSandboxRuntime, registeredRuntimeTuple } from '../sandbox/bwrap/bwrapFleet.js';
import * as inputState from './inputState.js';
import { MAX_NO_WAIT_BARRIER_ENTRIES, MAX_NO_WAIT_WAVE_INDEX } from './noWaitWorker.js';
import {
  noWaitRunScopedLogPath,
  noWaitRunScopedStatusPath,
} from './noWaitPaths.js';
import {
  exactNoWaitCoordinationStatusPath,
  exactNoWaitImmutableIdentity,
} from './noWaitWorkerArgs.js';
import { retireNoWaitRunMarkers } from './noWaitMarkerLifecycle.js';
import { acquireSettledWorkspaceMutationLease, inspectLiveNoWaitWorkers } from './noWaitRunSettlement.js';
import { prepareDefaultBootRepositories } from './ploinkyboot.js';
import { prepareManifestRepositories, resolveWorkspaceGraphSsoConfig } from '../utils/runtime/bootstrapManifest.js';
import { buildLifecycleHookEnv, executeHostHook, markPreinstallRunInProcess, resetPreinstallRunInProcess, isInlineCommand } from '../utils/runtime/lifecycleHooks.js';
import { getActiveProfile, getProfileConfig, resolveManifestRuntimeProfile } from '../utils/runtime/profileService.js';
import { loadEnvFile } from '../utils/security/secretInjector.js';
import { readSecretsFile } from '../utils/security/encryptedSecretsFile.js';
import { PUBLIC_ROUTER_HOSTS_ENV } from '../utils/publicRouterHosts.mjs';
import {
  ensureRouterGenerationReady,
  readRouterGenerationHealth,
} from '../utils/runtime/routerGenerationReadiness.mjs';
import {
  sanitizeManagedMasterKeyEnvironment,
} from '../utils/security/masterKey.js';
import { getExposedNames, getManifestEnvNames } from '../utils/security/secretVars.js';
import {
  isLlmRuntimeManifest,
  prepareLlmStartup,
  resolveLlmRuntimeAdmissionContext,
} from '../sandbox/docker/llmRuntimeIntegration.js';
import { resolveAgentExecutionMode, resolveAgentReadinessProtocol, resolveManifestReadinessWaitOptions } from '../utils/runtime/startupReadiness.js';
import { normalizeProbeConfig, runContainerScriptReadiness } from '../sandbox/docker/healthProbes.js';
import { applyStartupConfigProvidersForGraph } from '../sandbox/startupConfigProviders.js';
import {
  createWorkspaceMutationLease,
  releaseWorkspaceMutationLease,
  releaseWorkspaceStartLock,
  runWithWorkspaceMutationLease,
  withMaintenanceLock,
  withWorkspaceMutationLease,
} from '../utils/runtime/maintenanceLocks.js';
import {
  issueDependencyRebuildRequest,
  runtimeCarriesRebuildToken,
  settleDependencyRebuildRequest,
} from '../utils/dependencies/store/runtimeDependencies.mjs';
import {
  collectDependencyObjectsAfterAdmission,
  reportDependencyCollection,
} from '../utils/dependencies/store/collector.mjs';
import {
  AGENTS_DATA_DIR,
  LOGS_DIR,
  PLOINKY_CWD,
  PLOINKY_DIR,
  PLOINKY_WORKSPACE_ROOT,
  REPOS_DIR,
  RUNNING_DIR,
} from '../utils/config.js';
import { classifyDependencyGraphWaitMode, resolveWorkspaceDependencyGraph, topologicallyGroupDependencyGraph } from '../utils/workspaceDependencyGraph.js';
import {
  mergeRoutingConfig,
  mergeRuntimeRoute,
  readRoutingConfig,
  writeRoutingConfig,
} from '../server/routingFile.js';
import {
  abortEdgeRoutingPreparation,
  commitAdditiveEdgeRoutingGeneration,
  initializeFreshEdgeRoutingSources,
  inactivateEdgeRoutingGeneration,
  prepareHostModeCapabilityForInactiveGeneration,
  readEdgeRoutingPreparationOwner,
  readEdgeRoutingSelection,
  retireAbandonedAgentPreparation,
  retireAbandonedWorkspaceStartPreparation,
  withEdgeGenerationApplyLock,
} from '../sandbox/edgeGeneration.js';
import { applyEdgeRoutingGeneration } from '../sandbox/coordinatedEdgeApply.js';
import { readRuntimeCandidate, retireRuntimeCandidate } from '../sandbox/runtimeCandidateStore.js';
import {
  hasCompleteRuntimeTuple,
  readRuntimePredecessor,
  retireRuntimePredecessor,
  writeRuntimePredecessor,
} from '../sandbox/runtimePredecessorStore.js';
import {
  finalizeStartupRoutes,
  partitionAdditionalStartupAgents,
  resolveManifestStartup,
} from '../utils/runtime/manifestStartup.js';
import {
  buildRelayReadinessRoute,
  waitForAgentReady,
} from '../server/utils/agentReadiness.js';
import {
  createNetworkLifecycleAdapter,
  NETWORK_LOCK_WAIT_MS,
  withNetworkLifecycleLock,
  withNetworkLifecycleLockAsync,
  withNetworkLifecycleLockReclaimingStoppedOwner,
} from '../sandbox/networkLifecycle.js';
import { networkContractHash } from '../sandbox/networkContract.js';
import {
  admitManifestRuntimeCapabilities,
  assertRuntimeAdmissionCurrent,
  limitsHashReuseReason,
  hardwareRefusalOf,
} from '../sandbox/runtimeCapabilities.js';
import {
  formatReplacementReason,
  formatRuntimeReplacementLine,
  hashMismatchDetail,
  limitsHashDetail,
} from '../sandbox/runtimeReplacementLog.js';
import { LIMITS_HASH_LABEL } from '../sandbox/hardwareLimits/resolve.mjs';
import { prepareMpsGraph } from '../sandbox/hardwareLimits/mpsGraph.mjs';
import { acknowledgeMpsRuntimeReady, finalizeMpsGraph, releaseMpsRuntimeOwner, verifyMpsRuntimeReady } from '../sandbox/hardwareLimits/mpsLifecycle.mjs';
import {
  blockingEdgesFromGraph,
  classifyAvailability,
  summarizeStartResult,
} from '../sandbox/hardwareLimits/outcomes.mjs';
import {
  HardwareLimitsError,
  findHardwareOutcome,
  formatHardwareOutcome,
  validateHardwareOutcome,
} from '../sandbox/hardwareLimits/errors.mjs';
import {
  buildAvailabilityProjection,
  markRouteHardwareUnavailable,
} from '../server/hardwareAvailability.mjs';
import { getAgentDataDir } from '../utils/workspaceStructure.js';
import {
  formatAgentAttachmentBanner,
  resolveAgentAttachmentIdentity,
} from '../sandbox/layerIdentification.js';
import { deriveAgentPrincipalId } from '../utils/security/agentIdentity.js';
import {
  GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE,
  readVerifiedGeneratedRouterDescriptorFile,
} from '../utils/security/generatedRouterDescriptor.js';
import { sanitizeDiagnosticText } from '../utils/diagnosticText.js';
import { waitForChildSpawn } from '../utils/childSpawn.js';
import {
  assertSafeRelativeSegment,
  ensureVerifiedProducerDirectory,
} from '../utils/verifiedReadOnlyFile.js';
import {
  assertRouterEndpoint,
  parseRouterPort,
  resolveInitialRouterPort,
  resolvePersistedRouterPort,
  resolveRouterEndpoint,
} from '../sandbox/routerPort.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// One run-scoped log per detached worker. Two starts of the same agent must
// never share a file: interleaved output from a superseded run is unreadable,
// and a follower bound to the current run would show a predecessor's lines.
// Exclusive creation makes a collision a spawn failure instead of an append.
function createRunScopedLogStdio(logFile) {
  ensureVerifiedProducerDirectory({
    trustedRoot: PLOINKY_WORKSPACE_ROOT,
    relativeSegments: ['.ploinky', 'logs', 'no-wait'],
    mode: 0o700,
  });
  // A single descriptor carries both streams so interleaved worker output
  // keeps one append offset.
  let descriptor;
  let opened;
  try {
    descriptor = fs.openSync(logFile, 'wx', 0o600);
    opened = fs.fstatSync(descriptor);
    if (!opened.isFile()) throw new Error('no-wait log producer did not open one regular file');
  } catch (error) {
    if (descriptor !== undefined) {
      try { fs.closeSync(descriptor); } catch (_) {}
    }
    if (opened) {
      try {
        const current = fs.lstatSync(logFile);
        if (current.dev === opened.dev && current.ino === opened.ino) fs.unlinkSync(logFile);
      } catch (_) {}
    }
    throw error;
  }
  return {
    stdio: ['ignore', descriptor, descriptor],
    closeParentFds() {
      try { fs.closeSync(descriptor); } catch (_) {}
    },
    discard() {
      try { fs.closeSync(descriptor); } catch (_) {}
      try {
        const current = fs.lstatSync(logFile);
        if (current.dev === opened.dev && current.ino === opened.ino) fs.unlinkSync(logFile);
      } catch (_) {}
    },
  };
}

function createAppendLogStdio(logFile) {
  const opened = [];
  try {
    fs.mkdirSync(path.dirname(logFile), { recursive: true });
    const stdoutFd = fs.openSync(logFile, 'a');
    const stderrFd = fs.openSync(logFile, 'a');
    opened.push(stdoutFd, stderrFd);
    return {
      stdio: ['ignore', stdoutFd, stderrFd],
      closeParentFds() {
        for (const fd of opened) {
          try { fs.closeSync(fd); } catch (_) {}
        }
      }
    };
  } catch (_) {
    for (const fd of opened) {
      try { fs.closeSync(fd); } catch (_) {}
    }
    return {
      stdio: 'ignore',
      closeParentFds() {}
    };
  }
}

// Resolve the env handed to the Watchdog (and, by inheritance, to the
// RoutingServer it spawns and respawns). Merge order mirrors
// secretInjector.getSecret(): walked-up `.env` -> `.ploinky/data/.secrets` ->
// `process.env`, with operator-exported values winning. This way the router
// stays able to forward LLM/auth secrets to handlers across crash-restart
// cycles without depending on the operator having `export`'d each one. Managed
// Boxes then remove PLOINKY_MASTER_KEY because core reads its owned key file.
export function sanitizeRouterEnvironment(environment, { managedBox } = {}) {
  return sanitizeManagedMasterKeyEnvironment(environment, { managedBox });
}

export function buildRouterEnv({ managedBox } = {}) {
  let envFile = {};
  try { envFile = loadEnvFile() || {}; } catch (_) { envFile = {}; }
  let secrets = {};
  try { secrets = readSecretsFile() || {}; } catch (_) { secrets = {}; }
  // Trusted outer-host aliases come only from the host-created Box environment.
  // Workspace .env and secret files are writable through agent workspace mounts.
  const { [PUBLIC_ROUTER_HOSTS_ENV]: _envFileHosts, ...fileEnvironment } = envFile;
  const { [PUBLIC_ROUTER_HOSTS_ENV]: _secretHosts, ...secretEnvironment } = secrets;
  return sanitizeRouterEnvironment(
    { ...fileEnvironment, ...secretEnvironment, ...process.env },
    { managedBox },
  );
}

async function spawnNoWaitWorker({
  node,
  identity,
  routerPort,
  forceRecreate = false,
  statusFile,
  waitForStatuses = [],
}) {
  const immutableIdentity = exactNoWaitImmutableIdentity(identity);
  const {
    containerName,
    instanceId,
    enableGeneration,
    repoName,
    shortAgent,
    alias,
    routeKey,
    runId,
    runStartedAtMs,
    waveIndex,
  } = immutableIdentity;
  if (node?.repoName !== repoName
      || node?.shortAgentName !== shortAgent
      || String(node?.alias || '') !== alias) {
    throw new Error(`no-wait worker '${containerName}' was scheduled with a foreign graph identity`);
  }
  const noWaitStatusDir = path.join(RUNNING_DIR, 'no-wait');
  // Derived from the same validated container name and run UUID as the
  // run-scoped status, so a marker, a status, and a log always agree on which
  // run they describe.
  const logFile = noWaitRunScopedLogPath(containerName, runId);
  const canonicalStatusFile = path.join(noWaitStatusDir, `${containerName}.json`);
  const resolvedStatusFile = exactNoWaitCoordinationStatusPath(statusFile, {
    containerName,
    runId,
    runningDir: RUNNING_DIR,
  });
  if (path.basename(resolvedStatusFile) !== immutableIdentity.statusFile) {
    throw new Error(`no-wait worker '${containerName}' was scheduled with a foreign coordination status file`);
  }
  if (!Number.isSafeInteger(waveIndex) || waveIndex < 0
      || waveIndex > MAX_NO_WAIT_WAVE_INDEX) {
    throw new Error(
      `no-wait worker '${containerName}' requires one exact wave index between 0 and ${MAX_NO_WAIT_WAVE_INDEX}`,
    );
  }
  const workerScript = path.resolve(__dirname, 'noWaitWorker.js');
  // Every run-scoped argument is mandatory and unconditional. An omitted flag
  // must never let a worker silently select another coordination protocol.
  const args = [
    workerScript,
    '--container', containerName,
    '--instance-id', instanceId,
    '--enable-generation', enableGeneration,
    '--short-agent', shortAgent,
    '--repo', repoName,
    '--alias', alias,
    '--manifest-path', node.manifestPath,
    '--agent-path', node.agentPath,
    '--route-key', routeKey,
    '--run-id', runId,
    '--run-started-at-ms', String(exactNoWaitRunStartedAtMs(runStartedAtMs)),
    '--wave-index', String(waveIndex),
    '--status-file', resolvedStatusFile,
    '--wait-for-statuses', JSON.stringify(waitForStatuses || []),
  ];
  if (node.profile) {
    args.push('--profile', node.profile);
  }
  if (routerPort) {
    args.push('--router-port', String(routerPort));
  }
  if (forceRecreate) {
    args.push('--force-recreate', '1');
  }
  // An open or spawn failure must surface as a spawn failure so the caller
  // publishes the bounded, redacted terminal status. Silently downgrading to
  // ignored stdio would leave a valid-looking worker with no diagnostics.
  const logStdio = createRunScopedLogStdio(logFile);
  try {
    writeNoWaitRunMarker({
      identity: immutableIdentity,
      statusFile: resolvedStatusFile,
    });
  } catch (error) {
    // The marker was not published, so this task-owned, unexposed log can be
    // removed. A spawn failure after publication deliberately retains it.
    logStdio.discard();
    throw error;
  }
  let child;
  try {
    child = spawn(process.execPath, args, {
      detached: true,
      stdio: logStdio.stdio,
      env: { ...process.env }
    });
    await waitForChildSpawn(child, {
      label: `no-wait worker '${containerName}'`,
    });
  } finally {
    logStdio.closeParentFds();
  }
  child.unref();
  return {
    pid: child.pid,
    logFile,
    statusFile: resolvedStatusFile,
    canonicalStatusFile,
  };
}

// The run identity and its derived file names live in `noWaitPaths.js` so the
// read-only `logs` observer can share them without importing this pipeline.
function noWaitCoordinationStatusPath(containerName, runId, {
  runningDir = RUNNING_DIR,
} = {}) {
  return noWaitRunScopedStatusPath(containerName, runId, { runningDir });
}

// One run start is shared by every worker in the run. Queued workers derive
// their cumulative wave budget from it, so it must be an exact epoch integer
// rather than a per-worker clock sample.
function exactNoWaitRunStartedAtMs(value) {
  const runStartedAtMs = Number(value);
  if (!Number.isSafeInteger(runStartedAtMs) || runStartedAtMs < 0) {
    throw new Error('no-wait run start must be one exact non-negative epoch millisecond integer');
  }
  return runStartedAtMs;
}

export function buildNoWaitLaunchSchedule(deferredNoWaitWaves, {
  runId,
  runStartedAtMs,
  runningDir = RUNNING_DIR,
} = {}) {
  const exactRunStartedAtMs = exactNoWaitRunStartedAtMs(runStartedAtMs);
  const waves = (Array.isArray(deferredNoWaitWaves) ? deferredNoWaitWaves : [])
    .map((entries) => (Array.isArray(entries) ? entries.filter(Boolean) : []))
    .filter((entries) => entries.length > 0);
  // The worker rejects any wave index beyond this bound. Fail in the
  // foreground rather than reporting detached launches whose workers would
  // exit before publishing a status and stall every later wave.
  if (waves.length > MAX_NO_WAIT_WAVE_INDEX + 1) {
    throw new Error(
      `no-wait launch schedule has ${waves.length} waves, which exceeds the supported maximum of ${MAX_NO_WAIT_WAVE_INDEX + 1}`,
    );
  }
  const statusByNodeId = new Map();
  const nodeIdByStatus = new Map();
  waves.forEach((entries, waveIndex) => {
    for (const entry of entries) {
      if (!entry?.node?.id || !entry.registryName) continue;
      if (statusByNodeId.has(entry.node.id)) {
        throw new Error(`no-wait launch schedule repeats graph node '${entry.node.id}'`);
      }
      const statusPath = noWaitCoordinationStatusPath(entry.registryName, runId, { runningDir });
      if (nodeIdByStatus.has(statusPath)) {
        throw new Error(
          `no-wait launch schedule maps '${entry.node.id}' and '${nodeIdByStatus.get(statusPath)}' to one status file`,
        );
      }
      nodeIdByStatus.set(statusPath, entry.node.id);
      // The recorded wave index belongs to the referenced target, not to the
      // worker that will wait for it. A waiter needs the target's wave to bind
      // the observed status and to size its cumulative queued budget.
      statusByNodeId.set(entry.node.id, Object.freeze({
        nodeId: entry.node.id,
        producerKey: entry.registryName,
        path: statusPath,
        runId,
        waveIndex,
      }));
    }
  });

  // A worker waits for its own dependencies and nothing else. Gating on every
  // member of the immediately preceding wave made an agent wait on peers it has
  // no relationship with: in a measured run soul-gateway, whose only dependency
  // is default-local-llm, sat idle behind an unrelated onlyOffice launch. The
  // dependency graph already expresses the ordering that correctness needs.
  return waves.map((entries, waveIndex) => {
    const scheduled = entries.map((entry) => {
      const directDependencyIds = new Set(entry.node?.dependencies || []);
      const references = new Map();
      const addReference = (reference, directDependency, relation = 'blocking') => {
        if (!reference) return;
        // The worker rejects a barrier entry that does not name a strictly
        // earlier wave, exiting before it can publish a status while the parent
        // still reports a successful spawn. Reject it here instead.
        if (reference.waveIndex >= waveIndex) {
          throw new Error(
            `no-wait launch schedule points '${entry.node.id}' in wave ${waveIndex} at '${reference.nodeId}' in wave ${reference.waveIndex}`,
          );
        }
        const existing = references.get(reference.path);
        if (existing && (existing.nodeId !== reference.nodeId
          || existing.runId !== reference.runId
          || existing.waveIndex !== reference.waveIndex)) {
          throw new Error(
            `no-wait launch schedule maps two distinct barrier identities to '${path.basename(reference.path)}'`,
          );
        }
        references.set(reference.path, {
          ...reference,
          directDependency: Boolean(directDependency || existing?.directDependency),
          relation: existing?.relation === 'blocking' ? 'blocking' : relation,
        });
      };
      // Only blocking edges synthesize a waiting relation (plan §9.1, U15).
      // An optional no-wait edge neither delays nor blocks its consumer; a
      // duplicate blocking declaration already won in the graph's edge map.
      for (const dependencyId of directDependencyIds) {
        if (entry.node?.dependencyEdges?.get?.(dependencyId)?.noWait === true) continue;
        addReference(statusByNodeId.get(dependencyId), true, 'blocking');
      }
      // Independently explicit status waits supplied by the scheduler.
      for (const dependencyId of entry.explicitStatusWaitNodeIds || []) {
        addReference(statusByNodeId.get(dependencyId), true, 'explicit-status-wait');
      }
      // The worker rejects a barrier larger than this, and would exit during
      // argument parsing without publishing a terminal status while the parent
      // reported a successful spawn. Fail in the foreground instead.
      if (references.size > MAX_NO_WAIT_BARRIER_ENTRIES) {
        throw new Error(
          `no-wait launch schedule gives '${entry.node.id}' ${references.size} barrier entries, which exceeds the supported maximum of ${MAX_NO_WAIT_BARRIER_ENTRIES}`,
        );
      }
      return Object.freeze({
        ...entry,
        waveIndex,
        runId,
        runStartedAtMs: exactRunStartedAtMs,
        statusFile: statusByNodeId.get(entry.node.id)?.path || '',
        waitForStatuses: Object.freeze(Array.from(references.values(), Object.freeze)),
      });
    });
    return Object.freeze(scheduled);
  });
}

// Bind a pure graph schedule to the exact staged registry tuple before any
// marker, status, log, or worker process is created. Later launch code consumes
// this captured identity rather than re-reading mutable registry fields.
export function bindNoWaitLaunchScheduleIdentity(schedule, registry, {
  runningDir = RUNNING_DIR,
} = {}) {
  if (!Array.isArray(schedule) || !registry || typeof registry !== 'object') {
    throw new Error('no-wait launch identity binding requires one schedule and registry snapshot');
  }
  return Object.freeze(schedule.map((wave) => Object.freeze(wave.map((entry) => {
    const containerName = String(entry?.registryName || '');
    const node = entry?.node;
    const record = registry[containerName];
    const alias = record?.alias === undefined || record?.alias === null ? '' : record.alias;
    if (!node || record?.type !== 'agent'
        || record.repoName !== node.repoName
        || record.agentName !== node.shortAgentName
        || alias !== String(node.alias || '')) {
      throw new Error(`no-wait launch cannot bind '${containerName}' to the staged registry identity`);
    }
    const statusPath = exactNoWaitCoordinationStatusPath(entry.statusFile, {
      containerName,
      runId: entry.runId,
      runningDir,
    });
    const identity = exactNoWaitImmutableIdentity({
      containerName,
      instanceId: record.instanceId,
      enableGeneration: record.enableGeneration,
      repoName: record.repoName,
      shortAgent: record.agentName,
      alias,
      routeKey: alias || record.agentName,
      runId: entry.runId,
      runStartedAtMs: entry.runStartedAtMs,
      waveIndex: entry.waveIndex,
      statusFile: path.basename(statusPath),
    });
    return Object.freeze({ ...entry, identity });
  }))));
}

function writeNoWaitAtomicJson(target, payload) {
  const resolvedTarget = path.resolve(String(target || ''));
  const targetDirectory = path.dirname(resolvedTarget);
  if (path.basename(targetDirectory) !== 'no-wait') {
    throw new Error('no-wait status publication requires a file in the workspace no-wait directory');
  }
  assertSafeRelativeSegment(path.basename(resolvedTarget), 'no-wait status filename');
  let targetRunningDirectory;
  let workspaceRunningDirectory;
  try {
    targetRunningDirectory = fs.realpathSync(path.dirname(targetDirectory));
    workspaceRunningDirectory = fs.realpathSync(RUNNING_DIR);
  } catch (_) {
    throw new Error('no-wait status publication requires the existing workspace running directory');
  }
  if (targetRunningDirectory !== workspaceRunningDirectory) {
    throw new Error('no-wait status publication requires a file in the workspace no-wait directory');
  }
  ensureVerifiedProducerDirectory({
    trustedRoot: PLOINKY_WORKSPACE_ROOT,
    relativeSegments: ['.ploinky', 'running', 'no-wait'],
    mode: 0o700,
  });
  const temporary = `${resolvedTarget}.${process.pid}.${randomUUID()}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(payload, null, 2), { flag: 'wx', mode: 0o600 });
    fs.renameSync(temporary, resolvedTarget);
  } finally {
    try { fs.unlinkSync(temporary); } catch (error) {
      if (error?.code !== 'ENOENT') throw error;
    }
  }
}

function writeNoWaitRunMarker(entry) {
  const identity = exactNoWaitImmutableIdentity(entry?.identity);
  const target = path.join(RUNNING_DIR, 'no-wait', `${identity.containerName}.current.json`);
  if (path.resolve(String(entry?.statusFile || '')) !== noWaitCoordinationStatusPath(
    identity.containerName,
    identity.runId,
  )) {
    throw new Error('no-wait run marker requires the exact coordination status path');
  }
  writeNoWaitAtomicJson(target, {
    createdAt: new Date().toISOString(),
    ...identity,
  });
}

// Publish a terminal hardware outcome for a no-wait instance whose refusal or
// block is already known from graph metadata. No worker or runtime is created;
// consumers that wait on this producer observe the typed subtype.
export function writeNoWaitHardwareOutcome(entry, outcome) {
  // The run marker binds observers (status, startup page, Marketplace) to
  // this exact run before the terminal status is published.
  writeNoWaitRunMarker({ identity: entry?.identity, statusFile: entry?.statusFile });
  writeNoWaitSpawnFailure(entry, new HardwareLimitsError(outcome), { phase: 'admission' });
}

export function writeNoWaitSpawnFailure(entry, error, { phase = 'spawn' } = {}) {
  const finishedAtMs = Date.now();
  // This runs inside the spawn loop's catch. Without an exact coordination
  // path there is nothing to publish, and throwing here would replace the
  // original spawn failure with an unrelated rename error and abort the start.
  const identity = exactNoWaitImmutableIdentity(entry?.identity);
  const coordinationStatusFile = exactNoWaitCoordinationStatusPath(entry?.statusFile, {
    containerName: identity.containerName,
    runId: identity.runId,
    runningDir: RUNNING_DIR,
  });
  if (path.basename(coordinationStatusFile) !== identity.statusFile) {
    throw new Error('no-wait spawn failure requires the exact run-scoped status identity');
  }
  // A spawn failure has to be a valid terminal member of a wave barrier so a
  // dependent worker can make a deterministic dependency decision instead of
  // stalling on a status that never arrives.
  const hardwareOutcome = findHardwareOutcome(error);
  const payload = {
    state: 'failed',
    sequencePhase: 'active',
    phase,
    startedAt: new Date(finishedAtMs).toISOString(),
    startedAtMs: finishedAtMs,
    sequencePhaseStartedAt: new Date(finishedAtMs).toISOString(),
    sequencePhaseStartedAtMs: finishedAtMs,
    finishedAt: new Date(finishedAtMs).toISOString(),
    finishedAtMs,
    error: hardwareOutcome
      ? { message: sanitizeDiagnosticText(error), code: hardwareOutcome.code, hardwareOutcome }
      : { message: sanitizeDiagnosticText(error) },
    ...identity,
  };
  const canonical = path.join(RUNNING_DIR, 'no-wait', `${identity.containerName}.json`);
  // Match the worker's publication protocol: the canonical monitor view must
  // be durable before the run-scoped file releases a dependent wave.
  for (const target of new Set([canonical, coordinationStatusFile])) {
    writeNoWaitAtomicJson(target, payload);
  }
}

function spawnWatchdog(routerPath, port, routerPidFile) {
  const logStdio = createAppendLogStdio(path.join(LOGS_DIR, 'watchdog.log'));
  const child = spawn(process.execPath, [routerPath], {
    detached: true,
    stdio: logStdio.stdio,
    env: {
      ...buildRouterEnv(),
      PORT: String(port),
      PLOINKY_WORKSPACE_ROOT,
      PLOINKY_ROUTER_PID_FILE: routerPidFile
    }
  });
  logStdio.closeParentFds();
  return child;
}

async function waitForRouterReady(port, child, timeoutMs = 15000, {
  createConnection = net.createConnection,
} = {}) {
  const validatedPort = parseRouterPort(port, { source: 'router readiness port' });
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (child?.exitCode !== null && child?.exitCode !== undefined) {
      throw new Error(`router exited before TCP listener became ready (exit ${child.exitCode})`);
    }
    const tcpReady = await new Promise((resolve) => {
      const socket = createConnection({ host: '127.0.0.1', port: validatedPort });
      const done = (value) => { socket.destroy(); resolve(value); };
      socket.once('connect', () => done(true));
      socket.once('error', () => done(false));
      socket.setTimeout(250, () => done(false));
    });
    if (tcpReady) return;
    await new Promise((resolve) => setTimeout(resolve, 100));
  }
  throw new Error(`router TCP listener did not become ready at 127.0.0.1:${validatedPort}`);
}

function runWithSuspendedInput(callback) {
  const restoreInput = inputState.prepareForExternalCommand?.() || (() => {});
  try {
    return callback();
  } finally {
    restoreInput();
  }
}

function getCliCmd(manifest) {
  const explicitCli =
    (manifest.cli && String(manifest.cli)) ||
    (manifest.commands && manifest.commands.cli);

  if (explicitCli) {
    return explicitCli;
  }

  return '/Agent/default_cli.sh';
}

function shellQuote(str) {
  if (str === undefined || str === null) return "''";
  const s = String(str);
  if (s.length === 0) return "''";
  return `'${s.replace(/'/g, "'\\''")}'`;
}

function wrapCliWithWebchat(command, env = process.env) {
  const trimmed = (command || '').trim();
  if (!trimmed) return trimmed;
  if (env.PLOINKY_SKIP_MANIFEST_CLI_WEBCHAT === '1') {
    return trimmed;
  }
  const enableWrap = env.PLOINKY_MANIFEST_CLI_WEBCHAT === '1';
  if (!enableWrap) {
    return trimmed;
  }
  if (/^(?:\/Agent\/bin\/)?webchat\b/.test(trimmed) || /^ploinky\s+webchat\b/.test(trimmed)) {
    return trimmed;
  }
  return `/Agent/bin/webchat -- ${shellQuote(trimmed)}`;
}

function resolveManifestRouterEndpoint(manifest, {
  explicitPort,
  profileName,
  persistedProfileName,
  routerEndpoint,
  path: manifestPath = 'manifest',
} = {}) {
  const resolution = resolveManifestRuntimeProfile(manifest, {
    profileName,
    persistedProfileName,
    path: manifestPath,
  });
  if (routerEndpoint !== undefined) {
    return assertRouterEndpoint(routerEndpoint, resolution.network.mode, { explicitPort });
  }
  return resolveRouterEndpoint(resolution.network.mode, { explicitPort });
}

function findAgentManifest(agentName) {
  const { manifestPath } = utils.findAgent(agentName);
  return manifestPath;
}

function deduplicateAgentRegistry(reg, getAgentContainerName) {
  const dedup = {};
  const aliasEntries = {};
  const canonical = new Map();

  for (const [key, rec] of Object.entries(reg || {})) {
    if (key === '_config') continue;
    if (!rec || typeof rec !== 'object') {
      dedup[key] = rec;
      continue;
    }
    if (rec.type !== 'agent') {
      dedup[key] = rec;
      continue;
    }
    if (rec.alias) {
      aliasEntries[key] = rec;
      continue;
    }
    if (!rec.agentName) continue;
    const repo = rec.repoName || '';
    const expectedKey = getAgentContainerName(rec.agentName, repo);
    const agentKey = `${repo}::${rec.agentName}`;
    const existing = canonical.get(agentKey);
    if (!existing || key === expectedKey) {
      // A coordinated additive replacement has a deliberately distinct
      // __candidate_<identity> runtime name.  Preserve that exact registry
      // key when it is the sole record for this logical agent; rewriting it
      // to the conventional name severs the registry/runtime binding and
      // makes the next workspace start treat the live candidate as stopped.
      // If both records exist, the real conventional key still wins.
      canonical.set(agentKey, { key, rec });
    }
  }

  for (const { key, rec } of canonical.values()) {
    dedup[key] = rec;
  }
  for (const [aliasKey, rec] of Object.entries(aliasEntries)) {
    dedup[aliasKey] = rec;
  }

  const preservedCfg = workspaceSvc.getConfig();
  if (preservedCfg && Object.keys(preservedCfg).length) {
    dedup._config = preservedCfg;
  }
  return dedup;
}

function findRegistryEntryForGraphNode(reg, node, getAgentContainerName) {
  if (!reg || !node) return null;
  const expectedKey = getAgentContainerName(node.alias || node.shortAgentName, node.repoName);
  const expectedRecord = reg[expectedKey];
  if (
    expectedRecord && expectedRecord.type === 'agent' &&
    expectedRecord.repoName === node.repoName &&
    expectedRecord.agentName === node.shortAgentName &&
    (node.alias ? expectedRecord.alias === node.alias : !expectedRecord.alias)
  ) {
    return { key: expectedKey, rec: expectedRecord };
  }

  for (const [key, rec] of Object.entries(reg || {})) {
    if (key === '_config' || !rec || rec.type !== 'agent') continue;
    if (rec.repoName !== node.repoName || rec.agentName !== node.shortAgentName) continue;
    if (node.alias) {
      if (rec.alias === node.alias) {
        return { key, rec };
      }
      continue;
    }
    if (!rec.alias) {
      return { key, rec };
    }
  }
  if (!node.alias) {
    for (const [key, rec] of Object.entries(reg || {})) {
      if (key === '_config' || !rec || rec.type !== 'agent') continue;
      if (rec.repoName === node.repoName && rec.agentName === node.shortAgentName) {
        return { key, rec };
      }
    }
  }
  return null;
}

function resolveStaticRouterContainerName({
  registry,
  staticNode,
  staticAgent,
  staticRepoName,
  getAgentContainerName,
}) {
  const registryEntry = findRegistryEntryForGraphNode(
    registry,
    staticNode,
    getAgentContainerName,
  );
  return registryEntry?.key || getAgentContainerName(
    staticNode?.shortAgentName || staticAgent,
    staticNode?.repoName || staticRepoName || '',
  );
}

function resolveGraphNodeExecutionRecord(node, {
  workspaceRoot = PLOINKY_WORKSPACE_ROOT,
  reposDir = REPOS_DIR,
  getAgentDataDirImpl = getAgentDataDir,
} = {}) {
  const normalized = agentsSvc.normalizeEnableArgs(node.enableSpec || node.agentRef);
  const requestedMode = String(normalized.mode || '').trim().toLowerCase();
  const instanceName = node.alias || node.shortAgentName;

  if (!requestedMode || requestedMode === 'default' || requestedMode === agentsSvc.DEFAULT_ENABLE_AGENT_MODE) {
    return {
      runMode: agentsSvc.DEFAULT_ENABLE_AGENT_MODE,
      projectPath: getAgentDataDirImpl(instanceName),
      develRepo: undefined,
    };
  }
  if (requestedMode === 'global') {
    return {
      runMode: 'global',
      projectPath: workspaceRoot,
      develRepo: undefined,
    };
  }
  if (requestedMode === 'devel') {
    const develRepo = String(normalized.repoNameParam || '').trim();
    if (!develRepo) {
      throw new Error(`Graph node '${node.id}' requests devel mode without a repository name.`);
    }
    const projectPath = reposDir === REPOS_DIR
      ? resolveAgentRepositoryPath(develRepo)
      : path.join(reposDir, develRepo);
    if (!fs.existsSync(projectPath) || !fs.statSync(projectPath).isDirectory()) {
      throw new Error(`Repository '${develRepo}' required by graph node '${node.id}' was not found in ${reposDir}.`);
    }
    return { runMode: 'devel', projectPath, develRepo };
  }
  throw new Error(
    `Graph node '${node.id}' requests unknown mode '${requestedMode}'. Allowed: ${agentsSvc.ENABLE_AGENT_MODES.join(' | ')}`,
  );
}

function resolveRetainedGraphNodeExecutionRecord(node, record, {
  workspaceRoot = PLOINKY_WORKSPACE_ROOT,
  getAgentDataDirImpl = getAgentDataDir,
} = {}) {
  const runMode = String(record?.runMode || agentsSvc.DEFAULT_ENABLE_AGENT_MODE).trim().toLowerCase();
  const instanceName = node.alias || record?.alias || node.shortAgentName;
  let projectPath;
  let develRepo;

  if (runMode === agentsSvc.DEFAULT_ENABLE_AGENT_MODE) {
    projectPath = getAgentDataDirImpl(instanceName);
  } else if (runMode === 'global') {
    projectPath = workspaceRoot;
  } else if (runMode === 'devel') {
    develRepo = String(record?.develRepo || '').trim();
    projectPath = String(record?.projectPath || '').trim();
    if (!develRepo || !projectPath || !fs.existsSync(projectPath) || !fs.statSync(projectPath).isDirectory()) {
      throw new Error(
        `Retained graph node '${node.id}' has an incomplete devel execution record; re-enable it with an exact repository.`,
      );
    }
    projectPath = path.resolve(projectPath);
  } else {
    throw new Error(
      `Retained graph node '${node.id}' has unknown mode '${runMode}'. Allowed: ${agentsSvc.ENABLE_AGENT_MODES.join(' | ')}`,
    );
  }

  // The static agent owns the workspace-facing process contract even when it
  // was originally enabled as an isolated instance. Conversely, an isolated
  // agent that is no longer static must return to its per-instance data root.
  // Stage that transition before the immutable generation is prepared so
  // runtime finalization never changes a lifecycle-bound projectPath.
  if (node.isStatic) projectPath = workspaceRoot;

  return { runMode, projectPath, develRepo };
}

function executionRecordDifferences(record, expected) {
  const currentProjectPath = String(record?.projectPath || '').trim();
  const expectedProjectPath = String(expected.projectPath || '').trim();
  const sameProjectPath = currentProjectPath
    && expectedProjectPath
    && path.resolve(currentProjectPath) === path.resolve(expectedProjectPath);
  const currentDevelRepo = String(record?.develRepo || '').trim();
  const sameDevelRepo = expected.runMode === 'devel'
    ? currentDevelRepo === expected.develRepo
    : !currentDevelRepo;
  const differences = [];
  if (record?.runMode !== expected.runMode) {
    differences.push(`runMode ${record?.runMode || 'none'} -> ${expected.runMode || 'none'}`);
  }
  if (!sameProjectPath) {
    differences.push(`projectPath ${currentProjectPath || 'none'} -> ${expectedProjectPath || 'none'}`);
  }
  if (!sameDevelRepo) {
    differences.push(`develRepo ${currentDevelRepo || 'none'} -> ${String(expected.develRepo || '') || 'none'}`);
  }
  return differences;
}

function executionRecordDiffers(record, expected) {
  return executionRecordDifferences(record, expected).length > 0;
}

// The one start-graph line for a changed plan: every reason that applies.
function graphReplacementLine(plan) {
  const reasons = [];
  if (plan.executionChanged) {
    reasons.push(`execution changed: ${(plan.executionDifferences || []).join(', ') || 'unknown'}`);
  }
  if (plan.profileChanged) {
    reasons.push(`profile changed: ${plan.existing.rec.profile || 'none'} -> ${plan.node.profile}`);
  }
  if (plan.runtimeReason) {
    reasons.push(formatReplacementReason(plan.runtimeReason, plan.runtimeReasonDetail));
  }
  return formatRuntimeReplacementLine(plan.node.id, reasons.join('; '));
}

function mintChangedRuntimeIdentityPair(record, uuid) {
  const instanceId = String(uuid() || '').trim();
  const enableGeneration = String(uuid() || '').trim();
  const prior = new Set([
    String(record?.instanceId || '').trim(),
    String(record?.enableGeneration || '').trim(),
  ].filter(Boolean));
  if (!instanceId || !enableGeneration
      || instanceId === enableGeneration
      || prior.has(instanceId)
      || prior.has(enableGeneration)) {
    throw new Error('workspace graph could not mint a fresh instanceId/enableGeneration pair');
  }
  return Object.freeze({ instanceId, enableGeneration });
}

function effectiveGraphInstanceKey(node) {
  return node.alias
    ? `${node.repoName}/${node.shortAgentName}#alias:${node.alias}`
    : `${node.repoName}/${node.shortAgentName}#canonical`;
}

function retainedManagedDescriptorBind(record) {
  const binds = (record?.config?.binds || []).filter((bind) => (
    String(bind?.target || '') === GENERATED_ROUTER_DESCRIPTOR_CONTAINER_FILE
  ));
  if (binds.length !== 1
      || binds[0]?.generatedRouterDescriptor !== true
      || binds[0]?.ro !== true) {
    return null;
  }
  return binds[0];
}

function computeRetainedManagedEnvHash(node, record, profileConfig, runtimeNetworkPlan, {
  computeEnvHashImpl = computeEnvHash,
  descriptorRoot = path.join(PLOINKY_DIR, 'run', 'router-descriptors'),
  deriveAgentPrincipalIdImpl = deriveAgentPrincipalId,
  readDescriptorFileImpl = readVerifiedGeneratedRouterDescriptorFile,
} = {}) {
  try {
    const bind = retainedManagedDescriptorBind(record);
    if (!bind) return '';
    const root = path.resolve(descriptorRoot);
    const source = path.resolve(String(bind.source || ''));
    const relative = path.relative(root, source);
    if (!/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\.json$/i.test(relative)
        || relative.startsWith('..')
        || path.isAbsolute(relative)
        || relative.includes(path.sep)) {
      return '';
    }
    const realRoot = fs.realpathSync.native(root);
    const realSource = fs.realpathSync.native(source);
    if (realSource !== path.join(realRoot, relative)) return '';

    const payload = readDescriptorFileImpl(source)?.payload;
    const principalId = deriveAgentPrincipalIdImpl(node.repoName, node.shortAgentName);
    if (payload?.agentPrincipal !== principalId
        || payload?.instanceId !== String(record.instanceId || '')
        || payload?.generationId !== String(record.enableGeneration || '')) {
      return '';
    }
    // The same construction the creation label and managed adoption use.
    return computeAgentEnvHash(node.manifest, profileConfig, {
      agentName: node.shortAgentName,
      repoName: node.repoName,
      runtimeNetworkPlan,
      generatedRouter: {
        payload,
        principalId,
        instanceId: record.instanceId,
        enableGeneration: record.enableGeneration,
      },
    }, computeEnvHashImpl);
  } catch (_) {
    return '';
  }
}

function removeGraphContainerForRecreate(containerName, label, predecessorRecord, {
  predecessorReceipt = null,
  clearLivenessStateImpl = dockerSvc.clearLivenessState,
  containerExistsImpl = dockerSvc.containerExists,
  getRuntimeImpl = dockerSvc.getRuntime,
  removeExactRegisteredContainerImpl = removeExactRegisteredContainer,
  readRuntimeCandidateImpl = readRuntimeCandidate,
  retireRuntimeCandidateImpl = retireRuntimeCandidate,
  retireRuntimePredecessorImpl = retireRuntimePredecessor,
  inspectExactContainerImpl = inspectExactContainer,
  removeExactSandboxPredecessorImpl = removeExactSandboxPredecessor,
} = {}) {
  // The predecessor record's own runtime selects how it is observed and
  // removed, whatever backend its successor resolves to. A native predecessor
  // has no container: only its exact PID record and process identity count.
  if (isSandboxRuntime(predecessorRecord?.runtime)) {
    let outcome;
    try {
      outcome = removeExactSandboxPredecessorImpl(containerName, predecessorRecord, {
        process: predecessorReceipt?.predecessor?.process ?? predecessorRecord?.process,
      });
    } catch (cause) {
      const error = new Error(
        `[${label}] preserved sandbox '${containerName}' because exact process ownership/removal was not proven`,
        { cause },
      );
      error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
      throw error;
    }
    if (outcome?.state !== 'absent' && outcome?.state !== 'removed') {
      const error = new Error(
        `[${label}] preserved sandbox '${containerName}' because exact process ownership/removal was not proven (${outcome?.state || 'unknown'}: ${outcome?.reason || 'unreported'})`,
      );
      error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
      throw error;
    }
    // Absent or removed: the exact predecessor no longer needs its proof.
    clearLivenessStateImpl(containerName);
    if (predecessorReceipt) retireRuntimePredecessorImpl(predecessorReceipt);
    return { removed: outcome.state === 'removed', state: outcome.state === 'removed' ? 'removed' : 'absent' };
  }
  // A staged predecessor whose launcher never published it (a no-wait worker
  // that stopped or was superseded) has no registered container ID. Its launch
  // receipt, or else the container's exact workspace, instance, generation and
  // launch identity, proves ownership instead, exactly as for a reinstall whose
  // launcher died before persisting the ID.
  const unpublished = !/^[a-f0-9]{64}$/.test(String(predecessorRecord?.containerId || ''));
  if (!containerExistsImpl(containerName)) {
    // Nothing to remove by name. The launch receipt is the only recovery
    // evidence, so it is retired only when its own engine positively reports
    // the exact recorded ID missing. An unavailable engine, a timeout or any
    // other inspection failure is unknown and leaves the receipt in place.
    if (unpublished) {
      try {
        const receipt = readRuntimeCandidateImpl(containerName, predecessorRecord);
        if (receipt && inspectExactContainerImpl(receipt.runtime, receipt.containerId) === null) {
          retireRuntimeCandidateImpl(receipt);
        }
      } catch (_) {}
    }
    if (predecessorReceipt) {
      // The predecessor receipt is the only proof of the tuple a predecessor
      // still present here carries. A name miss can be an unavailable engine,
      // so retire it, and continue toward a launch, only once the engine
      // positively reports the exact predecessor missing.
      // The engine is probed, never required: with none installed the absence
      // is simply not proven (getRuntime would end the process).
      let absent = false;
      try {
        const engine = predecessorRecord?.runtime
          || (getRuntimeImpl === dockerSvc.getRuntime ? probeContainerRuntime() : getRuntimeImpl());
        absent = Boolean(engine) && inspectExactContainerImpl(
          engine,
          unpublished ? containerName : predecessorRecord.containerId,
        ) === null;
      } catch (_) {}
      if (!absent) {
        const error = new Error(
          `[${label}] preserved the predecessor receipt of '${containerName}' because the exact predecessor's absence was not proven`,
        );
        error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
        throw error;
      }
      retireRuntimePredecessorImpl(predecessorReceipt);
    }
    return { removed: false, state: 'absent' };
  }
  let result;
  try {
    // A launch for this exact tuple that stopped before publishing keeps the
    // replaced predecessor's ID in the registry; its receipt names the runtime
    // it created in that predecessor's place, exactly as for a direct recreate.
    const receipt = unpublished || hasCompleteRuntimeTuple(predecessorRecord)
      ? readRuntimeCandidateImpl(containerName, predecessorRecord)
      : null;
    if (receipt && !unpublished
        && receipt.containerId !== predecessorRecord.containerId
        && receipt.predecessorContainerId !== predecessorRecord.containerId) {
      throw new Error('registered container ID conflicts with the persisted launch receipt');
    }
    result = removeExactRegisteredContainerImpl(
      containerName,
      receipt ? { ...predecessorRecord, ...receipt.registryRecord } : predecessorRecord,
      {
        runtime: getRuntimeImpl(),
        ...(unpublished && !receipt ? { recoverIncompleteIdentity: true } : {}),
      },
    );
    if (result?.removed !== true) {
      throw new Error(`exact predecessor removal returned '${result?.state || 'unknown'}'`);
    }
    if (receipt) retireRuntimeCandidateImpl(receipt);
    clearLivenessStateImpl(containerName);
  } catch (cause) {
    const error = new Error(
      `[${label}] preserved container '${containerName}' because exact immutable ownership/removal was not proven`,
      { cause },
    );
    error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
    throw error;
  }
  // Removed: this exact predecessor no longer needs its proof.
  if (predecessorReceipt) retireRuntimePredecessorImpl(predecessorReceipt);
  return result;
}

// 'seatbelt' | 'bwrap' | 'container', or '' for a record that names no
// runtime (staged but never launched).
function graphRecordBackend(record) {
  const runtime = String(record?.runtime || '');
  if (!runtime) return '';
  return isSandboxRuntime(runtime) ? runtime : 'container';
}

// The backend a record's runtime was launched on, resolved once per graph
// stage. A record that names its runtime answers directly. A runtime-less one
// (legacy, or never finalized) never selects a backend by itself:
//   - a predecessor receipt that names a runtime is authoritative;
//   - the PID record of its exact tuple proves a native owner (live, or stale
//     for that tuple), whose kind is the desired native kind or the host's;
//   - an unverifiable slot refuses (the caller is still before any mutation);
//   - verified absence of any native owner leaves it a container record, unless
//     the desired backend is native and no container engine exists at all, in
//     which case nothing but a native runtime could ever have run.
function resolvePredecessorBackend(node, existing, {
  observeImpl,
  readReceiptImpl,
  getRuntimeForAgentImpl = getRuntimeForAgent,
  probeContainerRuntimeImpl = probeContainerRuntime,
}) {
  const named = graphRecordBackend(existing.rec);
  if (named) return named;
  const tuple = registeredRuntimeTuple(existing.rec);
  if (!tuple) return '';
  let receipt = null;
  try { receipt = readReceiptImpl(existing.key, existing.rec); } catch (_) { receipt = null; }
  if (receipt?.predecessor?.runtime) return graphRecordBackend(receipt.predecessor);
  const desired = getRuntimeForAgentImpl(node.manifest);
  const nativeKind = isSandboxRuntime(desired) ? desired : (process.platform === 'darwin' ? 'seatbelt' : 'bwrap');
  const observed = observeImpl(existing.key, { expectedIdentity: tuple });
  if (observed.state === 'unknown') throw sandboxOwnershipUnknown(existing.key, observed.reason);
  const carriesTuple = observed.record
    && observed.record.instanceId === tuple.instanceId
    && observed.record.enableGeneration === tuple.enableGeneration;
  if (observed.state === 'live-exact' || (observed.state === 'absent' && carriesTuple)) return nativeKind;
  if (isSandboxRuntime(desired) && !probeContainerRuntimeImpl()) return desired;
  return '';
}

function sandboxOwnershipUnknown(containerName, reason) {
  const error = new Error(
    `sandbox runtime '${containerName}' ownership could not be verified (${reason}); refusing to treat it as stopped`,
  );
  error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
  return error;
}

// Liveness for the graph: an unknown observation is never "stopped".
function isGraphSandboxRuntimeRunning(runtimeKey, expectedIdentity, {
  observeImpl = observeSandboxRuntime,
} = {}) {
  const observed = observeImpl(runtimeKey, { expectedIdentity });
  if (observed.state === 'unknown') throw sandboxOwnershipUnknown(runtimeKey, observed.reason);
  return observed.state === 'live-exact';
}

export function graphNodeRuntimeReplacementReason(plan, {
  containerExistsImpl = dockerSvc.containerExists,
  isContainerRunningImpl = dockerSvc.isContainerRunning,
  isSandboxRunningImpl = isGraphSandboxRuntimeRunning,
  getRuntimeForAgentImpl = getRuntimeForAgent,
  getRuntimeImpl = getRuntime,
  getContainerLabelImpl = getContainerLabel,
  computeEnvHashImpl = computeEnvHash,
  createNetworkLifecycleAdapterImpl = createNetworkLifecycleAdapter,
  resolvePublishedPortMappingsImpl = resolvePublishedPortMappings,
  isLlmRuntimeManifestImpl = isLlmRuntimeManifest,
  prepareLlmStartupImpl = prepareLlmStartup,
  getManifestEnvNamesImpl = getManifestEnvNames,
  getExposedNamesImpl = getExposedNames,
  computeRetainedManagedEnvHashImpl = computeRetainedManagedEnvHash,
  retainedManagedEnvHashOptions,
  admitRuntimeImpl = admitGraphNodeHardwareDescriptor,
} = {}) {
  const { node, existing } = plan;
  const record = existing.rec;
  if (!String(record.instanceId || '').trim() || !String(record.enableGeneration || '').trim()) {
    return 'missingRuntimeIdentity';
  }

  const profileResolution = resolveManifestRuntimeProfile(node.manifest, {
    agentName: `${node.repoName}/${node.shortAgentName}`,
    profileName: node.profile || undefined,
    path: `manifest(${node.repoName}/${node.shortAgentName})`,
  });
  const runtimeKind = getRuntimeForAgentImpl(node.manifest);
  // The existing record's own backend selects how it is probed; the desired
  // backend only selects the successor. A record without a runtime (never
  // launched) names no backend, so it never selects one for removal.
  const recordBackend = plan.predecessorBackend !== undefined
    ? plan.predecessorBackend
    : graphRecordBackend(record);
  const desiredBackend = isSandboxRuntime(runtimeKind) ? runtimeKind : 'container';
  if (recordBackend && recordBackend !== desiredBackend) return 'runtimeBackendChanged';
  const routerEndpoint = resolveManifestRouterEndpoint(node.manifest, {
    explicitPort: resolvePersistedRouterPort(),
    profileName: node.profile || undefined,
    path: `manifest(${node.repoName}/${node.shortAgentName})`,
  });
  if (recordBackend ? recordBackend !== 'container' : isSandboxRuntime(runtimeKind)) {
    if (!isSandboxRunningImpl(existing.key, {
      instanceId: record.instanceId,
      enableGeneration: record.enableGeneration,
    })) return 'sandboxRuntimeStopped';
    const desired = computeEnvHashImpl(
      node.manifest,
      profileResolution.profileConfig,
      routerEndpoint?.env || {},
      { agentName: node.shortAgentName, repoName: node.repoName },
    );
    if (desired && desired !== String(record.envHash || '')) {
      plan.runtimeReasonDetail = hashMismatchDetail('envHash', record.envHash, desired);
      return 'envHashChanged';
    }
    return '';
  }

  if (!containerExistsImpl(existing.key)) return 'registeredRuntimeMissing';
  if (!isContainerRunningImpl(existing.key)) return 'runtimeStopped';

  const runtime = getRuntimeImpl();
  const runtimeNetworkPlan = buildRuntimeNetworkPlan(runtime, profileResolution.network);
  const runtimeRouterEnv = buildRuntimeRouterEnv(runtime, {
    routerEndpoint,
    networkMode: profileResolution.network.mode,
  });
  const baseEnvHash = computeAgentEnvHash(node.manifest, profileResolution.profileConfig, {
    agentName: node.shortAgentName,
    repoName: node.repoName,
    runtimeNetworkPlan,
    runtimeRouterEnv,
  }, computeEnvHashImpl);
  const desiredEnvHash = runtimeNetworkPlan.requiresManagedNetwork
    ? computeRetainedManagedEnvHashImpl(
        node,
        record,
        profileResolution.profileConfig,
        runtimeNetworkPlan,
        retainedManagedEnvHashOptions,
      )
    : baseEnvHash;
  if (runtimeNetworkPlan.requiresManagedNetwork && !desiredEnvHash) {
    return 'managedRouterDescriptorDrift';
  }
  const observedEnvHash = desiredEnvHash ? getContainerLabelImpl(existing.key, 'ploinky.envhash') : '';
  if (desiredEnvHash && desiredEnvHash !== observedEnvHash) {
    plan.runtimeReasonDetail = hashMismatchDetail('envHash', observedEnvHash, desiredEnvHash);
    return 'envHashChanged';
  }
  // The same admitted descriptor drives creation, adoption and reuse: its
  // limits hash (empty without hardware placement) must match the runtime.
  const admitted = admitRuntimeImpl(node, profileResolution, { runtime, recordAlias: record.alias || '', key: existing.key });
  const admittedDescriptor = admitted?.descriptor || null;
  const limitsReason = admittedDescriptor
    ? limitsHashReuseReason(admittedDescriptor, getContainerLabelImpl(existing.key, LIMITS_HASH_LABEL))
    : null;
  if (limitsReason) {
    plan.runtimeReasonDetail = limitsHashDetail(admittedDescriptor, getContainerLabelImpl(existing.key, LIMITS_HASH_LABEL));
    return limitsReason;
  }
  if (isLlmRuntimeManifestImpl(node.manifest, profileResolution.profileConfig)) {
    const probe = prepareLlmStartupImpl({
      runtime,
      manifest: node.manifest,
      profileConfig: profileResolution.profileConfig,
      agentName: node.shortAgentName,
      alias: node.alias || '',
      env: process.env,
      agentWorkDirRoot: AGENTS_DATA_DIR,
      manifestEnvNames: [
        ...getManifestEnvNamesImpl(node.manifest, profileResolution.profileConfig, { forRuntime: true }),
        ...getExposedNamesImpl(node.manifest, profileResolution.profileConfig, { forRuntime: true }),
      ],
      envHash: baseEnvHash,
      effectiveNetwork: profileResolution.profileConfig?.network ?? node.manifest?.network ?? null,
      writeState: false,
      // Reuse uses the same admitted policy as creation (stored overrides
      // included); otherwise a limited LLM agent would restart on every start.
      ...(admittedDescriptor ? { admittedRuntimePolicy: admittedDescriptor.runtimePolicy } : {}),
      ...(admitted?.llmStartup ? {
        resolvedSelection: admitted.llmStartup.selection,
        resolvedHardware: admitted.llmStartup.hardware,
      } : {}),
    });
    const observedReuseHash = probe.enabled && probe.reuseHash
      ? getContainerLabelImpl(existing.key, 'ploinky.reusehash')
      : '';
    if (probe.enabled
        && probe.reuseHash
        && probe.reuseHash !== observedReuseHash) {
      plan.runtimeReasonDetail = hashMismatchDetail('reuseHash', observedReuseHash, probe.reuseHash);
      return 'llmReuseHashChanged';
    }
  }

  const inspection = createNetworkLifecycleAdapterImpl({ runtime }).inspectContainerContract(
    existing.key,
    profileResolution.network,
    node.shortAgentName,
    {
      instanceKey: effectiveGraphInstanceKey(node),
      contractHash: networkContractHash(profileResolution.network),
      instanceId: record.instanceId,
      enableGeneration: record.enableGeneration,
      requireRuntimeIdentity: true,
    },
  );
  if (inspection?.state === 'foreign') {
    throw new Error(`refusing graph replacement of foreign runtime '${existing.key}'`);
  }
  if (inspection?.state === 'owned-drift') {
    return inspection.reason === 'runtime-identity'
      ? 'runtimeIdentityDrift'
      : 'networkContractDrift';
  }
  return '';
}

// A metadata admission of a graph node's current inputs, used only to compare
// reuse against creation; it never authorizes rendering.
function admitGraphNodeHardwareDescriptor(node, profileResolution, { runtime, recordAlias, key }) {
  try {
    const manifestPath = node.manifestPath || (node.agentPath ? path.join(node.agentPath, 'manifest.json') : '');
    if (!manifestPath || !fs.existsSync(manifestPath)) return null;
    const manifestBytes = fs.readFileSync(manifestPath);
    const manifest = JSON.parse(manifestBytes.toString('utf8'));
    const llmAdmissionContext = resolveLlmRuntimeAdmissionContext({
      runtime,
      manifest,
      profileConfig: profileResolution.profileConfig,
      agentName: node.shortAgentName,
      alias: node.alias || recordAlias,
      env: process.env,
    });
    const { descriptor } = admitManifestRuntimeCapabilities(manifest, {
      manifestBytes,
      manifestPath,
      agentId: `${node.repoName}/${node.shortAgentName}`,
      profileName: profileResolution.resolvedProfileName,
      profileConfig: profileResolution.profileConfig,
      network: profileResolution.network,
      runtime,
      runtimeKind: 'container',
      catalogPolicy: llmAdmissionContext.catalogPolicy,
      catalogIdentity: llmAdmissionContext.catalogIdentity,
      hardwareAdmission: 'metadata',
      instanceKey: key,
      alias: node.alias || recordAlias || '',
    });
    return { descriptor, llmStartup: llmAdmissionContext.startup || null };
  } catch (_) {
    // Admission errors surface on the launch path itself.
    return null;
  }
}

function resolveExtraEnabledRuntimeNodes(graph, reg, getAgentContainerName = dockerSvc.getAgentContainerName) {
  const graphRegistryNames = new Set();
  for (const node of graph?.nodes?.values?.() || []) {
    const existing = findRegistryEntryForGraphNode(reg, node, getAgentContainerName);
    if (existing) graphRegistryNames.add(existing.key);
  }
  return Object.entries(reg || {})
    .filter(([containerName, record]) => (
      containerName !== '_config'
      && record?.type === 'agent'
      && !graphRegistryNames.has(containerName)
    ))
    .sort(([left], [right]) => left.localeCompare(right))
    .map(([containerName, record]) => {
      const ref = record.repoName
        ? `${record.repoName}/${record.agentName}`
        : record.agentName;
      const resolved = utils.findAgent(ref);
      const manifest = JSON.parse(fs.readFileSync(resolved.manifestPath, 'utf8'));
      return {
        id: `extra:${containerName}`,
        agentRef: ref,
        agentPath: path.dirname(resolved.manifestPath),
        alias: record.alias || '',
        manifest,
        manifestPath: resolved.manifestPath,
        profile: record.profile || '',
        repoName: resolved.repo,
        shortAgentName: resolved.shortAgentName,
      };
    });
}

function loadRegistryManifest(record) {
  const manifestRef = `${record.repoName}/${record.agentName}`;
  const manifestPath = findAgentManifest(manifestRef);
  return JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
}

// Native PID records are keyed by the exact container name and carry the
// record's tuple. The short agent name or alias names no runtime.
export function isRegistryRuntimeRunning(containerName, record, {
  observeImpl = observeSandboxRuntime,
} = {}) {
  if (isSandboxRuntime(record?.runtime)) {
    const tuple = registeredRuntimeTuple(record);
    if (!tuple) throw sandboxOwnershipUnknown(containerName, 'registry record has no exact runtime tuple');
    const observed = observeImpl(containerName, { expectedIdentity: tuple });
    if (observed.state === 'unknown') throw sandboxOwnershipUnknown(containerName, observed.reason);
    return observed.state === 'live-exact';
  }
  return dockerSvc.isContainerRunning(containerName);
}

// The exact registry containerName a graph node will use: its retained record
// or the conventional name staging will create.
function graphNodeRegistryKey(node, registry, getAgentContainerName = dockerSvc.getAgentContainerName) {
  if (String(node?.id || '').startsWith('extra:')) return node.id.slice('extra:'.length);
  const existing = findRegistryEntryForGraphNode(registry || {}, node, getAgentContainerName);
  return existing?.key || getAgentContainerName(node.alias || node.shortAgentName, node.repoName);
}

// Graph-wide admission is metadata-only for hardware eligibility (plan §9.1):
// a hardware refusal is recorded in the admission record, every other
// capability error stays strict, and no record can authorize argument
// rendering.
export function admitWorkspaceGraphRuntimeCapabilities(graph, {
  additionalNodes = [],
  registry = null,
  hardwareContext,
  boxMarkerOptions,
  getAgentContainerName = dockerSvc.getAgentContainerName,
} = {}) {
  const nodes = [
    ...Array.from(graph?.nodes?.values?.() || []),
    ...(Array.isArray(additionalNodes) ? additionalNodes : []),
  ].sort((a, b) => a.id.localeCompare(b.id));

  const admissions = [];
  for (const node of nodes) {
    const manifestPath = node.manifestPath
      || (node.agentPath ? path.join(node.agentPath, 'manifest.json') : '');
    const hasExactManifestFile = manifestPath && fs.existsSync(manifestPath);
    const manifestBytes = hasExactManifestFile
      ? fs.readFileSync(manifestPath)
      : Buffer.from(JSON.stringify(node.manifest || {}));
    const manifest = hasExactManifestFile
      ? JSON.parse(manifestBytes.toString('utf8'))
      : node.manifest || {};
    const profileResolution = resolveManifestRuntimeProfile(manifest, {
      agentName: `${node.repoName}/${node.shortAgentName}`,
      // In-memory graph fixtures have no independent profile namespace to
      // resolve. Production graph nodes always carry the exact manifest path.
      profileName: hasExactManifestFile ? (node.profile || undefined) : undefined,
      path: `manifest(${node.repoName}/${node.shortAgentName})`,
    });
    const runtime = getRuntimeForAgent(manifest);
    const runtimeKind = isSandboxRuntime(runtime) ? runtime : 'container';
    const llmAdmissionContext = runtimeKind === 'container'
      ? resolveLlmRuntimeAdmissionContext({
        runtime,
        manifest,
        profileConfig: profileResolution.profileConfig,
        agentName: node.shortAgentName,
        alias: node.alias,
        env: process.env,
      })
      : { catalogPolicy: null, catalogIdentity: null };
    const key = graphNodeRegistryKey(node, registry, getAgentContainerName);
    const admission = admitManifestRuntimeCapabilities(manifest, {
      manifestBytes,
      manifestPath: manifestPath || `manifest(${node.repoName}/${node.shortAgentName})`,
      agentId: `${node.repoName}/${node.shortAgentName}`,
      profileName: profileResolution.resolvedProfileName,
      profileConfig: profileResolution.profileConfig,
      network: profileResolution.network,
      runtime,
      runtimeKind,
      catalogPolicy: llmAdmissionContext.catalogPolicy,
      catalogIdentity: llmAdmissionContext.catalogIdentity,
      hardwareAdmission: 'metadata',
      ...(hardwareContext !== undefined ? { hardwareContext } : {}),
      ...(boxMarkerOptions !== undefined ? { boxMarkerOptions } : {}),
      instanceKey: key,
      alias: node.alias || '',
    });
    admissions.push(Object.freeze({
      nodeId: node.id,
      key,
      alias: node.alias || '',
      manifestPath: hasExactManifestFile ? manifestPath : '',
      manifestBytesBase64: Buffer.from(manifestBytes).toString('base64'),
      profileName: profileResolution.resolvedProfileName,
      runtimeKind,
      admission,
      hardwareRefusal: hardwareRefusalOf(admission),
    }));
  }
  return Object.freeze(admissions);
}

export function assertWorkspaceGraphAdmissionsCurrent(admissions, { hardwareContext, boxMarkerOptions } = {}) {
  for (const record of admissions || []) {
    const manifestBytes = record.manifestPath
      ? fs.readFileSync(record.manifestPath)
      : Buffer.from(record.manifestBytesBase64, 'base64');
    assertRuntimeAdmissionCurrent(record.admission, {
      manifestBytes,
      profileName: record.profileName,
      runtimeKind: record.runtimeKind,
      ...(hardwareContext !== undefined ? { hardwareContext } : {}),
      ...(boxMarkerOptions !== undefined ? { boxMarkerOptions } : {}),
    });
  }
  return admissions;
}

// Classify every admitted graph node as eligible, refused or blocked through
// the U15 blocking relation. Keys are exact registry containerNames.
export function classifyWorkspaceGraphAvailability(graph, admissions, { explicitWaits = [] } = {}) {
  const keyByNodeId = new Map((admissions || []).map((record) => [record.nodeId, record.key]));
  const nodes = (admissions || []).map((record) => ({
    key: record.key,
    ref: record.admission.agentId,
    alias: record.alias || null,
    refusal: record.hardwareRefusal || null,
  }));
  const edges = blockingEdgesFromGraph(graph, (nodeId) => keyByNodeId.get(nodeId), { explicitWaits });
  const classified = classifyAvailability({ nodes, edges });
  const byNodeId = new Map();
  for (const record of admissions || []) byNodeId.set(record.nodeId, classified.get(record.key));
  return Object.freeze({ byKey: classified, byNodeId, edges });
}

// A direct refusal re-keyed to the exact admitted instance it belongs to (its
// own key and root cause are that instance).
function rekeyHardwareRefusal(refusal, key) {
  return validateHardwareOutcome({
    ...refusal,
    key,
    rootCause: { ...refusal.rootCause, key },
    causalPath: [key],
  });
}

/**
 * The start's current availability: graph metadata outcomes plus hardware
 * refusals raised at launch (a readback refusal or the strict admission
 * recheck). A launch refusal is contained like a metadata one (U10/U14/U15,
 * §9.4): it is recorded, and its blocking and explicit-status-wait consumers
 * are reclassified as blocked so they are never launched.
 */
export function createGraphAvailabilityTracker(graph, admissions, { explicitWaits = [] } = {}) {
  const launchRefusals = new Map();
  let current = classifyWorkspaceGraphAvailability(graph, admissions, { explicitWaits });
  const admittedKeys = new Set((admissions || []).map((record) => record.key));
  const unavailable = (entry) => Boolean(entry && entry.state !== 'eligible');
  const unavailableEntries = () => [...current.byNodeId]
    .filter(([, entry]) => unavailable(entry))
    .map(([nodeId, entry]) => ({ nodeId, key: entry.outcome.key, outcome: entry.outcome }));
  return Object.freeze({
    outcomeForNode(nodeId) {
      const entry = current.byNodeId.get(nodeId);
      return unavailable(entry) ? entry.outcome : null;
    },
    outcomeForKey(key) {
      if (!admittedKeys.has(key)) return launchRefusals.get(key) || null;
      const entry = current.byKey.get(key);
      return unavailable(entry) ? entry.outcome : null;
    },
    unavailableEntries,
    // Record one launch-time refusal; returns every exact instance that
    // became unavailable because of it (the refused one first). A refusal
    // whose key is not an admitted key but whose ref matches an admitted
    // instance is mapped to that instance by ref and alias, or fails
    // loudly; it is never treated as an unrelated extra.
    recordLaunchRefusal(outcome) {
      let refusal = validateHardwareOutcome(outcome);
      if (!admittedKeys.has(refusal.key)) {
        const sameRef = (admissions || []).filter((record) => record.admission?.agentId === refusal.ref);
        if (sameRef.length) {
          const sameAlias = sameRef.filter((record) => (record.alias || null) === (refusal.alias || null));
          if (sameAlias.length !== 1) {
            throw new Error(`start: hardware refusal for '${refusal.key}' (${refusal.ref}, alias ${refusal.alias || 'none'}) `
              + `matches the admitted instances ${sameRef.map((record) => record.key).join(', ')} but not exactly one by alias; `
              + 'it cannot be contained as an unrelated agent');
          }
          refusal = rekeyHardwareRefusal(refusal, sameAlias[0].key);
        }
      }
      if (!admittedKeys.has(refusal.key)) {
        // An enabled extra outside the admitted graph: contained by itself.
        const known = launchRefusals.has(refusal.key);
        launchRefusals.set(refusal.key, refusal);
        return known ? [] : [{ nodeId: null, key: refusal.key, outcome: refusal }];
      }
      const before = new Set(unavailableEntries().map((entry) => entry.key));
      launchRefusals.set(refusal.key, refusal);
      const amended = (admissions || []).map((record) => (launchRefusals.has(record.key)
        ? { ...record, hardwareRefusal: launchRefusals.get(record.key) }
        : record));
      current = classifyWorkspaceGraphAvailability(graph, amended, { explicitWaits });
      return unavailableEntries()
        .filter((entry) => !before.has(entry.key))
        .sort((left, right) => {
          if (left.key === refusal.key) return -1;
          if (right.key === refusal.key) return 1;
          return left.key.localeCompare(right.key);
        });
    },
  });
}

/**
 * Fold one MPS graph preparation into the start's availability: a contained
 * preparation failure refuses only the graph's GPU-share agents (U10, §9.1),
 * whose nodes are then excluded from launch while every other node starts.
 */
export function recordMpsGraphPreparation(prepared, { availability, unavailableNodeIds, warn = (line) => console.warn(line) }) {
  if (prepared.diagnostic) warn(`[hardware-limits] ${prepared.diagnostic.message}. ${prepared.diagnostic.fix}`);
  for (const refusal of prepared.refusals || []) availability.recordLaunchRefusal(refusal);
  for (const entry of availability.unavailableEntries()) unavailableNodeIds.add(entry.nodeId);
  return prepared;
}

/**
 * The availability projection for each unavailable exact instance that has a
 * registry record: its logical route key and the validated projection that
 * removes every runtime target (§9.2, §9.4).
 */
export function unavailableRouteProjections(entries, { registry = {}, registryNameByNodeId = new Map() } = {}) {
  const projections = [];
  for (const { nodeId, key: outcomeKey, outcome } of entries || []) {
    const key = (nodeId && registryNameByNodeId.get(nodeId))
      || (nodeId?.startsWith('extra:') ? nodeId.slice('extra:'.length) : '')
      || (nodeId ? '' : outcomeKey);
    const record = key ? registry[key] : null;
    if (!record) continue;
    if (key !== outcome.key) {
      throw new Error(`start: hardware outcome for '${nodeId || outcomeKey}' does not match its staged registry identity`);
    }
    projections.push({
      routeKey: record.alias || record.agentName,
      projection: buildAvailabilityProjection({
        outcome,
        instanceId: record.instanceId,
        enableGeneration: record.enableGeneration,
      }),
    });
  }
  return projections;
}

/**
 * Launch one batch of route targets. A typed hardware outcome raised by the
 * launch is a contained refusal: it is handed to onHardwareRefusal and never
 * counted as an ordinary failure. Every other failure keeps the baseline
 * semantics: it throws "N agent(s) failed to start", or with allowFailures is
 * returned in failedAgents.
 */
export async function launchRouteTargets(targetNames, {
  launchTarget,
  commitResults = async () => {},
  onHardwareRefusal = async () => {},
  allowFailures = false,
  log = console,
} = {}) {
  if (!Array.isArray(targetNames) || !targetNames.length) {
    return { failedAgents: [], routeResults: [], hardwareRefusals: [] };
  }
  const settled = await Promise.all(targetNames.map(async (name) => {
    try {
      return await launchTarget(name);
    } catch (agentErr) {
      const outcome = findHardwareOutcome(agentErr);
      const shortAgentName = agentErr?.shortAgentName || name;
      // A refusal never hides a refused candidate that could not be removed:
      // that is an ordinary, fatal failure naming the leftover container.
      const leftover = outcome ? exactCleanupFailureOf(agentErr) : null;
      if (!outcome) {
        log.error(`[start] Failed to start agent '${shortAgentName}': ${agentErr?.message}`);
      } else if (leftover) {
        const container = `${leftover.containerName || name}${leftover.containerId ? ` (${leftover.containerId.slice(0, 12)})` : ''}`;
        log.error(`[start] Failed to start agent '${shortAgentName}': ${agentErr?.message}; the refused candidate container `
          + `${container} was not removed; remove it, then run start again`);
      }
      return { ok: false, name, shortAgentName, hardwareOutcome: leftover ? null : outcome };
    }
  }));
  const routeResults = settled.filter((result) => result?.ok);
  const failedAgents = settled.filter((result) => result && !result.ok && !result.hardwareOutcome)
    .map((result) => result.shortAgentName);
  const hardwareRefusals = settled.filter((result) => result && !result.ok && result.hardwareOutcome);
  await commitResults(settled);
  for (const refused of hardwareRefusals) await onHardwareRefusal(refused.hardwareOutcome, refused.name);
  if (failedAgents.length > 0) {
    const message = `${failedAgents.length} agent(s) failed to start: ${failedAgents.join(', ')}`;
    if (allowFailures) {
      log.warn(`[start] ${message}`);
      return { failedAgents, routeResults, hardwareRefusals };
    }
    throw new Error(message);
  }
  return { failedAgents, routeResults, hardwareRefusals };
}

/**
 * The start's hardware containment, shared by startWorkspace and its tests
 * (U10/U14/U15, §9.4). It reports each refused or blocked exact instance once,
 * projects unavailable instances onto their logical routes (no runtime
 * target), and launches route targets so that a typed hardware outcome raised
 * at launch is recorded in `availability`, projected, and its blocking and
 * explicit-status-wait consumers become blocked; unrelated agents continue.
 * `registry` is a getter for the live registry; `applyUnavailableRoutes`
 * writes [{routeKey, projection}] to the routing configuration.
 */
export function createStartLaunchContainment({
  availability,
  registry,
  registryNameByNodeId = new Map(),
  applyUnavailableRoutes,
  log = console,
}) {
  const hardwareOutcomes = { refused: [], blocked: [] };
  const recordedOutcomeKeys = new Set();
  const reportOutcome = (outcome) => {
    if (!outcome || recordedOutcomeKeys.has(outcome.key)) return;
    recordedOutcomeKeys.add(outcome.key);
    hardwareOutcomes[outcome.state === 'refused' ? 'refused' : 'blocked'].push(outcome);
    log.warn(`[start] ${formatHardwareOutcome(outcome)}`);
  };
  // Refused/blocked instances keep their logical routes but lose every
  // runtime target; the unavailable state is compiled into the generation.
  const markUnavailable = async (entries) => {
    const unavailableRoutes = unavailableRouteProjections(entries, { registry: registry(), registryNameByNodeId });
    if (!unavailableRoutes.length) return;
    await applyUnavailableRoutes(unavailableRoutes);
  };
  const containLaunchRefusal = async (outcome) => {
    const affected = availability.recordLaunchRefusal(outcome);
    await markUnavailable(affected);
    for (const entry of affected) reportOutcome(entry.outcome);
  };
  const launchTargets = (targetNames, { launchOne, commitResults, allowFailures = false }) => launchRouteTargets(targetNames, {
    launchTarget: async (name) => {
      try {
        return await launchOne(name);
      } catch (agentErr) {
        // launchRouteTargets reports it: a typed hardware outcome is a
        // contained refusal, anything else an ordinary failure.
        try { agentErr.shortAgentName = registry()?.[name]?.agentName || name; } catch (_) { /* reported by registry name */ }
        throw agentErr;
      }
    },
    allowFailures,
    commitResults,
    onHardwareRefusal: containLaunchRefusal,
    log,
  });
  return Object.freeze({ hardwareOutcomes, reportOutcome, markUnavailable, containLaunchRefusal, launchTargets });
}

/**
 * Launch the blocking members of every dependency wave, as startWorkspace
 * does. Refused or blocked instances (from graph metadata or refused at
 * launch) get no runtime create, readiness probe or start hook; unrelated
 * agents continue. Ordinary failures stay fatal exactly as before.
 */
export async function launchWorkspaceGraphWaves({
  graphWaves = [],
  nodes = new Map(),
  noWaitNodeIds = new Set(),
  registryNameByNodeId = new Map(),
  availability,
  launch,
  readinessEntryFor,
  waitForReadiness,
  reportOutcome,
  formatLabel = (node) => node.id,
  log = console.log,
}) {
  const readyAgentKeys = [];
  const deferredNoWaitWaves = [];
  for (let waveIndex = 0; waveIndex < graphWaves.length; waveIndex += 1) {
    const waveNodes = graphWaves[waveIndex].map((nodeId) => nodes.get(nodeId)).filter(Boolean);
    if (!waveNodes.length) continue;
    // Blocking nodes follow the wave-by-wave start/readiness path. Defer
    // detached no-wait workers until every coordinated blocking launch is
    // complete so their independent route applies cannot transiently
    // inactivate an exact host-generation capability during process create.
    const blockingNodes = [];
    const noWaitWaveNodes = [];
    for (const node of waveNodes) {
      if (noWaitNodeIds.has(node.id)) {
        noWaitWaveNodes.push({ node, registryName: registryNameByNodeId.get(node.id) });
      } else if (availability.outcomeForNode(node.id)) {
        // Refused or blocked: no runtime create, readiness probe or start
        // hook; the route stays target-less and unavailable.
        reportOutcome(availability.outcomeForNode(node.id));
      } else {
        blockingNodes.push(node);
      }
    }
    const blockingLabel = blockingNodes.length ? blockingNodes.map(formatLabel).join(', ') : '<none>';
    const noWaitLabel = noWaitWaveNodes.map(({ node }) => formatLabel(node)).join(', ');
    log(`[start] Dependency wave ${waveIndex + 1}/${graphWaves.length}: ${noWaitLabel ? `${blockingLabel} (no-wait: ${noWaitLabel})` : blockingLabel}`);
    if (noWaitWaveNodes.length) deferredNoWaitWaves.push(noWaitWaveNodes);
    const blockingNames = blockingNodes.map((node) => registryNameByNodeId.get(node.id)).filter(Boolean);
    const blockingLaunch = blockingNames.length ? await launch(blockingNames) : { routeResults: [] };
    // A member refused at launch is excluded from readiness waits.
    const launchedNodes = blockingNodes.filter((node) => !availability.outcomeForNode(node.id));
    if (!launchedNodes.length) continue;
    await waitForReadiness(launchedNodes.map((node) => readinessEntryFor(node, blockingLaunch)));
    readyAgentKeys.push(...launchedNodes.map((node) => registryNameByNodeId.get(node.id)).filter(Boolean));
  }
  return { readyAgentKeys, deferredNoWaitWaves };
}

/**
 * Launch the enabled agents outside the dependency graph. A hardware refusal
 * (known from metadata or raised at launch) is contained; any other failure
 * keeps the baseline error that leaves edge selectors inactive.
 */
export async function launchAdditionalRuntimes({
  additionalNames = [],
  availability,
  launch,
  readinessEntryFor,
  waitForReadiness,
  reportOutcome,
}) {
  const readyAgentKeys = [];
  for (const name of additionalNames) {
    const outcome = availability.outcomeForKey(name);
    if (outcome) reportOutcome(outcome);
  }
  const launchable = additionalNames.filter((name) => !availability.outcomeForKey(name));
  if (launchable.length) {
    const extra = await launch(launchable, { allowFailures: true });
    if (extra.failedAgents.length !== 0) {
      throw new Error('additional runtime failure left edge selectors inactive; repair and run start again');
    }
    const launched = extra.routeResults.filter((result) => !availability.outcomeForKey(result.containerName));
    await waitForReadiness(launched.map((result) => readinessEntryFor(result)));
    readyAgentKeys.push(...launched.map((result) => result.containerName));
  }
  return { readyAgentKeys };
}

// Match on every immutable field, never on the container name alone: only the
// exact staged tuple the worker was launched with can let it resume.
function supersededNoWaitRunFor(runs, containerName, record) {
  const alias = record?.alias === undefined || record?.alias === null ? '' : record.alias;
  return (Array.isArray(runs) ? runs : []).find(({ identity } = {}) => (
    identity?.containerName === containerName
      && identity.instanceId === record?.instanceId
      && identity.enableGeneration === record?.enableGeneration
      && identity.repoName === record?.repoName
      && identity.shortAgent === record?.agentName
      && identity.alias === alias
  )) || null;
}

function ensureGraphNodesEnabled(graph, reg, {
  prepareAgentEnableBatch = agentsSvc.prepareAgentEnableBatch,
  removeAgentContainerForRecreate = removeGraphContainerForRecreate,
  saveAgents = workspaceSvc.saveAgents,
  loadRouting = readRoutingConfig,
  saveRouting = (routing) => writeRoutingConfig(routing, { coordinate: false }),
  inactivateGeneration = inactivateEdgeRoutingGeneration,
  abortPreparation = abortEdgeRoutingPreparation,
  retireNoWaitMarkers = retireNoWaitRunMarkers,
  uuid = randomUUID,
  deferredNodeIds = new Set(),
  runtimeReplacementReason = graphNodeRuntimeReplacementReason,
  runtimeReplacementOptions,
  executionRecordOptions,
  additionalNodes = [],
  hardwareContext,
  boxMarkerOptions,
  unavailableNodeIds = new Set(),
  logLine = (line) => console.log(line),
  supersededNoWaitRuns = [],
  readRuntimePredecessorImpl = readRuntimePredecessor,
  writeRuntimePredecessorImpl = writeRuntimePredecessor,
  retireRuntimePredecessorImpl = retireRuntimePredecessor,
  observeSandboxRuntimeImpl = observeSandboxRuntime,
} = {}) {
  const nodes = [
    ...Array.from(graph?.nodes?.values?.() || []),
    ...(Array.isArray(additionalNodes) ? additionalNodes : []),
  ]
    .sort((a, b) => a.id.localeCompare(b.id));

  // Resolve and validate every retained record before removing anything. If a
  // later devel target is invalid, the complete existing stack is left alone.
  const existingPlans = [];
  const missingNodes = [];

  // Keep the physical preparation boundary independently fail-closed even
  // though startWorkspace performs the same complete-graph gate before locks.
  // Hardware eligibility is metadata here: a refusal is staged, not thrown.
  admitWorkspaceGraphRuntimeCapabilities(graph, {
    additionalNodes,
    registry: reg,
    ...(hardwareContext !== undefined ? { hardwareContext } : {}),
    ...(boxMarkerOptions !== undefined ? { boxMarkerOptions } : {}),
  });

  for (const node of nodes) {
    const existing = findRegistryEntryForGraphNode(reg, node, dockerSvc.getAgentContainerName);
    if (!existing) {
      missingNodes.push(node);
      continue;
    }

    const normalizedExecution = agentsSvc.normalizeEnableArgs(node.enableSpec || node.agentRef);
    const hasExplicitExecutionMode = agentsSvc.isEnableAgentMode(normalizedExecution.mode);
    const expectedExecution = hasExplicitExecutionMode
      ? resolveGraphNodeExecutionRecord(node, executionRecordOptions)
      : resolveRetainedGraphNodeExecutionRecord(node, existing.rec, executionRecordOptions);
    const executionChanged = executionRecordDiffers(existing.rec, expectedExecution);
    const profileChanged = Boolean(node.profile && existing.rec.profile !== node.profile);
    const executionDifferences = executionChanged
      ? executionRecordDifferences(existing.rec, expectedExecution)
      : [];
    const predecessorBackend = resolvePredecessorBackend(node, existing, {
      observeImpl: observeSandboxRuntimeImpl,
      readReceiptImpl: readRuntimePredecessorImpl,
      getRuntimeForAgentImpl: runtimeReplacementOptions?.getRuntimeForAgentImpl,
    });
    const preliminary = {
      node, existing, expectedExecution, executionChanged, profileChanged, predecessorBackend,
    };
    // A stalled worker of an earlier start still holds this exact staged
    // identity and would resume under any generation that carries it again, so
    // the identity always rotates and its unpublished runtime is removed.
    const superseded = supersededNoWaitRunFor(supersededNoWaitRuns, existing.key, existing.rec);
    // A refused or blocked instance keeps no authority: an existing runtime is
    // revoked by identity rotation and removed through exact ownership checks.
    const hardwareUnavailable = unavailableNodeIds.has(node.id)
      && (runtimeReplacementOptions?.containerExistsImpl || dockerSvc.containerExists)(existing.key);
    let runtimeReason = '';
    if (!executionChanged && !profileChanged) {
      runtimeReason = hardwareUnavailable
        ? 'hardwareUnavailable'
        : superseded
          ? 'noWaitRunSuperseded'
          : String(runtimeReplacementReason(preliminary, runtimeReplacementOptions) || '');
    }
    // A start that stopped after persisting this record's rotated tuple but
    // before removing its predecessor left that predecessor's own tuple in a
    // receipt keyed by the rotated one. Only that tuple proves the container.
    const priorPredecessorReceipt = executionChanged || profileChanged || runtimeReason
      ? readRuntimePredecessorImpl(existing.key, existing.rec)
      : null;
    const predecessorRecord = priorPredecessorReceipt
      ? { ...structuredClone(existing.rec), ...structuredClone(priorPredecessorReceipt.predecessor) }
      : structuredClone(existing.rec);
    // A runtime-less record proven native names its kind from here on, so the
    // receipt and the removal take the native path.
    if (isSandboxRuntime(predecessorBackend) && !isSandboxRuntime(predecessorRecord.runtime)) {
      predecessorRecord.runtime = predecessorBackend;
    }
    // Capture the native predecessor's process evidence before anything is
    // rotated. A slot that cannot be verified refuses the whole graph now,
    // while nothing has been inactivated, rotated or signalled.
    let predecessorProcess = null;
    if ((executionChanged || profileChanged || runtimeReason)
        && isSandboxRuntime(predecessorRecord.runtime)
        && hasCompleteRuntimeTuple(predecessorRecord)) {
      const observed = observeSandboxRuntimeImpl(existing.key, {
        expectedIdentity: {
          instanceId: predecessorRecord.instanceId,
          enableGeneration: predecessorRecord.enableGeneration,
        },
      });
      if (observed.state === 'unknown') throw sandboxOwnershipUnknown(existing.key, observed.reason);
      if (observed.state === 'live-exact') {
        predecessorProcess = {
          pid: observed.record.pid,
          processIdentity: observed.record.processIdentity,
        };
      }
    }
    if (isSandboxRuntime(predecessorRecord.runtime)) delete predecessorRecord.process;
    existingPlans.push({
      ...preliminary,
      executionDifferences,
      runtimeReason,
      registryRecord: structuredClone(existing.rec),
      priorPredecessorReceipt,
      predecessorProcess,
      // The desired registry receives a fresh candidate tuple before removal
      // so the inactive generation can be compiled. Keep a detached snapshot
      // as the only ownership proof authorized to remove the predecessor.
      predecessorRecord,
    });
  }

  const changedPlans = existingPlans
    .filter((plan) => plan.executionChanged || plan.profileChanged || plan.runtimeReason)
    .sort((left, right) => left.node.id.localeCompare(right.node.id));
  const changedContainers = changedPlans.map((plan) => plan.existing.key);
  // Say why each runtime is replaced before anything is revoked or removed.
  for (const plan of changedPlans) logLine(graphReplacementLine(plan));
  // Every retained route must be target-less in the prelaunch generation,
  // including a healthy blocking runtime that can later be reused. Keeping a
  // predecessor's resolved hostPort here would make the topology
  // prepared for hooks only nominally reconciling rather than truly target-less.
  // Identity rotation and physical removal remain limited to changedPlans.
  const stagedPlans = existingPlans
    .sort((left, right) => left.node.id.localeCompare(right.node.id));
  let routing = null;
  if (stagedPlans.length) {
    // Authorization is revoked before either desired-state file changes and
    // before the old process is touched. A failed compile or physical removal
    // intentionally leaves the fresh identity generation selected inactive.
    inactivateGeneration('workspace-graph-runtime-change-prelaunch');
    routing = loadRouting();
    routing.routes = routing.routes || {};
  }

  const missingContainerNames = missingNodes.map((node) => (
    dockerSvc.getAgentContainerName(node.alias || node.shortAgentName, node.repoName)
  ));

  for (const plan of stagedPlans) {
    const identityChanged = plan.executionChanged || plan.profileChanged || plan.runtimeReason;
    const freshIdentity = identityChanged
      ? mintChangedRuntimeIdentityPair(plan.existing.rec, uuid)
      : null;
    const nextRecord = identityChanged
      ? {
          ...plan.existing.rec,
          instanceId: freshIdentity.instanceId,
          enableGeneration: freshIdentity.enableGeneration,
        }
      : plan.existing.rec;
    if (plan.executionChanged) {
      nextRecord.runMode = plan.expectedExecution.runMode;
      nextRecord.projectPath = plan.expectedExecution.projectPath;
      if (plan.expectedExecution.runMode === 'devel') {
        nextRecord.develRepo = plan.expectedExecution.develRepo;
      } else {
        delete nextRecord.develRepo;
      }
    }
    if (plan.profileChanged) {
      nextRecord.profile = plan.node.profile;
    }
    if (identityChanged) reg[plan.existing.key] = nextRecord;
    const routeKey = nextRecord.alias || plan.node.alias || plan.node.shortAgentName;
    routing.routes[routeKey] = mergeRuntimeRoute(routing.routes[routeKey], {
      container: plan.existing.key,
      hostPath: plan.node.agentPath || routing.routes[routeKey]?.hostPath,
      repo: plan.node.repoName,
      agent: plan.node.shortAgentName,
      ...(nextRecord.alias ? { alias: nextRecord.alias } : {}),
    }, { hostPort: null });
  }

  if (stagedPlans.length) {
    // The fixed marker is an observer capability for one exact staged tuple.
    // Retire it before either desired-state file can select a replacement or
    // a successful target-less transition can complete without a new worker.
    retireNoWaitMarkers([
      ...stagedPlans.map((plan) => ({
        containerName: plan.existing.key,
        record: plan.registryRecord,
      })),
      ...missingContainerNames,
    ]);
    // The rotated registry below keeps each predecessor's container ID under
    // the fresh tuple. Make every predecessor's own tuple durable first, so a
    // start stopped before the removal loop completes stays recoverable.
    for (const plan of changedPlans) {
      if (!hasCompleteRuntimeTuple(plan.predecessorRecord)) continue;
      plan.predecessorReceipt = writeRuntimePredecessorImpl({
        containerName: plan.existing.key,
        successor: reg[plan.existing.key],
        predecessor: plan.predecessorProcess
          ? { ...plan.predecessorRecord, process: plan.predecessorProcess }
          : plan.predecessorRecord,
      });
    }
    if (changedPlans.length) saveAgents(reg, { coordinate: false });
    // The receipts just written now carry every earlier receipt's predecessor.
    for (const plan of changedPlans) {
      if (!plan.priorPredecessorReceipt) continue;
      try { retireRuntimePredecessorImpl(plan.priorPredecessorReceipt); } catch (_) {}
    }
    saveRouting(routing);
  } else if (missingContainerNames.length) {
    // prepareAgentEnableBatch persists the new registry tuple, so stale marker
    // retirement must precede that call even when this graph has no retained
    // records to stage itself.
    retireNoWaitMarkers(missingContainerNames);
  }

  const prepared = prepareAgentEnableBatch(missingNodes.map((node) => ({
    agentName: node.enableSpec || node.agentRef,
    aliasParam: node.alias || undefined,
    authOptions: {
      profile: node.profile || undefined,
    },
  })), {
    reason: 'workspace-graph-enable-prelaunch',
    availabilityMode: 'replacement',
    hardwareAdmission: 'metadata',
    ...(hardwareContext !== undefined ? { hardwareContext } : {}),
    ...(boxMarkerOptions !== undefined ? { boxMarkerOptions } : {}),
  });
  if (prepared?.preparedGeneration?.selector
      && prepared.preparedGeneration.selector.state !== 'inactive') {
    throw new Error('workspace graph prelaunch generation unexpectedly became active');
  }

  try {
    for (const plan of changedPlans) {
      const reasons = [
        ...(plan.executionChanged ? ['executionModeChanged'] : []),
        ...(plan.profileChanged ? ['profileChanged'] : []),
        ...(plan.runtimeReason ? [plan.runtimeReason] : []),
      ];
      removeAgentContainerForRecreate(
        plan.existing.key,
        `workspaceGraph:${plan.node.id}:${reasons.join('+')}`,
        plan.predecessorRecord,
        { predecessorReceipt: plan.predecessorReceipt || null },
      );
    }
  } catch (error) {
    try {
      inactivateGeneration('workspace-graph-runtime-removal-failed', {
        preserveSelectedGeneration: true,
      });
    } catch (_) {}
    try {
      const lease = prepared?.preparedGeneration?.preparationLease;
      if (lease) abortPreparation(lease, { reason: 'workspace-graph-runtime-removal-failed' });
    } catch (_) {}
    throw error;
  }

  return {
    ...prepared,
    changedContainers: Object.freeze([...changedContainers]),
  };
}

function preparedContainerNames(preparedGraph) {
  return new Set([
    ...(preparedGraph?.plans || []).map((plan) => plan.containerName),
    ...(preparedGraph?.changedContainers || []),
  ].filter(Boolean));
}

/**
 * Startup providers may change secrets consumed by a retained runtime. The
 * early generation exists so hooks can safely read target-less topology, but
 * it cannot remain the runtime-identity authority after those providers run.
 * Abort that lease, re-evaluate every predecessor that was not already staged,
 * and capture one fresh target-less generation before any process launch.
 */
function reprepareGraphAfterStartupProviders(graph, reg, initialPreparedGraph, {
  deferredNodeIds = new Set(),
  additionalNodes = [],
  abortPreparation = abortEdgeRoutingPreparation,
  ensureGraphNodesEnabledImpl = ensureGraphNodesEnabled,
  runtimeReplacementReason = graphNodeRuntimeReplacementReason,
  runtimeReplacementOptions,
  graphEnableOptions = {},
} = {}) {
  const initialLease = initialPreparedGraph?.preparedGeneration?.preparationLease;
  if (!initialLease) {
    throw new Error('start: startup-provider identity re-evaluation requires the exact early preparation lease');
  }
  const alreadyPrepared = preparedContainerNames(initialPreparedGraph);

  abortPreparation(initialLease, {
    reason: 'workspace-start-provider-reprepare',
  });

  const preparedGraph = ensureGraphNodesEnabledImpl(graph, reg, {
    ...graphEnableOptions,
    deferredNodeIds,
    additionalNodes,
    runtimeReplacementOptions,
    runtimeReplacementReason(plan, options) {
      // A record minted earlier in this same start has no predecessor running
      // under that tuple. Re-check only retained predecessor identities; those
      // must rotate if preinstall/provider output changed their runtime hash.
      if (alreadyPrepared.has(plan.existing.key)) return '';
      return runtimeReplacementReason(plan, options);
    },
  });
  if (preparedGraph?.preparedGeneration?.selector?.state !== 'inactive') {
    throw new Error('start: post-provider graph generation did not remain inactive');
  }

  const allPrepared = preparedContainerNames(preparedGraph);
  for (const containerName of alreadyPrepared) allPrepared.add(containerName);
  return Object.freeze({
    preparedGraph,
    preparedContainerNames: Object.freeze([...allPrepared]),
  });
}

function formatGraphNodeLabel(node, staticLabel) {
  if (!node) return '';
  if (node.isStatic) {
    return staticLabel || node.shortAgentName;
  }
  if (node.alias) {
    return `${node.shortAgentName} as ${node.alias}`;
  }
  return node.shortAgentName;
}

function buildReadinessEntryFromNode(node, route, staticLabel, fallbackTimeoutMs = 120000) {
  const protocol = resolveAgentReadinessProtocol(node.manifest);
  const entry = {
    key: node.id,
    label: formatGraphNodeLabel(node, staticLabel),
    kind: node.isStatic ? 'static' : 'dependency',
    route,
    protocol,
    ...resolveManifestReadinessWaitOptions(
      protocol === 'mcp' || protocol === 'tcp' ? node.manifest : null,
      fallbackTimeoutMs,
      {
        timeoutMs: process.env[node.isStatic ? 'PLOINKY_STATIC_AGENT_READY_TIMEOUT_MS' : 'PLOINKY_DEPENDENCY_AGENT_READY_TIMEOUT_MS'],
        intervalMs: process.env[node.isStatic ? 'PLOINKY_STATIC_AGENT_READY_INTERVAL_MS' : 'PLOINKY_DEPENDENCY_AGENT_READY_INTERVAL_MS'],
        probeTimeoutMs: process.env[node.isStatic ? 'PLOINKY_STATIC_AGENT_READY_PROBE_TIMEOUT_MS' : 'PLOINKY_DEPENDENCY_AGENT_READY_PROBE_TIMEOUT_MS'],
      },
    ),
  };
  if (protocol === 'script') {
    entry.scriptProbe = normalizeProbeConfig('readiness', node.manifest?.health?.readiness);
  }
  return entry;
}

function buildBlockingReadinessEntryFromNode(node, route, staticLabel, fallbackTimeoutMs = 120000) {
  const entry = buildReadinessEntryFromNode(node, route, staticLabel, fallbackTimeoutMs);
  if (entry.protocol === 'script' && !route?.container) {
    throw new Error(`${node.isStatic ? 'Static agent' : 'Dependent agent'} '${formatGraphNodeLabel(node, staticLabel)}' did not resolve its service container for script readiness.`);
  }
  const hasRelayTarget = Boolean(route?.relay && route?.primaryService?.port);
  if (!route?.hostPort && !hasRelayTarget && entry.protocol !== 'none') {
    if (entry.protocol === 'script') {
      return entry;
    }
    if (resolveAgentExecutionMode(node.manifest).type === 'start_only') {
      throw new Error(
        `${node.isStatic ? 'Static agent' : 'Dependent agent'} '${formatGraphNodeLabel(node, staticLabel)}' is start-only but has no reachable readiness contract. `
        + 'Declare readiness.port, health.readiness.script, or readiness.protocol none.'
      );
    }
    throw new Error(`${node.isStatic ? 'Static agent' : 'Dependent agent'} '${formatGraphNodeLabel(node, staticLabel)}' did not expose a host port.`);
  }
  return entry;
}

function readinessKindLabel(entry) {
  if (entry.kind === 'static') return 'Static agent';
  if (entry.kind === 'reinstall') return 'Reinstalled agent';
  return 'Dependent agent';
}

function formatReadyProgress({ elapsedMs, timeoutMs, portOpen, protocol, stage, lastError }) {
  const elapsedSec = Math.floor(Math.max(0, elapsedMs) / 1000);
  const timeoutSec = Math.floor(Math.max(0, timeoutMs) / 1000);
  if (stage === 'waiting_for_relay') {
    return `still waiting (${elapsedSec}s/${timeoutSec}s): confined relay target not ready${lastError ? `, last probe=${lastError}` : ''}`;
  }
  if (stage === 'waiting_for_port') {
    return `still waiting (${elapsedSec}s/${timeoutSec}s): port not open yet${lastError ? `, last probe=${lastError}` : ''}`;
  }
  if (protocol === 'tcp') {
    return `still waiting (${elapsedSec}s/${timeoutSec}s): port is open, waiting for TCP readiness`;
  }
  if (portOpen && stage === 'waiting_for_protocol') {
    return `still waiting (${elapsedSec}s/${timeoutSec}s): port is open, waiting for MCP handshake`;
  }
  return `still waiting (${elapsedSec}s/${timeoutSec}s)`;
}

async function waitForReadinessEntries(readinessEntries, options = {}) {
  const waitForAgentReadyImpl = options.waitForAgentReadyImpl || waitForAgentReady;
  const runContainerScriptReadinessImpl = options.runContainerScriptReadinessImpl || runContainerScriptReadiness;
  const readinessProgress = new Map();
  const readinessStartAt = Date.now();
  let lastSummaryBucket = -1;

  const summarizeReadiness = ({ force = false } = {}) => {
    const elapsedMs = Date.now() - readinessStartAt;
    const bucket = Math.floor(elapsedMs / 5000);
    if (!force) {
      if (bucket <= 0 || bucket === lastSummaryBucket) return;
    }
    lastSummaryBucket = bucket;
    const readyCount = readinessEntries.reduce((count, entry) => {
      const state = readinessProgress.get(entry.key);
      return count + (state?.ready ? 1 : 0);
    }, 0);
    const waiting = readinessEntries
      .filter((entry) => !(readinessProgress.get(entry.key)?.ready))
      .map((entry) => {
        const state = readinessProgress.get(entry.key) || {};
        if (state.elapsedMs) {
          return `${entry.label} (${formatReadyProgress({
            elapsedMs: state.elapsedMs,
            timeoutMs: entry.timeoutMs,
            portOpen: Boolean(state.portOpen),
            protocol: entry.protocol,
            stage: state.stage,
            lastError: state.lastError
          })})`;
        }
        return `${entry.label} (starting)`;
      });
    console.log(`[start] Readiness ${readyCount}/${readinessEntries.length} ready.${waiting.length ? ` Waiting on: ${waiting.join(', ')}` : ''}`);
  };

  for (const entry of readinessEntries) {
    const waitLabel = entry.kind === 'static' ? 'static agent' : (entry.kind === 'reinstall' ? 'reinstalled agent' : 'dependent agent');
    if (entry.protocol === 'none') {
      console.log(`[start] Marking ${waitLabel} '${entry.label}' ready (no port-bound readiness probe).`);
    } else if (entry.protocol === 'script') {
      console.log(`[start] Waiting for ${waitLabel} '${entry.label}' to pass container script './${entry.scriptProbe.script}'...`);
    } else {
      console.log(`[start] Waiting for ${waitLabel} '${entry.label}' to become ready on port ${entry.route.hostPort}...`);
    }
    readinessProgress.set(entry.key, {
      ready: false,
      stage: 'starting',
      elapsedMs: 0,
      portOpen: false,
      lastError: null
    });
  }
  if (readinessEntries.length) {
    console.log(`[start] Tracking readiness for ${readinessEntries.length} agent(s): ${readinessEntries.map((entry) => entry.label).join(', ')}`);
  }

  await Promise.all(readinessEntries.map(async (entry) => {
    if (options.beforeProbe) options.beforeProbe();
    const remainingMs = options.deadline === undefined ? null : Math.max(0, options.deadline - Date.now());
    if (remainingMs === 0) throw new Error('Readiness deadline expired.');
    if (entry.protocol === 'none') {
      readinessProgress.set(entry.key, {
        elapsedMs: 0,
        ready: true,
        stage: 'ready',
        portOpen: false,
        lastError: null
      });
      summarizeReadiness();
      return;
    }
    if (entry.protocol === 'script') {
      const result = await Promise.resolve(runContainerScriptReadinessImpl(
        entry.label,
        entry.route.container,
        remainingMs === null ? entry.scriptProbe : { ...entry.scriptProbe, timeout: Math.min(entry.scriptProbe.timeout, remainingMs / 1000) },
        { beforeProbe: options.beforeProbe, deadline: options.deadline },
      ));
      if (result?.status !== 'success') {
        const reason = result?.reason || 'unknown failure';
        const detail = result?.detail ? `, output='${result.detail}'` : '';
        throw new Error(`${readinessKindLabel(entry)} '${entry.label}' failed readiness script './${entry.scriptProbe.script}' (${reason}${detail}).`);
      }
      readinessProgress.set(entry.key, {
        elapsedMs: Date.now() - readinessStartAt,
        ready: true,
        stage: 'ready',
        portOpen: false,
        lastError: null
      });
      console.log(`[start] ${entry.label}: container script readiness passed.`);
      summarizeReadiness({ force: true });
      return;
    }
    const ready = await waitForAgentReadyImpl(entry.route, {
      timeoutMs: remainingMs === null ? entry.timeoutMs : Math.min(entry.timeoutMs, remainingMs),
      intervalMs: entry.intervalMs,
      probeTimeoutMs: entry.probeTimeoutMs,
      protocol: entry.protocol,
      beforeProbe: options.beforeProbe,
      onProgress: (progress) => {
        readinessProgress.set(entry.key, {
          ...progress,
          ready: Boolean(progress?.ready),
          stage: progress?.stage || 'starting',
          portOpen: Boolean(progress?.portOpen),
          lastError: progress?.lastError || null
        });
        summarizeReadiness();
      }
    });
    if (!ready) {
      throw new Error(`${readinessKindLabel(entry)} '${entry.label}' did not become ready within ${entry.timeoutMs}ms.`);
    }
    const elapsedMs = Number(readinessProgress.get(entry.key)?.elapsedMs || 0);
    const elapsedSec = Math.floor(elapsedMs / 1000);
    readinessProgress.set(entry.key, {
      ...(readinessProgress.get(entry.key) || {}),
      ready: true,
      stage: 'ready',
      portOpen: true,
      elapsedMs
    });
    console.log(`[start] ${entry.label}: ready after ${elapsedSec}s.`);
    summarizeReadiness({ force: true });
  }));
}

async function waitForManifestReadiness({ key, label, kind = 'dependency', manifest, route }, options = {}) {
  try {
    const node = {
      id: key || label,
      shortAgentName: label,
      isStatic: kind === 'static',
      manifest
    };
    const fallbackTimeoutMs = kind === 'reinstall' && resolveAgentReadinessProtocol(manifest) !== 'script'
      ? 15000
      : 120000;
    const entry = buildBlockingReadinessEntryFromNode(node, route, label, fallbackTimeoutMs);
    entry.kind = kind;
    entry.label = label;
    await waitForReadinessEntries([entry], options);
  } catch (error) {
    const readinessError = new Error(error?.message || String(error), { cause: error });
    readinessError.code = 'PLOINKY_READINESS_FAILED';
    throw readinessError;
  }
}

async function activatePreparedRuntimeAfterReadiness({
  result,
  routeKey,
  repoName,
  shortAgentName,
  agentPath,
  alias = '',
  networkLifecycleCapability,
}, {
  mergeRouting = mergeRoutingConfig,
  mergeRoute = mergeRuntimeRoute,
  loadAgents = workspaceSvc.loadAgents,
  saveAgents = workspaceSvc.saveAgents,
  readRouting = readRoutingConfig,
  commitAdditive = commitAdditiveEdgeRoutingGeneration,
  withApplyLock = withEdgeGenerationApplyLock,
  retirePredecessor = dockerSvc.retireExactAgentRuntimePredecessor,
  reportRetirementFailure = (predecessor, error) => console.warn(
    `[edge] active replacement committed, but exact predecessor '${predecessor?.containerName || '<unknown>'}' retirement failed: ${error?.message || error}`,
  ),
  cleanupFailure = cleanupFailedPreparedRuntime,
  retireCandidate = retireRuntimeCandidate,
} = {}) {
  if (!result?.requiresEdgeActivation) return false;
  if (!result?.containerName || !result?.registryRecord) {
    throw new Error('runtime replacement activation requires one exact returned container and registry record');
  }
  if (!result?.preparationLease) {
    throw new Error('runtime replacement activation requires its exact preparation lease');
  }
  const retirePublishedCandidate = () => {
    if (!result.durableCandidate) return;
    try { retireCandidate(result.durableCandidate); } catch (error) {
      console.warn(`[edge] active runtime recovery receipt could not be retired: ${error?.message || error}`);
    }
  };
  try {
    if (result.mpsReadiness) await verifyMpsRuntimeReady(result);
    if (result.preparationLease.mode === 'additive') {
      await withApplyLock((applyLockCapability) => {
        const agents = loadAgents();
        const predecessorName = String(result.replacementPredecessor?.containerName || '');
        if (predecessorName && predecessorName !== result.containerName) {
          delete agents[predecessorName];
        }
        agents[result.containerName] = structuredClone(result.registryRecord);
        const routing = readRouting();
        routing.routes = routing.routes || {};
        for (const route of Object.values(routing.routes)) {
          if (route && predecessorName && route.container === predecessorName) {
            route.container = result.containerName;
          }
        }
        routing.routes[routeKey] = mergeRoute(routing.routes[routeKey], {
          container: result.containerName,
          hostPath: agentPath,
          repo: repoName,
          agent: shortAgentName,
          ...(alias ? { alias } : {}),
        }, { hostPort: result.hostPort || 0 });
        delete routing.routes[routeKey].hardwareAvailability;
        return commitAdditive(result.preparationLease, {
          agents,
          routing,
          applyLockCapability,
        });
      }, { preparationLease: result.preparationLease });
      if (result.replacementPredecessor) {
        try {
          retirePredecessor(result.replacementPredecessor, { networkLifecycleCapability });
        } catch (retirementError) {
          try { reportRetirementFailure(result.replacementPredecessor, retirementError); } catch (_) {}
        }
      }
      retirePublishedCandidate();
      if (result.mpsReadiness) await acknowledgeMpsRuntimeReady(result);
      return true;
    }
    await mergeRouting((cfg) => {
      const agents = loadAgents();
      agents[result.containerName] = result.registryRecord;
      saveAgents(agents, { coordinate: false });
      cfg.routes = cfg.routes || {};
      cfg.routes[routeKey] = {
        ...(cfg.routes[routeKey] || {}),
        container: result.containerName,
        hostPath: agentPath,
        repo: repoName,
        agent: shortAgentName,
        ...(alias ? { alias } : {}),
        ...(result.hostPort ? { hostPort: result.hostPort } : {}),
      };
      if (!result.hostPort) delete cfg.routes[routeKey].hostPort;
      delete cfg.routes[routeKey].hardwareAvailability;
      return cfg;
    }, {
      reason: 'runtime-replacement-ready',
      preparationLease: result.preparationLease,
    });
    retirePublishedCandidate();
    if (result.mpsReadiness) await acknowledgeMpsRuntimeReady(result);
    return true;
  } catch (error) {
    cleanupFailure(
      result,
      error,
      'runtime-replacement-activation-failed',
    );
    throw error;
  }
}

const handledPreparedRuntimeFailures = new WeakSet();

export function cleanupFailedPreparedRuntime(
  result,
  error,
  reason = 'runtime-replacement-readiness-failed',
  {
    cleanupCandidate = dockerSvc.cleanupExactAgentRuntimeCandidate,
    inactivate = inactivateEdgeRoutingGeneration,
    abortPreparation = abortEdgeRoutingPreparation,
  } = {},
) {
  const failedResult = result || error?.ploinkyRestartCandidate || null;
  if (!failedResult) return;
  // The launching operation is over: a GPU share or share-less readiness
  // owner must not stay live in this process.
  releaseMpsRuntimeOwner(failedResult);
  // The activation helper and its lifecycle caller see the same prepared
  // runtime. A launch failure can instead surface the exact candidate only on
  // the error, before the caller receives a result. Cleanup receipts are
  // intentionally single-use authority, so the first failure owner consumes
  // the transaction and every outer catch is a no-op for that exact object.
  if (typeof failedResult === 'object') {
    if (handledPreparedRuntimeFailures.has(failedResult)) return;
    handledPreparedRuntimeFailures.add(failedResult);
  }
  if (failedResult.preparationLease
    && failedResult.containerName
    && failedResult.containerId
    && failedResult.registryRecord) {
    try {
      cleanupCandidate(failedResult);
    } catch (cleanupError) {
      error.message += `; exact runtime-failure cleanup: ${cleanupError?.message || cleanupError}`;
    }
  }
  if (!failedResult.preparationLease) return;
  if (failedResult.preparationLease.mode !== 'additive') {
    try {
      inactivate(reason, { preserveSelectedGeneration: true });
    } catch (cleanupError) {
      error.message += `; routing inactivation: ${cleanupError?.message || cleanupError}`;
    }
  }
  try {
    abortPreparation(failedResult.preparationLease, { reason });
  } catch (cleanupError) {
    error.message += `; routing preparation cleanup: ${cleanupError?.message || cleanupError}`;
  }
}

async function resolveAndPersistStartRouterPort(staticAgentArg, portArg, {
  coordinate = true,
} = {}) {
  const configuredStatic = workspaceSvc.getConfig()?.static;
  const isInitialRouterStartup = Boolean(staticAgentArg) && !configuredStatic?.agent;
  const resolvedStartPort = isInitialRouterStartup
    ? resolveInitialRouterPort({ explicitPort: portArg })
    : resolvePersistedRouterPort({ explicitPort: portArg });
  const update = (current) => {
    if (Object.prototype.hasOwnProperty.call(current, 'port')) {
      const lockedPort = parseRouterPort(current.port, { source: 'persisted router port' });
      if (lockedPort !== resolvedStartPort) {
        const error = new Error(`explicit router port ${resolvedStartPort} does not match persisted router port ${lockedPort}`);
        error.code = 'PLOINKY_ROUTER_PORT_MISMATCH';
        throw error;
      }
    }
    return {
      ...current,
      port: resolvedStartPort,
      routes: current.routes || {},
    };
  };
  if (coordinate) {
    await mergeRoutingConfig(update);
  } else {
    const current = readRoutingConfig();
    writeRoutingConfig(update(current), { coordinate: false });
  }
  return resolvedStartPort;
}

function assertStaticPreinstallSucceeded(result) {
  if (result?.success === true) return result;
  throw new Error(`static preinstall hook failed: ${result?.message || 'unknown hook failure'}`);
}

function buildRouterUrl(staticPort, env = process.env) {
  const publicAuthority = String(env.PLOINKY_PUBLIC_AUTHORITY || '').trim();
  return publicAuthority
    ? `http://${publicAuthority}`
    : `http://127.0.0.1:${staticPort}`;
}

export function preflightWorkspaceStartRuntimeCapabilities(staticAgentArg, { hardwareContext, boxMarkerOptions } = {}) {
  const configured = workspaceSvc.getConfig()?.static?.agent || '';
  let staticAgent = String(staticAgentArg || configured || '').trim();
  if (!staticAgent) {
    throw new Error('start: missing static agent or port. Usage: start <staticAgent> <port> (first time).');
  }
  try {
    const aliasRecord = agentsSvc.resolveEnabledAgentRecord(staticAgent);
    if (aliasRecord?.record?.alias) {
      staticAgent = `${aliasRecord.record.repoName}/${aliasRecord.record.agentName}`;
    }
  } catch (_) {
    // Graph resolution below owns the canonical not-found/ambiguity error.
  }
  const registry = deduplicateAgentRegistry(
    workspaceSvc.loadAgents(),
    dockerSvc.getAgentContainerName,
  );
  const graph = resolveWorkspaceDependencyGraph({
    staticAgentRef: staticAgent,
    registry,
  });
  const additionalNodes = resolveExtraEnabledRuntimeNodes(
    graph,
    registry,
    dockerSvc.getAgentContainerName,
  );
  const admissions = admitWorkspaceGraphRuntimeCapabilities(graph, {
    additionalNodes,
    registry,
    ...(hardwareContext !== undefined ? { hardwareContext } : {}),
    ...(boxMarkerOptions !== undefined ? { boxMarkerOptions } : {}),
  });
  return Object.freeze({ graph, registry, additionalNodes, admissions });
}

// Exact refusal/block counts and the overall state; never "all ready" while
// optional work is pending or the graph is degraded (plan §9.4).
export function printStartResultSummary(result, { log = console.log } = {}) {
  const refused = result.refusedAgents.count;
  const blocked = result.blockedAgents.count;
  const pending = result.asynchronousAgents.count;
  if (result.state === 'degraded') {
    log(`[start] Workspace started degraded: ${refused} agent(s) refused and ${blocked} blocked by hardware limits; `
      + `${pending} no-wait agent(s) still starting in the background. See the reasons and fixes above, or run ploinky limits status on the host.`);
  } else if (result.state === 'starting') {
    log(`[start] Required agents are ready; ${pending} no-wait agent(s) are still starting in the background.`);
  } else {
    log('[start] All selected agents are ready.');
  }
}

async function startWorkspace(staticAgentArg, portArg, {
  killRouterIfRunning,
  branchPolicy,
} = {}) {
  // Acquire every declared dependency source before resolving the complete
  // graph. A fresh workspace cannot admit repositories that do not exist yet.
  // Repository preparation remains ahead of authoritative workspace mutation,
  // then the exact resulting graph is admitted and retained.
  // The same admission is revalidated under the start lock before the first
  // selector, route, config, or Router write.
  const requestedStaticAgent = String(
    staticAgentArg || workspaceSvc.getConfig()?.static?.agent || '',
  ).trim();
  if (!requestedStaticAgent) {
    throw new Error('start: missing static agent or port. Usage: start <staticAgent> <port> (first time).');
  }
  try {
    prepareDefaultBootRepositories({
      branchPolicy,
      staticAgent: requestedStaticAgent,
    });
    await prepareManifestRepositories(requestedStaticAgent, {
      branchPolicy,
      profile: getActiveProfile(),
    });
  } catch (err) {
    throw new Error(`Failed to prepare manifest repositories for '${requestedStaticAgent}': ${err?.message || err}`);
  }
  const admittedStart = preflightWorkspaceStartRuntimeCapabilities(staticAgentArg);
  // The workspace mutation lease covers source initialization, candidate
  // writes, both inactive prelaunch preparations, and every subsequent start.
  // Only the final post-provider lease may authorize runtime targets.
  resetPreinstallRunInProcess();
  // A previous start may have returned while its no-wait workers are still
  // creating and activating runtimes. Wait until none can still make progress
  // (they need the lease, so the wait holds none), then revalidate the
  // admitted graph under the lease.
  const workspaceStartLock = await acquireSettledWorkspaceMutationLease({ operation: 'workspace-start' });
  let workspacePreparationLease = null;
  const workspaceRuntimeCandidates = [];
  const workspaceMpsRuntimes = [];
  try {
  // Everything below is this start's own work: nested lifecycle code reuses
  // this lease, and nothing else in the process can. A rollback start can
  // follow a killed start at once: wait out only that dead owner's stale
  // network-lock grace, never a live owner.
  return await runWithWorkspaceMutationLease(workspaceStartLock, () => withNetworkLifecycleLockReclaimingStoppedOwner(async (networkLifecycleCapability) => {
  try {
  assertWorkspaceGraphAdmissionsCurrent(admittedStart.admissions);
  // No earlier no-wait worker still alive here can change anything while this
  // start holds the workspace lease and network lock, and none has published.
  // Whether a stop or a source change stalled it or it became able to
  // progress just after the settle, staging rotates its identity.
  const supersededNoWaitRuns = inspectLiveNoWaitWorkers();
  if (supersededNoWaitRuns.length) {
    console.log(`[start] Superseding ${supersededNoWaitRuns.length} live no-wait worker(s) of an earlier start: ${supersededNoWaitRuns
      .map(({ containerName, pid }) => `${containerName} (${pid ? `pid ${pid}` : 'pid not yet published'})`).join(', ')}`);
  }
  const lockedStart = preflightWorkspaceStartRuntimeCapabilities(staticAgentArg);
  // Hardware refusals are recorded per exact instance; blocking and explicit
  // waiting consumers become blocked, unrelated agents start (plan §9.1).
  // A refusal raised later at launch is recorded in the same tracker.
  const graphAvailability = createGraphAvailabilityTracker(lockedStart.graph, lockedStart.admissions);
  const unavailableNodeIds = new Set(graphAvailability.unavailableEntries().map((entry) => entry.nodeId));
  const workspaceConfigForAuth = workspaceSvc.getConfig() || {};
  const graphSsoConfig = resolveWorkspaceGraphSsoConfig(lockedStart.graph, workspaceConfigForAuth.sso);
  initializeFreshEdgeRoutingSources({ workspaceRoot: PLOINKY_WORKSPACE_ROOT });
  // The inactivation below replaces the selector that binds a stopped start's
  // graph preparation, so retire or refuse that lease first.
  const abandonedPreparation = retireAbandonedWorkspaceStartPreparation({
    workspaceRoot: PLOINKY_WORKSPACE_ROOT,
    workspaceMutationLease: workspaceStartLock,
    networkLifecycleCapability,
  });
  if (abandonedPreparation.retired) {
    console.log(`[start] Retired the routing preparation of stopped workspace start pid ${abandonedPreparation.pid}.`);
  }
  inactivateEdgeRoutingGeneration('workspace-start-prepare', { workspaceRoot: PLOINKY_WORKSPACE_ROOT });
  if (graphSsoConfig) {
    workspaceSvc.setConfig({ ...workspaceConfigForAuth, sso: graphSsoConfig });
  }
  const resolvedStartPort = await resolveAndPersistStartRouterPort(staticAgentArg, portArg, {
    coordinate: false,
  });
  let routerReadyForStart = false;
  let routerPortForStart = 0;
  let routerContainerForStart = '';
  const ensureRouterReadyForStart = async ({
    staticAgent,
    staticPort,
    repoName,
    shortAgentName,
    containerName,
  }) => {
    const container = containerName
      || dockerSvc.getAgentContainerName(shortAgentName || staticAgent, repoName || '');
    if (routerReadyForStart) {
      if (routerPortForStart !== staticPort || routerContainerForStart !== container) {
        throw new Error('start: resolved static routing identity changed after the router listener became ready');
      }
      const routingCandidate = readRoutingConfig();
      writeRoutingConfig({
        ...routingCandidate,
        port: staticPort,
        static: { agent: staticAgent, container },
        routes: routingCandidate.routes || {},
      }, { coordinate: false });
      return container;
    }

    const routingCandidate = readRoutingConfig();
    writeRoutingConfig({
      ...routingCandidate,
      port: staticPort,
      static: { agent: staticAgent, container },
      routes: routingCandidate.routes || {},
    }, { coordinate: false });
    console.log(`Static: agent=${utils.colorize(staticAgent, 'cyan')} port=${utils.colorize(String(staticPort), 'yellow')}`);
    const routerHealthSocket = buildRouterEnv().PLOINKY_ROUTER_HEALTH_SOCKET
      || path.join(PLOINKY_DIR, 'run', 'router-health.sock');
    const readyRouter = await ensureRouterGenerationReady({
      waitForListener: (child, timeoutMs) => waitForRouterReady(staticPort, child, timeoutMs),
      readHealth: () => readRouterGenerationHealth({ socketPath: routerHealthSocket }),
      stopRouter: killRouterIfRunning,
      onReload: () => console.log('[start] Reloading Router before preparing the current routing generation format.'),
      spawnRouter: () => {
        const runningDir = RUNNING_DIR;
        fs.mkdirSync(runningDir, { recursive: true });
        const routerPath = path.resolve(__dirname, '../server/Watchdog.js');
        const routerPidFile = path.join(runningDir, 'router.pid');
        const child = spawnWatchdog(routerPath, staticPort, routerPidFile);
        try { fs.writeFileSync(routerPidFile, String(child.pid)); } catch (_) {}
        child.unref();
        return child;
      },
    });
    routerReadyForStart = true;
    routerPortForStart = staticPort;
    routerContainerForStart = container;
    if (readyRouter.reused) console.log('[start] Existing router TCP listener is ready; routing generation format verified.');
    else console.log(`[start] Watchdog launched in background (pid ${readyRouter.child.pid}); router generation reader is ready.`);
    return container;
  };
    if (staticAgentArg) {
      let aliasResolved = null;
      try {
        const resolvedAliasRecord = agentsSvc.resolveEnabledAgentRecord(staticAgentArg);
        if (resolvedAliasRecord && resolvedAliasRecord.record && resolvedAliasRecord.record.alias) {
          aliasResolved = `${resolvedAliasRecord.record.repoName}/${resolvedAliasRecord.record.agentName}`;
        }
      } catch (_) {
        aliasResolved = null;
      }
      const portNum = resolvedStartPort;
      const cfg = workspaceSvc.getConfig() || {};
      cfg.static = { agent: aliasResolved || staticAgentArg, port: portNum };
      workspaceSvc.setConfig(cfg);
    }
    const cfg0 = workspaceSvc.getConfig() || {};
    const staticAgentCfg = cfg0?.static?.agent;
    let normalizedStaticAgent = staticAgentCfg;
    if (staticAgentCfg) {
      try {
        const aliasRecord = agentsSvc.resolveEnabledAgentRecord(staticAgentCfg);
        if (aliasRecord && aliasRecord.record && aliasRecord.record.alias) {
          normalizedStaticAgent = `${aliasRecord.record.repoName}/${aliasRecord.record.agentName}`;
        }
      } catch (_) {
        normalizedStaticAgent = staticAgentCfg;
      }
    }
    if (!cfg0.static || !cfg0.static.agent || !cfg0.static.port) {
      throw new Error('start: missing static agent or port. Usage: start <staticAgent> <port> (first time).');
    }
    const staticAgent = normalizedStaticAgent || cfg0.static.agent;
    const staticPort = parseRouterPort(cfg0.static.port, { source: 'workspace static router port' });
    if (staticPort !== resolvedStartPort) {
      throw new Error(`start: workspace static router port ${staticPort} does not match persisted router port ${resolvedStartPort}`);
    }
    let staticRepoName = null;
    let staticShortAgent = null;

    try {
      const resolvedStaticAgent = utils.findAgent(staticAgent);
      staticRepoName = resolvedStaticAgent.repo;
      staticShortAgent = resolvedStaticAgent.shortAgentName;
    } catch (e) {
      throw new Error(`start: Agent '${staticAgent}' not found in any repo. Use 'enable agent <repo/name>' or check repos.`);
    }
    const admittedStaticNode = lockedStart.graph.nodes.get(lockedStart.graph.staticNodeId);
    const admittedStaticContainer = resolveStaticRouterContainerName({
      registry: lockedStart.registry,
      staticNode: admittedStaticNode,
      staticAgent,
      staticRepoName,
      getAgentContainerName: dockerSvc.getAgentContainerName,
    });
    await ensureRouterReadyForStart({
      staticAgent,
      staticPort,
      repoName: staticRepoName,
      shortAgentName: staticShortAgent,
      containerName: admittedStaticContainer,
    });

    // Compile the already prepared and admitted complete manifest graph into
    // one target-less inactive edge generation. Static
    // preinstall and config-provider hooks receive that exact topology before
    // any agent process or container is allowed to start.
    assertWorkspaceGraphAdmissionsCurrent(lockedStart.admissions);
    const providerRegistry = lockedStart.registry;
    const dependencyGraph = lockedStart.graph;

    // The locked admission intentionally precedes the first config mutation,
    // so its registry snapshot cannot contain the static identity persisted
    // above on an initial start. Refresh the non-authorizing workspace config
    // before saving that admitted registry; otherwise this stale write removes
    // `_config.static` and a later zero-argument start cannot recover it.
    let reg = deduplicateAgentRegistry(providerRegistry, dockerSvc.getAgentContainerName);
    workspaceSvc.saveAgents(reg);

    const { getAgentContainerName, ensureAgentService } = dockerSvc;

    const waitClassification = classifyDependencyGraphWaitMode(dependencyGraph);
    const extraRuntimeNodes = lockedStart.additionalNodes;
    const mpsGraphNodes = () => [...dependencyGraph.nodes.values(), ...extraRuntimeNodes].map((node) => {
      return { key: graphNodeRegistryKey(node, reg, dockerSvc.getAgentContainerName), node };
    });
    const prepareGraphMps = async () => recordMpsGraphPreparation(
      await prepareMpsGraph({ nodes: mpsGraphNodes(), networkLifecycleCapability }),
      { availability: graphAvailability, unavailableNodeIds },
    );
    let mpsGraphPreparation = await prepareGraphMps();
    const mpsReplacementReason = (plan, options) => mpsGraphPreparation.replacedKeys.has(plan.existing.key)
      ? 'mpsCohortTransition' : graphNodeRuntimeReplacementReason(plan, options);
    let preparedGraph = ensureGraphNodesEnabled(dependencyGraph, reg, {
      deferredNodeIds: waitClassification.noWait,
      additionalNodes: extraRuntimeNodes,
      unavailableNodeIds,
      supersededNoWaitRuns,
      runtimeReplacementReason: mpsReplacementReason,
    });
    workspacePreparationLease = preparedGraph?.preparedGeneration?.preparationLease || null;
    if (preparedGraph?.preparedGeneration?.selector?.state !== 'inactive') {
      throw new Error('start: graph prelaunch generation did not remain inactive');
    }

    // Run the static (main) agent preinstall only after the inactive topology
    // exists. This hook may populate values consumed by startup config
    // providers, but it must never observe raw candidate files before their
    // coordinated generation has been captured and validated.
    try {
      const staticAgentForPreinstall = cfg0.static.agent;
      if (staticAgentForPreinstall) {
        const resolved = utils.findAgent(staticAgentForPreinstall);
        if (resolved) {
          const agentPath = path.dirname(resolved.manifestPath);
          const activeProfile = getActiveProfile();
          const profileConfig = getProfileConfig(`${resolved.repo}/${resolved.shortAgentName}`, activeProfile);
          if (profileConfig?.preinstall) {
            console.log(`[start] Running preinstall hook for ${resolved.shortAgentName} (profile: ${activeProfile})...`);
            const hookValue = isInlineCommand(profileConfig.preinstall)
              ? profileConfig.preinstall
              : path.join(agentPath, profileConfig.preinstall);

            const hookEnv = buildLifecycleHookEnv({
              agentName: resolved.shortAgentName,
              repoName: resolved.repo,
              profileName: activeProfile,
              profileConfig,
              agentPath,
            });

            const result = executeHostHook(hookValue, hookEnv, { cwd: PLOINKY_WORKSPACE_ROOT });
            assertStaticPreinstallSucceeded(result);
            markPreinstallRunInProcess(resolved.shortAgentName, resolved.repo, activeProfile);
          }
        }
      }
    } catch (preErr) {
      throw new Error(`start: static preinstall preflight failed: ${preErr?.message || preErr}`);
    }

    try {
      const providerResult = await applyStartupConfigProvidersForGraph({
        dependencyGraph,
        profileName: getActiveProfile(),
        workspaceRoot: PLOINKY_WORKSPACE_ROOT,
      });
      if (providerResult.providers.length) {
        const appliedNames = providerResult.applied.map((entry) => entry.name);
        const appliedSummary = appliedNames.length ? appliedNames.join(', ') : 'no changed values';
        console.log(`[start] Startup config providers applied: ${appliedSummary}`);
        for (const warning of providerResult.warnings) {
          console.warn(`[start] Config provider warning: ${warning}`);
        }
      }
    } catch (providerErr) {
      throw new Error(`Startup config provider preflight failed: ${providerErr?.message || providerErr}`);
    }

    // Preinstall/provider output can change a retained runtime's effective
    // environment after the early topology generation was captured. Re-check
    // predecessor identities now and replace the early lease before any launch.
    // The early batch persisted newly enabled records, so reload them before
    // re-preparation; otherwise they would be mistaken for missing a second
    // time instead of retaining their already-fresh, never-launched tuple.
    reg = deduplicateAgentRegistry(workspaceSvc.loadAgents(), getAgentContainerName);
    mpsGraphPreparation = await prepareGraphMps();
    const postProviderPreparation = reprepareGraphAfterStartupProviders(
      dependencyGraph,
      reg,
      preparedGraph,
      {
        deferredNodeIds: waitClassification.noWait,
        additionalNodes: extraRuntimeNodes,
        graphEnableOptions: { unavailableNodeIds, supersededNoWaitRuns },
        runtimeReplacementReason: mpsReplacementReason,
      },
    );
    preparedGraph = postProviderPreparation.preparedGraph;
    workspacePreparationLease = preparedGraph?.preparedGeneration?.preparationLease || null;

    const newlyPreparedContainers = new Set(postProviderPreparation.preparedContainerNames);
    reg = deduplicateAgentRegistry(workspaceSvc.loadAgents(), getAgentContainerName);
    let cfg = readRoutingConfig();
    cfg.routes = cfg.routes || {};

    const allNames = Object.keys(reg || {}).filter((name) => name !== '_config');
    const graphWaves = topologicallyGroupDependencyGraph(dependencyGraph);
    const { noWait: noWaitNodeIds } = waitClassification;
    const graphRegistryNames = new Set();
    const registryNameByNodeId = new Map();
    const graphWaveNames = graphWaves.map((waveNodeIds) => waveNodeIds.map((nodeId) => {
      const node = dependencyGraph.nodes.get(nodeId);
      const registryEntry = findRegistryEntryForGraphNode(reg, node, getAgentContainerName);
      if (!registryEntry) {
        throw new Error(`Graph node '${nodeId}' is not enabled in the workspace registry.`);
      }
      graphRegistryNames.add(registryEntry.key);
      registryNameByNodeId.set(nodeId, registryEntry.key);
      return registryEntry.key;
    }));
    if (noWaitNodeIds.size) {
      const labels = Array.from(noWaitNodeIds).map((nodeId) => {
        const node = dependencyGraph.nodes.get(nodeId);
        return node ? formatGraphNodeLabel(node, staticAgent) : nodeId;
      });
      console.log(`[start] No-wait dependencies (background launch): ${labels.join(', ')}`);
    }
    const unavailableOutcome = (nodeId) => graphAvailability.outcomeForNode(nodeId);
    const readyAgentKeys = [];
    const asynchronousAgentKeys = [];

    const staticNode = dependencyGraph.nodes.get(dependencyGraph.staticNodeId);
    const staticContainer = resolveStaticRouterContainerName({
      registry: reg,
      staticNode,
      staticAgent,
      staticRepoName,
      getAgentContainerName,
    });

    if (Number(cfg.port) !== staticPort
        || cfg.static?.agent !== staticAgent
        || cfg.static?.container !== staticContainer) {
      throw new Error('start: prepared routing generation does not contain the exact static Router identity');
    }
    // The shared hardware containment: refused/blocked instances keep their
    // logical routes but lose every runtime target, and a typed hardware
    // outcome raised at launch is recorded, projected, and its blocking and
    // explicit-wait consumers become blocked and are skipped; unrelated
    // agents continue (U10/U14, §9.4).
    const hardwareContainment = createStartLaunchContainment({
      availability: graphAvailability,
      registry: () => reg,
      registryNameByNodeId,
      applyUnavailableRoutes: async (unavailableRoutes) => {
        cfg = await mergeRoutingConfig((current) => {
          current.routes = current.routes || {};
          for (const { routeKey, projection } of unavailableRoutes) {
            current.routes[routeKey] = markRouteHardwareUnavailable(current.routes[routeKey], projection);
            if (cfg.routes?.[routeKey]) cfg.routes[routeKey] = current.routes[routeKey];
          }
          return current;
        }, { coordinate: false });
      },
    });
    const { hardwareOutcomes, reportOutcome: reportHardwareOutcome } = hardwareContainment;
    await hardwareContainment.markUnavailable(graphAvailability.unavailableEntries());
    const updateRoutes = async (targetNames = [], { allowFailures = false } = {}) => {
      cfg.routes = cfg.routes || {};
      return hardwareContainment.launchTargets(targetNames, {
        launchOne: async (name) => {
          const rec = reg[name];
          if (!rec || !rec.agentName) return null;
          const shortAgentName = rec.agentName;
          const manifestRef = rec.repoName ? `${rec.repoName}/${shortAgentName}` : shortAgentName;
          const manifestPath0 = findAgentManifest(manifestRef);
          const manifest = JSON.parse(fs.readFileSync(manifestPath0, 'utf8'));
          const agentPath = path.dirname(manifestPath0);
          const repoName = rec.repoName || resolveAgentRepositoryName(agentPath);
          const routeKey = rec.alias || shortAgentName;
          const routerEndpoint = resolveManifestRouterEndpoint(manifest, {
            explicitPort: staticPort,
            persistedProfileName: rec.profile,
            path: `manifest(${repoName}/${shortAgentName})`,
          });
          const launchProfile = resolveManifestRuntimeProfile(manifest, {
            agentName: `${repoName}/${shortAgentName}`,
            profileName: rec.profile || undefined,
            path: `manifest(${repoName}/${shortAgentName})`,
          });
          const preparedHostModeCapability = launchProfile.network.mode === 'host'
            ? prepareHostModeCapabilityForInactiveGeneration({
                agentId: `agent:${repoName}/${shortAgentName}`,
                instanceId: rec.instanceId,
                enableGeneration: rec.enableGeneration,
                routeKey,
                containerName: name,
              })
            : undefined;
          const runtimeResult = await ensureAgentService(shortAgentName, manifest, agentPath, {
            containerName: name,
            hardwareInstanceKey: name,
            alias: rec.alias,
            routerEndpoint,
            profileName: rec.profile || undefined,
            instanceId: rec.instanceId,
            enableGeneration: rec.enableGeneration,
            forceRecreate: newlyPreparedContainers.has(name),
            // The graph removal step already removed every changed
            // predecessor, so the slot holds nothing or the exact successor.
            expectedPredecessor: null,
            forceRecreateReason: 'runtime identity rotated earlier in this start',
            preservePreparedRegistryRecord: true,
            preparationLease: workspacePreparationLease,
            preparedHostModeCapability,
            networkLifecycleCapability,
          });
          workspaceMpsRuntimes.push(runtimeResult);
          if (runtimeResult?.requiresEdgeActivation === true
              && runtimeResult?.preparationLease
              && runtimeResult?.containerId) {
            workspaceRuntimeCandidates.push(runtimeResult);
          }
          const {
            containerName,
            hostPort,
            registryRecord,
          } = runtimeResult;
          if (!registryRecord) {
            throw new Error(`runtime '${containerName}' returned no exact registry record`);
          }
          const executionMode = resolveAgentExecutionMode(manifest);
          const resolvedHostPort = hostPort || (
            executionMode.type === 'start_only' ? 0 : cfg.routes[routeKey]?.hostPort
          );
          const nextRoute = {
            ...(cfg.routes[routeKey] || {}),
            container: containerName,
            hostPath: agentPath,
            repo: repoName,
            agent: shortAgentName,
            ...(rec.alias ? { alias: rec.alias } : {}),
            ...(resolvedHostPort ? { hostPort: resolvedHostPort } : {}),
          };
          if (!resolvedHostPort) delete nextRoute.hostPort;
          // A freshly admitted launch supersedes any earlier unavailable state.
          delete nextRoute.hardwareAvailability;
          const readinessRoute = buildRelayReadinessRoute({
            route: nextRoute,
            manifest,
            runtimeResult,
            networkMode: launchProfile.network.mode,
            generationDigest: workspacePreparationLease?.preparedGeneration || '',
          });
          return {
            ok: true,
            containerName,
            registryRecord,
            shortAgentName,
            routeKey,
            route: nextRoute,
            readinessRoute,
            manifest,
          };
        },
        allowFailures,
        commitResults: async (routeResults) => {
          for (const result of routeResults) {
            if (!result?.ok) continue;
            cfg.routes[result.routeKey] = result.route;
          }
          cfg = await mergeRoutingConfig((current) => {
            for (const result of routeResults) {
              if (!result?.ok) continue;
              reg[result.containerName] = result.registryRecord;
            }
            const next = {
              ...current,
              ...cfg,
              routes: {
                ...(cfg.routes || {}),
                ...(current.routes || {})
              }
            };
            for (const result of routeResults) {
              if (!result?.ok) continue;
              next.routes[result.routeKey] = result.route;
            }
            return next;
          }, { coordinate: false });
        },
      });
    };

    const { readyAgentKeys: graphReadyKeys, deferredNoWaitWaves } = await launchWorkspaceGraphWaves({
      graphWaves,
      nodes: dependencyGraph.nodes,
      noWaitNodeIds,
      registryNameByNodeId,
      availability: graphAvailability,
      launch: (names) => updateRoutes(names),
      readinessEntryFor: (node, blockingLaunch) => {
        const registryName = registryNameByNodeId.get(node.id);
        const registryRecord = registryName ? reg[registryName] : null;
        const routeKey = registryRecord?.alias || node.alias || node.shortAgentName;
        const launchResult = blockingLaunch.routeResults.find((result) => result.routeKey === routeKey);
        const route = launchResult?.readinessRoute || cfg.routes?.[routeKey] || null;
        return buildBlockingReadinessEntryFromNode(node, route, staticAgent);
      },
      waitForReadiness: waitForReadinessEntries,
      reportOutcome: reportHardwareOutcome,
      formatLabel: (node) => formatGraphNodeLabel(node, staticAgent),
    });
    readyAgentKeys.push(...graphReadyKeys);

    const additionalStartup = partitionAdditionalStartupAgents({
      registry: reg,
      names: allNames,
      graphRegistryNames,
      loadManifest: loadRegistryManifest,
      isRuntimeRunning: isRegistryRuntimeRunning,
    });
    if (additionalStartup.inactiveManual.length) {
      cfg = await mergeRoutingConfig((current) => {
        const routes = finalizeStartupRoutes(
          cfg.routes,
          current.routes,
          additionalStartup.inactiveManual,
        );
        return {
          ...current,
          ...cfg,
          routes,
        };
      }, { coordinate: false });
      console.log(`[start] Leaving ${additionalStartup.inactiveManual.length} manual agent(s) stopped: ${additionalStartup.inactiveManual.map(({ name }) => name).join(', ')}`);
    }

    const activeManualNames = additionalStartup.activeManual.map(({ name }) => name);
    if (additionalStartup.automatic.length) {
      console.log(`[start] Starting ${additionalStartup.automatic.length} additional enabled agent(s) outside the dependency graph: ${additionalStartup.automatic.join(', ')}`);
    }
    if (activeManualNames.length) {
      console.log(`[start] Retaining ${activeManualNames.length} explicitly active manual agent(s): ${activeManualNames.join(', ')}`);
    }
    const additional = await launchAdditionalRuntimes({
      additionalNames: [...additionalStartup.automatic, ...activeManualNames],
      availability: graphAvailability,
      launch: (names, options) => updateRoutes(names, options),
      readinessEntryFor: (result) => buildBlockingReadinessEntryFromNode({
        id: `extra:${result.routeKey}`,
        shortAgentName: result.shortAgentName,
        isStatic: false,
        manifest: result.manifest,
      }, result.readinessRoute || result.route, result.shortAgentName),
      waitForReadiness: waitForReadinessEntries,
      reportOutcome: reportHardwareOutcome,
    });
    readyAgentKeys.push(...additional.readyAgentKeys);

    for (const runtimeResult of workspaceMpsRuntimes) {
      if (readyAgentKeys.includes(runtimeResult?.containerName)) await verifyMpsRuntimeReady(runtimeResult);
    }

    if (mpsGraphPreparation.graphPreparationId) await finalizeMpsGraph({ networkLifecycleCapability });

    // Runtime-only registry metadata may change while the lifecycle binding
    // remains exact. Persist it once, after all capability-sensitive launches
    // have completed, so one wave cannot invalidate the selector-bound host
    // launch token needed by a later wave.
    await mergeRoutingConfig((current) => {
      workspaceSvc.saveAgents(reg, { coordinate: false });
      return current;
    }, {
      reason: 'workspace-runtime-graph-ready',
      preparationLease: workspacePreparationLease,
    });
    workspacePreparationLease = null;
    for (const runtimeResult of workspaceMpsRuntimes) {
      if (readyAgentKeys.includes(runtimeResult?.containerName)) await acknowledgeMpsRuntimeReady(runtimeResult);
    }
    workspaceMpsRuntimes.length = 0;
    for (const candidate of workspaceRuntimeCandidates) {
      if (!candidate.durableCandidate) continue;
      try { retireRuntimeCandidate(candidate.durableCandidate); } catch (error) {
        console.warn(`[start] active runtime recovery receipt could not be retired: ${error?.message || error}`);
      }
    }
    workspaceRuntimeCandidates.length = 0;

    const noWaitRunId = randomUUID();
    const noWaitRunStartedAtMs = Date.now();
    const noWaitSchedule = bindNoWaitLaunchScheduleIdentity(
      buildNoWaitLaunchSchedule(deferredNoWaitWaves, {
        runId: noWaitRunId,
        runStartedAtMs: noWaitRunStartedAtMs,
      }),
      reg,
    );
    // Clear every public and run-scoped status before spawning any worker.
    // The UUID-scoped coordination paths prevent a late writer from an older
    // detached invocation from satisfying this run's wave barrier.
    if (noWaitSchedule.length) {
      ensureVerifiedProducerDirectory({
        trustedRoot: PLOINKY_WORKSPACE_ROOT,
        relativeSegments: ['.ploinky', 'running', 'no-wait'],
        mode: 0o700,
      });
    }
    for (const entry of noWaitSchedule.flat()) {
      if (!entry.registryName || !entry.statusFile) continue;
      const canonicalStatusFile = path.join(RUNNING_DIR, 'no-wait', `${entry.registryName}.json`);
      for (const target of new Set([canonicalStatusFile, entry.statusFile])) {
        try { fs.unlinkSync(target); } catch (error) {
          if (error?.code !== 'ENOENT') throw error;
        }
      }
    }
    for (const wave of noWaitSchedule) {
      for (const entry of wave) {
        const { node, registryName } = entry;
        if (!registryName) {
          console.warn(`[start] no-wait node '${formatGraphNodeLabel(node, staticAgent)}' missing registry entry; skipping background launch.`);
          continue;
        }
        const knownOutcome = unavailableOutcome(node.id);
        if (knownOutcome) {
          // Cheap metadata already settled this optional instance: publish
          // its terminal typed outcome without creating a worker or runtime.
          try {
            writeNoWaitHardwareOutcome(entry, knownOutcome);
          } catch (publishErr) {
            console.error(sanitizeDiagnosticText(
              `[start] no-wait hardware outcome for '${formatGraphNodeLabel(node, staticAgent)}' could not be published: ${sanitizeDiagnosticText(publishErr)}`,
              { singleLine: true },
            ));
          }
          reportHardwareOutcome(knownOutcome);
          continue;
        }
        try {
          const { pid, logFile, statusFile } = await spawnNoWaitWorker({
            node,
            identity: entry.identity,
            routerPort: staticPort,
            forceRecreate: newlyPreparedContainers.has(registryName),
            statusFile: entry.statusFile,
            waitForStatuses: entry.waitForStatuses,
          });
          console.log(`[start] ${formatGraphNodeLabel(node, staticAgent)}: no-wait wave ${entry.waveIndex + 1}/${noWaitSchedule.length} launch started (pid ${pid}). log=${logFile} status=${statusFile}`);
          asynchronousAgentKeys.push(registryName);
        } catch (spawnErr) {
          // Publishing the terminal status is best-effort here. Letting it
          // throw would replace the real spawn failure with a publication
          // error and abort the whole start instead of reporting this node.
          try {
            writeNoWaitSpawnFailure(entry, spawnErr);
          } catch (publishErr) {
            console.error(sanitizeDiagnosticText(
              `[start] no-wait spawn failure status for '${formatGraphNodeLabel(node, staticAgent)}' could not be published: ${sanitizeDiagnosticText(publishErr)}`,
              { singleLine: true },
            ));
          }
          console.error(sanitizeDiagnosticText(
            `[start] no-wait launch for '${formatGraphNodeLabel(node, staticAgent)}' failed to spawn: ${sanitizeDiagnosticText(spawnErr)}`,
            { singleLine: true },
          ));
        }
      }
    }

    console.log(`[start] Watchdog will automatically restart the server if it crashes.`);
    console.log(`[start] Server logs: ${path.join(LOGS_DIR, 'router.log')}`);
    console.log(`[start] Watchdog logs: ${path.join(LOGS_DIR, 'watchdog.log')}`);
    console.log(`[start] Router: ${buildRouterUrl(staticPort)}`);
    reportDependencyCollection(collectDependencyObjectsAfterAdmission({ lease: workspaceStartLock, reason: 'workspace-start' }));
    const startResult = summarizeStartResult({
      readyAgents: readyAgentKeys.map((key) => ({ key })),
      asynchronousAgents: asynchronousAgentKeys.map((key) => ({ key })),
      refusedAgents: hardwareOutcomes.refused,
      blockedAgents: hardwareOutcomes.blocked,
    });
    printStartResultSummary(startResult);
    return startResult;
  } catch (e) {
    const cleanedCandidateIds = new Set();
    for (const candidate of workspaceRuntimeCandidates.reverse()) {
      const candidateId = String(candidate?.containerId || '');
      if (!candidateId || cleanedCandidateIds.has(candidateId)) continue;
      cleanedCandidateIds.add(candidateId);
      try {
        dockerSvc.cleanupExactAgentRuntimeCandidate(candidate);
      } catch (cleanupError) {
        e.message += `; exact workspace candidate cleanup: ${cleanupError?.message || cleanupError}`;
      }
    }
    workspaceRuntimeCandidates.length = 0;
    if (workspacePreparationLease) {
      try {
        abortEdgeRoutingPreparation(workspacePreparationLease, {
          reason: 'workspace-start-failed',
        });
      } catch (_) {}
      workspacePreparationLease = null;
    }
    const message = e?.message || String(e);
    if (message.startsWith('start:') || message.startsWith('start (workspace) failed:')) {
      throw e;
    }
    throw new Error(`start (workspace) failed: ${message}`);
  }
  }));
  } finally {
    releaseWorkspaceStartLock(workspaceStartLock);
  }
}

/**
 * Restarts replace the selector and stop the Router and agents before
 * startWorkspace runs. First wait for the previous start's no-wait workers,
 * whose half-created runtimes the stop could neither see nor remove, then
 * settle a stopped start's graph preparation under that same lease, so that
 * either refusal happens while the running graph is still untouched.
 */
async function settleWorkspaceBeforeRestart() {
  const workspaceMutationLease = await acquireSettledWorkspaceMutationLease({ operation: 'workspace-restart' });
  let callbackError = null;
  try {
    // Bound as this restart's own lease, like every lease owner without a callback.
    return runWithWorkspaceMutationLease(workspaceMutationLease, () => (
      withNetworkLifecycleLockReclaimingStoppedOwner((networkLifecycleCapability) => {
        const result = retireAbandonedWorkspaceStartPreparation({
          workspaceRoot: PLOINKY_WORKSPACE_ROOT,
          workspaceMutationLease,
          networkLifecycleCapability,
        });
        if (result.retired) {
          console.log(`[restart] Retired the routing preparation of stopped workspace start pid ${result.pid}.`);
        }
        return result;
      })
    ));
  } catch (error) {
    callbackError = error;
    throw error;
  } finally {
    if (!releaseWorkspaceMutationLease(workspaceMutationLease)) {
      const releaseError = new Error("workspace mutation 'workspace-restart' could not release its exact lease");
      releaseError.code = 'workspace_mutation_lock_release_failed';
      if (callbackError) callbackError.message += `; ${releaseError.message}`;
      else throw releaseError;
    }
  }
}

/**
 * `stop` replaces the selector that binds a killed start's graph preparation,
 * after which only a stopped Box can retire that lease. Retire it before the
 * rewrite, on exactly the proof start and restart require, but never at the
 * cost of the stop: a busy lease or lock, a live owner or any mismatch leaves
 * the preparation in place and the stop continues.
 */
function retireAbandonedStartPreparationBeforeStop({ log = (message) => console.log(message) } = {}) {
  let owner;
  try {
    owner = readEdgeRoutingPreparationOwner({ workspaceRoot: PLOINKY_WORKSPACE_ROOT });
  } catch (error) {
    log(`[stop] Could not inspect the routing preparation lease: ${error?.message || error}`);
    return { retired: false };
  }
  if (!owner) return { retired: false };
  const leftInPlace = (why) => {
    log(`[stop] Left the routing preparation of pid ${owner.pid} (${owner.reason}) in place: ${why}`);
    return { retired: false };
  };
  let workspaceMutationLease;
  try {
    workspaceMutationLease = createWorkspaceMutationLease({ operation: 'workspace-stop' });
  } catch (error) {
    return leftInPlace(error?.message || String(error));
  }
  try {
    const retire = (networkLifecycleCapability) => retireAbandonedWorkspaceStartPreparation({
      workspaceRoot: PLOINKY_WORKSPACE_ROOT,
      workspaceMutationLease,
      networkLifecycleCapability,
    });
    // A killed start leaves its network lock behind, reclaimable once the
    // stale-owner grace has passed. Wait out that grace, never a live owner.
    const result = runWithWorkspaceMutationLease(workspaceMutationLease, () => (
      withNetworkLifecycleLockReclaimingStoppedOwner(retire)
    ));
    if (result.retired) {
      log(`[stop] Retired the routing preparation of stopped workspace start pid ${result.pid}.`);
    }
    return result;
  } catch (error) {
    return leftInPlace(error?.message || String(error));
  } finally {
    let released = false;
    try { released = releaseWorkspaceMutationLease(workspaceMutationLease); } catch (_) {}
    if (!released) log('[stop] Could not release the workspace lease taken to inspect the routing preparation.');
  }
}

export function admitDirectAgentRuntimeManifest(manifest, {
  manifestPath = '',
  manifestBytes,
  agentId = '',
  profileName,
  persistedProfileName,
  instanceKey,
  alias,
} = {}) {
  const exactBytes = manifestBytes === undefined
    ? (manifestPath && fs.existsSync(manifestPath)
      ? fs.readFileSync(manifestPath)
      : Buffer.from(JSON.stringify(manifest || {})))
    : manifestBytes;
  const exactManifest = JSON.parse(Buffer.from(exactBytes).toString('utf8'));
  if (JSON.stringify(exactManifest) !== JSON.stringify(manifest)) {
    const error = new Error(`runtime manifest bytes changed before admission for '${agentId || manifestPath}'`);
    error.code = 'PLOINKY_RUNTIME_INPUT_CHANGED';
    error.status = 409;
    throw error;
  }
  const profileResolution = resolveManifestRuntimeProfile(exactManifest, {
    agentName: agentId,
    profileName,
    persistedProfileName,
    path: `manifest(${agentId || manifestPath})`,
  });
  const runtime = getRuntimeForAgent(exactManifest);
  const runtimeKind = isSandboxRuntime(runtime) ? runtime : 'container';
  const llmAdmissionContext = runtimeKind === 'container'
    ? resolveLlmRuntimeAdmissionContext({
      runtime,
      manifest: exactManifest,
      profileConfig: profileResolution.profileConfig,
      agentName: String(agentId || '').split('/').pop(),
      env: process.env,
    })
    : { catalogPolicy: null, catalogIdentity: null };
  const runtimeAdmission = admitManifestRuntimeCapabilities(exactManifest, {
    manifestBytes: exactBytes,
    manifestPath,
    agentId,
    instanceKey,
    alias,
    profileName: profileResolution.resolvedProfileName,
    profileConfig: profileResolution.profileConfig,
    network: profileResolution.network,
    runtime,
    runtimeKind,
    catalogPolicy: llmAdmissionContext.catalogPolicy,
    catalogIdentity: llmAdmissionContext.catalogIdentity,
  });
  return Object.freeze({ runtimeAdmission, profileResolution, runtime, runtimeKind });
}

export async function runCliWithDependencies(agentName, args, dependencies) {
  if (!agentName) { throw new Error('Usage: cli <agentName> [args...]'); }
  const {
    env,
    resolveEnabledAgentRecord,
    findAgent,
    enableAgent,
    readManifest,
    ensureAgentService,
    getAgentContainerName: getAgentContainerNameImpl = dockerSvc.getAgentContainerName,
    resolveAgentReadinessProtocol: resolveAgentReadinessProtocolImpl = resolveAgentReadinessProtocol,
    waitForManifestReadiness: waitForManifestReadinessImpl = waitForManifestReadiness,
    waitForAgentReady: waitForAgentReadyImpl,
    activateRuntimeAfterReadiness: activateRuntimeAfterReadinessImpl = activatePreparedRuntimeAfterReadiness,
    loadAgentsMap: loadAgentsMapImpl,
    withMaintenanceLock: withMaintenanceLockImpl = withMaintenanceLock,
    withNetworkLifecycleLock: withNetworkLifecycleLockImpl = withNetworkLifecycleLockAsync,
    attachInteractive,
    attachBwrapInteractive,
    attachSeatbeltInteractive,
    resolveRouterEndpointForManifest: resolveRouterEndpointForManifestImpl = resolveManifestRouterEndpoint,
    projectPath,
    debugLog = () => {},
    log = () => {},
    warn = () => {},
    error = () => {},
    withSuspendedInput = callback => callback(),
    admitRuntimeManifest = admitDirectAgentRuntimeManifest,
    notifyCliReady = () => {
      if (startupControlFd === null) return;
      fs.writeSync(1, CLI_OUTPUT_BOUNDARY);
      fs.writeSync(2, CLI_OUTPUT_BOUNDARY);
      // This private launcher pipe is not part of the agent's stdout protocol.
      fs.writeSync(startupControlFd, JSON.stringify({ version: 1, state: 'ready' }) + '\n');
    },
  } = dependencies;
  const startupControlFd = env.PLOINKY_WEBCHAT_STARTUP_FD === '3' ? 3 : null;
  delete env.PLOINKY_WEBCHAT_STARTUP_FD;
  const suppressLauncherLogs = env.PLOINKY_NO_TTY === '1';
  let registryRecord = null;
  let manifestLookup = agentName;
  let routerEndpoint;
  try {
    registryRecord = resolveEnabledAgentRecord(agentName);
  } catch (err) {
    error(err?.message || err);
    return;
  }

  if (!registryRecord) {
    let autoEnableRef = null;
    let autoEnableManifestPath = '';
    try {
      const resolved = findAgent(agentName);
      autoEnableRef = `${resolved.repo}/${resolved.shortAgentName}`;
      manifestLookup = autoEnableRef;
      autoEnableManifestPath = resolved.manifestPath;
    } catch (err) {
      error(`Agent '${agentName}' is not found.`);
      if (err?.message) {
        error(err.message);
      }
      return;
    }

    const manifestBeforeEnable = readManifest(autoEnableManifestPath);
    routerEndpoint = resolveRouterEndpointForManifestImpl(manifestBeforeEnable, {
      path: `manifest(${autoEnableRef})`,
    });

    try {
      await enableAgent(autoEnableRef, 'global');
    } catch (err) {
      error(`Failed to enable '${agentName}' in global mode: ${err?.message || err}`);
      return;
    }

    try {
      registryRecord = resolveEnabledAgentRecord(agentName);
      if (!registryRecord) {
        registryRecord = resolveEnabledAgentRecord(autoEnableRef);
      }
    } catch (err) {
      error(err?.message || err);
      return;
    }
  }

  const resolvedManifestRef = registryRecord
    ? `${registryRecord.record.repoName}/${registryRecord.record.agentName}`
    : manifestLookup;
  const { manifestPath, shortAgentName } = findAgent(resolvedManifestRef);
  const manifest = readManifest(manifestPath);
  const directAdmission = admitRuntimeManifest(manifest, {
    manifestPath,
    agentId: resolvedManifestRef,
    persistedProfileName: registryRecord?.record?.profile,
  });
  resolveManifestStartup(manifest);
  if (routerEndpoint === undefined) {
    routerEndpoint = resolveRouterEndpointForManifestImpl(manifest, {
      persistedProfileName: registryRecord?.record?.profile,
      path: `manifest(${resolvedManifestRef})`,
    });
  }
  const cliBase = getCliCmd(manifest);
  if (!cliBase || !cliBase.trim()) { throw new Error(`Manifest for '${shortAgentName}' has no 'cli' command.`); }

  // Separate SSO args from regular args — SSO context is passed as env vars,
  // not CLI flags, so plain shell CLIs (/bin/sh) don't crash on unknown options.
  const ssoArgs = (args || []).filter(a => /^--sso-/.test(a));
  const regularArgs = (args || []).filter(a => !/^--sso-/.test(a));
  const ssoExports = ssoArgs.map(a => {
    const match = a.match(/^--sso-(.+?)=(.*)$/);
    if (!match) return '';
    const envName = 'SSO_' + match[1].toUpperCase().replace(/-/g, '_');
    return `${envName}=${shellQuote(match[2])}`;
  }).filter(Boolean);
  const ssoPrefix = ssoExports.length ? 'export ' + ssoExports.join(' ') + '; ' : '';
  const rawCmd = ssoPrefix + cliBase + (regularArgs.length ? (' ' + regularArgs.map(shellQuote).join(' ')) : '');
  const cmd = wrapCliWithWebchat(rawCmd, env);
  const agentDir = path.dirname(manifestPath);
  const repoName = resolveAgentRepositoryName(agentDir);
  const initialContainerName = registryRecord?.containerName || getAgentContainerNameImpl(shortAgentName, repoName);
  const expectedAlias = String(registryRecord?.record?.alias || '');
  const maintenanceContainerName = initialContainerName;
  debugLog(`[runCli] agent=${agentName} container=${initialContainerName} maintenance=${maintenanceContainerName}`);
  let containerInfo = null;
  let containerName = initialContainerName;
  await withMaintenanceLockImpl(maintenanceContainerName, {
    operation: 'cli-start',
    metadata: {
      agent: shortAgentName,
      repo: repoName,
    },
  }, async () => {
    const lifecycleResult = await withNetworkLifecycleLockImpl(async (networkLifecycleCapability) => {
      // A different agent can hold this workspace-wide lock through readiness.
      // Resolve the current exact target only after that wait, before mutation.
      const refreshedAgents = loadAgentsMapImpl() || {};
      const matchesIdentity = (record) => (
        record?.type === 'agent'
        && String(record.repoName || '') === repoName
        && String(record.agentName || '') === shortAgentName
        && String(record.alias || '') === expectedAlias
      );
      const initialRefreshedRecord = refreshedAgents[initialContainerName];
      if (initialRefreshedRecord) {
        if (!matchesIdentity(initialRefreshedRecord)) {
          throw new Error(`CLI startup for '${expectedAlias || shortAgentName}' found a changed runtime identity.`);
        }
        registryRecord = { containerName: initialContainerName, record: initialRefreshedRecord };
      } else {
        const refreshedMatches = Object.entries(refreshedAgents).filter(([, record]) => matchesIdentity(record));
        if (refreshedMatches.length !== 1) {
          throw new Error(
            `CLI startup for '${expectedAlias || shortAgentName}' requires one exact refreshed runtime identity; found ${refreshedMatches.length}.`,
          );
        }
        registryRecord = { containerName: refreshedMatches[0][0], record: refreshedMatches[0][1] };
      }
      let result = null;
      try {
        result = await ensureAgentService(shortAgentName, manifest, agentDir, {
          containerName: registryRecord?.containerName,
          alias: registryRecord?.record?.alias,
          routerEndpoint,
          runtimeAdmission: directAdmission.runtimeAdmission,
          networkLifecycleCapability,
          // The registry tuple read above is the only runtime this start may replace.
          expectedPredecessor: registeredRuntimeTuple(registryRecord?.record),
        });
        const exactContainerName = result?.containerName
          || registryRecord?.containerName
          || initialContainerName;
        const cliReadinessRoute = buildRelayReadinessRoute({
          route: {
            container: exactContainerName,
            hostPort: result?.hostPort || 0,
          },
          manifest,
          runtimeResult: result,
          networkMode: routerEndpoint?.mode || '',
          generationDigest: result?.preparationLease?.preparedGeneration || '',
        });
        const readinessProtocol = resolveAgentReadinessProtocolImpl(manifest);
        if (readinessProtocol === 'script') {
          await waitForManifestReadinessImpl({
            key: `cli:${shortAgentName}`,
            label: shortAgentName,
            manifest,
            route: cliReadinessRoute,
          });
        } else if (readinessProtocol !== 'none') {
          const hasReadinessTarget = Boolean(cliReadinessRoute.hostPort || cliReadinessRoute.relay);
          if (!hasReadinessTarget) {
            if (result?.requiresEdgeActivation) {
              throw new Error(`Agent '${shortAgentName}' replacement cannot activate without a resolved '${readinessProtocol}' readiness target.`);
            }
            if (!suppressLauncherLogs) {
              warn(`[cli] warning: cannot wait for '${shortAgentName}' readiness because no host port or confined relay target was resolved.`);
            }
          } else {
            if (!suppressLauncherLogs) {
              log(`[cli] Waiting for '${shortAgentName}' readiness (${readinessProtocol})...`);
            }
            const ready = await waitForAgentReadyImpl(cliReadinessRoute, {
              timeoutMs: resolveManifestReadinessWaitOptions(manifest, 600000).timeoutMs,
              protocol: readinessProtocol,
            });
            if (!ready) {
              throw new Error(`Agent '${shortAgentName}' did not become ready before CLI attach.`);
            }
          }
        }
        await activateRuntimeAfterReadinessImpl({
          result,
          routeKey: registryRecord?.record?.alias || shortAgentName,
          repoName,
          shortAgentName,
          agentPath: agentDir,
          alias: registryRecord?.record?.alias || '',
          networkLifecycleCapability,
        });
        return { containerInfo: result, containerName: exactContainerName };
      } catch (error) {
        cleanupFailedPreparedRuntime(result, error);
        throw error;
      }
    }, {
      // Interactive starts share the ordinary network acquisition budget, not
      // the longer background no-wait worker retry policy or readiness budget.
      waitMs: NETWORK_LOCK_WAIT_MS,
    });
    containerInfo = lifecycleResult.containerInfo;
    containerName = lifecycleResult.containerName;
  });

  // Determine actual runtime from registry (may differ from manifest if sandbox
  // failed and fell back to container during ensureAgentService)
  const agents = loadAgentsMapImpl();
  const registryEntry = agents[containerName] || {};
  const actualRuntime = registryEntry.runtime;

  let exitCode = 0;
  if (!suppressLauncherLogs) {
    const identity = resolveAgentAttachmentIdentity(
      shortAgentName,
      containerName,
      agents,
    );
    for (const line of formatAgentAttachmentBanner(identity)) {
      log(line);
    }
  }

  if (actualRuntime === 'bwrap') {
    const attach = attachBwrapInteractive
      || (await import('../sandbox/bwrap/bwrapServiceManager.js')).attachBwrapInteractive;
    exitCode = withSuspendedInput(() => {
      return attach(shortAgentName, manifest, agentDir, projectPath, cmd, { containerName, routerEndpoint, onReady: notifyCliReady });
    });
  } else if (actualRuntime === 'seatbelt') {
    const attach = attachSeatbeltInteractive
      || (await import('../sandbox/seatbelt/seatbeltServiceManager.js')).attachSeatbeltInteractive;
    exitCode = withSuspendedInput(() => {
      return attach(shortAgentName, manifest, agentDir, projectPath, cmd, { containerName, routerEndpoint, onReady: notifyCliReady });
    });
  } else {
    exitCode = withSuspendedInput(() => {
      return attachInteractive(containerName, projectPath, cmd, { onReady: notifyCliReady });
    });
  }
  return Number.isInteger(exitCode) ? exitCode : 0;
}

async function runCli(agentName, args) {
  const { ensureAgentService, attachInteractive, getAgentContainerName } = dockerSvc;
  return runCliWithDependencies(agentName, args, {
    env: process.env,
    resolveEnabledAgentRecord: (...callArgs) => agentsSvc.resolveEnabledAgentRecord(...callArgs),
    findAgent: (...callArgs) => utils.findAgent(...callArgs),
    enableAgent: (...callArgs) => agentsSvc.enableAgent(...callArgs),
    readManifest: manifestPath => JSON.parse(fs.readFileSync(manifestPath, 'utf8')),
    ensureAgentService,
    getAgentContainerName,
    resolveAgentReadinessProtocol,
    waitForManifestReadiness,
    waitForAgentReady,
    loadAgentsMap,
    attachInteractive,
    projectPath: PLOINKY_CWD,
    debugLog: (...callArgs) => utils.debugLog(...callArgs),
    log: (...callArgs) => console.log(...callArgs),
    warn: (...callArgs) => console.warn(...callArgs),
    error: (...callArgs) => console.error(...callArgs),
    withSuspendedInput: runWithSuspendedInput,
  });
}

async function runShell(agentName) {
  if (!agentName) { throw new Error('Usage: shell <agentName>'); }
  let registryRecord = null;
  try {
    registryRecord = agentsSvc.resolveEnabledAgentRecord(agentName);
  } catch (err) {
    console.error(err?.message || err);
    return;
  }
  const manifestLookup = registryRecord
    ? `${registryRecord.record.repoName}/${registryRecord.record.agentName}`
    : agentName;
  const { manifestPath, shortAgentName } = utils.findAgent(manifestLookup);
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
  const directAdmission = admitDirectAgentRuntimeManifest(manifest, {
    manifestPath,
    agentId: manifestLookup,
    persistedProfileName: registryRecord?.record?.profile,
  });
  const routerEndpoint = resolveManifestRouterEndpoint(manifest, {
    persistedProfileName: registryRecord?.record?.profile,
    path: `manifest(${manifestLookup})`,
  });
  const { ensureAgentService, attachInteractive, getConfiguredProjectPath, getAgentContainerName } = dockerSvc;
  const agentDir = path.dirname(manifestPath);
  const repoName = resolveAgentRepositoryName(agentDir);
  const registeredContainerName = registryRecord?.containerName || getAgentContainerName(shortAgentName, repoName);
  const { containerInfo, containerName } = await withNetworkLifecycleLock(async (networkLifecycleCapability) => {
    let result = null;
    try {
      result = await ensureAgentService(shortAgentName, manifest, agentDir, {
        containerName: registeredContainerName,
        alias: registryRecord?.record?.alias,
        routerEndpoint,
        runtimeAdmission: directAdmission.runtimeAdmission,
        networkLifecycleCapability,
        expectedPredecessor: registeredRuntimeTuple(registryRecord?.record),
      });
      const exactContainerName = result?.containerName || registeredContainerName;
      const shellReadinessRoute = buildRelayReadinessRoute({
        route: {
          container: exactContainerName,
          hostPort: result?.hostPort || 0,
        },
        manifest,
        runtimeResult: result,
        networkMode: routerEndpoint?.mode || '',
        generationDigest: result?.preparationLease?.preparedGeneration || '',
      });
      await waitForManifestReadiness({
        key: `shell:${shortAgentName}`,
        label: shortAgentName,
        kind: 'dependency',
        manifest,
        route: shellReadinessRoute,
      });
      await activatePreparedRuntimeAfterReadiness({
        result,
        routeKey: registryRecord?.record?.alias || shortAgentName,
        repoName,
        shortAgentName,
        agentPath: agentDir,
        alias: registryRecord?.record?.alias || '',
        networkLifecycleCapability,
      });
      return { containerInfo: result, containerName: exactContainerName };
    } catch (error) {
      cleanupFailedPreparedRuntime(result, error);
      throw error;
    }
  });
  const cmd = '/bin/sh';
  const projPath = getConfiguredProjectPath(shortAgentName, repoName, registryRecord?.record?.alias);

  // Determine actual runtime from registry (may differ from manifest if sandbox
  // failed and fell back to container during ensureAgentService)
  const agents = loadAgentsMap();
  const registryEntry = agents[containerName] || {};
  const actualRuntime = registryEntry.runtime;

  if (actualRuntime === 'bwrap') {
    console.log(`[shell] bwrap agent: ${shortAgentName}`);
    console.log(`[shell] command: ${cmd}`);
    const { attachBwrapInteractive } = await import('../sandbox/bwrap/bwrapServiceManager.js');
    runWithSuspendedInput(() => {
      attachBwrapInteractive(shortAgentName, manifest, agentDir, projPath, cmd, { containerName, routerEndpoint });
    });
  } else if (actualRuntime === 'seatbelt') {
    console.log(`[shell] seatbelt agent: ${shortAgentName}`);
    console.log(`[shell] command: ${cmd}`);
    const { attachSeatbeltInteractive } = await import('../sandbox/seatbelt/seatbeltServiceManager.js');
    runWithSuspendedInput(() => {
      attachSeatbeltInteractive(shortAgentName, manifest, agentDir, projPath, cmd, { containerName, routerEndpoint });
    });
  } else {
    console.log(`[shell] container: ${containerName}`);
    console.log(`[shell] command: ${cmd}`);
    console.log(`[shell] agent: ${shortAgentName}`);
    runWithSuspendedInput(() => {
      attachInteractive(containerName, projPath, cmd);
    });
  }
}

async function reinstallAgent(agentName) {
    const routerPort = resolvePersistedRouterPort();
    if (!agentName) { throw new Error('Usage: reinstall <name> | reinstall agent <name>'); }

    const { getAgentContainerName, ensureAgentService } = dockerSvc;
    // Reinstall targets exactly one enabled registration/alias. An ambiguous
    // or unresolvable reference fails (nonzero) before any state changes.
    let registryRecord = null;
    try {
        registryRecord = agentsSvc.resolveEnabledAgentRecord(agentName);
    } catch (err) {
        console.error(err?.message || err);
        throw err;
    }
    if (!registryRecord) {
        throw new Error(`Agent '${agentName}' is not enabled. Run 'ploinky start ${agentName}' first.`);
    }

    let resolved;
    try {
        const lookup = registryRecord
            ? `${registryRecord.record.repoName}/${registryRecord.record.agentName}`
            : agentName;
        resolved = utils.findAgent(lookup);
    } catch (err) {
        console.error(err?.message || `Agent '${agentName}' not found.`);
        return;
    }

    const containerName = registryRecord?.containerName || getAgentContainerName(resolved.shortAgentName, resolved.repo);

    // Read manifest early to determine runtime
    let manifest;
    try {
        manifest = JSON.parse(fs.readFileSync(resolved.manifestPath, 'utf8'));
    } catch (err) {
        console.error(`Failed to read manifest for '${agentName}': ${err?.message || err}`);
        return;
    }
    const routerEndpoint = resolveManifestRouterEndpoint(manifest, {
        explicitPort: routerPort,
        persistedProfileName: registryRecord?.record?.profile,
        path: `manifest(${resolved.repo}/${resolved.shortAgentName})`,
    });
    const directAdmission = admitDirectAgentRuntimeManifest(manifest, {
        manifestPath: resolved.manifestPath,
        agentId: `${resolved.repo}/${resolved.shortAgentName}`,
        persistedProfileName: registryRecord?.record?.profile,
    });

    const agentRuntime = getRuntimeForAgent(manifest);

    // Failed installations may have no runtime. The shared runtime manager
    // validates ownership and recreates missing, stopped, or running agents.

    console.log(`Reinstalling (re-creating) agent '${agentName}'...`);

    try {
        await withWorkspaceMutationLease({ operation: 'reinstall' }, async (workspaceMutationLease) => {
        await withMaintenanceLock(containerName, {
            operation: 'reinstall',
            metadata: {
                agent: resolved.shortAgentName,
                repo: resolved.repo,
            },
        }, async () => {
          return await withNetworkLifecycleLock(async (networkLifecycleCapability) => {
            let reinstallResult = null;
            let dependencyRebuild = null;
            let runtimeAdmitted = false;
            try {
            const currentRegistration = agentsSvc.resolveEnabledAgentRecord(agentName);
            if (currentRegistration?.containerName !== containerName
                || ['repoName', 'agentName', 'instanceId', 'enableGeneration', 'profile', 'alias'].some(
                    field => currentRegistration?.record?.[field] !== registryRecord.record[field],
                )) {
              throw new Error(`Agent '${agentName}' changed while waiting for reinstall; retry with its current registration.`);
            }
            // One exact logical registration gets a persistent desired rebuild
            // request (reused while it is still pending or failed). Its runtime
            // then builds from empty npm state, bypassing seeds.
            dependencyRebuild = issueDependencyRebuildRequest(containerName, { lease: workspaceMutationLease });
            const short = resolved.shortAgentName;
            const agentPath = path.dirname(resolved.manifestPath);
            const edgeSelection = readEdgeRoutingSelection();
            const stageAlongsidePredecessor = edgeSelection.selector.state === 'active';
            if (!stageAlongsidePredecessor) {
              retireAbandonedAgentPreparation(containerName, { workspaceMutationLease, networkLifecycleCapability });
            }

            // Failed workspace startup stops the Router. Runtime creation needs
            // its private attestation service before replacement can begin.
            const isRouterUp = (p) => {
                try {
                    const out = execSync(`lsof -t -i :${p} -sTCP:LISTEN`, { stdio: 'pipe' }).toString().trim();
                    if (out) return true;
                } catch(_) {}
                try {
                    const out = execSync('ss -ltnp', { stdio: 'pipe' }).toString();
                    return out.includes(`:${p}`) && out.includes('LISTEN');
                } catch(_) { return false; }
            };
            if (!isRouterUp(routerPort)) {
                const runningDir = RUNNING_DIR;
                fs.mkdirSync(runningDir, { recursive: true });
                const routerPath = path.resolve(__dirname, '../server/Watchdog.js');
                const routerPidFile = path.join(runningDir, 'router.pid');
                const child = spawnWatchdog(routerPath, routerPort, routerPidFile);
                try { fs.writeFileSync(routerPidFile, String(child.pid)); } catch(_) {}
                child.unref();
                await waitForRouterReady(routerPort, child);
                console.log(`[reinstall] Watchdog launched (pid ${child.pid}) on port ${routerPort}.`);
                console.log(`[reinstall] Watchdog will automatically restart the server if needed.`);
            }
            if (!stageAlongsidePredecessor && !isSandboxRuntime(agentRuntime)) {
              dockerSvc.removeAgentContainerForRecreate(
                containerName,
                'inactiveManifestReplacement',
              );
            }

            // The shared runtime manager owns inactivation and physical
            // replacement for every backend, including host sandboxes.
            reinstallResult = await ensureAgentService(short, manifest, agentPath, {
                containerName,
                alias: registryRecord?.record?.alias,
                forceRecreate: true,
                forceRecreateReason: 'reinstall command',
                routerEndpoint,
                runtimeAdmission: directAdmission.runtimeAdmission,
                networkLifecycleCapability,
                stageAlongsidePredecessor,
                // The registration read before the call (and re-verified under
                // the locks above) is the runtime a reinstall replaces.
                expectedPredecessor: registryRecord?.record?.instanceId && registryRecord?.record?.enableGeneration
                    ? {
                        instanceId: registryRecord.record.instanceId,
                        enableGeneration: registryRecord.record.enableGeneration,
                    }
                    : null,
            });
            const { containerName: newContainerName, hostPort } = reinstallResult;

            const repoName = resolveAgentRepositoryName(agentPath);
            const routeKey = registryRecord?.record.alias || short;
            const reinstallReadinessRoute = buildRelayReadinessRoute({
                route: {
                    container: newContainerName,
                    hostPort: hostPort || 0,
                },
                manifest,
                runtimeResult: reinstallResult,
                networkMode: routerEndpoint?.mode || '',
                generationDigest: reinstallResult?.preparationLease?.preparedGeneration || '',
            });

            await waitForManifestReadiness({
                key: `reinstall:${routeKey}`,
                label: short,
                kind: 'reinstall',
                manifest,
                route: reinstallReadinessRoute,
            });

            await activatePreparedRuntimeAfterReadiness({
                result: reinstallResult,
                routeKey,
                repoName,
                shortAgentName: short,
                agentPath,
                alias: registryRecord?.record?.alias || '',
                networkLifecycleCapability,
            });
            runtimeAdmitted = true;

            // Only an activated replacement publishes its admitted reference.
            // The runtime is already active here, so a settlement failure is
            // reported without undoing the activation.
            try {
              // Admit only a replacement that actually used the request's token.
              const applied = runtimeCarriesRebuildToken(reinstallResult?.registryRecord, dependencyRebuild.token);
              settleDependencyRebuildRequest(containerName, dependencyRebuild.token, {
                lease: workspaceMutationLease,
                outcome: applied ? 'admitted' : 'failed',
                ...(applied ? {} : { error: new Error('the activated runtime did not use the requested dependency rebuild') }),
              });
              if (!applied) throw new Error('the activated runtime did not use the requested dependency rebuild; the request stays retryable');
            } catch (settleError) {
              const recovery = new Error(`[reinstall] ${short}: runtime activated, but dependency rebuild settlement requires recovery: ${settleError?.message || settleError}`);
              recovery.code = 'PLOINKY_DEPS_REBUILD_RECOVERY_REQUIRED';
              recovery.cause = settleError;
              throw recovery;
            }
            console.log(`[reinstall] reinstalled '${short}' [container: ${newContainerName}]`);
            reportDependencyCollection(collectDependencyObjectsAfterAdmission({ lease: workspaceMutationLease, reason: 'reinstall' }));
            } catch (error) {
              // Activation is already committed. Report failure without
              // destroying the admitted replacement or claiming a rollback.
              if (runtimeAdmitted) throw error;
              cleanupFailedPreparedRuntime(reinstallResult, error, 'runtime-reinstall-readiness-failed');
              if (dependencyRebuild) {
                try {
                  settleDependencyRebuildRequest(containerName, dependencyRebuild.token, {
                    lease: workspaceMutationLease, outcome: 'failed', error,
                  });
                } catch (settleError) {
                  error.message += `; dependency rebuild request could not record the failure: ${settleError?.message || settleError}`;
                }
              }
              throw error;
            }
          });
        });
        });
    } catch (e) {
        console.error(`[reinstall] ${agentName}: ${e?.message||e}`);
        throw e;
    }
}

export {
  assertStaticPreinstallSucceeded,
  buildRouterUrl,
  buildBlockingReadinessEntryFromNode,
  computeRetainedManagedEnvHash,
  activatePreparedRuntimeAfterReadiness,
  deduplicateAgentRegistry,
  ensureGraphNodesEnabled,
  removeGraphContainerForRecreate,
  reprepareGraphAfterStartupProviders,
  resolveStaticRouterContainerName,
  resolveExtraEnabledRuntimeNodes,
  resolveManifestRouterEndpoint,
  resolveAndPersistStartRouterPort,
  resolveGraphNodeExecutionRecord,
  resolveRetainedGraphNodeExecutionRecord,
  retireAbandonedStartPreparationBeforeStop,
  settleWorkspaceBeforeRestart,
  waitForRouterReady,
  waitForManifestReadiness,
  waitForReadinessEntries,
  startWorkspace,
  runCli,
  runShell,
  reinstallAgent
};
