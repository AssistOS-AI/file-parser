import fs from 'fs';
import { listAgentRepositoryNames, resolveAgentRepositoryPath } from '../agentRepositorySource.mjs';
import path from 'path';
import { PROFILE_FILE, PLOINKY_CWD, PLOINKY_DIR, PLOINKY_WORKSPACE_ROOT, REPOS_DIR } from '../config.js';
import { validateSecrets } from '../security/secretInjector.js';
import { collectManifestEnv, validateManifestEnvProfileCompleteness } from '../security/secretVars.js';
import { debugLog, findAgent } from '../utils.js';
import { effectiveManifestNetwork, validateManifestNetworks } from '../../sandbox/networkContract.js';
import { mergeProfileHardwareLimits } from '../../sandbox/hardwareLimits/declaredLimits.mjs';

// Discover all valid profile names from installed agent manifests.
// Any profile name declared in a manifest's "profiles" section is valid.
// "default" is always valid — it's the base profile every agent must have.
function discoverManifestProfiles() {
    const discovered = new Set(['default']);
    try {
        for (const repo of listAgentRepositoryNames()) {
            const repoDir = resolveAgentRepositoryPath(repo);
            if (!fs.statSync(repoDir).isDirectory()) continue;
            for (const agent of fs.readdirSync(repoDir)) {
                const manifestPath = path.join(repoDir, agent, 'manifest.json');
                try {
                    if (!fs.existsSync(manifestPath)) continue;
                    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
                    if (manifest?.profiles && typeof manifest.profiles === 'object') {
                        for (const profileName of Object.keys(manifest.profiles)) {
                            discovered.add(profileName);
                        }
                    }
                } catch (_) {}
            }
        }
    } catch (_) {}
    return discovered;
}

function isValidProfile(profileName) {
    return discoverManifestProfiles().has(profileName);
}

// Hook names in execution order
// preinstall: HOST hook that runs BEFORE container creation (can set ploinky vars)
// hosthook_aftercreation: HOST hook that runs after container creation
// install: CONTAINER hook for installation
// postinstall: CONTAINER hook after install
// hosthook_postinstall: HOST hook after container postinstall
const HOOK_NAMES = ['preinstall', 'hosthook_aftercreation', 'install', 'postinstall', 'hosthook_postinstall'];

/**
 * Merge env configurations, handling both array and object formats.
 * Array format: ["VAR1", "VAR2=value"] - variable names to pull from .secrets
 * Object format: { "VAR1": "value" } - explicit key-value pairs
 *
 * For arrays: concatenate and deduplicate (active entries override default for same var name)
 * For objects: shallow merge (active overrides default)
 * For mixed: convert to array format and merge
 *
 * @param {Array|object} defaultEnv - Default profile env
 * @param {Array|object} activeEnv - Active profile env
 * @returns {Array|object} Merged env
 */
function mergeEnv(defaultEnv, activeEnv) {
    const defaultIsArray = Array.isArray(defaultEnv);
    const activeIsArray = Array.isArray(activeEnv);

    // Both arrays - merge and deduplicate
    if (defaultIsArray && activeIsArray) {
        const result = [];
        const seenVars = new Set();

        // Helper to extract variable name from array entry
        const getVarName = (entry) => {
            if (typeof entry === 'string') {
                const eqIdx = entry.indexOf('=');
                return eqIdx >= 0 ? entry.slice(0, eqIdx) : entry;
            }
            if (entry && typeof entry === 'object') {
                return entry.name || '';
            }
            return '';
        };

        // Add active entries first (they take precedence)
        for (const entry of activeEnv) {
            const varName = getVarName(entry);
            if (varName) {
                seenVars.add(varName);
                result.push(entry);
            }
        }

        // Add default entries that aren't overridden
        for (const entry of defaultEnv) {
            const varName = getVarName(entry);
            if (varName && !seenVars.has(varName)) {
                result.push(entry);
            }
        }

        return result;
    }

    // Both objects - shallow merge
    if (!defaultIsArray && !activeIsArray) {
        return { ...(defaultEnv || {}), ...(activeEnv || {}) };
    }

    // Mixed formats - convert object specs to array specs without flattening
    // structured entries into "[object Object]" strings.
    const toArray = (env) => {
        if (Array.isArray(env)) return env;
        if (!env || typeof env !== 'object') return [];
        return Object.entries(env).map(([key, val]) => {
            if (val && typeof val === 'object' && !Array.isArray(val)) {
                const { name: sourceName, varName, ...rest } = val;
                return {
                    name: key,
                    ...rest,
                    ...(varName !== undefined
                        ? { varName }
                        : (sourceName !== undefined ? { varName: sourceName } : {})),
                };
            }
            return val === '' || val === undefined ? key : `${key}=${val}`;
        });
    };

    return mergeEnv(toArray(defaultEnv), toArray(activeEnv));
}

/**
 * Merge default profile with active profile.
 * - Env variables: smart merge (handles both array and object formats)
 * - Hooks: active overrides default (not concatenate)
 * - Secrets: concatenate (active adds to default)
 * - Mounts: deep merge (active overrides default)
 * - Hardware limits (memory, cpus, pidsLimit): per key, active overrides
 *   default; each profile's own conflict is kept so admission refuses it
 *
 * @param {object} defaultProfile - The default profile configuration
 * @param {object} activeProfile - The active profile configuration
 * @returns {object} Merged profile configuration
 */
export function mergeProfiles(defaultProfile, activeProfile) {
    if (!defaultProfile) return activeProfile || {};
    if (!activeProfile || activeProfile === defaultProfile) return defaultProfile;

    const merged = { ...defaultProfile };

    // Merge env - handle both array and object formats
    if (activeProfile.env !== undefined) {
        merged.env = mergeEnv(defaultProfile.env, activeProfile.env);
    }

    // Hooks: active overrides default
    for (const hook of HOOK_NAMES) {
        if (activeProfile[hook] !== undefined) {
            merged[hook] = activeProfile[hook];
        }
    }

    // Merge array fields by concatenation (secrets)
    if (activeProfile.secrets || defaultProfile.secrets) {
        merged.secrets = [...(defaultProfile.secrets || []), ...(activeProfile.secrets || [])];
    }

    // Merge object fields (active overrides default) - mounts
    if (activeProfile.mounts) {
        merged.mounts = { ...defaultProfile.mounts, ...activeProfile.mounts };
    }

    // Merge open ports - active replaces default (like hooks)
    if (activeProfile.openPorts !== undefined) {
        merged.openPorts = activeProfile.openPorts;
    }

    // Merge network - active replaces default because the namespace is selected as a unit.
    if (activeProfile.network !== undefined) {
        merged.network = activeProfile.network;
    }

    // Startup config providers are profile-selected lifecycle inputs. The
    // active profile replaces the default list so deployment profiles can opt
    // into providers without changing development startup.
    if (activeProfile.configProviders !== undefined) {
        merged.configProviders = activeProfile.configProviders;
    }

    // Declared hardware limits from either profile, including the deprecated
    // llmRuntime.runtimePolicy.resources keys; other llmRuntime fields keep
    // the default profile's value.
    return mergeProfileHardwareLimits(merged, defaultProfile, activeProfile);
}

/**
 * Get the currently active profile.
 * @returns {string} The active profile name (defaults to 'dev')
 */
export function getActiveProfile() {
    try {
        if (fs.existsSync(PROFILE_FILE)) {
            const profile = fs.readFileSync(PROFILE_FILE, 'utf8').trim();
            if (profile && isValidProfile(profile)) {
                return profile;
            }
        }
    } catch (_) {}
    return 'default';
}

function profileNotFoundError(agentName, profileName, profiles) {
    const availableProfiles = Object.keys(profiles || {}).sort();
    const error = new Error(
        `[profile] ${agentName}: profile '${profileName}' not found. Available: ${availableProfiles.join(', ') || '(none)'}`,
    );
    error.code = 'PLOINKY_PROFILE_NOT_FOUND';
    return error;
}

/**
 * Resolve one atomic profile selection from an already-loaded manifest.
 * Callers must use resolvedProfileName, profileConfig, and network together.
 */
export function resolveManifestProfile(manifest, requestedProfileName, {
    agentName = 'agent',
    explicit = false,
    path: manifestPath = `manifest(${agentName})`,
} = {}) {
    const source = manifest && typeof manifest === 'object' && !Array.isArray(manifest)
        ? manifest
        : {};
    validateManifestNetworks(source, { path: manifestPath });

    const profiles = source.profiles && typeof source.profiles === 'object' && !Array.isArray(source.profiles)
        ? source.profiles
        : {};
    const requestedProfile = String(requestedProfileName || 'default').trim().toLowerCase() || 'default';
    const hasProfiles = Object.keys(profiles).length > 0;

    if (!hasProfiles) {
        if (explicit && requestedProfile !== 'default') {
            throw profileNotFoundError(agentName, requestedProfile, profiles);
        }
        return {
            requestedProfileName: requestedProfile,
            resolvedProfileName: 'default',
            profileConfig: null,
            network: effectiveManifestNetwork(source, 'default', { path: manifestPath }),
        };
    }

    const defaultProfile = profiles.default;
    if (!defaultProfile) {
        throw new Error(`Agent ${agentName} missing required 'default' profile in manifest.json`);
    }

    const requestedExists = Object.prototype.hasOwnProperty.call(profiles, requestedProfile);
    if (!requestedExists && explicit) {
        throw profileNotFoundError(agentName, requestedProfile, profiles);
    }
    const resolvedProfileName = requestedExists ? requestedProfile : 'default';
    const selectedProfile = profiles[resolvedProfileName];
    const network = effectiveManifestNetwork(source, resolvedProfileName, { path: manifestPath });
    const mergedProfile = resolvedProfileName === 'default'
        ? defaultProfile
        : mergeProfiles(defaultProfile, selectedProfile);

    return {
        requestedProfileName: requestedProfile,
        resolvedProfileName,
        profileConfig: { ...mergedProfile, network },
        network,
    };
}

/**
 * Resolve the effective runtime profile with stable precedence. CLI options and
 * persisted records are strict selections; the global profile may fall back to
 * the manifest's required default profile when it is not declared by an agent.
 */
export function resolveManifestRuntimeProfile(manifest, {
    agentName = 'agent',
    profileName,
    persistedProfileName,
    fallbackProfileName = getActiveProfile(),
    path: manifestPath = `manifest(${agentName})`,
} = {}) {
    const optionProfileName = String(profileName || '').trim().toLowerCase();
    const recordProfileName = String(persistedProfileName || '').trim().toLowerCase();
    const globalProfileName = String(fallbackProfileName || 'default').trim().toLowerCase() || 'default';
    const explicitProfileName = optionProfileName || recordProfileName;

    return resolveManifestProfile(manifest, explicitProfileName || globalProfileName, {
        agentName,
        explicit: Boolean(explicitProfileName),
        path: manifestPath,
    });
}

/**
 * Set the active profile.
 * @param {string} profileName - The profile name to set
 * @returns {{ success: boolean, message: string }}
 */
export function setActiveProfile(profileName) {
    const normalizedProfile = profileName.toLowerCase().trim();

    if (!isValidProfile(normalizedProfile)) {
        return {
            success: false,
            message: `Invalid profile '${profileName}'. Valid profiles are: ${getValidProfiles().join(', ')}`,
        };
    }

    try {
        // Ensure .ploinky directory exists
        if (!fs.existsSync(PLOINKY_DIR)) {
            fs.mkdirSync(PLOINKY_DIR, { recursive: true });
        }

        fs.writeFileSync(PROFILE_FILE, normalizedProfile);
        return {
            success: true,
            message: `Profile set to '${normalizedProfile}'`
        };
    } catch (err) {
        return {
            success: false,
            message: `Failed to set profile: ${err.message}`
        };
    }
}

/**
 * Get profile configuration from an agent's manifest.
 * Always merges the default profile with the requested profile.
 *
 * @param {string} agentName - The agent name
 * @param {string} profileName - The profile name (defaults to active profile)
 * @returns {object|null} The merged profile configuration or null
 */
export function getProfileConfig(agentName, profileName) {
    try {
        const resolvedAgent = findAgent(agentName);
        const { manifestPath } = resolvedAgent;
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
        return resolveManifestProfile(manifest, profileName || getActiveProfile(), {
            agentName,
            path: `manifest(${agentName})`,
        }).profileConfig;
    } catch (err) {
        debugLog(`getProfileConfig: ${err.message}`);
        // Re-throw missing profile errors so they bubble up
        if (err.message.includes('missing required')
            || err.code === 'PLOINKY_NETWORK_CONTRACT_INVALID'
            || err.code === 'PLOINKY_REMOVED_MANIFEST_FIELD'
            || err.code === 'PLOINKY_MANIFEST_HTTP_SERVICE_INVALID'
            || err.code === 'PLOINKY_PROFILE_NOT_FOUND') {
            throw err;
        }
        return null;
    }
}

/**
 * Validate a profile configuration for an agent.
 * Uses merged profile (default + requested profile).
 *
 * @param {string} agentName - The agent name
 * @param {string} profileName - The profile name
 * @returns {{ valid: boolean, issues: string[], config: object|null }}
 */
export function validateProfile(agentName, profileName) {
    const issues = [];
    let config = null;

    try {
        const resolvedAgent = findAgent(agentName);
        const { manifestPath } = resolvedAgent;
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

        if (!manifest.profiles) {
            issues.push('Manifest has no profiles section');
            return { valid: false, issues, config: null };
        }

        // Mandatory: every agent must have a 'default' profile
        if (!manifest.profiles.default) {
            issues.push(`Agent missing required 'default' profile in manifest.json`);
            return { valid: false, issues, config: null };
        }

        // Get merged profile configuration
        config = getProfileConfig(agentName, profileName);

        if (!config) {
            issues.push(`Could not resolve profile configuration for '${profileName}'`);
            return { valid: false, issues, config: null };
        }

        const envProfileValidation = validateManifestEnvProfileCompleteness(manifest, config, {
            agentName,
            profileName,
        });
        issues.push(...envProfileValidation.issues);
        const envResolution = collectManifestEnv(manifest, {
            profileConfig: config,
            agentName: resolvedAgent.shortAgentName,
            repoName: resolvedAgent.repo,
        });
        for (const spec of envResolution.missing) {
            const rendered = spec.sourceName && spec.sourceName !== spec.insideName
                ? `${spec.insideName} (source: ${spec.sourceName})`
                : spec.insideName;
            issues.push(`Missing required environment variable: ${rendered}`);
        }

        // Validate required secrets
        if (config.secrets && Array.isArray(config.secrets)) {
            const secretValidation = validateSecrets(config.secrets);
            for (const secretName of secretValidation.missing) {
                issues.push(`Missing required secret: ${secretName}`);
            }
        }

        // Validate hook scripts exist (only host hooks need file validation)
        // preinstall is now a host hook that runs before container creation
        const hostHookFields = ['preinstall', 'hosthook_aftercreation', 'hosthook_postinstall'];
        for (const hookField of hostHookFields) {
            if (config[hookField]) {
                const agentPath = path.dirname(manifestPath);
                const hookPath = path.join(agentPath, config[hookField]);
                if (!fs.existsSync(hookPath)) {
                    issues.push(`Host hook script not found: ${config[hookField]}`);
                }
            }
        }

        // Validate hook format (must be string, not array)
        for (const hookName of HOOK_NAMES) {
            if (config[hookName] !== undefined && typeof config[hookName] !== 'string') {
                issues.push(`Hook '${hookName}' must be a string command, not ${typeof config[hookName]}`);
            }
        }

        // Check mounts configuration
        if (config.mounts) {
            const validMountModes = ['rw', 'ro'];
            if (config.mounts.code && !validMountModes.includes(config.mounts.code)) {
                issues.push(`Invalid mount mode for code: ${config.mounts.code}`);
            }
            if (config.mounts.skills && !validMountModes.includes(config.mounts.skills)) {
                issues.push(`Invalid mount mode for skills: ${config.mounts.skills}`);
            }
        }

        return {
            valid: issues.length === 0,
            issues,
            config
        };
    } catch (err) {
        issues.push(`Validation error: ${err.message}`);
        return { valid: false, issues, config: null };
    }
}

/**
 * List available profiles for an agent.
 * @param {string} agentName - The agent name
 * @returns {{ profiles: string[], defaultProfile: string|null }}
 */
export function listProfiles(agentName) {
    try {
        const { manifestPath } = findAgent(agentName);
        const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

        const profiles = manifest.profiles ? Object.keys(manifest.profiles) : [];
        const defaultProfile = manifest.defaultProfile || (profiles.includes('dev') ? 'dev' : profiles[0] || null);

        return { profiles, defaultProfile };
    } catch (err) {
        debugLog(`listProfiles: ${err.message}`);
        return { profiles: [], defaultProfile: null };
    }
}

/**
 * Get default mount modes based on profile.
 * @param {string} profile - The profile name
 * @returns {{ code: string, skills: string }}
 */
export function getDefaultMountModes(profile) {
    // Installed source is immutable in every profile, including development.
    // Runtime data and user projects have separate writable mounts.
    return { code: 'ro', skills: 'ro' };
}

/**
 * Get profile environment based on profile name.
 * @param {string} profile - The profile name
 * @returns {string} Environment identifier
 */
export function getProfileEnvironment(profile) {
    if (profile === 'default') return 'development';
    return profile;
}

/**
 * Get all profile-related environment variables.
 * @param {string} agentName - The agent name
 * @param {string} repoName - The repository name
 * @param {string} profile - The profile name
 * @param {object} containerInfo - Container information
 * @returns {object} Environment variables map
 */
export function getProfileEnvVars(agentName, repoName, profile, containerInfo = {}) {
    return {
        PLOINKY_PROFILE: profile,
        PLOINKY_PROFILE_ENV: getProfileEnvironment(profile),
        PLOINKY_AGENT_NAME: agentName,
        PLOINKY_REPO_NAME: repoName,
        PLOINKY_WORKSPACE_ROOT,
        PLOINKY_CWD,
        ...(containerInfo.containerName && { PLOINKY_CONTAINER_NAME: containerInfo.containerName }),
        ...(containerInfo.containerId && { PLOINKY_CONTAINER_ID: containerInfo.containerId })
    };
}

/**
 * Get the list of valid profiles.
 * @returns {string[]} Array of valid profile names
 */
export function getValidProfiles() {
    return [...discoverManifestProfiles()];
}

export { isValidProfile };

/**
 * Get the list of hook names in execution order.
 * @returns {string[]} Array of hook names
 */
export function getHookNames() {
    return [...HOOK_NAMES];
}
