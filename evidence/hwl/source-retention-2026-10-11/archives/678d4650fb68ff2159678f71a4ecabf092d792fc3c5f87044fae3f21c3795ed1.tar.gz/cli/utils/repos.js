import fs from 'fs';
import { workspaceRepositories } from './repositorySource.mjs';
import path from 'path';
import { execFileSync } from 'child_process';
import { listWorkspaceSkillRepositories, resolveSkillRepositorySource } from './skillRepositorySource.js';
import { PLOINKY_WORKSPACE_ROOT, PLOINKY_DIR } from './config.js';
import { listAgentRepositoryNames, resolveAgentRepositoryPath, workspaceAgentRepositoryPath } from './agentRepositorySource.mjs';
import { isAgentRepositoryUnregistered, setAgentRepositoryRegistered } from './agentRepositoryRegistration.mjs';
import { parseBranchPolicy } from '../../agentlib/branchPolicy.mjs';
import { runGitCommand, sanitizeGitDiagnostic } from './gitCommand.js';
import { createOperationRecord } from '../commands/updateOutcome.js';
import { throwUnlessVerified, updateCheckoutFastForward } from './git/verifiedUpdate.js';
import { assessGeneratedCheckoutState } from './git/generatedState.js';

export const REPO_SOURCES_FILE = path.join(PLOINKY_DIR, 'repo_sources.json');
export const ENABLED_REPOS_FILE = path.join(PLOINKY_DIR, 'enabled_repos.json');
const REPOS_DIR = path.join(PLOINKY_DIR, 'repos');

function loadRepoSources() {
    try {
        const raw = fs.readFileSync(REPO_SOURCES_FILE, 'utf8');
        const data = JSON.parse(raw || '{}');
        return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
    } catch (_) {
        return {};
    }
}

function saveRepoSources(sources) {
    try {
        fs.mkdirSync(PLOINKY_DIR, { recursive: true });
        fs.writeFileSync(REPO_SOURCES_FILE, JSON.stringify(sources || {}, null, 2));
    } catch (_) {}
}

function normalizeRepoBranch(branch) {
    const value = String(branch || '').trim();
    if (!value || value === 'default') return null;
    return value;
}

function normalizeRepoSourceValue(value) {
    if (typeof value === 'string') {
        const url = value.trim();
        return url ? { url, branch: null } : null;
    }
    if (!value || typeof value !== 'object' || Array.isArray(value)) {
        return null;
    }
    const url = String(value.url || '').trim();
    if (!url) return null;
    const kind = String(value.kind || '').trim();
    return {
        url,
        branch: normalizeRepoBranch(value.branch),
        kind: kind || null,
    };
}

function readStoredRepoSource(name) {
    const repoName = String(name || '').trim();
    if (!repoName) return null;
    return normalizeRepoSourceValue(loadRepoSources()[repoName]);
}

export function getRepoSources() {
    const result = {};
    const sources = loadRepoSources();
    for (const [name, value] of Object.entries(sources)) {
        const source = normalizeRepoSourceValue(value);
        if (source?.url) result[name] = source;
    }
    return result;
}

function looksLikeRepoUrl(value) {
    const candidate = String(value || '').trim();
    if (!candidate) return false;
    return /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(candidate)
        || /^git@[^:]+:.+/.test(candidate)
        || candidate.startsWith('ssh://')
        || candidate.startsWith('file://')
        || candidate.startsWith('/')
        || candidate.startsWith('./')
        || candidate.startsWith('../')
        || candidate.endsWith('.git');
}

function recordRepoSource(name, url, branch = null, kind = null) {
    const repoName = String(name || '').trim();
    const repoUrl = String(url || '').trim();
    if (!repoName || !repoUrl) return;
    const previous = readStoredRepoSource(repoName);
    const repoBranch = normalizeRepoBranch(branch)
        || (previous?.url === repoUrl ? previous.branch : null);
    const repoKind = String(kind || '').trim()
        || (previous?.url === repoUrl ? previous.kind : null);
    const next = { url: repoUrl };
    if (repoBranch) next.branch = repoBranch;
    if (repoKind) next.kind = repoKind;
    const sources = loadRepoSources();
    const current = normalizeRepoSourceValue(sources[repoName]);
    if (current?.url === next.url
        && current?.branch === (next.branch || null)
        && current?.kind === (next.kind || null)) return;
    sources[repoName] = next;
    saveRepoSources(sources);
}

export function getInstalledRepos() {
    return listAgentRepositoryNames().filter(name => {
        const repoPath = resolveAgentRepositoryPath(name);
        try {
            return fs.statSync(repoPath).isDirectory();
        } catch (error) {
            if (error.code === 'ENOENT' || error.code === 'ENOTDIR') return false;
            throw error;
        }
    });
}

export function getActiveRepos() {
    const installed = getInstalledRepos();
    const enabled = loadEnabledRepos();
    if (!enabled.length) return installed;
    const installedNames = new Set(installed);
    return enabled.filter(repoName => installedNames.has(repoName));
}

const PREDEFINED_REPOS = {
    basic: { url: 'https://github.com/AssistOS-AI/Basic.git', description: 'Optional base agents', kind: 'agents' },
    cloud: { url: 'https://github.com/AssistOS-AI/cloud.git', description: 'Cloud infrastructure agents', kind: 'agents' },
    vibe: { url: 'https://github.com/AssistOS-AI/vibe.git', description: 'Vibe coding agents', kind: 'agents' },
    security: { url: 'https://github.com/AssistOS-AI/security.git', description: 'Security and scanning tools', kind: 'agents' },
    extra: { url: 'https://github.com/AssistOS-AI/extra.git', description: 'Additional utility agents', kind: 'agents' },
    AchillesIDE: { url: 'https://github.com/AssistOS-AI/AssistOSExplorer.git', description: 'Workspace IDE with Explorer UI, SOPLang editing and Git workflows', kind: 'agents' },
    AchillesCLI: { url: 'https://github.com/AssistOS-AI/AchillesCLI.git', description: 'Workspace CLI for setup and management', kind: 'agents' },
    'copilot-agents': { url: 'https://github.com/AssistOS-AI/copilot-agents.git', description: 'OpenCode copilot agents', kind: 'agents' },
    demo: { url: 'https://github.com/AssistOS-AI/demo.git', description: 'Demo agents and examples', kind: 'agents' },
    proxies: { url: 'https://github.com/AssistOS-AI/proxies.git', description: 'API proxy agents (Kiro Gateway)', kind: 'agents' },
    AchillesCopilotBasicSkills: { url: 'https://github.com/AssistOS-AI/AchillesCopilotBasicSkills.git', description: 'Skills maintained for achillesAgentLib', kind: 'skills' },
    DocumentationSkills: { url: 'https://github.com/AssistOS-AI/DocumentationSkills.git', description: 'Skills for software documentation', kind: 'skills' },
    PloinkySkills: { url: 'https://github.com/AssistOS-AI/PloinkySkills.git', description: 'Skills for developing the Ploinky application', kind: 'skills' }
};

const BOOT_REPO_NAMES = ['AchillesIDE', 'AchillesCLI', 'copilot-agents'];

export function getDefaultBootRepos() {
    return BOOT_REPO_NAMES
        .map((repoName) => {
            const url = resolveRepoUrl(repoName);
            if (!url) return null;
            return { name: repoName, url };
        })
        .filter(Boolean);
}

export function getPredefinedRepos() {
    return PREDEFINED_REPOS;
}

export function getSkillRepositoryRecommendations(options = {}) {
    const local = new Map(listWorkspaceSkillRepositories(options).map(repo => [repo.name, repo]));
    const sources = getRepoSources();
    const names = new Set([...Object.keys(PREDEFINED_REPOS), ...Object.keys(sources), ...getInstalledRepos(), ...local.keys()]);
    return [...names].sort((a, b) => a.localeCompare(b)).flatMap(name => {
        const preset = PREDEFINED_REPOS[name] || {};
        const registered = sources[name] || {};
        const declared = preset.kind || registered.kind;
        const kind = local.has(name) ? (['agents', 'mixed'].includes(declared) ? 'mixed' : 'skills') : declared || classifyRepoKind(name);
        if (!['skills', 'mixed'].includes(kind)) return [];
        const url = preset.url || registered.url || local.get(name)?.source || '';
        if (!url) return [];
        return [{ name, url, kind, description: preset.description || '',
            branch: registered.branch || '', warnings: local.get(name)?.warnings || [], skillSource: resolveSkillRepositorySource(name, url, options) }];
    });
}

export function classifyRepoKind(repoName) {
    const declared = PREDEFINED_REPOS[repoName]?.kind;
    if (declared) return declared;

    const preferred = resolveSkillRepositorySource(repoName, '');
    const repoPath = preferred.origin === 'workspace' ? preferred.source : resolveAgentRepositoryPath(repoName);
    if (!fs.existsSync(repoPath)) return 'unknown';

    let hasSkills = false;
    const skillsDir = path.join(repoPath, 'skills');
    try {
        if (fs.statSync(skillsDir).isDirectory()) {
            const subs = fs.readdirSync(skillsDir, { withFileTypes: true });
            hasSkills = subs.some(entry => entry.isDirectory()
                && fs.existsSync(path.join(skillsDir, entry.name, 'SKILL.md')));
        }
    } catch (_) {}

    let hasAgents = false;
    try {
        const top = fs.readdirSync(repoPath, { withFileTypes: true });
        hasAgents = top.some(entry => entry.isDirectory()
            && entry.name !== 'skills'
            && !entry.name.startsWith('.')
            && fs.existsSync(path.join(repoPath, entry.name, 'manifest.json')));
    } catch (_) {}

    if (hasSkills && hasAgents) return 'mixed';
    if (hasSkills) return 'skills';
    if (hasAgents) return 'agents';
    return 'unknown';
}

function ensureReposDir() {
    const dir = path.join(PLOINKY_DIR, 'repos');
    try {
        fs.mkdirSync(dir, { recursive: true });
    } catch (_) {}
    return dir;
}

export function resolveRepoUrl(name, url) {
    if (url && url.trim()) return url;
    const rawName = String(name || '');
    const preset = PREDEFINED_REPOS[rawName]
        || PREDEFINED_REPOS[rawName.toLowerCase()]
        || Object.entries(PREDEFINED_REPOS).find(([key]) => key.toLowerCase() === rawName.toLowerCase())?.[1];
    return preset ? preset.url : null;
}

export function deriveRepoNameFromUrl(url) {
    const rawUrl = String(url || '').trim();
    if (!rawUrl) return '';
    const withoutHash = rawUrl.split('#')[0].split('?')[0];
    const withoutSlash = withoutHash.replace(/\/+$/, '');
    const lastSegment = withoutSlash.slice(withoutSlash.lastIndexOf('/') + 1);
    const name = lastSegment.replace(/\.git$/i, '').replace(/[^a-zA-Z0-9_.-]+/g, '-');
    return name.replace(/^-+|-+$/g, '');
}

export function normalizeRepoName(name) {
    const repoName = String(name || '').trim();
    if (!repoName || !/^[a-zA-Z0-9_.-]+$/.test(repoName)) {
        throw new Error('Invalid repository name.');
    }
    return repoName;
}

function findManifestRepoSource(repoName) {
    const targetName = String(repoName || '').trim();
    if (!targetName) return null;
    const ignoredDirNames = new Set(['.git', 'node_modules']);

    function inspectManifest(filePath) {
        try {
            const manifest = JSON.parse(fs.readFileSync(filePath, 'utf8'));
            const repos = manifest?.repos;
            if (!repos || typeof repos !== 'object' || Array.isArray(repos)) return null;
            return normalizeRepoSourceValue(repos[targetName]);
        } catch (_) {
            return null;
        }
    }

    function visit(dir) {
        const manifestPath = path.join(dir, 'manifest.json');
        if (fs.existsSync(manifestPath)) {
            const url = inspectManifest(manifestPath);
            if (url) return url;
        }

        let entries;
        try {
            entries = fs.readdirSync(dir, { withFileTypes: true });
        } catch (_) {
            return null;
        }

        for (const entry of entries) {
            if (!entry.isDirectory()) continue;
            if (entry.name.startsWith('.') || ignoredDirNames.has(entry.name)) continue;
            const found = visit(path.join(dir, entry.name));
            if (found) return found;
        }
        return null;
    }

    for (const name of listAgentRepositoryNames()) {
        const source = visit(resolveAgentRepositoryPath(name));
        if (source) return source;
    }
    return null;
}

export function resolveRepoSource(name, url = null, branch = null) {
    const repoName = String(name || '').trim();
    const directUrl = resolveRepoUrl(name, url);
    const stored = readStoredRepoSource(repoName);
    const manifest = findManifestRepoSource(repoName);
    const sourceUrl = directUrl || stored?.url || manifest?.url || null;
    if (!sourceUrl) return null;

    const sourceBranch = normalizeRepoBranch(branch)
        || (stored?.url === sourceUrl ? stored.branch : null)
        || (manifest?.url === sourceUrl ? manifest.branch : null)
        || null;

    if (manifest?.url === sourceUrl || stored?.url === sourceUrl) {
        recordRepoSource(repoName, sourceUrl, sourceBranch);
    }
    return { url: sourceUrl, branch: sourceBranch };
}

export function resolveRepoSourceUrl(name, url = null) {
    return resolveRepoSource(name, url)?.url || null;
}

export function addRepo(name, url, branch = null, { stdio = 'inherit' } = {}) {
    if (!name) throw new Error('Missing repository name.');
    const localPath = workspaceAgentRepositoryPath(name, { url });
    if (localPath) {
        recordRepoSource(name, url, branch);
        setAgentRepositoryRegistered(name, true);
        return { status: 'exists', path: localPath, branch: currentBranch(localPath) };
    }
    const REPOS_DIR = ensureReposDir();
    const repoPath = path.join(REPOS_DIR, name);
    const source = resolveRepoSource(name, url, branch);
    const actualUrl = source?.url || null;
    const actualBranch = source?.branch || null;
    if (fs.existsSync(repoPath)) {
        recordRepoSource(name, actualUrl, actualBranch);
        return { status: 'exists', path: repoPath, branch: actualBranch };
    }
    if (!actualUrl) throw new Error(`Missing repository URL for '${name}'.`);
    const args = ['clone'];
    if (actualBranch) args.push('--branch', actualBranch);
    args.push(actualUrl, repoPath);
    runGitCommand(args, { stdio });
    recordRepoSource(name, actualUrl, actualBranch);
    return { status: 'cloned', path: repoPath, branch: actualBranch || 'default' };
}

export function loadEnabledRepos() {
    try {
        const raw = fs.readFileSync(ENABLED_REPOS_FILE, 'utf8');
        const parsed = JSON.parse(raw || '[]');
        if (!Array.isArray(parsed)) return [];
        const seen = new Set();
        const repos = [];
        for (const entry of parsed) {
            const repoName = String(entry || '').trim();
            if (!repoName || seen.has(repoName)) continue;
            seen.add(repoName);
            repos.push(repoName);
        }
        return repos;
    } catch (_) {
        return [];
    }
}

function saveEnabledRepos(repoNames) {
    const seen = new Set();
    const repos = [];
    for (const entry of repoNames || []) {
        const repoName = String(entry || '').trim();
        if (!repoName || seen.has(repoName)) continue;
        seen.add(repoName);
        repos.push(repoName);
    }
    fs.mkdirSync(PLOINKY_DIR, { recursive: true });
    fs.writeFileSync(ENABLED_REPOS_FILE, JSON.stringify(repos, null, 2));
    return repos;
}

export function enableRepo(name, { branch = null, branchPolicy = null, stdio = 'inherit' } = {}) {
    const repoName = normalizeRepoName(name);
    const source = resolveRepoSource(repoName, null, branch);
    const result = ensureRepoInstalled(repoName, source?.url || null, {
        branchPolicy,
        branch,
        stdio,
    });
    const enabled = loadEnabledRepos();
    if (!enabled.includes(repoName)) {
        enabled.push(repoName);
        saveEnabledRepos(enabled);
    }
    return {
        status: enabled.includes(repoName) ? 'enabled' : 'unchanged',
        name: repoName,
        path: result.path,
        branch: result.branch || null,
    };
}

export function disableRepo(name) {
    const repoName = normalizeRepoName(name);
    const enabled = loadEnabledRepos();
    const next = enabled.filter(entry => entry !== repoName);
    saveEnabledRepos(next);
    return {
        status: next.length === enabled.length ? 'not-enabled' : 'disabled',
        name: repoName,
    };
}

export function installRepo(url, name = null, branch = null, { stdio = 'inherit' } = {}) {
    const input = String(url || '').trim();
    if (!input) throw new Error('Missing repository URL.');

    let repoUrl = input;
    let repoName = name ? normalizeRepoName(name) : null;
    let resolvedBranch = normalizeRepoBranch(branch);

    if (!looksLikeRepoUrl(input)) {
        const sourceName = normalizeRepoName(input);
        const source = resolveRepoSource(sourceName, null, resolvedBranch);
        if (!source?.url) {
            throw new Error(`Missing repository URL for '${sourceName}'. Install by name only works for repositories in repo_sources.json or predefined repositories.`);
        }
        repoName = sourceName;
        repoUrl = source.url;
        resolvedBranch = normalizeRepoBranch(branch) || source.branch || null;
    } else if (!repoName) {
        repoName = normalizeRepoName(deriveRepoNameFromUrl(repoUrl));
    }

    const result = addRepo(repoName, repoUrl, resolvedBranch, { stdio });
    setAgentRepositoryRegistered(repoName, true);
    const kind = classifyRepoKind(repoName);
    recordRepoSource(repoName, repoUrl, result.branch, kind);
    return {
        ...result,
        name: repoName,
        url: repoUrl,
        kind,
        installed: true
    };
}

export function resolveInstalledRepoTarget(target) {
    const rawTarget = String(target || '').trim();
    if (!rawTarget) throw new Error('Missing repository target.');
    const reposDir = ensureReposDir();
    const installed = listAgentRepositoryNames();
    if (installed.includes(rawTarget)) return rawTarget;

    const sources = loadRepoSources();
    for (const repoName of installed) {
        const source = normalizeRepoSourceValue(sources[repoName]);
        if (source?.url === rawTarget) return repoName;
    }

    for (const repoName of installed) {
        const predefinedUrl = PREDEFINED_REPOS[repoName]?.url || '';
        if (predefinedUrl && predefinedUrl === rawTarget) return repoName;
    }

    const derived = deriveRepoNameFromUrl(rawTarget);
    if (derived && installed.includes(derived)) return derived;
    throw new Error(`Repository '${rawTarget}' is not installed.`);
}

export function uninstallRepo(target, { stdio = 'inherit' } = {}) {
    const repoName = resolveInstalledRepoTarget(target);
    const localPath = workspaceAgentRepositoryPath(repoName);
    const repoPath = resolveAgentRepositoryPath(repoName);
    disableRepo(repoName);
    if (localPath) {
        setAgentRepositoryRegistered(repoName, false);
        return { status: 'unregistered', name: repoName, path: repoPath, preserved: true };
    }
    if (!fs.existsSync(repoPath)) {
        return { status: 'missing', name: repoName, path: repoPath };
    }
    fs.rmSync(repoPath, { recursive: true, force: true });
    return { status: 'removed', name: repoName, path: repoPath };
}

// A managed non-Git directory is repaired only when it is provably empty and a
// source is known. The empty directory is removed without recursion right
// before the fresh clone is renamed into place, so a file that appears in the
// meantime aborts the repair instead of being deleted.
function recloneEmptyManagedRepo(name, repoPath, url, { branch = null, stdio = 'inherit' } = {}) {
    const reposRoot = path.dirname(repoPath);
    const safeName = String(name || 'repo').replace(/[^a-zA-Z0-9_.-]+/g, '-');
    const tempPath = path.join(reposRoot, `.${safeName}.clone-${process.pid}-${Date.now()}`);
    const args = ['clone', '--quiet'];
    if (branch) args.push('--branch', branch);
    args.push(url, tempPath);

    runGitCommand(args, { stdio });

    try {
        if (fs.existsSync(repoPath)) fs.rmdirSync(repoPath);
        fs.renameSync(tempPath, repoPath);
    } finally {
        try { fs.rmSync(tempPath, { recursive: true, force: true }); } catch (_) {}
    }

    recordRepoSource(name, url);
    return { recloned: true, replaced: true };
}

function directoryIsEmpty(dirPath) {
    try {
        return fs.readdirSync(dirPath).length === 0;
    } catch (_) {
        return false;
    }
}

function nonGitRecord(name, repoPath, outcome, code, reason, extra = {}) {
    return createOperationRecord({
        phase: 'registered-repository',
        id: name,
        outcome,
        attempted: outcome !== 'skipped',
        code,
        reason,
        details: { checkout: { path: repoPath }, ...extra },
    });
}

/**
 * Repair a managed registered-repository directory that has no `.git`.
 * Never deletes content: a non-empty directory is preserved and reported.
 */
function repairNonGitManagedRepo(name, repoPath, { localPath, stdio }) {
    if (localPath) {
        return nonGitRecord(name, repoPath, 'skipped', 'non-git-directory-preserved',
            `workspace repository '${name}' at ${repoPath} is not a Git checkout; it was preserved`);
    }
    if (!directoryIsEmpty(repoPath)) {
        return nonGitRecord(name, repoPath, 'skipped', 'non-git-directory-preserved',
            `repository '${name}' at ${repoPath} is not a Git checkout and is not empty; it was preserved. `
            + 'Inspect it and move it aside to let Ploinky clone it again.');
    }
    const source = resolveRepoSource(name, null);
    if (!source?.url) {
        return nonGitRecord(name, repoPath, 'skipped', 'non-git-source-unknown',
            `repository '${name}' at ${repoPath} is an empty non-Git directory and no source URL is known`);
    }
    try {
        recloneEmptyManagedRepo(name, repoPath, source.url, { branch: source.branch, stdio });
    } catch (error) {
        return nonGitRecord(name, repoPath, 'failed', 'reclone-failed', gitCommandErrorMessage(error));
    }
    return nonGitRecord(name, repoPath, 'changed', 'recloned-empty-directory',
        `repository '${name}' was cloned into its empty managed directory`, { recloned: true });
}

function gitCommandErrorMessage(err) {
    const stderr = err?.stderr ? String(err.stderr).trim() : '';
    if (stderr) return sanitizeGitDiagnostic(stderr);
    return sanitizeGitDiagnostic(err?.message || String(err));
}

/**
 * Update one registered repository and return its operation record.
 * Never throws for a Git outcome.
 *
 * Policy: without an explicit branch, the checkout must track the same branch
 * on origin. With an explicit branch, the checkout must already be on that
 * branch and is advanced from origin/<branch>.
 */
export function updateRegisteredRepository(name, {
    branch = null,
    stdio = 'inherit',
    assessGeneratedState = assessGeneratedCheckoutState,
    checkoutOptions = {},
} = {}) {
    if (!name) throw new Error('Missing repository name.');
    if (isAgentRepositoryUnregistered(name)) throw new Error(`Repository '${name}' is not installed.`);
    const localPath = workspaceAgentRepositoryPath(name);
    const repoPath = resolveAgentRepositoryPath(name);
    if (!fs.existsSync(repoPath)) {
        throw new Error(`Repository '${name}' is not installed.`);
    }
    if (!isGitRepository(repoPath)) {
        return repairNonGitManagedRepo(name, repoPath, { localPath, stdio });
    }
    return updateCheckoutFastForward({
        ...checkoutOptions,
        repoPath,
        phase: 'registered-repository',
        id: name,
        policy: { kind: 'registered', branch: normalizeRepoBranch(branch) },
        assessGeneratedState,
    });
}

/**
 * Skills-manifest source refresh: returns the verified record and throws a
 * GitUpdateError carrying `.record` for any skipped, failed or uncertain
 * outcome.
 */
export function updateRepo(name, { stdio = 'inherit', branch = null, assessGeneratedState = assessGeneratedCheckoutState, checkoutOptions = {} } = {}) {
    const record = updateRegisteredRepository(name, { branch, stdio, assessGeneratedState, checkoutOptions });
    throwUnlessVerified(record);
    return record;
}

export function isGitRepository(repoPath) {
    if (!repoPath) return false;
    try {
        return fs.existsSync(path.join(repoPath, '.git'));
    } catch (_) {
        return false;
    }
}

export function findWorkspaceGitRepos(workspaceRoot) {
    const root = path.resolve(workspaceRoot);
    if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) {
        throw new Error(`Search root '${root}' is not a directory.`);
    }

    const repos = [];
    const ignoredDirNames = new Set([
        '.git',
        '.ploinky',
        'node_modules',
        'globalDeps',
    ]);

    function visit(dir) {
        if (fs.existsSync(path.join(dir, '.git'))) {
            repos.push({ name: path.basename(dir), path: dir });
            if (dir !== root) return;
        }

        let entries;
        try {
            entries = fs.readdirSync(dir, { withFileTypes: true });
        } catch (err) {
            if (err?.code === 'EACCES' || err?.code === 'EPERM') return;
            throw err;
        }

        for (const entry of entries) {
            if (!entry.isDirectory()) continue;
            if (entry.name.startsWith('.') || ignoredDirNames.has(entry.name)) continue;
            visit(path.join(dir, entry.name));
        }
    }

    visit(root);
    return repos;
}

export function checkGitRemoteReachable(repoPath, { remote = 'origin' } = {}) {
    const remoteName = String(remote || 'origin').trim() || 'origin';
    let remoteUrl = '';

    try {
        remoteUrl = String(execFileSync('git', ['-C', repoPath, 'remote', 'get-url', remoteName], {
            stdio: ['ignore', 'pipe', 'pipe'],
        }) || '').trim();
    } catch (err) {
        return {
            reachable: false,
            skipped: true,
            reason: `missing ${remoteName} remote`,
            remote: remoteName,
            message: gitCommandErrorMessage(err),
        };
    }

    try {
        execFileSync('git', ['-C', repoPath, 'ls-remote', '--quiet', remoteName], {
            stdio: ['ignore', 'ignore', 'pipe'],
        });
        return {
            reachable: true,
            skipped: false,
            remote: remoteName,
            remoteUrl,
        };
    } catch (err) {
        return {
            reachable: false,
            skipped: true,
            reason: 'remote not reachable',
            remote: remoteName,
            remoteUrl,
            message: gitCommandErrorMessage(err),
        };
    }
}

/**
 * Update a generic workspace checkout from its configured upstream and return
 * its operation record. An unreachable remote is a named skip.
 */
export function updateWorkspaceRepository(repoPath, {
    id = repoPath,
    aliases = [],
    assessGeneratedState = assessGeneratedCheckoutState,
    checkoutOptions = {},
} = {}) {
    return updateCheckoutFastForward({
        ...checkoutOptions,
        repoPath,
        phase: 'workspace-repository',
        id,
        aliases,
        policy: { kind: 'generic' },
        probeRemote: true,
        assessGeneratedState,
    });
}

// ---------------------------------------------------------------------------
// Branch policy — used by `ploinky start --branch`
// ---------------------------------------------------------------------------
// The parser itself lives in the dependency-free `agentlib/` group so the outer
// `ploinky` supervisor can select the achillesAgentLib source with exactly the
// same policy before it reconciles the Box.

export { parseBranchPolicy };

export function parseStartArgs(rawArgs) {
    const args = (rawArgs || []).map(a => String(a));
    let staticAgent = null;
    let port = null;
    let profile = null;
    const policyArgs = [];
    const positional = [];

    const selectProfile = (value) => {
        const normalized = String(value || '').trim().toLowerCase();
        if (!normalized) {
            throw new Error('--profile needs a value.');
        }
        if (profile && profile !== normalized) {
            throw new Error(`Conflicting --profile values '${profile}' and '${normalized}'.`);
        }
        profile = normalized;
    };

    for (let i = 0; i < args.length; i += 1) {
        const arg = args[i];
        if (arg === '--port' || arg.startsWith('--port=')) {
            throw new Error(
                "start-tail --port is not supported. Use prefix 'ploinky --port PORT start AGENT' or positional 'ploinky start AGENT PORT'.",
            );
        }
        if (arg === '--profile') {
            const value = args[i + 1];
            if (value === undefined || value === '' || value.startsWith('--')) {
                throw new Error('--profile needs a value.');
            }
            selectProfile(value);
            i += 1;
            continue;
        }
        if (arg.startsWith('--profile=')) {
            selectProfile(arg.slice('--profile='.length));
            continue;
        }
        if (arg === '--branch' || arg === '--repo-branch' || arg === '--branch-fallback') {
            policyArgs.push(arg);
            if (i + 1 < args.length) policyArgs.push(args[++i]);
            continue;
        }
        if (arg.startsWith('--branch=') || arg.startsWith('--repo-branch=') || arg.startsWith('--branch-fallback=')) {
            policyArgs.push(arg);
            continue;
        }
        if (arg === '--reset-repos') {
            policyArgs.push(arg);
            continue;
        }
        if (arg.startsWith('--')) continue;
        positional.push(arg);
    }

    if (positional.length >= 1) staticAgent = positional[0];
    if (positional.length >= 2) {
        port = positional[1];
    }

    return {
        staticAgent,
        port,
        profile,
        branchPolicy: parseBranchPolicy(policyArgs),
    };
}

export function resolveBranchForRepo(repoName, source, branchPolicy) {
    if (!branchPolicy) return source?.branch || null;
    if (branchPolicy.repoBranches[repoName]) {
        return branchPolicy.repoBranches[repoName];
    }
    if (source?.branch) return source.branch;
    if (branchPolicy.branch) return branchPolicy.branch;
    const stored = readStoredRepoSource(repoName);
    if (stored?.branch) return stored.branch;
    return null;
}

export function remoteBranchExists(repoPathOrUrl, branch) {
    if (!branch) return false;
    try {
        const output = execFileSync('git', ['ls-remote', '--heads', repoPathOrUrl, `refs/heads/${branch}`], {
            stdio: ['ignore', 'pipe', 'pipe'],
        });
        return String(output).trim().length > 0;
    } catch (_) {
        return false;
    }
}

function repoIsDirty(repoPath) {
    try {
        const status = String(execFileSync('git', ['-C', repoPath, 'status', '--porcelain'], {
            stdio: ['ignore', 'pipe', 'pipe'],
        }));
        return status.trim().length > 0;
    } catch (_) {
        return false;
    }
}

function currentBranch(repoPath) {
    try {
        return String(execFileSync('git', ['-C', repoPath, 'rev-parse', '--abbrev-ref', 'HEAD'], {
            stdio: ['ignore', 'pipe', 'pipe'],
        })).trim();
    } catch (_) {
        return null;
    }
}

export function ensureRepoInstalled(name, url, { branchPolicy, branch, stdio = 'inherit' } = {}) {
    // Workspace checkouts belong to the developer; never clone, reset or
    // switch their branch as a side effect of starting an agent.
    const localPath = workspaceAgentRepositoryPath(name, { url });
    if (localPath) {
        recordRepoSource(name, url, branch);
        return { status: 'exists', path: localPath, branch: currentBranch(localPath) };
    }
    const reposDir = ensureReposDir();
    const repoPath = path.join(reposDir, name);
    const source = resolveRepoSource(name, url, branch);
    const actualUrl = source?.url || url || null;
    const resolvedBranch = resolveBranchForRepo(name, { branch: branch || source?.branch }, branchPolicy);

    if (fs.existsSync(repoPath)) {
        let actualBranch = resolvedBranch || currentBranch(repoPath);
        if (resolvedBranch && isGitRepository(repoPath)) {
            const switchResult = ensureRepoOnBranch(name, {
                branch: resolvedBranch,
                resetRepos: branchPolicy?.resetRepos || false,
                fallback: branchPolicy?.fallback || 'default',
                stdio,
            });
            actualBranch = switchResult?.branch || currentBranch(repoPath);
        }
        recordRepoSource(name, actualUrl, actualBranch);
        return { status: 'exists', path: repoPath, branch: actualBranch };
    }

    if (!actualUrl) throw new Error(`Missing repository URL for '${name}'.`);

    let cloneBranch = resolvedBranch;
    if (cloneBranch && !remoteBranchExists(actualUrl, cloneBranch)) {
        if (branchPolicy?.fallback === 'fail') {
            throw new Error(`Branch '${cloneBranch}' does not exist on remote for repo '${name}'. Aborting (--branch-fallback fail).`);
        }
        console.log(`[repos] Branch '${cloneBranch}' not found on remote for '${name}'; falling back to default branch.`);
        cloneBranch = null;
    }

    const args = ['clone'];
    if (cloneBranch) args.push('--branch', cloneBranch);
    args.push(actualUrl, repoPath);
    runGitCommand(args, { stdio });
    recordRepoSource(name, actualUrl, cloneBranch);
    return { status: 'cloned', path: repoPath, branch: cloneBranch || 'default' };
}

export function ensureRepoOnBranch(name, { branch, resetRepos = false, fallback = 'default', stdio = 'inherit', fetchRequestedBranch = false } = {}) {
    const localPath = workspaceAgentRepositoryPath(name);
    if (localPath) return { status: 'local', path: localPath, branch: currentBranch(localPath) };
    if (!branch) return { status: 'noop', branch: null };
    const repoPath = path.join(PLOINKY_DIR, 'repos', name);
    if (!fs.existsSync(repoPath) || !isGitRepository(repoPath)) return { status: 'missing', branch: null };

    const current = currentBranch(repoPath);
    if (current === branch && !resetRepos) {
        recordRepoSource(name, resolveRepoSourceUrl(name), branch);
        return { status: 'current', branch };
    }

    if (repoIsDirty(repoPath)) {
        if (!resetRepos) {
            throw new Error(
                `Repository '${name}' has uncommitted changes and is on branch '${current}', ` +
                `not '${branch}'. Use --reset-repos to force checkout, or commit/stash changes first.`
            );
        }
    }

    try {
        const fetchArgs = ['-C', repoPath, 'fetch', '--prune'];
        if (fetchRequestedBranch) fetchArgs.push('origin', `+refs/heads/${branch}:refs/remotes/origin/${branch}`);
        runGitCommand(fetchArgs, { stdio });
    } catch (error) {
        if (fallback === 'fail') {
            throw new Error(
                `Unable to fetch branch '${branch}' for repo '${name}': ${error.message}`
            );
        }
    }

    const localBranchExists = (() => {
        try {
            execFileSync('git', ['-C', repoPath, 'rev-parse', '--verify', `refs/heads/${branch}`], {
                stdio: ['ignore', 'pipe', 'pipe'],
            });
            return true;
        } catch (_) {
            return false;
        }
    })();

    const remoteBranch = (() => {
        try {
            execFileSync('git', ['-C', repoPath, 'rev-parse', '--verify', `refs/remotes/origin/${branch}`], {
                stdio: ['ignore', 'pipe', 'pipe'],
            });
            return true;
        } catch (_) {
            return false;
        }
    })();

    if (!localBranchExists && !remoteBranch) {
        if (fallback === 'fail') {
            throw new Error(`Branch '${branch}' does not exist locally or on remote for repo '${name}'. Aborting (--branch-fallback fail).`);
        }
        console.log(`[repos] Branch '${branch}' not available for '${name}'; keeping current branch '${current}'.`);
        return { status: 'fallback', branch: current, requestedBranch: branch };
    }

    if (resetRepos) {
        const target = remoteBranch ? `origin/${branch}` : branch;
        execFileSync('git', ['-C', repoPath, 'checkout', '-B', branch, target], { stdio });
        execFileSync('git', ['-C', repoPath, 'reset', '--hard', target], { stdio });
        execFileSync('git', ['-C', repoPath, 'clean', '-fd'], { stdio });
    } else {
        if (localBranchExists) {
            runGitCommand(['-C', repoPath, 'checkout', branch], { stdio });
        } else {
            runGitCommand(['-C', repoPath, 'checkout', '-b', branch, `origin/${branch}`], { stdio });
        }
    }

    recordRepoSource(name, resolveRepoSourceUrl(name), branch);
    return { status: 'switched', branch };
}

export function listRepositorySources() {
    const registered = { ...PREDEFINED_REPOS, ...getRepoSources() };
    const names = new Set([...Object.keys(registered), ...getInstalledRepos(), ...listAgentRepositoryNames(),
        ...workspaceRepositories(PLOINKY_WORKSPACE_ROOT, candidate => fs.existsSync(path.join(candidate, '.git'))).map(entry => entry.name)]);
    const skills = new Map(getSkillRepositoryRecommendations().map(repo => [repo.name, repo]));
    return [...names].sort().map(name => {
        const url = registered[name]?.url || '';
        const agentSource = workspaceAgentRepositoryPath(name);
        const resolved = agentSource ? { source: fs.realpathSync(agentSource), origin: 'workspace' }
            : resolveSkillRepositorySource(name, url);
        return { name, repoName: name, url, ...resolved, kind: skills.get(name)?.kind || classifyRepoKind(name),
            warnings: skills.get(name)?.warnings || [] };
    });
}
