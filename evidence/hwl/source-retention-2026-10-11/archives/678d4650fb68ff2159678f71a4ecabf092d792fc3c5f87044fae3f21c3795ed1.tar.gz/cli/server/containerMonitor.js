import fs from 'fs';
import { readMpsStatus } from '../sandbox/hardwareLimits/mpsStatus.mjs';
import { releaseMpsRuntimeOwner } from '../sandbox/hardwareLimits/mpsLifecycle.mjs';
import { readAppliedObservation } from '../sandbox/hardwareLimits/runtimeState.mjs';
import { resolveAgentRepositoryPath } from '../utils/agentRepositorySource.mjs';
import crypto from 'node:crypto';
import path from 'path';
import { Worker } from 'worker_threads';
import { fileURLToPath } from 'url';

import * as workspaceSvc from '../utils/workspace.js';
import { REPOS_DIR, RUNNING_DIR } from '../utils/config.js';
import { mergeRoutingConfig, mergeRuntimeRoute, readRoutingConfig } from './routingFile.js';
import {
    createWorkspaceMutationLease,
    inspectMaintenanceLock,
    inspectWorkspaceStartLock,
    releaseWorkspaceMutationLease,
    runWithWorkspaceMutationLease,
} from '../utils/runtime/maintenanceLocks.js';
import {
    cleanupExactAgentRuntimeCandidate,
    ensureAgentService,
    getFailedRuntimeIdentityRotation,
    listRunningContainerNames,
    retireExactAgentRuntimePredecessor,
} from '../sandbox/docker/index.js';
import { shouldMonitorManifestRuntime } from '../utils/runtime/manifestStartup.js';
import { getRuntimeForAgent, isSandboxRuntime } from '../sandbox/docker/common.js';
import { resolveLlmRuntimeAdmissionContext } from '../sandbox/docker/llmRuntimeIntegration.js';
import { observeSandboxRuntime, registeredRuntimeTuple } from '../sandbox/bwrap/bwrapFleet.js';
import { resolveManifestRuntimeProfile } from '../utils/runtime/profileService.js';
import { assertManifestStorageAdmission } from '../utils/runtime/manifestVolumePolicy.js';
import {
    admitManifestRuntimeCapabilities,
    assertRuntimeAdmissionCurrent,
    RUNTIME_CAPABILITY_POLICY_VERSION,
} from '../sandbox/runtimeCapabilities.js';
import { resolveRouterEndpoint } from '../sandbox/routerPort.js';
import { resolveAgentReadinessProtocol, resolveManifestReadinessWaitOptions } from '../utils/runtime/startupReadiness.js';
import { runContainerScriptReadiness } from '../sandbox/docker/healthProbes.js';
import {
    buildRelayReadinessRoute,
    waitForAgentReady,
} from './utils/agentReadiness.js';
import { applyEdgeRoutingGeneration } from '../sandbox/coordinatedEdgeApply.js';
import { withNetworkLifecycleLock } from '../sandbox/networkLifecycle.js';
import { readRuntimePredecessor } from '../sandbox/runtimePredecessorStore.js';
import {
    abortEdgeRoutingPreparation,
    commitAdditiveEdgeRoutingGeneration,
    inactivateEdgeRoutingGeneration,
    readEdgeRoutingSelection,
    withEdgeGenerationApplyLock,
} from '../sandbox/edgeGeneration.js';
import {
    HARDWARE_DEPENDENCY_BLOCKED,
    HARDWARE_UNENFORCEABLE,
    findHardwareOutcome,
} from '../sandbox/hardwareLimits/errors.mjs';
import {
    NO_WAIT_STATE_BYTE_LIMIT,
    createNoWaitRunBinding,
    readNoWaitRunMarker,
} from '../commands/noWaitLogObserver.js';
import { publishNoWaitRunMarker, retireNoWaitRunMarker } from '../commands/noWaitMarkerLifecycle.js';
import {
    exactNoWaitImmutableIdentity,
    sameNoWaitImmutableIdentity,
} from '../commands/noWaitWorkerArgs.js';
import { writeNoWaitWorkerStatus } from '../commands/noWaitWorker.js';
import { isProcessAlive, proveWorkerProcessIdentity } from '../sandbox/processIdentity.js';
import { readVerifiedJsonObject } from '../utils/verifiedReadOnlyFile.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PROBE_WORKER_URL = new URL('./probeWorker.js', import.meta.url);
// A rootless nested Podman control plane can stall its network relay when
// multiple inspect/exec/list operations overlap. Keep recurring semantic
// probes single-file by default; callers may still opt into more concurrency
// when their runtime has proved that it can safely sustain it.
const DEFAULT_MAX_CONCURRENT_PROBE_WORKERS = 1;
const DEFAULT_CONTINUOUS_PROBE_INTERVAL_MS = 5 * 60 * 1000;
const DEFAULT_CONTAINER_SNAPSHOT_RETRY_INITIAL_MS = 15_000;
const DEFAULT_CONTAINER_SNAPSHOT_RETRY_MAX_MS = 60_000;
const TRANSIENT_PROBE_INFRASTRUCTURE_CODES = new Set([
    'PLOINKY_PROBE_CONTROL_PLANE_TIMEOUT',
]);
const LOGGED_RESTART_FAILURES = new WeakSet();
const TERMINAL_POLICY_CODES = new Set([
    'PLOINKY_AGENT_DATA_POLICY_VIOLATION',
    'PLOINKY_BOX_RUNTIME_CAPABILITY_UNSUPPORTED',
    'PLOINKY_MANIFEST_SECURITY_INVALID',
    'PLOINKY_MANIFEST_SECURITY_PROFILE_UNSUPPORTED',
    'PLOINKY_BOX_MARKER_INVALID',
    'PLOINKY_BWRAP_CAPABILITY_UNAVAILABLE',
    'PLOINKY_OPEN_INTERPRETER_BOX_UNAVAILABLE',
    // Hardware refusal and dependency block are terminal policy outcomes:
    // no retry or readiness probe until their relevant inputs change.
    HARDWARE_UNENFORCEABLE,
    HARDWARE_DEPENDENCY_BLOCKED,
]);
const TERMINAL_LEDGER_SCHEMA_VERSION = 1;
// Terminal blockers survive monitor restarts while their registry entry is
// present. Once the entry disappears, retain the tombstone only long enough
// to suppress a short remove/re-add race; it must not grow without bound.
const DEFAULT_TERMINAL_TOMBSTONE_RETENTION_MS = 7 * 24 * 60 * 60 * 1000;

function noopLog() {}

function stableValue(value) {
    if (Array.isArray(value)) return value.map(stableValue);
    if (value && typeof value === 'object') {
        return Object.fromEntries(Object.keys(value).sort().map((key) => [key, stableValue(value[key])]));
    }
    return value;
}

function digestValue(value) {
    return `sha256:${crypto.createHash('sha256').update(JSON.stringify(stableValue(value))).digest('hex')}`;
}

function terminalLedgerFile(monitor) {
    return monitor?.terminalLedgerFile || path.join(RUNNING_DIR, 'container-monitor-terminal.json');
}

function loadTerminalLedger(monitor) {
    try {
        const parsed = JSON.parse(fs.readFileSync(terminalLedgerFile(monitor), 'utf8'));
        if (parsed?.schemaVersion !== TERMINAL_LEDGER_SCHEMA_VERSION || !parsed.entries
            || typeof parsed.entries !== 'object' || Array.isArray(parsed.entries)) return new Map();
        return new Map(Object.entries(parsed.entries));
    } catch (_) {
        return new Map();
    }
}

function persistTerminalLedger(monitor) {
    const file = terminalLedgerFile(monitor);
    fs.mkdirSync(path.dirname(file), { recursive: true, mode: 0o700 });
    const document = {
        schemaVersion: TERMINAL_LEDGER_SCHEMA_VERSION,
        entries: Object.fromEntries(Array.from(monitor.terminalLedger || new Map()).sort(([a], [b]) => a.localeCompare(b))),
    };
    const tmp = `${file}.${process.pid}.${crypto.randomUUID()}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(document, null, 2), { mode: 0o600 });
    fs.renameSync(tmp, file);
}

function terminalTombstoneRetentionMs(monitor) {
    const configured = Number(monitor?.config?.TERMINAL_TOMBSTONE_RETENTION_MS);
    return Number.isSafeInteger(configured) && configured >= 0
        ? configured
        : DEFAULT_TERMINAL_TOMBSTONE_RETENTION_MS;
}

function pruneTerminalLedger(monitor, presentRegistryNames, now = Date.now()) {
    monitor.terminalLedger ||= loadTerminalLedger(monitor);
    const retentionMs = terminalTombstoneRetentionMs(monitor);
    let changed = false;
    for (const [containerName, entry] of monitor.terminalLedger.entries()) {
        if (presentRegistryNames.has(containerName)) {
            if (entry?.absentSince || entry?.expiresAt) {
                monitor.terminalLedger.set(containerName, Object.freeze({
                    ...entry,
                    absentSince: null,
                    expiresAt: null,
                }));
                changed = true;
            }
            continue;
        }
        const absentSinceMs = Date.parse(String(entry?.absentSince || ''));
        const effectiveAbsentSince = Number.isFinite(absentSinceMs)
            ? absentSinceMs
            : now;
        const expiresAtMs = Number.isFinite(Date.parse(String(entry?.expiresAt || '')))
            ? Date.parse(String(entry.expiresAt))
            : effectiveAbsentSince + retentionMs;
        if (expiresAtMs <= now) {
            monitor.terminalLedger.delete(containerName);
            changed = true;
            continue;
        }
        if (!entry?.absentSince || !entry?.expiresAt) {
            monitor.terminalLedger.set(containerName, Object.freeze({
                ...entry,
                absentSince: new Date(effectiveAbsentSince).toISOString(),
                expiresAt: new Date(expiresAtMs).toISOString(),
            }));
            changed = true;
        }
    }
    if (changed) persistTerminalLedger(monitor);
}

function classifyTerminalFailure(error) {
    const code = String(error?.code || '');
    if (TERMINAL_POLICY_CODES.has(code)) return 'policy';
    if (code === 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS'
        || code === 'PLOINKY_RUNTIME_PREPARATION_REQUIRED') return 'identity';
    if (code === 'PLOINKY_PREDECESSOR_CLEANUP_REQUIRED') return 'cleanup';
    return '';
}

function runtimeCleanupEvidence(candidate) {
    if (!candidate) return null;
    const record = candidate.registryRecord || {};
    return deepFreezeSnapshot({
        containerName: candidate.containerName,
        containerId: candidate.containerId || null,
        runtimeNetwork: candidate.runtimeNetwork ? structuredClone(candidate.runtimeNetwork) : null,
        identity: {
            type: record.type,
            runtime: record.runtime || 'container',
            repoName: record.repoName,
            agentName: record.agentName,
            alias: record.alias || null,
            instanceId: record.instanceId,
            enableGeneration: record.enableGeneration,
        },
    });
}

function runtimeCleanupFailureEvidence(result, publicationCommitted = false) {
    return Object.freeze({
        publicationCommitted,
        candidate: runtimeCleanupEvidence(result),
        predecessor: runtimeCleanupEvidence(result?.replacementPredecessor),
    });
}

function recordTerminalFailure(monitor, info, error, restartInputDigest) {
    monitor.terminalLedger ||= loadTerminalLedger(monitor);
    const code = String(error?.code || 'PLOINKY_WATCHDOG_TERMINAL');
    const blockerFingerprint = digestValue({
        code,
        cause: String(error?.cause?.code || ''),
        identity: {
            containerName: info.containerName,
            repoName: info.repoName,
            agentName: info.agentName,
            instanceId: info.instanceId,
            enableGeneration: info.enableGeneration,
        },
    });
    const entry = Object.freeze({
        containerName: info.containerName,
        repoName: info.repoName,
        agentName: info.agentName,
        restartInputDigest,
        mpsFingerprint: info.mpsFingerprint || null,
        blockerFingerprint,
        code,
        classification: classifyTerminalFailure(error) || 'policy',
        ...(error?.ploinkyCleanupEvidence ? { cleanupEvidence: error.ploinkyCleanupEvidence } : {}),
        recordedAt: new Date().toISOString(),
        absentSince: null,
        expiresAt: null,
    });
    monitor.terminalLedger.set(info.containerName, entry);
    persistTerminalLedger(monitor);
    return entry;
}

function logEvent(monitor, level, event, data = {}) {
    const logger = typeof monitor?.log === 'function' ? monitor.log : noopLog;
    logger(level, event, data);
}

function cleanRestartHistory(monitor, target) {
    if (!target) return;
    const windowMs = monitor?.config?.RESTART_WINDOW_MS ?? 60000;
    const now = Date.now();
    target.restartHistory = (target.restartHistory || []).filter((ts) => (now - ts) < windowMs);
}

function calculateBackoff(monitor, target) {
    if (!target) return monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
    const initial = monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
    const maxBackoff = monitor?.config?.MAX_BACKOFF_MS ?? 30000;
    const multiplier = monitor?.config?.BACKOFF_MULTIPLIER ?? 2;
    if (typeof target.currentBackoff !== 'number' || Number.isNaN(target.currentBackoff) || target.currentBackoff <= 0) {
        target.currentBackoff = initial;
    }
    const backoff = Math.min(target.currentBackoff, maxBackoff);
    target.currentBackoff = Math.min(target.currentBackoff * multiplier, maxBackoff);
    return backoff;
}

function createContainerTarget(info, monitor) {
    const initial = monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
    return {
        containerName: info.containerName,
        agentName: info.agentName,
        repoName: info.repoName,
        alias: info.alias || null,
        profile: info.profile || null,
        instanceId: info.instanceId || null,
        enableGeneration: info.enableGeneration || null,
        type: info.type,
        manifestPath: info.manifestPath,
        restartHistory: [],
        totalRestarts: 0,
        currentBackoff: initial,
        isRestarting: false,
        pendingRestartTimer: null,
        lastStartTime: null,
        lastSeenRunningAt: null,
        circuitBreakerTripped: false,
        lastError: null,
        probeState: 'pending',
        probeWorker: null,
        probeLastSuccessAt: null,
        probeInfrastructureFailures: 0,
        probeRetryNotBefore: null,
        probeConcurrencyDeferred: false,
        attemptEpoch: 0,
        restartInputDigest: info.restartInputDigest,
        mpsFingerprint: info.mpsFingerprint || null,
        mpsPending: info.mpsPending === true,
        runtimeAdmission: info.runtimeAdmission,
        restartSnapshot: info.restartSnapshot,
        terminalState: null,
        pendingRestartPreparation: null,
        pendingPredecessorRetirement: null,
    };
}

function resolveWatchdogRestartInput(record, info, monitor) {
    const manifestBytes = fs.readFileSync(info.manifestPath);
    const manifest = JSON.parse(manifestBytes.toString('utf8') || '{}');
    const routeKey = info.alias || info.agentName;
    if (!shouldMonitorManifestRuntime(manifest, {
        hasRoute: Boolean(info.routing?.routes?.[routeKey]),
    })) return null;
    const resolveRuntimeProfile = monitor.resolveManifestRuntimeProfile || resolveManifestRuntimeProfile;
    const profileResolution = resolveRuntimeProfile(manifest, {
        agentName: `${info.repoName}/${info.agentName}`,
        profileName: info.profile || undefined,
        path: `manifest(${info.repoName}/${info.agentName})`,
    });
    assertManifestStorageAdmission(manifest, profileResolution.profileConfig);
    const runtimeKind = info.runtime === 'bwrap' || info.runtime === 'seatbelt'
        ? info.runtime
        : 'container';
    const selectedRuntime = runtimeKind === 'container'
        ? getRuntimeForAgent(manifest)
        : info.runtime;
    const llmAdmissionContext = runtimeKind === 'container'
        ? resolveLlmRuntimeAdmissionContext({
            runtime: selectedRuntime,
            manifest,
            profileConfig: profileResolution.profileConfig,
            agentName: info.agentName,
            alias: info.alias,
            env: process.env,
        })
        : { catalogPolicy: null, catalogIdentity: null };
    const runtimeAdmission = admitManifestRuntimeCapabilities(manifest, {
        manifestBytes,
        manifestPath: info.manifestPath,
        agentId: `${info.repoName}/${info.agentName}`,
        profileName: profileResolution.resolvedProfileName,
        profileConfig: profileResolution.profileConfig,
        network: profileResolution.network,
        runtime: selectedRuntime,
        runtimeKind,
        catalogPolicy: llmAdmissionContext.catalogPolicy,
        catalogIdentity: llmAdmissionContext.catalogIdentity,
        instanceKey: info.containerName,
        alias: info.alias || '',
        ...(monitor.hardwareContext !== undefined ? { hardwareContext: monitor.hardwareContext } : {}),
        ...(monitor.boxMarkerOptions !== undefined ? { boxMarkerOptions: monitor.boxMarkerOptions } : {}),
        ...(monitor.gpuGrantOptions !== undefined ? { gpuGrantOptions: monitor.gpuGrantOptions } : {}),
        ...(monitor.workspaceRoot !== undefined ? { workspaceRoot: monitor.workspaceRoot } : {}),
    });
    const stat = fs.statSync(info.manifestPath, { bigint: true });
    const restartInputDigest = digestValue({
        registryRecordDigest: digestValue(record),
        manifestDigest: runtimeAdmission.manifestDigest,
        manifestPath: path.resolve(info.manifestPath),
        manifestIdentity: `${stat.dev}:${stat.ino}`,
        profileName: profileResolution.resolvedProfileName,
        profileConfig: profileResolution.profileConfig,
        capabilityDescriptor: runtimeAdmission.descriptor,
        capabilityPolicyVersion: RUNTIME_CAPABILITY_POLICY_VERSION,
        runtimeKind,
        runtime: info.runtime,
        imageDigest: String(record.imageDigest || record.containerImageDigest || record.containerImage || ''),
        runnerAbi: String(record.runnerAbi || ''),
        network: profileResolution.network,
        instanceId: info.instanceId,
        enableGeneration: info.enableGeneration,
        alias: info.alias,
        containerName: info.containerName,
        retainedNodeIdentity: String(record.retainedNodeIdentity || ''),
    });
    const restartSnapshot = deepFreezeSnapshot({
        digest: restartInputDigest,
        manifestBytesBase64: manifestBytes.toString('base64'),
        manifestPath: info.manifestPath,
        profileResolution,
        runtimeAdmission,
        registryRecord: structuredClone(record),
        registryRecordDigest: digestValue(record),
        info: {
            containerName: info.containerName,
            agentName: info.agentName,
            repoName: info.repoName,
            alias: info.alias || null,
            profile: info.profile || null,
            runtime: info.runtime,
            instanceId: info.instanceId || null,
            enableGeneration: info.enableGeneration || null,
            manifestPath: info.manifestPath,
        },
    });
    return { manifest, profileResolution, runtimeAdmission, restartInputDigest, restartSnapshot };
}

function deepFreezeSnapshot(value) {
    if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
    for (const child of Object.values(value)) deepFreezeSnapshot(child);
    return Object.freeze(value);
}

function stopProbeWorker(target) {
    if (!target) return;
    if (target.probeWorker) {
        const worker = target.probeWorker;
        try {
            worker.postMessage({ type: 'terminate' });
        } catch (_) {}
        try {
            const termination = worker.terminate();
            if (termination && typeof termination.catch === 'function') {
                termination.catch(() => {});
            }
        } catch (_) {}
    }
    target.probeWorker = null;
    if (target.probeState !== 'success') {
        target.probeState = 'pending';
    }
}

function activeProbeWorkerCount(monitor) {
    if (!monitor?.targets) return 0;
    let count = 0;
    for (const current of monitor.targets.values()) {
        if (current?.probeWorker) count += 1;
    }
    return count;
}

function handleProbeFailure(monitor, target, message, { runtimeHealth = false } = {}) {
    if (!monitor || !target) return;
    // A manually managed replacement may be running before its declared
    // readiness contract succeeds. Continuous liveness is not authoritative
    // during that transaction: treating the expected not-ready interval as a
    // failure would inactivate the exact generation owned by the maintainer.
    if (deferMonitorWorkForMaintenance(monitor, target)) return;
    target.probeState = 'failed';
    target.lastError = message;
    target.probeFailures = (target.probeFailures || 0) + 1;
    logEvent(monitor, 'error', 'container_probe_failed', {
        container: target.containerName,
        agent: target.agentName,
        repo: target.repoName,
        error: message,
        failures: target.probeFailures
    });
    if (runtimeHealth) {
        const inactivate = monitor.inactivateEdgeRoutingGeneration || inactivateEdgeRoutingGeneration;
        try {
            inactivate(`continuous-runtime-probe-failed:${target.containerName}`);
        } catch (error) {
            logEvent(monitor, 'error', 'container_probe_inactivation_failed', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                error: error?.message || error,
            });
        }
        scheduleContainerRestart(monitor, target, 'semantic_probe_failed');
    }
}

function handleProbeInfrastructureFailure(monitor, target, message, code) {
    if (!monitor || !target) return;
    target.probeState = 'pending';
    target.lastError = message;
    target.probeInfrastructureFailures = (target.probeInfrastructureFailures || 0) + 1;
    const initialBackoffMs = positiveInteger(
        monitor?.config?.PROBE_INFRASTRUCTURE_BACKOFF_MS
            ?? process.env.PLOINKY_CONTAINER_MONITOR_PROBE_INFRASTRUCTURE_BACKOFF_MS,
        5_000,
    );
    const maxBackoffMs = positiveInteger(
        monitor?.config?.PROBE_INFRASTRUCTURE_MAX_BACKOFF_MS
            ?? process.env.PLOINKY_CONTAINER_MONITOR_PROBE_INFRASTRUCTURE_MAX_BACKOFF_MS,
        30_000,
    );
    const exponent = Math.min(target.probeInfrastructureFailures - 1, 10);
    const retryInMs = Math.min(initialBackoffMs * (2 ** exponent), maxBackoffMs);
    target.probeRetryNotBefore = Date.now() + retryInMs;
    logEvent(monitor, 'warn', 'container_probe_infrastructure_error', {
        container: target.containerName,
        agent: target.agentName,
        repo: target.repoName,
        error: message,
        code,
        failures: target.probeInfrastructureFailures,
        retryInMs,
    });
}

export function startProbeWorker(monitor, target) {
    if (!monitor || !target) return;
    if (target.circuitBreakerTripped) return;
    if (deferMonitorWorkForMaintenance(monitor, target)) return;
    if (target.probeWorker || target.probeState === 'success') return;
    const now = Date.now();
    if (typeof target.probeRetryNotBefore === 'number'
        && now < target.probeRetryNotBefore) return;
    target.probeRetryNotBefore = null;

    const maxConcurrency = positiveInteger(
        monitor?.config?.PROBE_MAX_CONCURRENCY
            ?? process.env.PLOINKY_CONTAINER_MONITOR_PROBE_MAX_CONCURRENCY,
        DEFAULT_MAX_CONCURRENT_PROBE_WORKERS,
    );
    const activeWorkers = activeProbeWorkerCount(monitor);
    if (activeWorkers >= maxConcurrency) {
        if (!target.probeConcurrencyDeferred) {
            target.probeConcurrencyDeferred = true;
            logEvent(monitor, 'debug', 'container_probe_concurrency_deferred', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                maxConcurrentWorkers: maxConcurrency,
            });
        }
        return;
    }
    target.probeConcurrencyDeferred = false;

    let manifest;
    try {
        const manifestContent = fs.readFileSync(target.manifestPath, 'utf8');
        manifest = JSON.parse(manifestContent || '{}');
    } catch (error) {
        handleProbeFailure(monitor, target, error?.message || error);
        return;
    }

    if (!manifest || typeof manifest !== 'object' || !manifest.health) {
        target.probeState = 'success';
        return;
    }

    try {
        const WorkerClass = monitor.Worker || Worker;
        target.probeWorker = new WorkerClass(PROBE_WORKER_URL, {
            workerData: {
                agentName: target.agentName,
                containerName: target.containerName,
                manifest: { health: manifest.health }
            },
            stdout: true,
            stderr: true
        });
    } catch (error) {
        handleProbeFailure(monitor, target, error?.message || error);
        return;
    }

    target.probeState = 'running';
    logEvent(monitor, 'info', 'container_probe_started', {
        container: target.containerName,
        agent: target.agentName,
        repo: target.repoName
    });

    const worker = target.probeWorker;

    worker.on('message', (msg) => {
        if (!msg || typeof msg !== 'object') return;
        if (msg.type === 'log' && msg.message) {
            const level = msg.level || 'info';
            if (level === 'warn') {
                console.warn(msg.message);
            } else if (level === 'error') {
                console.error(msg.message);
            } else {
                console.log(msg.message);
            }
            return;
        }
        if (msg.status === 'success') {
            if (deferMonitorWorkForMaintenance(monitor, target)) return;
            target.probeState = 'success';
            target.probeLastSuccessAt = Date.now();
            target.probeInfrastructureFailures = 0;
            target.probeRetryNotBefore = null;
            target.lastError = null;
            logEvent(monitor, 'info', 'container_probe_succeeded', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName
            });
            stopProbeWorker(target);
        } else if (msg.status === 'error') {
            stopProbeWorker(target);
            const message = msg.error || 'Probe worker reported failure.';
            const code = String(msg.code || '');
            if (TRANSIENT_PROBE_INFRASTRUCTURE_CODES.has(code)) {
                handleProbeInfrastructureFailure(monitor, target, message, code);
            } else {
                handleProbeFailure(monitor, target, message, { runtimeHealth: true });
            }
        }
    });

    worker.on('error', (error) => {
        stopProbeWorker(target);
        handleProbeFailure(monitor, target, error?.message || error, { runtimeHealth: true });
    });

    worker.on('exit', (code) => {
        if (target.probeWorker === worker) {
            target.probeWorker = null;
        }
        if (code !== 0 && target.probeState === 'running') {
            handleProbeFailure(monitor, target, `Probe worker exited with code ${code}`, { runtimeHealth: true });
        }
    });
}

const UNREADABLE_NO_WAIT_STATUS = Object.freeze({ state: 'unreadable' });

// Must be an actual JSON number. Number() would coerce null, '' and false to
// zero, so a malformed wave-zero marker would compare equal to a wave-zero
// status and reopen probing instead of failing closed.
const MAX_NO_WAIT_MARKER_WAVE_INDEX = 1023;

function exactNoWaitMarkerInteger(value, { minimum = 0, maximum = Number.MAX_SAFE_INTEGER } = {}) {
    return typeof value === 'number' && Number.isSafeInteger(value)
        && value >= minimum && value <= maximum
        ? value
        : null;
}

export function readNoWaitStatus(containerName, { runningDir = RUNNING_DIR } = {}) {
    if (!containerName) return null;
    if (path.basename(containerName) !== containerName) return UNREADABLE_NO_WAIT_STATUS;
    const markerPath = path.join(runningDir, 'no-wait', `${containerName}.current.json`);
    const statusPath = path.join(runningDir, 'no-wait', `${containerName}.json`);
    let currentRun = null;
    try {
        const parsed = JSON.parse(fs.readFileSync(markerPath, 'utf8'));
        const runStartedAtMs = exactNoWaitMarkerInteger(parsed?.runStartedAtMs);
        const waveIndex = exactNoWaitMarkerInteger(parsed?.waveIndex, {
            maximum: MAX_NO_WAIT_MARKER_WAVE_INDEX,
        });
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)
            || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
                .test(String(parsed.runId || ''))
            || String(parsed.statusFile || '') !== `${containerName}.${parsed.runId}.json`
            || runStartedAtMs === null || waveIndex === null) {
            return UNREADABLE_NO_WAIT_STATUS;
        }
        currentRun = { runId: String(parsed.runId), runStartedAtMs, waveIndex };
    } catch (error) {
        if (error?.code !== 'ENOENT') return UNREADABLE_NO_WAIT_STATUS;
    }
    try {
        const parsed = JSON.parse(fs.readFileSync(statusPath, 'utf8'));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
            return UNREADABLE_NO_WAIT_STATUS;
        }
        // The marker binds the canonical status to one exact run identity,
        // run start, and wave. Carrying the fields without cross-checking all
        // three would let a late writer from an earlier run or wave reopen
        // monitor probing.
        if (currentRun && (String(parsed.runId || '') !== currentRun.runId
            || exactNoWaitMarkerInteger(parsed.runStartedAtMs) !== currentRun.runStartedAtMs
            || exactNoWaitMarkerInteger(parsed.waveIndex, {
                maximum: MAX_NO_WAIT_MARKER_WAVE_INDEX,
            }) !== currentRun.waveIndex)) {
            return UNREADABLE_NO_WAIT_STATUS;
        }
        const state = String(parsed.state || '').trim().toLowerCase();
        return ['starting', 'running', 'failed'].includes(state)
            ? parsed
            : UNREADABLE_NO_WAIT_STATUS;
    } catch (error) {
        return error?.code === 'ENOENT' && !currentRun
            ? null
            : UNREADABLE_NO_WAIT_STATUS;
    }
}

function shouldDeferNoWaitRestart(monitor, target) {
    const readStatus = monitor?.readNoWaitStatus || readNoWaitStatus;
    let status;
    try {
        status = readStatus(target?.containerName || '');
    } catch (_) {
        status = UNREADABLE_NO_WAIT_STATUS;
    }
    const observedState = String(status?.state || '').trim().toLowerCase();
    const state = ['starting', 'failed'].includes(observedState)
        ? observedState
        : (status && observedState !== 'running' ? 'unreadable' : observedState);
    if (!['starting', 'failed', 'unreadable'].includes(state)) {
        target.noWaitDeferredState = null;
        return false;
    }
    if (target.noWaitDeferredState !== state) {
        target.noWaitDeferredState = state;
        logEvent(monitor, 'info', 'container_no_wait_restart_deferred', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            state,
            statusFile: path.join(RUNNING_DIR, 'no-wait', `${target.containerName}.json`)
        });
    }
    return true;
}

const NO_WAIT_WORKER_SCRIPT_PATH = fileURLToPath(new URL('../commands/noWaitWorker.js', import.meta.url));
const DEFAULT_NO_WAIT_WORKER_EXIT_WAIT_MS = 5000;
const NO_WAIT_WORKER_EXIT_POLL_MS = 100;

function readNoWaitRunDocument(fileName) {
    return readVerifiedJsonObject({
        trustedRoot: RUNNING_DIR,
        relativeSegments: ['no-wait', fileName],
        byteLimit: NO_WAIT_STATE_BYTE_LIMIT,
        absent: null,
    });
}

// True only for a terminal `running` document of exactly this run identity.
function namesRunningNoWaitRun(document, identity) {
    if (!document || document.state !== 'running') return false;
    try {
        return sameNoWaitImmutableIdentity(exactNoWaitImmutableIdentity(document), identity);
    } catch (_) {
        return false;
    }
}

// A run retained from a failed attempt spans two lock holds: in between, a
// start, enable or disable may have launched, retired or replaced it. Reuse it
// only while the registry still holds exactly the tuple that attempt left, no
// marker binds either name, and the predecessor's canonical status still names
// the retained run.
function retainedNoWaitLineageCurrent(monitor, target, pending, record) {
    if (!pending?.lineage || !target.restartInputDigest
        || pending.restartInputDigest !== target.restartInputDigest) {
        return false;
    }
    const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
    const live = loadAgents()?.[target.containerName];
    if (!live || digestValue(live) !== pending.registryDigest
        || digestValue(record) !== pending.registryDigest) {
        return false;
    }
    const { lineage } = pending;
    const readMarker = monitor.readNoWaitRunMarker || readNoWaitRunMarker;
    if (lineage.containerName !== target.containerName
        && readMarker(lineage.containerName, { runningDir: RUNNING_DIR })) {
        return false;
    }
    return namesRunningNoWaitRun(readNoWaitRunDocument(`${lineage.containerName}.json`), lineage.identity);
}

// A replacement of a no-wait runtime retires the current-run marker of the
// tuple it replaces: the replacement coordinator does it before a non-additive
// registry write, and the staged branch leaves it for the rebind below.
// Capture that exact run before the replacement, under the workspace mutation
// lease and network lifecycle lock that every marker writer holds, so the
// replacement can be bound back to the same deployment run. A run retained
// from a failed attempt is consumed here and reused only if still current.
// It lives in this process only: a Router restart forgets it, and the
// replacement then stays unbound (fail-closed).
function captureNoWaitRebindLineage(monitor, target, record) {
    const pending = target.pendingNoWaitRebind || null;
    target.pendingNoWaitRebind = null;
    const readMarker = monitor.readNoWaitRunMarker || readNoWaitRunMarker;
    try {
        const marker = readMarker(target.containerName, { runningDir: RUNNING_DIR });
        if (!marker) {
            return retainedNoWaitLineageCurrent(monitor, target, pending, record) ? pending.lineage : null;
        }
        createNoWaitRunBinding(target.containerName, record, marker);
        return Object.freeze({
            containerName: target.containerName,
            record: deepFreezeSnapshot(structuredClone(record)),
            identity: exactNoWaitImmutableIdentity(marker),
        });
    } catch (_) {
        // A malformed or foreign marker has no run this Watchdog may rebind;
        // the replacement coordinator refuses to retire it on its own.
        return null;
    }
}

// The predecessor's worker could still publish over the rebound run. Rebind
// only once its own terminal status is on disk and its process is provably
// gone (dead, or its pid reused by a foreign process). The structured proof
// runs once; the bounded wait after it polls only liveness and yields to the
// event loop, because this runs in the Router process. Returns the reason to
// refuse, or null.
async function waitForPredecessorNoWaitWorkerExit(monitor, lineage) {
    let status;
    try {
        status = readNoWaitRunDocument(lineage.identity.statusFile);
    } catch (error) {
        return `the predecessor run status is unreadable: ${error?.message || error}`;
    }
    if (!status) return 'the predecessor run published no status';
    if (!namesRunningNoWaitRun(status, lineage.identity)) {
        return 'the predecessor run status is not the terminal running status of the captured run';
    }
    // A status this Watchdog published for an earlier replacement names no
    // worker: none exists.
    if (!Object.hasOwn(status, 'pid')) return null;
    const prove = monitor.proveNoWaitWorkerProcess || proveWorkerProcessIdentity;
    try {
        prove({
            pid: status.pid,
            executablePath: process.execPath,
            workerScriptPath: NO_WAIT_WORKER_SCRIPT_PATH,
            runningDir: RUNNING_DIR,
            identity: lineage.identity,
        });
    } catch (error) {
        if (error?.code === 'PROCESS_IDENTITY_STALE' || error?.foreign === true) return null;
        return `the predecessor worker could not be proven gone: ${error?.message || error}`;
    }
    // A pid reused during the wait keeps it alive and ends in refusal.
    const isAlive = monitor.isNoWaitWorkerAlive || isProcessAlive;
    const waitMs = Number.isSafeInteger(monitor.noWaitWorkerExitWaitMs) && monitor.noWaitWorkerExitWaitMs >= 0
        ? monitor.noWaitWorkerExitWaitMs
        : DEFAULT_NO_WAIT_WORKER_EXIT_WAIT_MS;
    const deadline = Date.now() + waitMs;
    for (;;) {
        const remaining = deadline - Date.now();
        if (remaining <= 0) return `the predecessor worker ${status.pid} is still running`;
        await new Promise((resolve) => setTimeout(resolve, Math.min(NO_WAIT_WORKER_EXIT_POLL_MS, remaining)));
        if (!isAlive(status.pid)) return null;
    }
}

// After a rebind under a new name, the retired run's documents stay behind
// under the predecessor name, which a later candidate can cycle back to.
// Remove each only while it still names exactly that run; the run's worker is
// proven gone and every other writer holds this restart's locks.
function removeSupersededNoWaitRunDocuments(lineage) {
    for (const fileName of [lineage.identity.statusFile, `${lineage.containerName}.json`]) {
        if (!namesRunningNoWaitRun(readNoWaitRunDocument(fileName), lineage.identity)) continue;
        fs.unlinkSync(path.join(RUNNING_DIR, 'no-wait', fileName));
    }
}

/**
 * Bind a committed replacement back to the deployment run its predecessor
 * belonged to: the same run id, run start and wave, under the replacement's
 * own container name, instance and enable generation. The terminal `running`
 * status follows this Watchdog's own readiness and route activation. The
 * statuses are written first and the marker last, so an interruption leaves
 * the runtime unbound (fail-closed) and never defers the Watchdog. Nothing is
 * published if the registry moved or a newer marker appeared, and no failure
 * here may undo the committed replacement.
 */
async function rebindNoWaitRunAfterReplacement(monitor, target, lineage, {
    committedName,
    committedRecord,
    hostPort,
    agentDir,
}) {
    const event = {
        container: committedName,
        agent: target.agentName,
        repo: target.repoName,
        runId: lineage.identity.runId,
    };
    const refuse = (reason) => {
        logEvent(monitor, 'warn', 'container_no_wait_rebind_refused', { ...event, reason });
        return false;
    };
    try {
        const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
        const readMarker = monitor.readNoWaitRunMarker || readNoWaitRunMarker;
        const registryCurrent = () => {
            const current = loadAgents()?.[committedName];
            return Boolean(current) && digestValue(current) === digestValue(committedRecord);
        };
        if (!registryCurrent()) return refuse('the registry moved after activation');
        const predecessorMarker = readMarker(lineage.containerName, { runningDir: RUNNING_DIR });
        if (predecessorMarker && !sameNoWaitImmutableIdentity(predecessorMarker, lineage.identity)) {
            return refuse('a newer marker names the predecessor runtime');
        }
        if (committedName !== lineage.containerName
            && readMarker(committedName, { runningDir: RUNNING_DIR })) {
            return refuse('a newer marker already binds the replacement');
        }
        const workerProblem = await waitForPredecessorNoWaitWorkerExit(monitor, lineage);
        if (workerProblem) return refuse(workerProblem);

        const alias = committedRecord.alias === undefined || committedRecord.alias === null
            ? ''
            : committedRecord.alias;
        const identity = exactNoWaitImmutableIdentity({
            containerName: committedName,
            instanceId: committedRecord.instanceId,
            enableGeneration: committedRecord.enableGeneration,
            repoName: committedRecord.repoName,
            shortAgent: committedRecord.agentName,
            alias,
            routeKey: alias || committedRecord.agentName,
            runId: lineage.identity.runId,
            runStartedAtMs: lineage.identity.runStartedAtMs,
            waveIndex: lineage.identity.waveIndex,
            statusFile: `${committedName}.${lineage.identity.runId}.json`,
        });
        if (['repoName', 'shortAgent', 'alias', 'routeKey']
            .some((field) => identity[field] !== lineage.identity[field])) {
            return refuse('the replacement is a different logical agent');
        }

        // Revalidate everything immediately before the first write.
        if (!registryCurrent()) return refuse('the registry moved before publication');
        const currentPredecessorMarker = readMarker(lineage.containerName, { runningDir: RUNNING_DIR });
        if (currentPredecessorMarker && !sameNoWaitImmutableIdentity(currentPredecessorMarker, lineage.identity)) {
            return refuse('a newer marker names the predecessor runtime');
        }
        if (committedName !== lineage.containerName
            && readMarker(committedName, { runningDir: RUNNING_DIR })) {
            return refuse('a newer marker already binds the replacement');
        }
        if (!namesRunningNoWaitRun(readNoWaitRunDocument(`${lineage.containerName}.json`), lineage.identity)) {
            return refuse('the canonical status no longer names the captured run');
        }
        if (currentPredecessorMarker) {
            const retire = monitor.retireNoWaitRunMarker || retireNoWaitRunMarker;
            const retired = retire(lineage.containerName, {
                runningDir: RUNNING_DIR,
                expectedRecord: lineage.record,
            });
            if (!retired?.retired || !sameNoWaitImmutableIdentity(retired.identity, lineage.identity)) {
                throw new Error('the predecessor marker retirement did not retire the captured run');
            }
        }
        if (readMarker(committedName, { runningDir: RUNNING_DIR })) {
            return refuse('a newer marker already binds the replacement');
        }
        const nowMs = Date.now();
        const now = new Date(nowMs).toISOString();
        const writeStatus = monitor.writeNoWaitWorkerStatus || writeNoWaitWorkerStatus;
        writeStatus(committedName, {
            containerName: committedName,
            shortAgent: identity.shortAgent,
            repoName: identity.repoName,
            alias: identity.alias,
            routeKey: identity.routeKey,
            manifestPath: target.manifestPath,
            agentPath: agentDir,
            startedAt: now,
            startedAtMs: nowMs,
            sequencePhase: 'active',
            sequencePhaseStartedAt: now,
            sequencePhaseStartedAtMs: nowMs,
            state: 'running',
            finishedAt: now,
            finishedAtMs: nowMs,
            container: committedName,
            hostPort: hostPort || null,
        }, {
            identity,
            runId: identity.runId,
            runStartedAtMs: identity.runStartedAtMs,
            waveIndex: identity.waveIndex,
            statusFile: path.join(RUNNING_DIR, 'no-wait', identity.statusFile),
            runningDir: RUNNING_DIR,
        });
        const publishMarker = monitor.publishNoWaitRunMarker || publishNoWaitRunMarker;
        publishMarker(identity, { runningDir: RUNNING_DIR });
        if (committedName !== lineage.containerName) {
            try {
                removeSupersededNoWaitRunDocuments(lineage);
            } catch (error) {
                logEvent(monitor, 'warn', 'container_no_wait_superseded_status_retained', {
                    ...event,
                    predecessorContainer: lineage.containerName,
                    error: error?.message || String(error),
                    code: error?.code || null,
                });
            }
        }
        logEvent(monitor, 'info', 'container_no_wait_run_rebound', {
            ...event,
            predecessorContainer: lineage.containerName,
            predecessorInstanceId: lineage.identity.instanceId,
            predecessorEnableGeneration: lineage.identity.enableGeneration,
            instanceId: identity.instanceId,
            enableGeneration: identity.enableGeneration,
        });
        return true;
    } catch (error) {
        logEvent(monitor, 'error', 'container_no_wait_rebind_failed', {
            ...event,
            error: error?.message || String(error),
            code: error?.code || null,
        });
        return false;
    }
}

function shouldDeferMaintenanceRestart(monitor, target) {
    const result = inspectMaintenanceLock(target?.containerName || '');
    if (result.stale) {
        logEvent(monitor, 'info', 'container_maintenance_lock_removed', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            operation: result.lock?.operation || null,
            ownerPid: result.lock?.ownerPid || null,
            expiresAt: result.lock?.expiresAt || null
        });
    }
    if (!result.active) {
        target.maintenanceDeferred = false;
        return false;
    }
    if (!target.maintenanceDeferred) {
        target.maintenanceDeferred = true;
        logEvent(monitor, 'info', 'container_restart_deferred_maintenance', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            operation: result.lock?.operation || null,
            ownerPid: result.lock?.ownerPid || null,
            expiresAt: result.lock?.expiresAt || null
        });
    }
    return true;
}

function deferMonitorWorkForMaintenance(monitor, target) {
    if (!shouldDeferMaintenanceRestart(monitor, target)) return false;
    // A worker may have started immediately before the maintenance lock was
    // acquired. Terminate it and discard any earlier success timestamp so the
    // first post-maintenance tick performs a fresh semantic probe.
    stopProbeWorker(target);
    target.probeState = 'pending';
    target.probeLastSuccessAt = null;
    return true;
}

// A workspace start that stopped after persisting this record's rotated tuple,
// but before removing the predecessor that tuple replaces, left the
// predecessor's own tuple in a receipt keyed by the rotated one. Only the next
// start can consume it. A restart here would rotate the record again, so the
// receipt would no longer bind and no later start could prove, and remove, the
// predecessor. The record stays with the next start. A receipt that exists but
// does not bind is refused by that start too, so it also defers, and it is
// never erased here.
function shouldDeferForStartPredecessor(monitor, target, record) {
    const readPredecessor = monitor?.readRuntimePredecessor || readRuntimePredecessor;
    let code = null;
    try {
        if (!readPredecessor(target?.containerName || '', record)) {
            target.startPredecessorDeferred = false;
            return false;
        }
    } catch (error) {
        code = String(error?.code || 'PLOINKY_RUNTIME_PREDECESSOR_INVALID');
    }
    if (!target.startPredecessorDeferred) {
        target.startPredecessorDeferred = true;
        logEvent(monitor, 'info', 'container_restart_deferred_start_predecessor', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            ...(code ? { code } : {}),
        });
    }
    return true;
}

function deferMonitorWorkForStartPredecessor(monitor, target) {
    if (!shouldDeferForStartPredecessor(monitor, target, target?.restartSnapshot?.registryRecord)) return false;
    // A probe failure could only schedule a restart that must be deferred.
    stopProbeWorker(target);
    target.probeState = 'pending';
    target.probeLastSuccessAt = null;
    return true;
}

export function syncManagedContainers(monitor) {
    const monitorRef = monitor;
    if (!monitorRef) return;
    let inventoryChanged = false;

    let agentsMap = {};
    try {
        const loadAgents = monitorRef.loadAgents || workspaceSvc.loadAgents;
        agentsMap = loadAgents() || {};
    } catch (error) {
        logEvent(monitorRef, 'error', 'container_sync_failed', { error: error?.message || error });
        return;
    }

    const presentRegistryNames = new Set(Object.keys(agentsMap).filter((name) => (
        name !== '_config' && !name.startsWith('_')
    )));
    pruneTerminalLedger(monitorRef, presentRegistryNames);

    let mpsStatus;
    const observeMpsTarget = (containerName, record, descriptor) => {
        let applied = null;
        try { applied = (monitorRef.readAppliedObservation || readAppliedObservation)(containerName, record.containerId); } catch (_) {}
        const exact = applied && applied.containerId === record.containerId && applied.instanceId === record.instanceId && applied.enableGeneration === record.enableGeneration;
        const desiredShare = Boolean(descriptor?.hardwareGpu);
        const appliedShare = Boolean(applied?.mpsGeneration) && (exact || desiredShare);
        if (!desiredShare && !appliedShare) return { mpsFingerprint: null, mpsPending: false };
        if (mpsStatus === undefined) {
            try { mpsStatus = (monitorRef.readMpsStatus || readMpsStatus)() || {}; } catch (_) { mpsStatus = { daemonStatus: 'unknown', mpsGeneration: null }; }
        }
        const generation = typeof mpsStatus?.mpsGeneration === 'string' ? mpsStatus.mpsGeneration.slice(0, 257) : null;
        const daemonStatus = String(mpsStatus?.daemonStatus || 'unknown').slice(0, 32);
        // Only applied-share facts restart a running instance: an exact share
        // client whose daemon is lost, or a client whose share is still
        // desired and whose applied identity is stale or whose applied
        // generation differs. Saving a new share or clearing one changes
        // desired policy only; Apply, start and restart reconcile it (§3, §5.3).
        return {
            mpsFingerprint: digestValue({ generation, daemonStatus }),
            mpsPending: appliedShare && (!exact || daemonStatus !== 'ready' || (desiredShare && applied.mpsGeneration !== generation)),
        };
    };
    const desired = new Map();
    const readRouting = monitorRef.readRoutingConfig || readRoutingConfig;
    const routing = readRouting();

    for (const [containerName, record] of Object.entries(agentsMap)) {
        if (!record || typeof record !== 'object') continue;
        if (containerName === '_config' || containerName.startsWith('_')) continue;

        const type = record.type || 'agent';
        if (type !== 'agent') continue;

        const agentName = record.agentName || record.shortAgentName || null;
        const repoName = record.repoName || record.repo || null;
        const alias = record.alias || null;
        if (!agentName || !repoName) continue;

        const manifestPath = path.join(resolveAgentRepositoryPath(repoName), agentName, 'manifest.json');
        if (!fs.existsSync(manifestPath)) {
            logEvent(monitorRef, 'warn', 'container_manifest_missing', {
                container: containerName,
                agent: agentName,
                repo: repoName,
                manifest: manifestPath
            });
            continue;
        }

        let restartInput;
        try {
            restartInput = resolveWatchdogRestartInput(record, {
                containerName,
                agentName,
                repoName,
                alias,
                profile: record.profile || null,
                runtime: record.runtime || 'container',
                instanceId: String(record.instanceId || '').trim() || null,
                enableGeneration: String(record.enableGeneration || '').trim() || null,
                manifestPath,
                routing,
            }, monitorRef);
            if (!restartInput) continue;
        } catch (error) {
            const terminal = classifyTerminalFailure(error);
            const fallbackDigest = digestValue({
                containerName,
                repoName,
                agentName,
                manifestPath,
                code: String(error?.code || 'manifest-invalid'),
                manifestDigest: (() => {
                    try { return digestValue(fs.readFileSync(manifestPath).toString('base64')); } catch (_) { return ''; }
                })(),
                profile: record.profile || null,
                runtime: record.runtime || 'container',
                instanceId: String(record.instanceId || ''),
                enableGeneration: String(record.enableGeneration || ''),
                // Only this agent's own hardware inputs re-arm it; unrelated
                // policy writes leave the fingerprint unchanged.
                hardwareFingerprint: findHardwareOutcome(error)?.inputFingerprint || '',
            });
            if (terminal) {
                const info = {
                    containerName,
                    agentName,
                    repoName,
                    instanceId: String(record.instanceId || '').trim() || null,
                    enableGeneration: String(record.enableGeneration || '').trim() || null,
                    ...observeMpsTarget(containerName, record, { hardwareGpu: findHardwareOutcome(error)?.requested?.some((entry) => entry.field === 'gpu') === true }),
                };
                const existing = monitorRef.terminalLedger?.get(containerName);
                if (existing?.restartInputDigest !== fallbackDigest || (existing?.mpsFingerprint || null) !== info.mpsFingerprint) {
                    recordTerminalFailure(monitorRef, info, error, fallbackDigest);
                }
                const target = monitorRef.targets.get(containerName);
                if (target?.pendingRestartTimer) clearTimeout(target.pendingRestartTimer);
                if (target) stopProbeWorker(target);
                inventoryChanged = monitorRef.targets.delete(containerName) || inventoryChanged;
            }
            logEvent(monitorRef, terminal ? 'warn' : 'error', terminal
                ? 'container_runtime_policy_terminal'
                : 'container_manifest_invalid', {
                container: containerName,
                agent: agentName,
                repo: repoName,
                manifest: manifestPath,
                error: error?.message || String(error),
                code: error?.code || null,
                restartInputDigest: fallbackDigest,
            });
            continue;
        }

        const runtime = record.runtime || 'container';
        const profile = record.profile || null;
        const instanceId = String(record.instanceId || '').trim() || null;
        const enableGeneration = String(record.enableGeneration || '').trim() || null;
        const info = {
            containerName,
            type,
            agentName,
            repoName,
            alias,
            profile,
            manifestPath,
            runtime,
            instanceId,
            enableGeneration,
            restartInputDigest: restartInput.restartInputDigest,
            runtimeAdmission: restartInput.runtimeAdmission,
            restartSnapshot: restartInput.restartSnapshot,
            ...observeMpsTarget(containerName, record, restartInput.runtimeAdmission.descriptor),
        };
        monitorRef.terminalLedger ||= loadTerminalLedger(monitorRef);
        const terminal = monitorRef.terminalLedger.get(containerName);
        if (terminal?.restartInputDigest === restartInput.restartInputDigest && (terminal?.mpsFingerprint || null) === info.mpsFingerprint) {
            continue;
        }
        if (terminal) {
            monitorRef.terminalLedger.delete(containerName);
            persistTerminalLedger(monitorRef);
        }
        desired.set(containerName, info);

        let target = monitorRef.targets.get(containerName);
        if (!target) {
            target = createContainerTarget(info, monitorRef);
            target.runtime = runtime;
            monitorRef.targets.set(containerName, target);
            inventoryChanged = true;
            logEvent(monitorRef, 'info', 'container_watch_added', {
                container: containerName,
                agent: agentName,
                repo: repoName,
                runtime
            });
        } else {
            // The active attempt owns its immutable snapshot and verifies the
            // live manifest/registry at every lifecycle checkpoint. A normal
            // monitor sync may observe the attempt's intentionally staged
            // successor tuple, but must not adopt it, clear isRestarting, or
            // start a second probe/restart underneath readiness. External
            // drift remains visible in the live files and the active attempt
            // rejects it before publication; the next tick adopts state only
            // after that attempt has finished or failed stale.
            if (target.isRestarting) continue;
            if (target.restartInputDigest !== restartInput.restartInputDigest || (target.mpsFingerprint || null) !== info.mpsFingerprint) {
                target.attemptEpoch += 1;
                if (target.pendingRestartTimer) clearTimeout(target.pendingRestartTimer);
                target.pendingRestartTimer = null;
                target.isRestarting = false;
                target.restartHistory = [];
                target.circuitBreakerTripped = false;
                target.currentBackoff = monitorRef?.config?.INITIAL_BACKOFF_MS ?? 1000;
            }
            target.agentName = agentName;
            target.repoName = repoName;
            target.alias = alias;
            target.profile = profile;
            target.instanceId = instanceId;
            target.enableGeneration = enableGeneration;
            target.type = type;
            target.manifestPath = manifestPath;
            target.runtime = runtime;
            target.restartInputDigest = restartInput.restartInputDigest;
            target.runtimeAdmission = restartInput.runtimeAdmission;
            target.restartSnapshot = restartInput.restartSnapshot;
            target.mpsFingerprint = info.mpsFingerprint;
            target.mpsPending = info.mpsPending;
        }
    }

    for (const [containerName, target] of Array.from(monitorRef.targets.entries())) {
        if (!desired.has(containerName)) {
            if (target?.pendingRestartTimer) {
                clearTimeout(target.pendingRestartTimer);
            }
            stopProbeWorker(target);
            target.attemptEpoch += 1;
            monitorRef.targets.delete(containerName);
            inventoryChanged = true;
            logEvent(monitorRef, 'info', 'container_watch_removed', { container: containerName });
        }
    }

    if (inventoryChanged) {
        monitorRef.runtimeSnapshotTakenAt = 0;
    }
}

function scheduleContainerRestart(monitor, target, reason) {
    if (!monitor || !target) return;
    if (monitor.isShuttingDown()) return;
    if (target.circuitBreakerTripped || target.isRestarting || target.pendingRestartTimer) return;

    cleanRestartHistory(monitor, target);
    const maxRestarts = monitor?.config?.MAX_RESTARTS_IN_WINDOW ?? 5;
    if (target.restartHistory.length >= maxRestarts) {
        target.circuitBreakerTripped = true;
        logEvent(monitor, 'fatal', 'container_circuit_breaker_tripped', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            restarts: target.restartHistory.length,
            windowMs: monitor?.config?.RESTART_WINDOW_MS ?? 60000
        });
        return;
    }

    const now = Date.now();
    target.restartHistory.push(now);
    target.totalRestarts = (target.totalRestarts || 0) + 1;

    const backoff = calculateBackoff(monitor, target);

    logEvent(monitor, 'warn', 'container_scheduling_restart', {
        container: target.containerName,
        agent: target.agentName,
        repo: target.repoName,
        reason,
        backoffMs: backoff,
        attemptsInWindow: target.restartHistory.length
    });

    target.isRestarting = true;
    const attempt = target.restartInputDigest && target.restartSnapshot
        ? Object.freeze({
            target,
            epoch: (target.attemptEpoch || 0) + 1,
            digest: target.restartInputDigest,
            snapshot: target.restartSnapshot,
        })
        : null;
    if (attempt) target.attemptEpoch = attempt.epoch;
    target.pendingRestartTimer = setTimeout(() => {
        target.pendingRestartTimer = null;
        performContainerRestart(monitor, target, reason, attempt).catch((error) => {
            target.lastError = error?.message || error;
            if (!error || typeof error !== 'object' || !LOGGED_RESTART_FAILURES.has(error)) {
                logEvent(monitor, 'error', 'container_restart_failed', {
                    container: target.containerName,
                    agent: target.agentName,
                    repo: target.repoName,
                    reason,
                    error: target.lastError
                });
            }
            target.isRestarting = false;
            if (error?.code === 'PLOINKY_RESTART_ATTEMPT_STALE') return;
            if (classifyTerminalFailure(error)) {
                target.terminalState = recordTerminalFailure(
                    monitor,
                    target,
                    error,
                    target.restartInputDigest || attempt?.digest || '',
                );
                target.circuitBreakerTripped = true;
                return;
            }
            scheduleContainerRestart(monitor, target, 'restart_failed');
        });
    }, backoff);
}

function assertRestartAttemptCurrent(monitor, target, attempt, checkpoint, {
    expectedRegistryRecord = null,
    expectedContainerName = null,
} = {}) {
    if (!attempt) return;
    let currentBytes;
    try {
        currentBytes = fs.readFileSync(attempt.snapshot.manifestPath);
    } catch (_) {}
    let recomputedDigest = '';
    try {
        const readRouting = monitor.readRoutingConfig || readRoutingConfig;
        const recomputed = resolveWatchdogRestartInput(
            attempt.snapshot.registryRecord,
            { ...attempt.snapshot.info, routing: readRouting() },
            monitor,
        );
        recomputedDigest = recomputed?.restartInputDigest || '';
    } catch (_) {}
    let registryRecordMatches = true;
    try {
        const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
        const currentRecord = loadAgents()?.[
            String(expectedContainerName || attempt.snapshot.info.containerName)
        ];
        const expectedDigest = digestValue(expectedRegistryRecord || attempt.snapshot.registryRecord);
        registryRecordMatches = Boolean(currentRecord) && digestValue(currentRecord) === expectedDigest;
    } catch (_) {
        registryRecordMatches = false;
    }
    if (attempt.target !== target
        || monitor.targets.get(target.containerName) !== target
        || target.attemptEpoch !== attempt.epoch
        || target.restartInputDigest !== attempt.digest
        || attempt.snapshot?.digest !== attempt.digest
        || currentBytes?.toString('base64') !== attempt.snapshot.manifestBytesBase64
        || recomputedDigest !== attempt.digest
        || !registryRecordMatches) {
        const error = new Error(`watchdog restart attempt became stale at ${checkpoint}`);
        error.code = 'PLOINKY_RESTART_ATTEMPT_STALE';
        throw error;
    }
}

function positiveInteger(value, fallback) {
    const parsed = Number.parseInt(String(value ?? ''), 10);
    return Number.isSafeInteger(parsed) && parsed > 0 ? parsed : fallback;
}

function assertRestartPreparationResult(target, result) {
    const containerName = String(result?.containerName || '').trim();
    const record = result?.registryRecord;
    const targetContainerName = String(target.containerName || '');
    const replacementPredecessor = result?.replacementPredecessor || null;
    const containerIdentityMatches = containerName === targetContainerName
        || (Boolean(replacementPredecessor)
            && containerName !== targetContainerName
            && String(replacementPredecessor?.containerName || '') === targetContainerName
            && replacementPredecessor?.registryRecord?.type === 'agent');
    if (!containerName || !containerIdentityMatches
        || !record || typeof record !== 'object' || Array.isArray(record)
        || record.type !== 'agent'
        || String(record.repoName || '') !== String(target.repoName || '')
        || String(record.agentName || '') !== String(target.agentName || '')
        || String(record.alias || '') !== String(target.alias || '')
        || !String(record.instanceId || '')
        || !String(record.enableGeneration || '')) {
        throw new Error(`watchdog runtime ensure returned a mismatched exact registry identity for '${containerName || target.containerName}'`);
    }
    if (result?.requiresEdgeActivation !== true) return null;
    const stagedRecord = result?.stagedRegistryRecord;
    if (!stagedRecord || typeof stagedRecord !== 'object' || Array.isArray(stagedRecord)
        || stagedRecord.type !== 'agent'
        || String(stagedRecord.repoName || '') !== String(record.repoName || '')
        || String(stagedRecord.agentName || '') !== String(record.agentName || '')
        || String(stagedRecord.alias || '') !== String(record.alias || '')
        || String(stagedRecord.instanceId || '') !== String(record.instanceId || '')
        || String(stagedRecord.enableGeneration || '') !== String(record.enableGeneration || '')) {
        throw new Error(`watchdog runtime replacement requires its exact staged registry record for '${containerName}'`);
    }
    if (!result.preparationLease) {
        throw new Error('watchdog runtime replacement requires its exact preparation lease');
    }
    if (containerName !== targetContainerName
        && (!replacementPredecessor?.containerId
            || String(replacementPredecessor.registryRecord?.repoName || '') !== String(target.repoName || '')
            || String(replacementPredecessor.registryRecord?.agentName || '') !== String(target.agentName || '')
            || String(replacementPredecessor.registryRecord?.alias || '') !== String(target.alias || ''))) {
        throw new Error(`watchdog distinct replacement requires the exact predecessor identity for '${targetContainerName}'`);
    }
    return { containerName, record, stagedRecord };
}

function preActivationRegistryRecord(result, attempt = null) {
    if (result?.preparationLease?.mode === 'additive') {
        return attempt?.snapshot?.registryRecord || null;
    }
    return result?.requiresEdgeActivation === true
        ? result?.stagedRegistryRecord || null
        : result?.registryRecord || null;
}

function rekeyOwnedRestartTarget(monitor, target, attempt, result, expectedRegistryRecord) {
    if (!attempt || result?.requiresEdgeActivation !== true
        || !result.preparationLease || result.preparationLease.mode === 'additive') return false;
    const predecessorName = attempt.snapshot.info.containerName;
    const prepared = assertRestartPreparationResult({ ...target, containerName: predecessorName }, result);
    const candidateName = prepared.containerName;
    if (candidateName !== predecessorName) {
        const predecessor = result.replacementPredecessor;
        const original = attempt.snapshot.registryRecord;
        if (String(predecessor.registryRecord.instanceId || '') !== String(original.instanceId || '')
            || String(predecessor.registryRecord.enableGeneration || '') !== String(original.enableGeneration || '')
            || String(predecessor.registryRecord.containerId || '') !== String(predecessor.containerId || '')
            || (original.containerId && String(original.containerId) !== String(predecessor.containerId || ''))
            || digestValue(predecessor.runtimeNetwork || null) !== digestValue(attempt.snapshot.profileResolution.network)) {
            throw new Error('watchdog replacement predecessor differs from its immutable restart attempt');
        }
        const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
        if (loadAgents()?.[predecessorName] !== undefined
            || (monitor.targets.has(candidateName) && monitor.targets.get(candidateName) !== target)) {
            const error = new Error('watchdog replacement identity changed before target rekey');
            error.code = 'PLOINKY_RESTART_ATTEMPT_STALE';
            throw error;
        }
    }
    assertRestartAttemptCurrent(monitor, target, attempt, 'pre-target-rekey', {
        expectedRegistryRecord,
        expectedContainerName: candidateName,
    });
    if (target.containerName !== candidateName) {
        monitor.targets.delete(target.containerName);
        target.containerName = candidateName;
        monitor.targets.set(candidateName, target);
        monitor.runtimeSnapshotTakenAt = 0;
    }
    // Only the index changes while readiness is in flight. The original
    // immutable attempt remains authoritative at every lifecycle checkpoint;
    // sync now sees isRestarting on this same target instead of starting a
    // second watch with an empty retry history for the staged registry key.
    return true;
}

function refreshFailedRestartInput(monitor, target, record) {
    const readRouting = monitor.readRoutingConfig || readRoutingConfig;
    const info = {
        containerName: target.containerName,
        agentName: target.agentName,
        repoName: target.repoName,
        alias: record.alias || null,
        profile: record.profile || null,
        runtime: record.runtime || 'container',
        instanceId: String(record.instanceId || '').trim() || null,
        enableGeneration: String(record.enableGeneration || '').trim() || null,
        manifestPath: target.manifestPath,
        routing: readRouting(),
    };
    const input = resolveWatchdogRestartInput(record, info, monitor);
    if (!input) throw new Error('watchdog failed replacement no longer has a monitored runtime');
    target.alias = info.alias;
    target.profile = info.profile;
    target.runtime = info.runtime;
    target.instanceId = info.instanceId;
    target.enableGeneration = info.enableGeneration;
    target.restartInputDigest = input.restartInputDigest;
    target.runtimeAdmission = input.runtimeAdmission;
    target.restartSnapshot = input.restartSnapshot;
    stopProbeWorker(target);
    target.probeState = 'pending';
    target.probeLastSuccessAt = null;
}

function quarantineFailedRuntimeIdentityRotation(monitor, target, attempt, failure, rotation) {
    if (!attempt) throw failure;
    const original = attempt.snapshot.registryRecord;
    const predecessorName = attempt.snapshot.info.containerName;
    const candidateName = rotation.containerName;
    const staged = rotation.stagedRegistryRecord;
    const network = rotation.runtimeNetwork || attempt.snapshot.profileResolution.network;
    const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
    if (target.containerName !== predecessorName
        || rotation.predecessorContainerName !== predecessorName
        || digestValue(rotation.predecessorRegistryRecord) !== digestValue(original)
        || !staged?.instanceId || !staged.enableGeneration
        || digestValue(staged) !== digestValue({
            ...original,
            instanceId: staged.instanceId,
            enableGeneration: staged.enableGeneration,
        })
        || digestValue(network) !== digestValue(attempt.snapshot.profileResolution.network)
        || (original.containerId && String(original.containerId) !== String(rotation.predecessorContainerId || ''))
        || (candidateName !== predecessorName && loadAgents()?.[predecessorName] !== undefined)
        || (monitor.targets.has(candidateName) && monitor.targets.get(candidateName) !== target)) {
        const error = new Error('watchdog failed identity rotation no longer matches its exact immutable attempt');
        error.code = 'PLOINKY_RESTART_ATTEMPT_STALE';
        throw error;
    }
    assertRestartAttemptCurrent(monitor, target, attempt, 'pre-unprepared-rotation-quarantine', {
        expectedRegistryRecord: staged,
        expectedContainerName: candidateName,
    });
    if (target.containerName !== candidateName) {
        monitor.targets.delete(target.containerName);
        target.containerName = candidateName;
        monitor.targets.set(candidateName, target);
        monitor.runtimeSnapshotTakenAt = 0;
    }
    refreshFailedRestartInput(monitor, target, staged);
    const error = new Error('watchdog runtime identity was staged but preparation failed before launch; explicit reconciliation is required', { cause: failure });
    error.code = 'PLOINKY_RUNTIME_PREPARATION_REQUIRED';
    const cleanupEvidence = Object.freeze({
        ...runtimeCleanupFailureEvidence({
            containerName: candidateName,
            // The staged record can still contain the predecessor's ID. No
            // new physical candidate exists at this coordinator boundary.
            containerId: null,
            registryRecord: staged,
            runtimeNetwork: network,
            replacementPredecessor: {
                containerName: predecessorName,
                containerId: rotation.predecessorContainerId || null,
                registryRecord: original,
                runtimeNetwork: network,
            },
        }),
        launchAttempted: false,
        preparationPhase: rotation.phase,
    });
    Object.defineProperty(error, 'ploinkyCleanupEvidence', { value: cleanupEvidence });
    // A provenance-bound failed write is evidence for quarantine only. It is
    // not a preparation lease or cleanup receipt, and never authorizes abort,
    // predecessor restoration, or removal of either physical runtime.
    target.terminalState = recordTerminalFailure(monitor, target, error, target.restartInputDigest);
    target.circuitBreakerTripped = true;
    target.lastError = error.message;
    logEvent(monitor, 'error', 'container_restart_preparation_failed_before_launch', {
        container: candidateName,
        agent: target.agentName,
        repo: target.repoName,
        code: error.code,
        cleanupEvidence,
        error: failure?.message || failure,
    });
    LOGGED_RESTART_FAILURES.add(error);
    throw error;
}

function retainFailedRestartPreparation(monitor, target, result, failure) {
    const retainedResult = { ...result };
    for (const field of ['registryRecord', 'stagedRegistryRecord', 'runtimeNetwork', 'replacementPredecessor']) {
        if (retainedResult[field]) retainedResult[field] = deepFreezeSnapshot(structuredClone(retainedResult[field]));
    }
    // These capabilities are provenance-bound, not serializable documents.
    // Preserve the original preparationLease and cleanupReceipt references;
    // cloning a field-identical receipt does not authorize exact cleanup.
    target.pendingRestartPreparation = Object.freeze({
        result: Object.freeze(retainedResult),
        failure,
        restartInputDigest: target.restartInputDigest,
    });
    logEvent(monitor, 'error', 'container_restart_preparation_retained', {
        ...runtimeCleanupEvidence(retainedResult),
        container: retainedResult.containerName,
        predecessor: runtimeCleanupEvidence(retainedResult.replacementPredecessor),
        code: failure?.code || null,
    });
}

async function retryFailedRestartPreparation(monitor, target, reason, assertCurrent) {
    const pending = target.pendingRestartPreparation;
    if (!pending || pending.restartInputDigest !== target.restartInputDigest) return;
    assertCurrent();
    // Cleanup may have consumed its one-shot receipt before physical removal
    // failed. Keep the evidence, but never retry that capability or launch a
    // further candidate automatically after ownership becomes ambiguous.
    if (pending.result.candidateCleanupFailed === true) throw pending.failure;
    try {
        await abortFailedRestartPreparation(monitor, target, pending.result, reason, pending.failure);
    } catch (error) {
        retainFailedRestartPreparation(monitor, target, error.ploinkyRestartCandidate || pending.result, error);
        throw error;
    }
    target.pendingRestartPreparation = null;
    if (pending.result.preparationLease?.mode !== 'additive' && pending.result.replacementPredecessor) {
        target.pendingPredecessorRetirement = Object.freeze({
            predecessor: pending.result.replacementPredecessor,
            restartInputDigest: target.restartInputDigest,
        });
    }
    // The completed candidate cleanup must not be repeated if this check
    // detects drift. Its separately retained predecessor remains fenced by
    // the original input digest and inactive, unregistered identity checks.
    assertCurrent();
}

async function retryFailedPredecessorRetirement(monitor, target, networkLifecycleCapability, assertCurrent) {
    const pending = target.pendingPredecessorRetirement;
    if (!pending) return;
    // An external replacement must not inherit either this cleanup authority
    // or the failed attempt's retry budget. The logged immutable receipt
    // remains available for explicit reconciliation if the input changed.
    if (pending.restartInputDigest !== target.restartInputDigest) return;
    // A published successor stays active. This is terminal reconciliation
    // evidence, not permission to run inactive-generation recovery against it.
    if (pending.publicationCommitted === true) throw pending.failure;
    const predecessor = pending.predecessor;
    const readSelection = monitor.readEdgeRoutingSelection || readEdgeRoutingSelection;
    const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
    assertCurrent();
    if (readSelection()?.selector?.state !== 'inactive'
        || loadAgents()?.[predecessor.containerName] !== undefined) {
        const error = new Error('watchdog failed predecessor is no longer revoked and unregistered');
        error.code = 'PLOINKY_RESTART_ATTEMPT_STALE';
        throw error;
    }
    const retire = monitor.retireExactAgentRuntimePredecessor || retireExactAgentRuntimePredecessor;
    try {
        await Promise.resolve(retire(predecessor, { networkLifecycleCapability }));
        target.pendingPredecessorRetirement = null;
    } catch (cause) {
        // Preserve the exact receipt before surfacing a failed cleanup. The
        // next attempt retries it before it may create another replacement.
        logEvent(monitor, 'error', 'container_restart_predecessor_retirement_failed', {
            container: predecessor.containerName,
            containerId: predecessor.containerId,
            replacement: target.containerName,
            runtimeNetwork: predecessor.runtimeNetwork,
            identity: {
                repoName: predecessor.registryRecord.repoName,
                agentName: predecessor.registryRecord.agentName,
                alias: predecessor.registryRecord.alias || null,
                instanceId: predecessor.registryRecord.instanceId,
                enableGeneration: predecessor.registryRecord.enableGeneration,
            },
            error: cause?.message || cause,
        });
        const error = new Error('watchdog could not retire its exact revoked predecessor; preserving its cleanup receipt', { cause });
        error.code = 'PLOINKY_RECOVERY_PREDECESSOR_RETIREMENT_FAILED';
        throw error;
    }
}

async function waitForRestartedContainerReadiness(
    monitor,
    target,
    manifest,
    result,
    networkMode = '',
) {
    const resolveProtocol = monitor.resolveAgentReadinessProtocol || resolveAgentReadinessProtocol;
    const protocol = resolveProtocol(manifest);
    if (protocol === 'none') return;
    if (protocol === 'script') {
        const runScript = monitor.runContainerScriptReadiness || runContainerScriptReadiness;
        const probe = await Promise.resolve(runScript(
            target.agentName,
            result.containerName,
            manifest?.health?.readiness,
        ));
        if (probe?.status !== 'success') {
            const detail = probe?.detail ? `, output='${probe.detail}'` : '';
            throw new Error(`watchdog readiness script failed (${probe?.reason || 'unknown failure'}${detail})`);
        }
        return;
    }
    if (protocol !== 'tcp' && protocol !== 'mcp') {
        throw new Error(`watchdog resolved unsupported readiness protocol '${protocol}'`);
    }
    const readinessRoute = buildRelayReadinessRoute({
        route: {
            hostPort: Number(result.hostPort || 0),
        },
        manifest,
        runtimeResult: result,
        networkMode,
        generationDigest: result?.preparationLease?.preparedGeneration || '',
    });
    if (!readinessRoute.hostPort && !readinessRoute.relay) {
        throw new Error(`watchdog readiness protocol '${protocol}' requires one resolved private target or readiness.port`);
    }
    const waitUntilReady = monitor.waitForAgentReady || waitForAgentReady;
    const ready = await waitUntilReady(readinessRoute, {
        ...resolveManifestReadinessWaitOptions(manifest, 120000, {
            timeoutMs: monitor?.config?.CONTAINER_RESTART_READY_TIMEOUT_MS
                ?? process.env.PLOINKY_CONTAINER_MONITOR_READY_TIMEOUT_MS,
            intervalMs: monitor?.config?.CONTAINER_RESTART_READY_INTERVAL_MS
                ?? process.env.PLOINKY_CONTAINER_MONITOR_READY_INTERVAL_MS,
            probeTimeoutMs: monitor?.config?.CONTAINER_RESTART_READY_PROBE_TIMEOUT_MS
                ?? process.env.PLOINKY_CONTAINER_MONITOR_READY_PROBE_TIMEOUT_MS,
        }),
        protocol,
    });
    if (!ready) {
        throw new Error(`watchdog readiness protocol '${protocol}' did not succeed`);
    }
}

function publishedPredecessorCleanupFailure(monitor, target, result, cause) {
    const cleanupEvidence = runtimeCleanupFailureEvidence(result, true);
    const evidence = cleanupEvidence.predecessor;
    const predecessor = deepFreezeSnapshot({
        containerName: evidence.containerName,
        containerId: evidence.containerId,
        runtimeNetwork: evidence.runtimeNetwork,
        registryRecord: { ...evidence.identity, containerId: evidence.containerId },
    });
    const error = new Error('watchdog activated its successor but could not retire the exact predecessor; explicit cleanup is required', { cause });
    error.code = 'PLOINKY_PREDECESSOR_CLEANUP_REQUIRED';
    Object.defineProperty(error, 'ploinkyCleanupEvidence', { value: cleanupEvidence });
    target.pendingPredecessorRetirement = Object.freeze({
        predecessor,
        publicationCommitted: true,
        failure: error,
        restartInputDigest: target.restartInputDigest,
    });
    logEvent(monitor, 'error', 'container_restart_predecessor_retirement_failed', {
        container: predecessor.containerName,
        containerId: predecessor.containerId,
        replacement: result.containerName,
        cleanupEvidence,
        error: cause?.message || cause,
    });
    return error;
}

async function activateRestartedContainerRoute(monitor, target, agentDir, result, networkMode, {
    assertCurrent = () => {},
    onRegistryCommitted = () => {},
    onCommitted = () => {},
    networkLifecycleCapability = null,
} = {}) {
    const prepared = assertRestartPreparationResult(target, result);
    if (!prepared) return false;
    const routeKey = target.alias || target.agentName;
    const route = {
        container: prepared.containerName,
        hostPath: agentDir,
        repo: target.repoName,
        agent: target.agentName,
        ...(target.alias ? { alias: target.alias } : {}),
        hostPort: networkMode === 'none' ? null : result.hostPort || null,
    };

    const mergeRoute = monitor.mergeRoutingConfig || mergeRoutingConfig;
    const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
    const saveAgents = monitor.saveAgents || workspaceSvc.saveAgents;
    const applyGeneration = monitor.applyEdgeRoutingGeneration || applyEdgeRoutingGeneration;
    const runWithApplyLock = monitor.withEdgeGenerationApplyLock
        || (monitor.applyEdgeRoutingGeneration
            ? (callback) => callback(Object.freeze({ testOnly: true }))
            : withEdgeGenerationApplyLock);
    const retirePredecessor = monitor.retireExactAgentRuntimePredecessor
        || retireExactAgentRuntimePredecessor;
    if (result.preparationLease?.mode === 'additive') {
        const readRouting = monitor.readRoutingConfig || readRoutingConfig;
        const commitAdditive = monitor.commitAdditiveEdgeRoutingGeneration
            || commitAdditiveEdgeRoutingGeneration;
        const predecessorName = String(result.replacementPredecessor?.containerName || '');
        if (!predecessorName || predecessorName === prepared.containerName) {
            throw new Error(`watchdog additive replacement requires one distinct exact predecessor for '${prepared.containerName}'`);
        }
        await runWithApplyLock(async (applyLockCapability) => {
            assertCurrent('additive-route-registry-commit', result.replacementPredecessor.registryRecord);
            const agents = loadAgents();
            const predecessor = agents?.[predecessorName];
            if (!predecessor || predecessor.type !== 'agent'
                || digestValue(predecessor) !== digestValue(result.replacementPredecessor.registryRecord)) {
                throw new Error(`watchdog additive replacement lost its active predecessor registry identity for '${predecessorName}'`);
            }
            delete agents[predecessorName];
            agents[prepared.containerName] = structuredClone(prepared.record);
            const routing = readRouting();
            routing.routes = routing.routes || {};
            for (const currentRoute of Object.values(routing.routes)) {
                if (currentRoute && currentRoute.container === predecessorName) {
                    currentRoute.container = prepared.containerName;
                }
            }
            routing.routes[routeKey] = mergeRuntimeRoute(
                routing.routes[routeKey],
                route,
                { hostPort: route.hostPort },
            );
            await Promise.resolve(commitAdditive(result.preparationLease, {
                agents,
                routing,
                applyLockCapability,
            }));
            onRegistryCommitted();
            onCommitted();
        }, { preparationLease: result.preparationLease });
        try {
            await Promise.resolve(retirePredecessor(result.replacementPredecessor, {
                networkLifecycleCapability,
            }));
        } catch (error) {
            throw publishedPredecessorCleanupFailure(monitor, target, result, error);
        }
        return true;
    }
    await runWithApplyLock(async (applyLockCapability) => {
        await mergeRoute((cfg) => {
            assertCurrent('route-registry-commit', prepared.stagedRecord);
            const agents = loadAgents();
            const staged = agents?.[prepared.containerName];
            if (!staged || staged.type !== 'agent'
                || digestValue(staged) !== digestValue(prepared.stagedRecord)) {
                throw new Error(`watchdog runtime replacement lost its staged registry identity for '${prepared.containerName}'`);
            }
            agents[prepared.containerName] = structuredClone(prepared.record);
            saveAgents(agents, { coordinate: false });
            onRegistryCommitted();
            cfg.routes = cfg.routes || {};
            cfg.routes[routeKey] = mergeRuntimeRoute(
                cfg.routes[routeKey],
                route,
                { hostPort: route.hostPort },
            );
            return cfg;
        }, { coordinate: false });

        await Promise.resolve(applyGeneration({
            reason: `watchdog-runtime-ready:${routeKey}`,
            preparationLease: result.preparationLease,
            applyLockCapability,
            testHooks: {
                beforeSelectorCommit() {
                    assertCurrent('selector-commit', prepared.record);
                },
            },
        }));
        onCommitted();
    }, { preparationLease: result.preparationLease });
    if (result.replacementPredecessor
        && String(result.replacementPredecessor.containerName || '') !== prepared.containerName) {
        try {
            await Promise.resolve(retirePredecessor(result.replacementPredecessor, {
                networkLifecycleCapability,
            }));
        } catch (error) {
            throw publishedPredecessorCleanupFailure(monitor, target, result, error);
        }
    }
    return true;
}

async function abortFailedRestartPreparation(monitor, target, result, reason, originalFailure) {
    if (result?.preparationLease) {
        const abortPreparation = monitor.abortEdgeRoutingPreparation || abortEdgeRoutingPreparation;
        try {
            await Promise.resolve(abortPreparation(result.preparationLease, {
                reason: `watchdog-runtime-failed:${reason}`,
            }));
        } catch (error) {
            logEvent(monitor, 'error', 'container_restart_preparation_abort_failed', {
                container: result.containerName || target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                error: error?.message || error,
            });
            const recoveryError = new Error(
                `watchdog recovery could not abort the exact edge preparation for '${result.containerName || target.containerName}'; preserving its failed runtime candidate: ${error?.message || error}`,
                { cause: error },
            );
            recoveryError.code = 'PLOINKY_RECOVERY_ABORT_FAILED';
            Object.defineProperty(recoveryError, 'originalFailure', {
                configurable: false,
                enumerable: false,
                writable: false,
                value: originalFailure,
            });
            Object.defineProperty(recoveryError, 'ploinkyRestartCandidate', {
                configurable: false,
                enumerable: false,
                writable: false,
                value: Object.freeze({
                    ...result,
                    exactCleanupPerformed: result.exactCleanupPerformed === true,
                    preparationAbortFailed: true,
                    preparationAbortedBeforeCleanup: false,
                }),
            });
            throw recoveryError;
        }
    }
    if (result?.requiresEdgeActivation === true && result?.exactCleanupPerformed !== true) {
        const cleanupCandidate = monitor.cleanupExactAgentRuntimeCandidate
            || cleanupExactAgentRuntimeCandidate;
        try {
            await Promise.resolve(cleanupCandidate(result));
        } catch (cause) {
            logEvent(monitor, 'error', 'container_restart_candidate_cleanup_failed', {
                container: result.containerName || target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                error: cause?.message || cause,
            });
            const error = new Error('watchdog could not prove exact candidate cleanup; preserving its runtime ownership evidence for reconciliation', { cause });
            error.code = 'PLOINKY_RUNTIME_OWNERSHIP_AMBIGUOUS';
            Object.defineProperty(error, 'originalFailure', { value: originalFailure });
            Object.defineProperty(error, 'ploinkyCleanupEvidence', { value: runtimeCleanupFailureEvidence(result) });
            Object.defineProperty(error, 'ploinkyRestartCandidate', {
                value: Object.freeze({
                    ...result,
                    exactCleanupPerformed: false,
                    preparationAbortFailed: false,
                    preparationAbortedBeforeCleanup: Boolean(result.preparationLease),
                    candidateCleanupFailed: true,
                }),
            });
            throw error;
        }
    }
}

export async function performContainerRestart(monitor, target, reason, attempt = null) {
    if (!monitor || !target) return;
    if (!attempt && target.restartInputDigest && target.restartSnapshot) {
        attempt = Object.freeze({
            target,
            epoch: target.attemptEpoch,
            digest: target.restartInputDigest,
            snapshot: target.restartSnapshot,
        });
    }
    assertRestartAttemptCurrent(monitor, target, attempt, 'pre-mutation-lock');
    if (monitor.isShuttingDown()) {
        target.isRestarting = false;
        return;
    }
    if (inspectWorkspaceStartLock().active) {
        target.isRestarting = false;
        logEvent(monitor, 'info', 'container_restart_deferred_workspace_start', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
        });
        return;
    }

    // A restart timer may have been scheduled immediately before a CLI
    // maintenance operation acquired its lock. Recheck at execution time so
    // the stale timer cannot race reinstall/restart staging.
    if (shouldDeferMaintenanceRestart(monitor, target)) {
        target.isRestarting = false;
        return;
    }

    if (target.type !== 'agent') {
        logEvent(monitor, 'warn', 'container_restart_skipped_type', {
            container: target.containerName,
            type: target.type
        });
        target.isRestarting = false;
        return;
    }

    const acquireWorkspaceLease = monitor.createWorkspaceMutationLease || createWorkspaceMutationLease;
    const releaseWorkspaceLease = monitor.releaseWorkspaceMutationLease || releaseWorkspaceMutationLease;
    let workspaceLease;
    try {
        workspaceLease = acquireWorkspaceLease({ operation: `watchdog-restart:${target.containerName}` });
    } catch (error) {
        if (error?.code === 'PLOINKY_WORKSPACE_MUTATION_BUSY') {
            target.isRestarting = false;
            logEvent(monitor, 'info', 'container_restart_deferred_workspace_start', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName,
            });
            return;
        }
        target.isRestarting = false;
        throw error;
    }

    const runNetworkLifecycle = monitor.withNetworkLifecycleLock || withNetworkLifecycleLock;
    try {
        // Only a workspace start writes or consumes a predecessor receipt, and
        // it holds this lease to do so. The pre-physical-ensure check below
        // proves the live record still equals the attempt's snapshot.
        const loadAgents = monitor.loadAgents || workspaceSvc.loadAgents;
        const restartRecord = attempt
            ? attempt.snapshot.registryRecord
            : loadAgents()?.[target.containerName];
        if (shouldDeferForStartPredecessor(monitor, target, restartRecord)) {
            target.isRestarting = false;
            return;
        }
        // Dependency preparation inside this restart reuses its lease. A
        // concurrent Router operation (a disable, a publication) cannot.
        await runWithWorkspaceMutationLease(workspaceLease, () => runNetworkLifecycle(async (networkLifecycleCapability) => {
        let result = null;
        let activationCommitted = false;
        let registryCandidateCommitted = false;
        let ownedCandidate = false;
        let retryingPreparation = false;
        let noWaitLineage = null;
        try {
        assertRestartAttemptCurrent(monitor, target, attempt, 'pre-physical-ensure');
        retryingPreparation = true;
        await retryFailedRestartPreparation(monitor, target, reason, () => {
            assertRestartAttemptCurrent(monitor, target, attempt, 'pre-pending-preparation-cleanup');
        });
        retryingPreparation = false;
        await retryFailedPredecessorRetirement(monitor, target, networkLifecycleCapability, () => {
            assertRestartAttemptCurrent(monitor, target, attempt, 'pre-pending-predecessor-retirement');
        });
        let manifestBytes;
        let manifest;
        try {
            manifestBytes = fs.readFileSync(target.manifestPath);
            manifest = JSON.parse(manifestBytes.toString('utf8') || '{}');
        } catch (error) {
            target.circuitBreakerTripped = true;
            target.lastError = error?.message || error;
            logEvent(monitor, 'error', fs.existsSync(target.manifestPath)
                ? 'container_manifest_parse_error'
                : 'container_manifest_missing', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                manifest: target.manifestPath,
                error: target.lastError,
            });
            target.isRestarting = false;
            return;
        }
        const assertManifestUnchanged = () => {
            let current;
            try {
                current = fs.readFileSync(target.manifestPath);
            } catch (error) {
                const changed = new Error(`watchdog manifest changed or disappeared during restart: ${error?.message || error}`);
                changed.code = 'PLOINKY_RESTART_MANIFEST_CHANGED';
                throw changed;
            }
            if (!current.equals(manifestBytes)) {
                const changed = new Error('watchdog manifest bytes changed during restart; a fresh replacement is required');
                changed.code = 'PLOINKY_RESTART_MANIFEST_CHANGED';
                throw changed;
            }
        };
        const resolveRuntimeProfile = monitor.resolveManifestRuntimeProfile || resolveManifestRuntimeProfile;
        const profileResolution = resolveRuntimeProfile(manifest, {
            agentName: `${target.repoName}/${target.agentName}`,
            profileName: target.profile || undefined,
            path: `manifest(${target.repoName}/${target.agentName})`,
        });
        const resolveEndpoint = monitor.resolveRouterEndpoint || resolveRouterEndpoint;
        const routerEndpoint = resolveEndpoint(profileResolution.network.mode);
        const agentDir = path.dirname(target.manifestPath);
        const ensureAgentServiceImpl = monitor.ensureAgentService || ensureAgentService;
        const readEdgeSelection = monitor.readEdgeRoutingSelection || readEdgeRoutingSelection;
        // Only managed networks can stage a distinct runtime while its
        // predecessor remains authorized. Host/none recovery replaces the
        // same runtime name and must revoke the old identity first, under the
        // replacement coordinator's lifecycle and generation locks.
        const canStageReplacement = profileResolution.network.mode === 'default'
            || profileResolution.network.mode === 'bridge';
        const preserveActiveAuthorization = canStageReplacement
            && readEdgeSelection().selector.state === 'active';
        if (target.runtimeAdmission) {
            assertRuntimeAdmissionCurrent(target.runtimeAdmission, {
                manifestBytes,
                profileName: profileResolution.resolvedProfileName,
                runtimeKind: target.runtime === 'bwrap' || target.runtime === 'seatbelt'
                    ? target.runtime
                    : 'container',
            });
        }
        noWaitLineage = captureNoWaitRebindLineage(monitor, target, restartRecord);
        result = await Promise.resolve(ensureAgentServiceImpl(target.agentName, manifest, agentDir, {
            hardwareInstanceKey: target.containerName,
            containerName: target.containerName,
            commandHint: `ploinky restart ${target.alias || target.agentName}`,
            networkLockWaitMs: 0,
            profileName: profileResolution.resolvedProfileName,
            profileResolution,
            routerEndpoint,
            forceRecreate: reason === 'semantic_probe_failed' || reason === 'mps_generation_changed',
            forceRecreateReason: `monitor restart (${reason})`,
            // The registry record captured with this restart attempt is the
            // only runtime it may replace.
            expectedPredecessor: registeredRuntimeTuple(restartRecord),
            preserveActiveAuthorization,
            networkLifecycleCapability,
            runtimeAdmission: target.runtimeAdmission,
        }));
        assertRestartAttemptCurrent(monitor, target, attempt, 'post-physical-ensure', {
            expectedRegistryRecord: preActivationRegistryRecord(result, attempt),
            expectedContainerName: result?.preparationLease?.mode === 'additive'
                ? target.containerName
                : result?.containerName,
        });
        // Preparation rereads the manifest for generation capture, while the
        // physical launch consumes the object above. Exact-byte comparisons on
        // both sides of semantic readiness prevent those inputs from diverging.
        assertManifestUnchanged();

        const prepared = assertRestartPreparationResult(target, result);
        if (!prepared) {
            target.lastSeenRunningAt = Date.now();
            target.currentBackoff = monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
            target.lastError = null;
            logEvent(monitor, 'info', 'container_restart_reused_running', {
                container: result?.containerName || target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                reason,
            });
            target.isRestarting = false;
            return;
        }
        ownedCandidate = rekeyOwnedRestartTarget(
            monitor, target, attempt, result, preActivationRegistryRecord(result, attempt),
        );

        await waitForRestartedContainerReadiness(
            monitor,
            target,
            manifest,
            result,
            profileResolution.network.mode,
        );
        assertRestartAttemptCurrent(monitor, target, attempt, 'post-readiness', {
            expectedRegistryRecord: preActivationRegistryRecord(result, attempt),
            expectedContainerName: result?.preparationLease?.mode === 'additive'
                ? target.containerName
                : result?.containerName,
        });
        assertManifestUnchanged();
        assertRestartAttemptCurrent(monitor, target, attempt, 'pre-route-activation', {
            expectedRegistryRecord: preActivationRegistryRecord(result, attempt),
            expectedContainerName: result?.preparationLease?.mode === 'additive'
                ? target.containerName
                : result?.containerName,
        });
        try {
        await activateRestartedContainerRoute(
            monitor,
            target,
            agentDir,
            result,
            profileResolution.network.mode,
            {
                networkLifecycleCapability,
                assertCurrent(checkpoint, expectedRegistryRecord) {
                    assertRestartAttemptCurrent(monitor, target, attempt, checkpoint, {
                        expectedRegistryRecord,
                        expectedContainerName: result?.preparationLease?.mode === 'additive'
                            ? target.containerName
                            : result?.containerName,
                    });
                    assertManifestUnchanged();
                },
                onRegistryCommitted() {
                    registryCandidateCommitted = true;
                },
                onCommitted() {
                    activationCommitted = true;
                    target.instanceId = String(result?.registryRecord?.instanceId || '') || null;
                    target.enableGeneration = String(result?.registryRecord?.enableGeneration || '') || null;

                    if (prepared.containerName !== target.containerName) {
                        const oldName = target.containerName;
                        monitor.targets.delete(oldName);
                        target.containerName = prepared.containerName;
                        monitor.targets.set(target.containerName, target);
                        monitor.runtimeSnapshotTakenAt = 0;
                    }

                    stopProbeWorker(target);
                    target.probeState = 'pending';

                    const now = Date.now();
                    target.lastStartTime = now;
                    target.lastSeenRunningAt = now;
                    target.currentBackoff = monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
                    target.circuitBreakerTripped = false;
                    target.lastError = null;
                },
            },
        );
        } finally {
            // Once committed, the replacement serves the deployment run its
            // predecessor belonged to, even if predecessor cleanup failed.
            if (activationCommitted && noWaitLineage) {
                await rebindNoWaitRunAfterReplacement(monitor, target, noWaitLineage, {
                    committedName: prepared.containerName,
                    committedRecord: prepared.record,
                    hostPort: profileResolution.network.mode === 'none' ? null : result?.hostPort,
                    agentDir,
                });
            }
        }

        logEvent(monitor, 'info', 'container_restart_success', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            reason
        });
        } catch (error) {
        const failedRotation = getFailedRuntimeIdentityRotation(error);
        if (failedRotation) {
            try {
                quarantineFailedRuntimeIdentityRotation(monitor, target, attempt, error, failedRotation);
            } finally {
                target.isRestarting = false;
            }
        }
        // A retained transaction has already handled its exact abort/cleanup.
        // Its failure must not be processed again as a newly launched result.
        const failedResult = retryingPreparation ? null : result || error?.ploinkyRestartCandidate || null;
        // The launching operation is over: a GPU share or share-less readiness
        // owner must not stay live in this process (the failure counterpart of
        // acknowledging readiness).
        releaseMpsRuntimeOwner(failedResult);
        const expectedRegistryRecord = registryCandidateCommitted
            ? failedResult?.registryRecord || null
            : preActivationRegistryRecord(failedResult, attempt);
        const expectedContainerName = failedResult?.preparationLease?.mode === 'additive'
            && !registryCandidateCommitted
            ? target.containerName
            : failedResult?.containerName;
        let surfacedError = error;
        let preparationAborted = false;
        if (!activationCommitted && !ownedCandidate) {
            try {
                ownedCandidate = rekeyOwnedRestartTarget(
                    monitor, target, attempt, failedResult, expectedRegistryRecord,
                );
            } catch (_) {
                // Cleanup still owns its exact launch receipt after external
                // drift. The existing failure checkpoint below rejects stale
                // registry/manifest state before any target can adopt it.
            }
        }
        if (!activationCommitted) {
            try {
                await abortFailedRestartPreparation(monitor, target, failedResult, reason, error);
                preparationAborted = Boolean(failedResult?.preparationLease);
            } catch (recoveryError) {
                surfacedError = recoveryError;
            }
        }
        const assertFailureCurrent = () => assertRestartAttemptCurrent(
            monitor, target, attempt, 'pre-failure-record', {
                expectedRegistryRecord,
                expectedContainerName,
            },
        );
        assertFailureCurrent();
        const recoveryCandidate = surfacedError?.ploinkyRestartCandidate;
        if (!activationCommitted && !retryingPreparation && attempt
            && (recoveryCandidate?.preparationAbortFailed || recoveryCandidate?.candidateCleanupFailed)
            && (ownedCandidate || (failedResult?.preparationLease?.mode === 'additive'
                && assertRestartPreparationResult(target, failedResult)))) {
            retainFailedRestartPreparation(monitor, target, recoveryCandidate, surfacedError);
        }
        if (!activationCommitted && ownedCandidate) {
            if (preparationAborted && failedResult.replacementPredecessor) {
                target.pendingPredecessorRetirement = deepFreezeSnapshot({
                    predecessor: structuredClone(failedResult.replacementPredecessor),
                    restartInputDigest: target.restartInputDigest,
                });
                try {
                    await retryFailedPredecessorRetirement(
                        monitor, target, networkLifecycleCapability, assertFailureCurrent,
                    );
                } catch (recoveryError) {
                    surfacedError = recoveryError;
                }
            }
        }
        const publishedCleanupRequired = activationCommitted
            && surfacedError?.code === 'PLOINKY_PREDECESSOR_CLEANUP_REQUIRED';
        if ((!activationCommitted && ownedCandidate) || publishedCleanupRequired) {
            assertFailureCurrent();
            refreshFailedRestartInput(monitor, target, expectedRegistryRecord);
            if (attempt && target.pendingRestartPreparation?.restartInputDigest === attempt.digest) {
                target.pendingRestartPreparation = Object.freeze({
                    ...target.pendingRestartPreparation,
                    restartInputDigest: target.restartInputDigest,
                });
            }
            if (attempt && target.pendingPredecessorRetirement?.restartInputDigest === attempt.digest) {
                target.pendingPredecessorRetirement = Object.freeze({
                    ...target.pendingPredecessorRetirement,
                    restartInputDigest: target.restartInputDigest,
                });
            }
            // Retain the run this attempt captured (its coordinator may have
            // retired the marker) for the retry, bound to exactly the registry
            // tuple the failed attempt left.
            const retainedLineage = noWaitLineage
                || (attempt && target.pendingNoWaitRebind?.restartInputDigest === attempt.digest
                    ? target.pendingNoWaitRebind.lineage
                    : null);
            target.pendingNoWaitRebind = !activationCommitted && retainedLineage
                ? Object.freeze({
                    lineage: retainedLineage,
                    restartInputDigest: target.restartInputDigest,
                    registryDigest: digestValue(expectedRegistryRecord),
                })
                : null;
        }
        if (publishedCleanupRequired) {
            // Persist the sanitized immutable predecessor evidence while the
            // exact committed successor is still fenced. Never abort its
            // successful publication or let a cleanup failure restart it.
            target.terminalState = recordTerminalFailure(monitor, target, surfacedError, target.restartInputDigest);
            target.circuitBreakerTripped = true;
        }
        target.lastError = surfacedError?.message || surfacedError;
        logEvent(monitor, 'error', 'container_restart_failed', {
            container: target.containerName,
            agent: target.agentName,
            repo: target.repoName,
            reason,
            error: target.lastError,
            code: surfacedError?.code || null,
        });
        if (surfacedError && typeof surfacedError === 'object') LOGGED_RESTART_FAILURES.add(surfacedError);
        target.isRestarting = false;
        throw surfacedError;
        }
        }));
    } finally {
        releaseWorkspaceLease(workspaceLease);
    }

    target.isRestarting = false;
}

export function snapshotRunningContainerNames(monitor) {
    if (![...monitor.targets.values()].some((target) => (
        target && !isSandboxRuntime(target.runtime)
    ))) {
        monitor.runtimeSnapshotFreshForTick = false;
        return null;
    }
    const now = typeof monitor.now === 'function' ? monitor.now() : Date.now();
    const configuredSnapshotInterval = Number(monitor?.config?.CONTAINER_SNAPSHOT_INTERVAL_MS);
    const snapshotIntervalMs = Number.isSafeInteger(configuredSnapshotInterval)
        && configuredSnapshotInterval >= 0
        ? configuredSnapshotInterval
        : 0;
    if (snapshotIntervalMs > 0
        && monitor.runtimeSnapshot instanceof Set
        && Number(monitor.runtimeSnapshotTakenAt || 0) > 0
        && now - monitor.runtimeSnapshotTakenAt < snapshotIntervalMs) {
        monitor.runtimeSnapshotFreshForTick = false;
        return monitor.runtimeSnapshot;
    }
    if (Number(monitor.runtimeSnapshotRetryNotBefore || 0) > now) {
        monitor.runtimeSnapshotFreshForTick = false;
        return null;
    }
    try {
        const listRunning = monitor.listRunningContainerNames || listRunningContainerNames;
        const runningContainerNames = new Set(listRunning());
        monitor.runtimeSnapshot = runningContainerNames;
        monitor.runtimeSnapshotTakenAt = now;
        const previousFailures = Number(monitor.runtimeSnapshotFailures || 0);
        monitor.runtimeSnapshotFailures = 0;
        monitor.runtimeSnapshotRetryNotBefore = 0;
        monitor.runtimeSnapshotFreshForTick = true;
        if (previousFailures > 0) {
            logEvent(monitor, 'info', 'container_status_snapshot_recovered', {
                previousFailures,
            });
        }
        return runningContainerNames;
    } catch (error) {
        const consecutiveFailures = Number(monitor.runtimeSnapshotFailures || 0) + 1;
        const initialRetryMs = positiveInteger(
            monitor?.config?.CONTAINER_SNAPSHOT_RETRY_INITIAL_MS,
            DEFAULT_CONTAINER_SNAPSHOT_RETRY_INITIAL_MS,
        );
        const maxRetryMs = positiveInteger(
            monitor?.config?.CONTAINER_SNAPSHOT_RETRY_MAX_MS,
            DEFAULT_CONTAINER_SNAPSHOT_RETRY_MAX_MS,
        );
        const retryAfterMs = Math.min(
            initialRetryMs * (2 ** Math.min(consecutiveFailures - 1, 20)),
            Math.max(initialRetryMs, maxRetryMs),
        );
        monitor.runtimeSnapshotFailures = consecutiveFailures;
        monitor.runtimeSnapshotRetryNotBefore = now + retryAfterMs;
        monitor.runtimeSnapshotFreshForTick = false;
        logEvent(monitor, 'error', 'container_status_snapshot_failed', {
            error: error?.message || error,
            consecutiveFailures,
            retryAfterMs,
        });
        return null;
    }
}

export function monitorTick(monitor) {
    if (!monitor || monitor.isShuttingDown()) return;

    const inspectStartLock = monitor.inspectWorkspaceStartLock || inspectWorkspaceStartLock;
    const workspaceStart = inspectStartLock();
    if (workspaceStart.stale) {
        logEvent(monitor, 'info', 'workspace_start_lock_removed', {
            operation: workspaceStart.lock?.operation || null,
            ownerPid: workspaceStart.lock?.ownerPid || null,
            expiresAt: workspaceStart.lock?.expiresAt || null,
        });
    }
    if (workspaceStart.active) {
        if (!monitor.workspaceStartDeferred) {
            monitor.workspaceStartDeferred = true;
            logEvent(monitor, 'info', 'container_monitor_deferred_workspace_start', {
                operation: workspaceStart.lock?.operation || null,
                ownerPid: workspaceStart.lock?.ownerPid || null,
                expiresAt: workspaceStart.lock?.expiresAt || null,
            });
        }
        return;
    }
    monitor.workspaceStartDeferred = false;

    const syncContainers = monitor.syncManagedContainers || syncManagedContainers;
    syncContainers(monitor);

    // Each semantic probe owns a bounded sequence of runtime inspect/exec
    // calls. Do not overlap the shared `podman ps` snapshot with that sequence:
    // nested rootless Podman has one practical control-plane lane, and
    // saturating it can interrupt otherwise healthy agent traffic. The next
    // five-second monitor tick resumes snapshots as soon as the worker exits.
    // Maintenance owns the stronger lifecycle contract and must still be able
    // to cancel a worker before snapshot serialization takes effect, and so
    // does a stopped start for a record it left to the next start.
    for (const target of monitor.targets.values()) {
        if (target?.probeWorker && !deferMonitorWorkForMaintenance(monitor, target)) {
            deferMonitorWorkForStartPredecessor(monitor, target);
        }
    }
    const activeWorkers = activeProbeWorkerCount(monitor);
    if (activeWorkers > 0) {
        if (!monitor.runtimeSnapshotProbeDeferred) {
            monitor.runtimeSnapshotProbeDeferred = true;
            logEvent(monitor, 'debug', 'container_status_snapshot_deferred_active_probe', {
                activeWorkers,
            });
        }
        return;
    }
    monitor.runtimeSnapshotProbeDeferred = false;

    const runningContainerNames = snapshotRunningContainerNames(monitor);

    for (const target of monitor.targets.values()) {
        if (!target || target.circuitBreakerTripped) continue;
        if (deferMonitorWorkForMaintenance(monitor, target)) continue;
        if (deferMonitorWorkForStartPredecessor(monitor, target)) continue;
        if (target.isRestarting || target.pendingRestartTimer) continue;

        let running = false;
        try {
            // A target whose record names no runtime ('container' is only the
            // default for that) is checked for a native owner of its exact
            // tuple first; only a verified absence leaves it a container.
            const namedNative = isSandboxRuntime(target.runtime);
            const unnamed = target.runtime === 'container' && Boolean(target.instanceId && target.enableGeneration);
            let nativeDecided = false;
            if (namedNative || unnamed) {
                nativeDecided = namedNative;
                if (target.instanceId && target.enableGeneration) {
                    const observeSandbox = monitor.observeSandboxRuntime || observeSandboxRuntime;
                    const observed = observeSandbox(target.containerName, {
                        expectedIdentity: {
                            instanceId: target.instanceId,
                            enableGeneration: target.enableGeneration,
                        },
                    });
                    if (observed.state === 'live-exact') {
                        running = true;
                        nativeDecided = true;
                    } else if (observed.state !== 'absent') {
                        // `unknown` is not absence, and a live foreign tuple
                        // means a newer owner holds the slot: a restart here
                        // would stop it or collide with it. Defer this tick.
                        const signature = `${observed.state}:${observed.reason}`;
                        if (target.sandboxObservationDeferred !== signature) {
                            target.sandboxObservationDeferred = signature;
                            logEvent(monitor, 'warn', 'container_restart_deferred_sandbox_observation', {
                                container: target.containerName,
                                agent: target.agentName,
                                repo: target.repoName,
                                state: observed.state,
                                reason: observed.reason,
                            });
                        }
                        continue;
                    }
                    target.sandboxObservationDeferred = null;
                }
            }
            if (nativeDecided) {
                // running was decided by the native observation above
            } else if (runningContainerNames) {
                if (runningContainerNames.has(target.containerName)) {
                    running = true;
                } else if (monitor.runtimeSnapshotFreshForTick === false) {
                    // Cached presence is still useful positive evidence, but
                    // cached absence says nothing about containers created
                    // after the snapshot. Only a runtime list collected by
                    // this tick may authorize a not_running restart.
                    continue;
                }
            } else {
                // A failed shared runtime snapshot means container state is
                // unknown. Defer this tick instead of multiplying the outage
                // into one blocking runtime call (or false restart) per target.
                continue;
            }
        } catch (error) {
            logEvent(monitor, 'error', 'container_status_check_failed', {
                container: target.containerName,
                agent: target.agentName,
                repo: target.repoName,
                error: error?.message || error
            });
        }

        if (running) {
            const now = Date.now();
            target.lastSeenRunningAt = now;
            if (!target.lastStartTime) target.lastStartTime = now;
            const resetAfter = 60000;
            if ((now - target.lastStartTime) > resetAfter && target.currentBackoff !== (monitor?.config?.INITIAL_BACKOFF_MS ?? 1000)) {
                target.currentBackoff = monitor?.config?.INITIAL_BACKOFF_MS ?? 1000;
                cleanRestartHistory(monitor, target);
                target.circuitBreakerTripped = false;
                logEvent(monitor, 'debug', 'container_backoff_reset', {
                    container: target.containerName,
                    agent: target.agentName,
                    repo: target.repoName
                });
            }
            // Detached no-wait launches own activation readiness until their
            // status becomes terminal. A running OCI container can still be
            // only partially initialized during that window, so recurring
            // liveness must not race activation and restart it underneath the
            // no-wait worker.
            if (shouldDeferNoWaitRestart(monitor, target)) {
                stopProbeWorker(target);
                continue;
            }
            if (target.mpsPending) {
                stopProbeWorker(target);
                scheduleContainerRestart(monitor, target, 'mps_generation_changed');
                continue;
            }
            const continuousProbeIntervalMs = positiveInteger(
                monitor?.config?.CONTINUOUS_PROBE_INTERVAL_MS
                    ?? process.env.PLOINKY_CONTAINER_MONITOR_CONTINUOUS_PROBE_INTERVAL_MS,
                DEFAULT_CONTINUOUS_PROBE_INTERVAL_MS,
            );
            if (target.probeState === 'success'
                && (!target.probeLastSuccessAt
                    || now - target.probeLastSuccessAt >= continuousProbeIntervalMs)) {
                target.probeState = 'pending';
            }
            const startWorker = monitor.startProbeWorker || startProbeWorker;
            startWorker(monitor, target);
            continue;
        }

        if (target.probeState === 'running') {
            continue;
        }

        if (shouldDeferNoWaitRestart(monitor, target)) {
            continue;
        }

        stopProbeWorker(target);
        scheduleContainerRestart(monitor, target, target.mpsPending ? 'mps_generation_changed' : 'not_running');
    }
}

export function createContainerMonitor({ config, log, isShuttingDown, terminalLedgerFile: ledgerFile, readMpsStatus: observeMps, readAppliedObservation: observeApplied } = {}) {
    const monitor = {
        config: config || {},
        log,
        isShuttingDown: typeof isShuttingDown === 'function' ? isShuttingDown : () => false,
        targets: new Map(),
        ...(observeMps ? { readMpsStatus: observeMps } : {}),
        ...(observeApplied ? { readAppliedObservation: observeApplied } : {}),
        timer: null,
        runtimeSnapshotFailures: 0,
        runtimeSnapshotRetryNotBefore: 0,
        runtimeSnapshot: null,
        runtimeSnapshotTakenAt: 0,
        runtimeSnapshotFreshForTick: false,
        ...(ledgerFile ? { terminalLedgerFile: ledgerFile } : {}),
        terminalLedger: null,
    };
    monitor.terminalLedger = loadTerminalLedger(monitor);
    return monitor;
}

export function startContainerMonitor(monitor) {
    if (!monitor || monitor.timer) return;
    if (monitor.isShuttingDown()) return;

    syncManagedContainers(monitor);
    monitorTick(monitor);

    const interval = monitor?.config?.CONTAINER_CHECK_INTERVAL_MS ?? 5000;
    monitor.timer = setInterval(() => {
        try {
            monitorTick(monitor);
        } catch (error) {
            logEvent(monitor, 'error', 'container_monitor_tick_error', { error: error?.message || error });
        }
    }, interval);

    logEvent(monitor, 'info', 'container_monitor_started', { intervalMs: interval });
}

export function stopContainerMonitor(monitor) {
    if (!monitor) return;
    if (monitor.timer) {
        clearInterval(monitor.timer);
        monitor.timer = null;
    }
    for (const target of monitor.targets.values()) {
        if (target?.pendingRestartTimer) {
            clearTimeout(target.pendingRestartTimer);
            target.pendingRestartTimer = null;
        }
        target.isRestarting = false;
        stopProbeWorker(target);
    }
    logEvent(monitor, 'info', 'container_monitor_stopped', {
        tracked: monitor.targets.size
    });
}

export function clearContainerTargets(monitor) {
    if (!monitor) return;
    stopContainerMonitor(monitor);
    monitor.targets.clear();
    monitor.runtimeSnapshot = null;
    monitor.runtimeSnapshotTakenAt = 0;
    monitor.runtimeSnapshotFreshForTick = false;
}

export const __testables = Object.freeze({
    classifyTerminalFailure,
});
