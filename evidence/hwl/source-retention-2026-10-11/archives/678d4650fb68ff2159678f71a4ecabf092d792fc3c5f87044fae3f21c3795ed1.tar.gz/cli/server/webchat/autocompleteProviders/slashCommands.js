const ACHILLES_COMMAND_CATALOG_TOOL = 'list_achilles_cli_commands';
const MCP_ACCEPT = 'application/json, text/event-stream';
const BROWSER_CSRF_HEADER = 'x-ploinky-browser-csrf-token';
const BROWSER_MUTATION_RETRY_ERRORS = new Set([
    'browser_csrf_invalid',
    'edge_generation_changed',
]);
const browserMutationProofs = new Map();
const INITIAL_CATALOG_RETRY_DELAYS_MS = Object.freeze([
    250,
    500,
    1000,
    ...Array(14).fill(2000),
]);

function waitForRetry(delayMs) {
    return new Promise((resolve) => setTimeout(resolve, delayMs));
}

function catalogLoadError(message, { retryable = true } = {}) {
    const error = new Error(message);
    error.retryable = retryable;
    return error;
}

function responseIsAccessDenied(response, body = null) {
    return response?.status === 401
        || response?.status === 403
        || response?.redirected === true
        || /\/auth\/login(?:[/?#]|$)/.test(String(response?.url || ''))
        || body?.error?.code === -32003;
}

function responseFailure(stage, response, body = null) {
    return catalogLoadError(`Slash command catalog ${stage} failed.`, {
        retryable: !responseIsAccessDenied(response, body),
    });
}

function findCommandSlash(value) {
    return String(value || '').startsWith('/') ? 0 : -1;
}

function buildMcpHeaders(sessionId = null) {
    return {
        'Content-Type': 'application/json',
        Accept: MCP_ACCEPT,
        ...(sessionId ? { 'mcp-session-id': sessionId } : {})
    };
}

async function loadBrowserMutationProof(agentName, { refresh = false } = {}) {
    const routeKey = String(agentName || '').trim();
    if (!routeKey) throw new Error('agent route key is required');
    if (!refresh && browserMutationProofs.has(routeKey)) {
        return browserMutationProofs.get(routeKey);
    }
    const proofUrl = new URL('/auth/token', globalThis.location?.href || globalThis.location?.origin);
    proofUrl.searchParams.set('mutationRoute', routeKey);
    const response = await fetch(proofUrl.toString(), {
        method: 'GET',
        credentials: 'include',
        cache: 'no-store',
        headers: { accept: 'application/json' },
    });
    const payload = await response.json().catch(() => ({}));
    const proof = payload?.browserMutation;
    if (!response.ok
        || !proof?.csrfToken
        || proof.routeKey !== routeKey
        || proof.origin !== globalThis.location?.origin) {
        throw new Error(`browser mutation proof unavailable for ${routeKey}`);
    }
    browserMutationProofs.set(routeKey, proof.csrfToken);
    return proof.csrfToken;
}

async function fetchAgentMcp(agentName, endpoint, options = {}) {
    const request = async (refreshProof = false) => {
        const csrfToken = await loadBrowserMutationProof(agentName, { refresh: refreshProof });
        const headers = new Headers(options.headers || {});
        headers.set(BROWSER_CSRF_HEADER, csrfToken);
        return fetch(endpoint, {
            ...options,
            headers,
            credentials: 'include',
        });
    };
    let response = await request(false);
    if ([403, 503].includes(response.status)) {
        const payload = await response.clone().json().catch(() => null);
        if (BROWSER_MUTATION_RETRY_ERRORS.has(String(payload?.error || '').toLowerCase())) {
            browserMutationProofs.delete(String(agentName || '').trim());
            response = await request(true);
        }
    }
    return response;
}

export function applySlashSelectionToValue(value, cmd) {
    const inputValue = typeof value === 'string' ? value : '';
    const slashIdx = findCommandSlash(inputValue);
    if (slashIdx === -1 || !cmd) {
        return null;
    }

    const afterSlash = inputValue.slice(slashIdx + 1);
    const spaceIdx = afterSlash.indexOf(' ');
    const hasSubToken = spaceIdx !== -1;

    let insertText;
    if (hasSubToken && cmd.subCommands && cmd.subCommands.length) {
        const cmdName = cmd.name.replace('/', '');
        const subToken = afterSlash.slice(spaceIdx + 1).trim().toLowerCase();
        const matchingSub = cmd.subCommands.find((sub) =>
            getSubCommandName(sub).toLowerCase().includes(subToken)
        ) || cmd.subCommands[0];
        insertText = `/${cmdName} ${getSubCommandName(matchingSub)} `;
    } else {
        insertText = cmd.name + ' ';
    }

    const replaceEnd = slashIdx + 1 + afterSlash.length;
    const nextValue = inputValue.slice(0, slashIdx) + insertText + (hasSubToken ? '' : inputValue.slice(replaceEnd));
    return {
        value: nextValue,
        cursor: slashIdx + insertText.length
    };
}

function getSubCommandName(subCommand) {
    if (typeof subCommand === 'string') {
        return subCommand.trim();
    }
    if (subCommand && typeof subCommand.name === 'string') {
        return subCommand.name.trim();
    }
    return '';
}

export function applySlashInsertTextToValue(value, insertText) {
    const inputValue = typeof value === 'string' ? value : '';
    const safeInsertText = typeof insertText === 'string' ? insertText : '';
    const slashIdx = findCommandSlash(inputValue);
    if (slashIdx === -1 || !safeInsertText) {
        return null;
    }

    const afterSlash = inputValue.slice(slashIdx + 1);
    const replaceEnd = slashIdx + 1 + afterSlash.length;
    return {
        value: inputValue.slice(0, slashIdx) + safeInsertText + inputValue.slice(replaceEnd),
        cursor: slashIdx + safeInsertText.length
    };
}

function buildCatalogArguments() {
    const query = globalThis.document?.body?.dataset?.agentQuery || '';
    const args = {};
    try {
        const params = new URLSearchParams(query);
        const dir = params.get('dir') || globalThis.document?.body?.dataset?.workdir || '';
        if (dir) {
            args.dir = dir;
        }
    } catch (_) {
        // Ignore malformed query strings; catalog tools should remain optional.
    }
    return args;
}

function normalizeArgCompletions(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return value
        .map((entry) => {
            if (typeof entry === 'string') {
                const text = entry.trim();
                return text ? { value: text, label: text, description: '' } : null;
            }
            if (!entry || typeof entry !== 'object') {
                return null;
            }
            const rawValue = typeof entry.value === 'string'
                ? entry.value.trim()
                : (typeof entry.name === 'string' ? entry.name.trim() : '');
            if (!rawValue) {
                return null;
            }
            return {
                value: rawValue,
                label: typeof entry.label === 'string' && entry.label.trim() ? entry.label.trim() : rawValue,
                description: typeof entry.description === 'string' ? entry.description : ''
            };
        })
        .filter(Boolean);
}

function normalizeSubCommands(value) {
    if (!Array.isArray(value)) {
        return [];
    }
    return value
        .map((subCommand) => {
            const name = getSubCommandName(subCommand);
            if (!name) {
                return null;
            }
            if (typeof subCommand === 'string') {
                return {
                    name,
                    description: '',
                    argCompletions: []
                };
            }
            return {
                name,
                description: typeof subCommand.description === 'string' ? subCommand.description : '',
                argCompletions: normalizeArgCompletions(subCommand.argCompletions)
            };
        })
        .filter(Boolean);
}

function getFirstToken(value) {
    return String(value || '').trim().split(/\s+/)[0] || '';
}

function getRemainingAfterFirstToken(value) {
    const text = String(value || '');
    const match = text.match(/^\s*\S+\s+(.*)$/);
    return match ? match[1] : '';
}

function isCompletedKnownToken(rawToken, completions) {
    const text = String(rawToken || '');
    if (!/\s$/.test(text)) return false;
    const token = text.trim().toLowerCase();
    if (!token) return false;
    return normalizeArgCompletions(completions).some((completion) =>
        completion.value.toLowerCase() === token
        || completion.label.toLowerCase() === token
    );
}

function appendArgCompletionSuggestions(suggestions, { cmdName, cmd, argCompletions, argToken, prefixText = '' }) {
    const normalizedArgToken = String(argToken || '').trim().toLowerCase();
    const allowFragmentSearch = cmd.argMatchMode === 'fragment';
    const configuredLimit = Number(cmd.argSuggestionLimit);
    const suggestionLimit = Number.isInteger(configuredLimit) && configuredLimit > 0
        ? configuredLimit
        : null;
    const matchScore = (completion) => {
        if (!normalizedArgToken) return 0;
        const values = [completion.value, completion.label, completion.description]
            .map((value) => String(value || '').toLowerCase());
        if (values.some((value) => value === normalizedArgToken)) return 0;
        if (values.slice(0, 2).some((value) => value.startsWith(normalizedArgToken))) return 1;
        if (!allowFragmentSearch) return null;
        if (values.some((value) => value.split(/[^a-z0-9]+/).some((part) => part.startsWith(normalizedArgToken)))) return 2;
        if (values.some((value) => value.includes(normalizedArgToken))) return 3;
        return null;
    };
    const rankedArgs = argCompletions
        .map((completion, index) => ({ completion, index, score: matchScore(completion) }))
        .filter((entry) => entry.score !== null)
        .sort((left, right) => left.score - right.score || left.index - right.index);
    const matchingArgs = (suggestionLimit ? rankedArgs.slice(0, suggestionLimit) : rankedArgs)
        .map((entry) => entry.completion);
    for (const completion of matchingArgs) {
        suggestions.push({
            label: `/${cmdName} ${prefixText}${completion.label}`,
            description: completion.description || cmd.description || '',
            command: cmd,
            insertText: `/${cmdName} ${prefixText}${completion.value} `,
            keepMenuOpen: false
        });
    }
}

function extractSubCommands(tool) {
    const subs = [];
    const schema = tool.inputSchema;
    if (!schema || !schema.properties) return subs;

    const props = Object.keys(schema.properties);
    if (props.length <= 2) return subs;

    for (const prop of props) {
        if (!['input', 'prompt', 'text', 'message', 'query'].includes(prop.toLowerCase())) {
            subs.push(prop);
        }
    }
    return subs.slice(0, 6);
}

export function buildSuggestions(commands, {
    currentToken,
    hasSubToken,
    subToken
}) {
    const normalizedToken = currentToken.trim().toLowerCase();
    const suggestions = [];

    for (const cmd of commands) {
        const suggestionCountBeforeCommand = suggestions.length;
        const cmdName = cmd.name.replace('/', '');
        const normalizedCmdName = cmdName.toLowerCase();
        const subCommands = normalizeSubCommands(cmd.subCommands);
        const argCompletions = normalizeArgCompletions(cmd.argCompletions);

        if (hasSubToken && normalizedCmdName.startsWith(normalizedToken)) {
            const rawSubToken = String(subToken || '');
            const firstSubToken = getFirstToken(rawSubToken).toLowerCase();
            const matchedSub = firstSubToken
                ? subCommands.find((sub) => sub.name.toLowerCase() === firstSubToken)
                : null;
            const isAfterMatchedSub = Boolean(matchedSub)
                && (/\s$/.test(rawSubToken) || getRemainingAfterFirstToken(rawSubToken).length > 0);

            if (isAfterMatchedSub && matchedSub.argCompletions.length > 0) {
                appendArgCompletionSuggestions(suggestions, {
                    cmdName,
                    cmd,
                    argCompletions: matchedSub.argCompletions,
                    argToken: getRemainingAfterFirstToken(rawSubToken),
                    prefixText: `${matchedSub.name} `
                });
                continue;
            }
            if (isAfterMatchedSub) {
                continue;
            }

            if (subCommands.length > 0 && !isAfterMatchedSub) {
                const normalizedSubToken = rawSubToken.trim().toLowerCase();
                const matchingSubs = subCommands.filter((sub) =>
                    sub.name.toLowerCase().includes(normalizedSubToken)
                );
                for (const sub of matchingSubs) {
                    suggestions.push({
                        label: `/${cmdName} ${sub.name}`,
                        description: sub.description || cmd.description || '',
                        command: {
                            ...cmd,
                            subCommands: [sub]
                        },
                        insertText: `/${cmdName} ${sub.name} `,
                        keepMenuOpen: sub.argCompletions.length > 0
                    });
                }
            }

            const isCompletingFirstArg = !rawSubToken.trim().includes(' ')
                && !isCompletedKnownToken(rawSubToken, argCompletions);
            if (argCompletions.length > 0 && isCompletingFirstArg) {
                appendArgCompletionSuggestions(suggestions, {
                    cmdName,
                    cmd,
                    argCompletions,
                    argToken: rawSubToken
                });
            }

            continue;
        }

        if (normalizedCmdName.includes(normalizedToken)) {
            suggestions.push({
                label: cmd.name,
                description: cmd.description || '',
                command: cmd,
                insertText: `${cmd.name} `,
                keepMenuOpen: subCommands.length > 0 || argCompletions.length > 0
            });
        }
    }

    return suggestions;
}

async function callMcpInitialize(agentName, mcpEndpoint) {
    const initRes = await fetchAgentMcp(agentName, mcpEndpoint, {
        method: 'POST',
        headers: buildMcpHeaders(),
        body: JSON.stringify({
            jsonrpc: '2.0',
            id: 'wc-init-1',
            method: 'initialize',
            params: {
                protocolVersion: '2024-11-05',
                capabilities: {},
                clientInfo: { name: 'webchat', version: '1.0.0' }
            }
        })
    });
    if (!initRes.ok) throw responseFailure('initialization', initRes);
    const initBody = await initRes.json().catch(() => null);
    if (!initBody || !initBody.result) throw responseFailure('initialization', initRes, initBody);
    const sessionId = initRes.headers.get('mcp-session-id') || initBody.result?.meta?.sessionId;
    const initializedRes = await fetchAgentMcp(agentName, mcpEndpoint, {
        method: 'POST',
        headers: buildMcpHeaders(sessionId),
        body: JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' })
    });
    if (!initializedRes.ok) throw responseFailure('acknowledgement', initializedRes);
    return sessionId;
}

async function fetchStructuredCatalog(agentName, mcpEndpoint, sessionId, tools, catalogArguments = {}) {
    const catalogTool = tools.find((tool) => tool?.name === ACHILLES_COMMAND_CATALOG_TOOL);
    if (!catalogTool) return [];
    // Forward only declared string selectors, never arbitrary URL parameters.
    const schema = catalogTool.inputSchema?.properties || catalogTool.inputSchema || {};
    if (!schema.sessionId) delete catalogArguments.sessionId;
    const query = new URLSearchParams(globalThis.document?.body?.dataset?.agentQuery || '');
    for (const [key, definition] of Object.entries(schema)) {
        if (key !== 'dir' && !Object.hasOwn(catalogArguments, key) && definition?.type === 'string' && query.has(key)) {
            catalogArguments[key] = query.get(key);
        }
    }

    const callRes = await fetchAgentMcp(agentName, mcpEndpoint, {
        method: 'POST',
        headers: buildMcpHeaders(sessionId),
        body: JSON.stringify({
            jsonrpc: '2.0',
            id: 'wc-tool-call-commands-1',
            method: 'tools/call',
            params: {
                name: catalogTool.name,
                arguments: catalogArguments && typeof catalogArguments === 'object' ? catalogArguments : {}
            }
        })
    });
    if (!callRes.ok) throw responseFailure('tool call', callRes);
    const callBody = await callRes.json().catch(() => null);
    if (callBody?.error) throw responseFailure('tool call', callRes, callBody);
    const content = callBody?.result?.content || callBody?.result?.result?.content;
    if (!Array.isArray(content)) throw responseFailure('tool response', callRes, callBody);

    const textPart = content.find((entry) => entry?.type === 'text' && typeof entry.text === 'string');
    if (!textPart) throw responseFailure('tool response', callRes, callBody);

    const parsed = JSON.parse(textPart.text);
    if (!parsed || parsed.type !== 'achilles-slash-command-catalog' || !Array.isArray(parsed.commands)) {
        return [];
    }

    return parsed.commands
        .map((command) => {
            const rawName = typeof command?.name === 'string' ? command.name.trim() : '';
            if (!rawName) return null;
            const normalizedName = rawName.startsWith('/') ? rawName : `/${rawName}`;
            const subCommands = Array.isArray(command.subCommands)
                ? command.subCommands
                    .map((subCommand) => {
                        const name = getSubCommandName(subCommand);
                        if (!name) return null;
                        if (typeof subCommand === 'string') {
                            return name;
                        }
                        return {
                            name,
                            description: typeof subCommand.description === 'string' ? subCommand.description : '',
                            argCompletions: normalizeArgCompletions(subCommand.argCompletions)
                        };
                    })
                    .filter(Boolean)
                : [];
            const argCompletions = normalizeArgCompletions(command.argCompletions);
            return {
                name: normalizedName,
                catalogWarning: normalizedName === '/model' && parsed.modelError ? String(parsed.modelError) : '',
                description: typeof command.description === 'string' ? command.description : '',
                argMatchMode: command.argMatchMode === 'fragment' ? 'fragment' : 'prefix',
                argSuggestionLimit: Number.isInteger(Number(command.argSuggestionLimit))
                    && Number(command.argSuggestionLimit) > 0
                    ? Number(command.argSuggestionLimit)
                    : null,
                subCommands,
                argCompletions
            };
        })
        .filter(Boolean);
}

async function fetchCommandsFromAgent(agentName, dlog, extraArguments = {}) {
    if (!agentName) return [];
    const mcpEndpoint = `/${agentName}/mcp`;
    const sessionId = await callMcpInitialize(agentName, mcpEndpoint);

    const toolsRes = await fetchAgentMcp(agentName, mcpEndpoint, {
        method: 'POST',
        headers: buildMcpHeaders(sessionId),
        body: JSON.stringify({ jsonrpc: '2.0', id: 'wc-tools-1', method: 'tools/list' })
    });
    if (!toolsRes.ok) throw responseFailure('tool listing', toolsRes);

    const toolsBody = await toolsRes.json().catch(() => null);
    if (!toolsBody || !toolsBody.result || !Array.isArray(toolsBody.result.tools)) {
        throw responseFailure('tool listing', toolsRes, toolsBody);
    }

    const tools = toolsBody.result.tools;
    let structuredCatalogError = null;
    try {
        const structured = await fetchStructuredCatalog(
            agentName,
            mcpEndpoint,
            sessionId,
            tools,
            { ...buildCatalogArguments(), ...extraArguments },
        );
        if (structured.length > 0) {
            return structured.sort((a, b) => a.name.localeCompare(b.name));
        }
    } catch (err) {
        structuredCatalogError = err;
        dlog?.('SlashCommandsProvider: structured catalog parse failed, falling back', err?.message || err);
    }

    const fallback = [];
    for (const tool of tools) {
        const toolName = tool.name || '';
        if (!toolName.startsWith('execute_')) continue;
        const skillName = toolName.replace('execute_', '').replace(/_/g, '-');
        fallback.push({
            name: `/${skillName}`,
            description: tool.description || '',
            inputSchema: tool.inputSchema || null,
            subCommands: extractSubCommands(tool)
        });
    }
    if (fallback.length === 0 && structuredCatalogError) throw structuredCatalogError;
    return fallback.sort((a, b) => a.name.localeCompare(b.name));
}

export async function loadSlashCommandsWithRetry(loadCommands, {
    retryDelays = INITIAL_CATALOG_RETRY_DELAYS_MS,
    wait = waitForRetry,
    dlog,
} = {}) {
    const delays = Array.isArray(retryDelays) ? retryDelays : [];
    for (let attempt = 0; ; attempt += 1) {
        try {
            return await loadCommands();
        } catch (error) {
            const retryable = error?.retryable !== false;
            if (!retryable || attempt >= delays.length) {
                dlog?.('SlashCommandsProvider: catalog loading stopped', error?.message || error);
                return [];
            }
            const delayMs = Math.max(0, Number(delays[attempt]) || 0);
            dlog?.('SlashCommandsProvider: catalog not ready; retrying', {
                attempt: attempt + 1,
                delayMs,
            });
            await wait(delayMs);
        }
    }
}

export function createSlashCommandsProvider({
    agentName,
    dlog,
    retryDelays = INITIAL_CATALOG_RETRY_DELAYS_MS,
    wait = waitForRetry,
    getCatalogArguments = () => ({}),
} = {}) {
    let commands = [];
    let refreshPromise = null;
    let refreshKey = '';

    function detectTrigger(value, caretIndex) {
        const inputValue = typeof value === 'string' ? value : '';
        const slashIdx = findCommandSlash(inputValue);
        if (slashIdx === -1) return null;
        const afterSlash = inputValue.slice(slashIdx + 1, caretIndex);
        if (afterSlash.includes(' ') === false && /\s/.test(afterSlash)) {
            return null;
        }
        return { triggerIndex: slashIdx, token: afterSlash };
    }

    function getSuggestions(value, caretIndex) {
        const inputValue = typeof value === 'string' ? value : '';
        const slashIdx = findCommandSlash(inputValue);
        if (slashIdx === -1) return [];
        const afterSlash = inputValue.slice(slashIdx + 1);
        const firstChar = afterSlash.charAt(0);
        if (firstChar === ' ' || firstChar === '\n') return [];
        const spaceIdx = afterSlash.indexOf(' ');
        const currentToken = spaceIdx === -1 ? afterSlash : afterSlash.slice(0, spaceIdx);
        const hasSubToken = spaceIdx !== -1;
        const subToken = hasSubToken ? afterSlash.slice(spaceIdx + 1) : '';
        if (refreshPromise && hasSubToken) return [{ trigger: '/', group: 'Commands',
            loading: true, label: 'Loading options…', loadingLabel: 'Loading options…' }];
        const warning = commands.find((entry) => entry.name === `/${currentToken}`)?.catalogWarning;
        if (warning && hasSubToken) return [{ trigger: '/', group: 'Commands', loading: true,
            label: `Unable to load models: ${warning}`, loadingLabel: `Unable to load models: ${warning}` }];

        return buildSuggestions(commands, { currentToken, hasSubToken, subToken })
            .map((suggestion) => ({
                ...suggestion,
                trigger: '/',
                group: 'Commands'
            }));
    }

    function applySelection(value, suggestion) {
        if (!suggestion) return null;
        if (suggestion.insertText) {
            return applySlashInsertTextToValue(value, suggestion.insertText);
        }
        if (suggestion.command) {
            return applySlashSelectionToValue(value, suggestion.command);
        }
        return null;
    }

    function refresh() {
        const args = getCatalogArguments();
        const key = JSON.stringify(args);
        if (refreshPromise && refreshKey === key) return refreshPromise;
        refreshKey = key;
        commands = [];
        const pending = loadSlashCommandsWithRetry(
            () => fetchCommandsFromAgent(agentName, dlog, args),
            { retryDelays, wait, dlog },
        ).then((loadedCommands) => {
            if (refreshPromise !== pending) return commands;
            commands = loadedCommands;
            dlog?.('SlashCommandsProvider: loaded', commands.length, 'commands');
            return commands;
        }).finally(() => {
            if (refreshPromise === pending) refreshPromise = null;
        });
        refreshPromise = pending;
        return refreshPromise;
    }

    return {
        trigger: '/',
        groupLabel: 'Commands',
        detectTrigger,
        getSuggestions,
        applySelection,
        refresh
    };
}
